#params used in package.json and powershell
param([string] $env,[string] $namespace, [string] $uiRepo, [switch] $u, [switch] $a, [switch] $ns)

#params used in only powershell
$values = Get-Content .k8s/vars.txt | Out-String | ConvertFrom-StringData

#Create Credentials Path delete or edit if you need to change credentials
if(!(Test-Path -Path $values.credPath )){
    New-Item -ItemType directory -Path $values.credPath
    Write-Host "New Credentials folder created"
}

#Create Tmp directory for local ymls
if(!(Test-Path -Path $values.tmpPath )){
    New-Item -ItemType directory -Path $values.tmpPath
    Write-Host "New Temp folder created"
}

#Get Credentials if none exist and save them
if(!(Test-Path -Path "$($values.credPath)/user.txt" )){
    $user = Read-Host 'What is your username?'
    Set-Content -Path "$($values.credPath)/user.txt" -Value $user
}
else {
  $user = Get-Content "$($values.credPath)/user.txt"
}
if(!(Test-Path -Path "$($values.credPath)/pass.txt" )){
    $pass = Read-Host 'What is your password?'
    Set-Content -Path "$($values.credPath)/pass.txt" -Value $pass
}
else {
  $pass = Get-Content "$($values.credPath)/pass.txt"
}

#Environment Specific Variables
switch ($env) {
   "prd" {
            $apiSpringProfile = $values.apiSpringProfilePrd;
            $proxyProvider = $values.proxyProviderPrd;
            $proxyClientId = $values.proxyClientIdPrd;
            $proxyClientSecret = $values.proxyClientSecretPrd;
          }
   "tst" {
           $apiSpringProfile = $values.apiSpringProfileTst;
           $proxyProvider = $values.proxyProviderTst;
           $proxyClientId = $values.proxyClientIdTst;
           $proxyClientSecret = $values.proxyClientSecretTst;
         }
   default{
           $apiSpringProfile = $values.apiSpringProfileDev;
           $proxyProvider = $values.proxyProviderDev;
           $proxyClientId = $values.proxyClientIdDev;
           $proxyClientSecret = $values.proxyClientSecretDev;
           }
}

#if u true create ui yml
If ($u) {
  Write-Host "Building Local Manifest"
  $uiRepoDash=$uiRepo.replace("_","-")
  Copy-Item manifest.yml "$($values.tmpPath)/manifest.yml"
  (Get-Content "$($values.tmpPath)/manifest.yml") |
  Foreach-Object {
     $_ -replace '!{dns}!.jbhunt.com',  $values.ingressHost `
        -replace '!{namespace}!',             $namespace  `
        -replace '#{DockerRepo}#',            $values.dockRepo `
        -replace '#{LowerCaseRepoNameDash}#', $uiRepoDash `
        -replace '#{LowerCaseRepoName}#',     $uiRepo `
        -replace '#{Build.BuildId}#',         $values.uiRepoTag `
        -replace '!{Oauth2ProxyRepoName}!',   $values.proxyRepo `
        -replace '!{Oauth2ProxyTag}!',        $values.proxyRepoTag`
        -replace '!{cookieDomain}!',          $values.proxyCookieDomain `
        -replace '!{cookieSecret}!',          $values.proxyCookieSecret `
        -replace '!{upstream}!',              $values.proxyUpstream `
        -replace '!{callback}!',              $values.proxyCallback `
        -replace '!{provider}!',              $proxyProvider `
        -replace '!{clientID}!',              $proxyClientId `
        -replace '!{clientSecret}!',          $proxyClientSecret

  } |
  Set-Content "$($values.tmpPath)/manifest.yml"
  Write-Host "Done Building Local Manifest"
}

#if a true create api yml
If ($a) {
  Write-Host "Building Local Api"

  $apiRepoDash=$values.apiRepo.replace("_","-")
  Copy-Item .k8s/api.yml "$($values.tmpPath)/api.yml"
  (Get-Content "$($values.tmpPath)/api.yml") |
  Foreach-Object {
     $_ -replace '!{namespace}!',             $namespace `
        -replace '#{DockerRepo}#',            $values.dockRepo `
        -replace '#{LowerCaseRepoNameDash}#', $apiRepoDash `
        -replace '#{ApiProxyRepoName}#',      $values.apiRepo `
        -replace '#{ApiProxyRepoTag}#',       $values.apiTag `
        `
        -replace '#{Pass}#',                  $pass `
        -replace '#{User}#',                  $user `
        -replace '!{SpringProfile}!',         $apiSpringProfile

  } |
  Set-Content "$($values.tmpPath)/api.yml"
  Write-Host "Done Building Local Api"
}

#if ns true create namespace yml
If ($ns) {
  Write-Host "Building Local Namespace"
  Copy-Item .k8s/namespace.yml "$($values.tmpPath)/namespace.yml"
  (Get-Content "$($values.tmpPath)/namespace.yml") |
  Foreach-Object {
     $_ -replace '!{namespace}!',             $namespace
  } |
  Set-Content "$($values.tmpPath)/namespace.yml"
  Write-Host "Done Building Local Namespace"
}
