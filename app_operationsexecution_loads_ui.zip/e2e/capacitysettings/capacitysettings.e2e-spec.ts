import { CapacitySettingsPage } from './capacitysettings.po';

describe('app-operationsexecution-loads CapacitySettings', () => {
    let page: CapacitySettingsPage;

    beforeEach(() => {
        page = new CapacitySettingsPage();
    });

    it('should display header Capacity Settings', () => {
        page.navigateTo();
        expect(page.getHeaderText()).toEqual('CAPACITY SETTINGS');
    });

    it('should display tab header JBI Inbound Limits', () => {
        page.navigateTo();
        expect(page.getJBITabText()).toEqual('JBI Inbound Limits');
    });

    it('should display  JBI Tab DropDown Value', () => {
        page.navigateTo();
        expect(page.getJBITabDropDownText()).toEqual('Inbound Area Limits');
    });

});
