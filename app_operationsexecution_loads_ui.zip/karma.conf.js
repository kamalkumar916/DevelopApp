// Karma configuration file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html

// TFS Intergration
// https://isaacmartinezblog.wordpress.com/2018/04/02/angular-code-coverage-in-sonar-qube-and-vsts/

// ChromeHeadless from Puppeteer
// https://github.com/karma-runner/karma-chrome-launcher

// Set Env for ChromeHeadless from puppeteer
process.env.CHROME_BIN = require('puppeteer').executablePath();
module.exports = function(config) {
  config.set({
    basePath: '',
    frameworks: ['parallel', 'jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-spec-reporter'),
      require('karma-verbose-reporter'),
      require('karma-parallel'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage-istanbul-reporter'),
      require('karma-junit-reporter'),
      require('@angular-devkit/build-angular/plugins/karma'),
      require('karma-phantomjs-launcher'),
      require('puppeteer')
    ],
    parallelOptions: {
      executors: 4,
      shardStrategy: 'round-robin'
    },
    client: {
      clearContext: false, // leave Jasmine Spec Runner output visible in browser
      jasmine: {
        random: false
      }
    },

    files: [],
    preprocessors: {},
    mime: {
      'text/x-typescript': ['ts', 'tsx']
    },
    junitReporter: {
      outputDir: 'coverage', // results will be saved as $outputDir/$browserName.xml
      useBrowserName: false, // add browser name to report and classes names
      outputFile: 'report.xml' // if included, results will be saved as $outputDir/$browserName/$outputFile
    },
    coverageIstanbulReporter: {
      dir: require('path').join(__dirname, 'coverage'),
      // reports: ['html', 'lcovonly', 'text-summary'],	  
      reports: ['html', 'lcov', 'cobertura'],
      fixWebpackSourcePaths: true
    },
    reporters:
      config.angularCli && config.angularCli.codeCoverage
        ? ['progress', 'coverage-istanbul', 'junit']
        : ['progress', 'kjhtml', 'junit'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: ['Chrome_without_security'],
						 
    // you can define custom flags
    customLaunchers: {
      Chrome_without_security: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox']
      }
    },
    singleRun: false,
							  
    captureTimeout: 2100000,
    browserDisconnectTimeout: 210000,
    browserDisconnectTolerance: 3,
    browserNoActivityTimeout: 2100000
  });
};
