# Break Up The Loads Tile

## Status

Pending

## Context and Problem Statement

The load tile contains a lot of functionality and we are investigating whether it makes sense to break it up into multiple tiles.

## Considered Options

* One tile. Loads
* Two tiles.  Capacity and Loads
* Three tiles. Capacity, (Load) Planning and (Load) Execution
<!--
## Decision

TBD

## Assumptions

* Rail rates are not structurally different than other rates with the exception of splits.

##Constraints

* None
-->
## Positions

* Tiles are based on personnas.  There is one personna for loads, Olivia.  So, there should be one tile, Loads.
  * Personnas can represent multiple roles.  For example, a football player personna could represent quarter backs and line backers.
  * Olivia represents capacity managers, load planners and fleet managers.
* The loads tile and the Olivia personna are overloaded.  Should split into three tiles.  Capacity, Planning and Execution.
  * Based on user population, a large percentage of people may be lumped into this one personna.
    * Capacity Managers
    * Load Planners
    * Fleet Managers
  * Based on the as-is code base, a large percentage of functionality and code may get lumped into this one tile.
* Capacity is the outlier and should be broken off from loads.
  * There was general agreement that capacity was the most different of the three.
  * Some thought that capacity management and yard management could be merged.
  * Others thought that capacity management was different than yard management.
  
## Action Items

* UX will research whether the Olivia personna can/should be split using their methodology.
* EA will schedule a working session with UX and SMEs to do knowledge transfer on edge cases and the conceptual design.

<!--
## Arguement

Chosen option: TBD

* Point One
* Point Two

## Consequences

* Workflow
* Team assignments
-->