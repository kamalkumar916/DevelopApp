import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { LocalStorageService } from '../../shared/jbh-app-services/local-storage.service';
import { UserService } from '../../shared/jbh-esa';

import { AsideNavComponent } from './nav/aside-nav.component';
import { AsideComponent } from './aside.component';

describe('AsideComponent', () => {
    let component: AsideComponent;
    let fixture: ComponentFixture<AsideComponent>;

    configureTestSuite(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, HttpClientTestingModule],
            declarations: [AsideComponent, AsideNavComponent],
            providers: [LocalStorageService, UserService]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(AsideComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('onToggleAppDrawer to be checked', () => {
        component.onToggleAppDrawer();
        expect(component.showAppDrawer).toEqual(true);
    });

});
