import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpResponse,
    HttpErrorResponse,
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { tap } from 'rxjs/operators';

import { ErrorHandlerService } from './error-handler.service';
import { MessageService } from 'primeng/components/common/messageservice';


@Injectable()
export class ResponseInterceptor implements HttpInterceptor {

    constructor(private readonly errorHandlerService: ErrorHandlerService) { }

    intercept(
        request: HttpRequest<any>,
        next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(
            tap(() => { }, (response) => {
                if (response instanceof HttpErrorResponse && [401, 503].includes(response.status)) {
                    this.errorHandlerService.handleErrors(response.error, response.status);
                    return;
                }
                return throwError(response);
            }));
    }
}
