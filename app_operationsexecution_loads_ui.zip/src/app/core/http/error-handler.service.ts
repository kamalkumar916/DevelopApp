import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { MessageService } from 'primeng/components/common/messageservice';

@Injectable()
export class ErrorHandlerService {

    private readonly errors = new Subject<string[]>();

    private readonly defaultErrorText = `A network connection problem occurred.
     In your browser, refresh the page or wait a little while to try again.
     If the issue continues, contact the Service Desk.`;

    constructor(private readonly messageService: MessageService) { }

    private getErrorMessage(statusCode: number): string {
        let detailsDesc = this.defaultErrorText;
        const serviceDeskLink = `<a href='javascript:void(0)' class='service-desk-link'>479-820-4347<br/></a>`;
        const row1 = `<div class='pull-right'><span class='sub-heading'>Service Desk </span>${serviceDeskLink}</div>`;
        const footerRow1 = `<div class='ui-g'><div class='ui-g-offset-5 ui-g-7 ui-g-nopad'>${row1}</div></div>`;
        const footerLeft = `<div class='ui-g-6 ui-g-nopad'>Error ${statusCode} </div>`;
        const helpTicketLink = `<a href='javascript:void(0)' class='create-help-ticket-link'>Create Help Ticket</a>`;
        const footerRight = `<div class='ui-g-6 ui-g-nopad'><div class='pull-right'>${helpTicketLink}</div>`;
        const footerRow2 = `<div class='ui-g'> ${footerLeft} ${footerRight}</div>`;
        const footer = `<div class='growl-footer'>${footerRow1} ${footerRow2}</div>`;
        detailsDesc += footer;
        return detailsDesc;
    }

    private readonly showUnAuthorizedError = (errors: string[]): void => {
        if (errors.length > 0) {
            this.messageService.add({
                severity: 'error',
                summary: `Unauthorized`,
                detail: `Full authentication is required to access this resource`
            });
        }
    }

    handleErrors(errors: any, statusCode: number) {
        switch (statusCode) {
            case 503:
                 this.messageService.clear();
                 this.messageService.add({
                     key: 'stickymsg',
                     severity: 'error',
                     summary: 'Website Not Responding',
                     detail: this.getErrorMessage(statusCode)
                 });
                break;
            case 401:
                this.showUnAuthorizedError(Array.isArray(errors) ? errors : [errors]);
                break;
            default:
                break;
        }
    }

    public getErrors = () =>
        this.errors.asObservable()
}
