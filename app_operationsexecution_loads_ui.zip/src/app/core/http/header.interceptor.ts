import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpResponse } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

import { SpinnerService } from '../../shared/spinner/index';


@Injectable()
export class HeaderInterceptor {

  // constructor(private loader: SpinnerService) { }
  constructor() { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // add a custom header
    let customReq;
    const applicationJSON = 'application/json';
    if (request.headers.get('uploadType') === 'uploadDoc') {
      customReq = request.clone({
        headers: request.headers
          .set('Accept', applicationJSON)
          .set('Cache-Control', 'no-cache')
          .set('Pragma', 'no-cache')
      });
    } else {
      customReq = request.clone({
        headers: request.headers.set('Content-Type', applicationJSON)
          .set('Accept', applicationJSON)
          .set('Cache-Control', 'no-cache')
          .set('Pragma', 'no-cache')
      });
    }
    // pass on the modified request object )
    return next.handle(customReq).pipe(
      tap((event: HttpEvent<any>) => {
        // if the event is for http response
        if (event instanceof HttpResponse) {
          // stop our loader here
          // this.loader.hide();
        }

      }),
      catchError((response: any) => {
        if (response instanceof HttpErrorResponse) {
          // Handle the errors over here
          // console.log('Error: Response in the catch: ', response);
        }
        // stop our loader here
        // this.loader.hide();
        return throwError(response);
      })
    );

    // .do((event: HttpEvent<any>) => {
    //   // if the event is for http response
    //   if (event instanceof HttpResponse) {
    //     // stop our loader here
    //     // this.loader.hide();
    //   }

    // }).catch((response: any) => {
    //   if (response instanceof HttpErrorResponse) {
    //     // Handle the errors over here
    //     // console.log('Error: Response in the catch: ', response);
    //   }
    //   // stop our loader here
    //   // this.loader.hide();
    //   return Observable.throw(response);
    // });

  }
}
