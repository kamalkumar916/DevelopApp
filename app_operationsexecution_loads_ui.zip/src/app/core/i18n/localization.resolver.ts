import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

import { TranslateService } from '@ngx-translate/core';
import { JbhTransLoader } from '../../core/i18n/jbh-trans.loader';

@Injectable()
export class LocalizationResolver implements Resolve<Observable<any>> {

    constructor(private readonly translate: TranslateService) {
    }

    public resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
        const loader: JbhTransLoader = this.translate.currentLoader as JbhTransLoader;
        const lang = this.translate.currentLang;
        const moduleName = (route['routeConfig'].path).replace('/', '');
        let data$;
        data$ = new Observable(observer => {
            if (route['data'] && !route['data']['translationLoaded']) {
                loader.getTranslation(lang, moduleName).subscribe(
                    (data) => {
                        this.translate.setTranslation(lang, data, true);
                    },
                    (err) => {
                    },
                    () => {
                        observer.next('true');
                        observer.complete();
                    }
                );
            } else {
                observer.next('true');
                observer.complete();
            }
        });
        return data$;
    }
}
