import { MissingTranslationHandler, MissingTranslationHandlerParams } from '@ngx-translate/core';

export class JbhMissingTransHandler implements MissingTranslationHandler {
    handle(params: MissingTranslationHandlerParams) {
        return 'NO TRANSLATION';
    }
}
