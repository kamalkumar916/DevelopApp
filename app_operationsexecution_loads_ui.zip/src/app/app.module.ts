import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CoreModule } from './core/core.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { SpinnerComponent, SpinnerService } from './shared/spinner/index';
import { AppSharedDataService } from './shared/jbh-app-services/app-shared-data.service';
import { ShortCutKeyService } from './shared/jbh-app-services/shortcutkey.service';
import { MouseEventService } from './shared/jbh-app-services/mouseevent.service';
import { CanDeactivateGuardService } from './shared/jbh-app-services/can-deactivate-guard.service';
import { LocalStorageService } from './shared/jbh-app-services/local-storage.service';

import { JbhEsaModule, UserService } from './shared/jbh-esa';
import { ErrorPageComponent, ErrorsModule } from './shared/errors/index';
import { PlatformLocation } from '@angular/common';
import { AppConfigService } from './shared/service/app-config.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { DirectivesModule } from './shared/directives/directives.module';
import { JbhSidebarModule } from './features/sidebar/jbh-sidebar.module';

import { DefaultNavigationMenuService, NAV_MENU_SERVICE, NavigationMenuModule } from 'lib-platform-components';

import { MessageService } from 'primeng/components/common/messageservice';
import { GrowlModule } from 'primeng/growl';
import { UnsavedChangesGuard } from './shared/unsaved-changes.guard';
import { PotentialDelayExceptionService } from './features/tracking/potential-delay-exception/services/potential-delay-exception.service';
import { DataTableModule, PaginatorModule } from 'primeng/primeng';


@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CoreModule,
    AppRoutingModule,
    GrowlModule,
    ErrorsModule,
    JbhEsaModule.forRoot(),
    DirectivesModule,
    JbhSidebarModule,
    NavigationMenuModule,
    DataTableModule,
    PaginatorModule,
    ConfirmDialogModule
  ],
  providers: [
    {
      provide: NAV_MENU_SERVICE,
      useClass: DefaultNavigationMenuService
    },
    PotentialDelayExceptionService,
    SpinnerService,
    AppSharedDataService,
    LocalStorageService,
    MessageService,
    ShortCutKeyService,
    MouseEventService,
    AppConfigService,
    UnsavedChangesGuard,
    CanDeactivateGuardService
  ],
  bootstrap: [AppComponent]
})

export class AppModule {
}
