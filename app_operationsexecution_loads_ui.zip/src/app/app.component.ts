import { Component, HostListener, NgZone, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Message } from 'primeng/components/common/api';
import { filter } from 'rxjs/operators';
import { LocalStorageService } from './shared/jbh-app-services/local-storage.service';
import {
  Event as RouterEvent, NavigationCancel, NavigationEnd,
  NavigationError, NavigationStart, Router, Route
} from '@angular/router';
import * as _ from 'lodash';
import { ShortCutKeyService } from './shared/jbh-app-services/shortcutkey.service';
import { UserService } from './shared/jbh-esa';
import { NGXLogger } from 'ngx-logger';
import { NavigationMenuItem } from 'lib-platform-components';
import { StompConnectionService } from './shared/stomp-connection/stomp-connection.service';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';

import { BrowserTitleService } from './shared/jbh-app-services/browser-title.service';

declare var JBH360Platform: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  public utils = _;
  public isLocked: boolean;
  isAcccessApplication: boolean;
  isShowHeader: boolean;
  menuItems: NavigationMenuItem[] = [];
  /**
   * sidebar states
   * @type {any}
   */
  public sidebar = {
    left: {
      open: false,
      locked: false,
      changing: false
    },
    right: {
      open: false
    }
  };
  public breakPoint = '';

  public platform = {};
  msgs: Message[] = [];

  /**
   * [constructor description]
   * @param {BreakpointService} private _breakpointService [description]
   * @param {WindowService} private _window [description]
   */
  constructor(private readonly router: Router,
    private readonly shortcuts: ShortCutKeyService,
    private readonly ngZone: NgZone,
    private readonly user: UserService,
    private readonly translate: TranslateService,
    private readonly logger: NGXLogger,
    private readonly localStorage: LocalStorageService,
    private readonly stompConnection: StompConnectionService,
    private readonly browserTitleService: BrowserTitleService
  ) {
    // this language will be used as a fallback when a translation isn't found in the current language
    translate.addLangs(['en', 'fr']);
    // translate.setDefaultLang('en');
    // the lang to use, if the lang isn't available, it will use the current loader to get them
    translate.use(this.user.getUserLang());

    this.isLocked = false;
    this.isAcccessApplication = true;
    this.isShowHeader = false;
    // this is to log our custom message to browser for debugging purpose
    // this.logger.log('Your log message goes here');
  }

  ngOnInit() {
    this.setUserPage(this.user.getAuthenticationStatus());
    this.initHeader();
    this.menuItems = this.router.config
      .filter(route => route.path && route.path !== '**' && route.path !== 'error/:status'
        && route.data.createSidebarEntry && this.checkMenuAccess(`/${route.path}`))
      .map(route => this.getNavigationMenuItems(route));
    this.stompConnection.startStompConnection();
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => this.browserTitleService.setPageTitle());
  }
  ngOnDestroy(): void {
    this.stompConnection.stopStompConnection();
  }
  private checkMenuAccess(routePath: string) {
    let hasLeftMenuAccess = false;
    switch (routePath) {
      case '/drivertask/create':
        hasLeftMenuAccess = this.user.hasAccess(routePath, 'PU');
        break;
      case '/drivertask/search':
        hasLeftMenuAccess = this.user.hasAccess(routePath, 'R');
        break;
      case '/capacityplanning':
      case '/capacitysettings':
      case '/ldc':
      case '/searchplanninghistory':
      case '/dashboard':
      case '/loadsanalytics':
        hasLeftMenuAccess = true;
        break;
      default:
        hasLeftMenuAccess = this.user.hasAccess(routePath, 'R');
        break;
    }
    return hasLeftMenuAccess;
  }
  private getNavigationMenuItems(route: Route): NavigationMenuItem {
    const navigationMenuItem: NavigationMenuItem = NavigationMenuItem.fromObject({
      displayName: route.data.pathDisplayText,
      icon: route.data.pathIcon,
      href: { routerPath: route.path }
    });
    const childRoutes: NavigationMenuItem[] = route.children ? this.getNavigationMenuItemsForChildren(route.children, route.path) : [];
    childRoutes.forEach(child => navigationMenuItem.addChild(child));
    return navigationMenuItem;
  }

  private getNavigationMenuItemsForChildren(routeData: Route[], parentRoute: string): NavigationMenuItem[] {
    return routeData
      .filter(route => route.path && route.path !== '**' && route.path !== 'error/:status'
        && route.data.createSidebarEntry && this.checkMenuAccess(`/${parentRoute}/${route.path}`))
      .map(route => NavigationMenuItem.fromObject({
        displayName: route.data.pathDisplayText,
        href: { routerPath: `${parentRoute}/${route.path}` }
      })
      );
  }

  private initHeader(): void {
    const config: object = {
      hamburgerClickFunction: (): void => {
        this.ngZone.run(() => {
        });
      }
    };
    try {
      JBH360Platform.init(config);
    } catch (error) {
      this.isShowHeader = true;
    }
  }

  /**
   * resetSidebarState sets sidebar locked and open states back to default (false)
   * @param {[type]} event [description]
   */
  resetSidebarState(event) {
    this.sidebar.left.locked = false;
    this.sidebar.left.open = false;
    this.sidebar.right.open = false;
  }

  /**
   * toggleSidebarLeft is called when a left sidebar toggle event is emitted
   * @param {[type]} event [description]
   */
  toggleSidebarLeft(event) {
    this.sidebar.left.locked = !this.sidebar.left.locked;
    this.sidebar.left.open = !this.sidebar.left.open;
    this.sidebar.right.open = false;
  }

  /**
   * toggleSidebarLeftLock is called when the left sidebar lock toggle event is emitted
   * @param {[type]} event [description]
   */
  toggleNavigationPin($event: boolean) {
    this.sidebar.left.locked = $event;
  }

  /* @HostListener('window:beforeunload', ['$event']) unloadNotification($event: any) {
    $event.returnValue = true;
  } */

  @HostListener('window:keyup', ['$event'])
  keyboardInput(event: Event) {
    this.shortcuts.saveData({
      keyCode: this.shortcuts.getKeyCode(event),
      eventElement: event.target
    });
  }

  private setUserPage(status: number) {
    switch (status) {
      case 200:
        this.isAcccessApplication = this.user.hasAccess('/user', 'R');
        if (!this.isAcccessApplication) {
          this.router.navigateByUrl('error/401', { replaceUrl: true });
        }
        break;
      case 401:
      case 404:
      case 500:
        this.router.navigateByUrl(`error/${status}`, { replaceUrl: true });
        break;
      default:
        this.isAcccessApplication = false;
        this.router.navigateByUrl('error/401', { replaceUrl: true });
        break;
    }
    this.isAcccessApplication = true;
  }

  menuSelected(event) {
    this.localStorage.clearItem('advanceSearchNavigation', 'key');
    this.localStorage.clearItem('formDetails', 'values');
  }
}
