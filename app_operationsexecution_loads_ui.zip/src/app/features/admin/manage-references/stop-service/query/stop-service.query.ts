export class StopServiceQuery {
  static getStopServiceListFromES(searchText: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size,
      query: {
        query_string: {
          fields: [
            'ServiceTypeDescription',
            'ServiceTypeCode',
            'ApplicableTo',
            'LastUpdateTimestamp.text',
            'LastUpdateProgramName',
            'LastUpdateUserID',
            'Status'
          ],
          query: `*${searchText}*`,
          default_operator: 'AND'
        }
      },
      sort: this.getSortQuery(sortOrder, sortField),
      _source: [
        'ServiceTypeDescription',
        'ServiceTypeCode',
        'ApplicableTo',
        'LastUpdateTimestamp',
        'LastUpdateProgramName',
        'LastUpdateUserID',
        'Status'
      ]
    };
  }

  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'ServiceTypeDescription':
      case 'ServiceTypeCode':
      case 'ApplicableTo':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'LastUpdateTimestamp': {
            order: 'desc'
          },
          'ServiceTypeDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }

}
