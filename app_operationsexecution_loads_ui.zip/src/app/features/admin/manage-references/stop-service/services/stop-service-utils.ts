import { StopServiceListModel, StopServiceActiveInactiveModel } from '../model/stop-service.interface';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';

import * as utils from 'lodash';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class StopServiceUtils {

  constructor() { }

  static getStopServiceListData(stopServiceList: ElasticResponseModel): Array<StopServiceListModel> {
    const thisEsList: Array<HitsModel> = (stopServiceList && stopServiceList.hits && stopServiceList.hits.hits) ?
      stopServiceList.hits.hits : [];
    if (!thisEsList || thisEsList.length === 0) {
      return [];
    }

    return thisEsList.map((stopServiceStatus: HitsModel) => {
      return {
        'effectiveTimestamp': stopServiceStatus._source.EffectiveTimestamp,
        'expirationTimestamp': stopServiceStatus._source.ExpirationTimestamp,
        'lastUpdateProgramName': stopServiceStatus._source.LastUpdateProgramName,
        'lastUpdateTimestamp':
        DateUtils.convertOffsetDateByDefaultTimeZone(stopServiceStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
        'lastUpdateUserID': stopServiceStatus._source.LastUpdateUserID,
        'status': stopServiceStatus._source.Status,
        'applicableTo': stopServiceStatus._source.ApplicableTo,
        'serviceTypeCode': stopServiceStatus._source.ServiceTypeCode,
        'serviceTypeDescription': stopServiceStatus._source.ServiceTypeDescription,
        'lastUpdatedBy': `${stopServiceStatus._source.LastUpdateProgramName} ${'('}${stopServiceStatus._source.LastUpdateUserID}${')'}`
      };
    });
  }

  static activateInactivateContent(typeCode: string): StopServiceActiveInactiveModel {
    return {
      'stopServiceTypeCode': typeCode
    };
  }

  static getExcelDownloadRequestBody(esQuery: object) {
    return {
        query: esQuery['query'],
        sort: esQuery['sort']
    };
  }
}
