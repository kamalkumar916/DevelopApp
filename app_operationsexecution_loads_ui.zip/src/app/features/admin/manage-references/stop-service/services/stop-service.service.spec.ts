import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { StopServiceService } from './stop-service.service';
import { configureTestSuite } from 'ng-bullet';

describe('StopServiceService', () => {
  configureTestSuite(() => TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AppConfigService, StopServiceService]
    }));

    it('should be created', () => {
      const service: StopServiceService = TestBed.get(StopServiceService);
      expect(service).toBeTruthy();
    });
});
