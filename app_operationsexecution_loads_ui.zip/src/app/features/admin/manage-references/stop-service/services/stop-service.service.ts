import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { StopServiceListAddModel, StopServiceActiveInactiveModel } from '../model/stop-service.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import { Driver } from '../../../../../../../node_modules/@types/selenium-webdriver/opera';

@Injectable()
export class StopServiceService {
  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }

  /* Elastic Search - POST API
      Params - Input : Elastic Search Query
    */
  getStopServiceList(query: object) {
    return this.http.post<ElasticResponseModel>(this.endpoint.getStopServiceList, query);
  }

  saveStopServiceList(query: StopServiceListAddModel) {
    return this.http.post<boolean>(this.endpoint.saveStopService, query);
  }

  editStopServiceList(query: StopServiceListAddModel) {
    return this.http.patch<boolean>(this.endpoint.saveStopService, query);
  }

  inactivateStopServiceList(stopServiceCodeModel: StopServiceActiveInactiveModel) {
    return this.http.patch<boolean>(this.endpoint.inactivateStopServiceStatus, stopServiceCodeModel);
  }

  reactivateStopServiceList(stopServiceCodeModel: StopServiceActiveInactiveModel) {
    return this.http.patch<boolean>(this.endpoint.reactivateStopServiceStatus, stopServiceCodeModel);
  }

  saveStopServiceListWorkOrder(query: StopServiceListAddModel) {
    return this.http.post<boolean>(this.endpoint.saveStopServiceOwo, query);
  }

  editStopServiceListWorkOrder(query: StopServiceListAddModel) {
    return this.http.patch<boolean>(this.endpoint.saveStopServiceOwo, query);
  }

  inactivateStopServiceListWorkOrder(stopServiceCodeModel: StopServiceActiveInactiveModel) {
    return this.http.patch<boolean>(this.endpoint.inactivateStopServiceStatusOwo, stopServiceCodeModel);
  }

  reactivateStopServiceListWorkOrder(stopServiceCodeModel: StopServiceActiveInactiveModel) {
    return this.http.patch<boolean>(this.endpoint.reactivateStopServiceStatusOwo, stopServiceCodeModel);
  }

  stopServiceExcelDownload(requestParam, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoint.stopServiceExportExcel, requestParam, { headers, responseType: 'blob' });
  }

}
