import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { configureTestSuite } from 'ng-bullet';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { StopServiceComponent } from './stop-service.component';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { StopServiceService } from '../stop-service/services/stop-service.service';
import { TooltipModule } from 'primeng/tooltip';

describe('StopServiceComponent', () => {
  let component: StopServiceComponent;
  let fixture: ComponentFixture<StopServiceComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        HttpClientTestingModule,
        DirectivesModule,
        TableModule,
        FormsModule,
        ReactiveFormsModule,
        MenuModule,
        ButtonModule,
        AutoCompleteModule,
        PipesModule,
        ConfirmDialogModule,
        JbhLoaderModule,
        TooltipModule
      ],

      providers: [AppConfigService, MessageService, StopServiceService, ConfirmationService],
      declarations: [StopServiceComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StopServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('checking sortOrder value when desc', () => {
    spyOn(component, 'fetchStopServiceListData');
    const thisEvent = { sortOrder: -1 };
    component.onPage(thisEvent);
    expect(component.stopServiceModel.sortOrder).toBe('desc');
    expect(component.fetchStopServiceListData).toHaveBeenCalled();
  });
  it('checking sortOrder value when asc', () => {
    spyOn(component, 'fetchStopServiceListData');
    const thisEvent = { sortOrder: 0 };
    component.onPage(thisEvent);
    expect(component.stopServiceModel.sortOrder).toBe('asc');
    expect(component.fetchStopServiceListData).toHaveBeenCalled();
  });
  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.stopServiceModel.splitView).toBe(false);
  });
  it('fetchAllData have been called', () => {
    component.fetchAllData();
    expect(component.stopServiceModel.queryString).toBe('');
  });
});
