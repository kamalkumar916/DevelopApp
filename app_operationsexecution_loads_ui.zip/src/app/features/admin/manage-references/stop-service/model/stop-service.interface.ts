export interface TableColumnModel {
  label: string;
  key: string;
  esKey?: string;
}

export interface StopServiceListModel {
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateProgramName: string;
  lastUpdateTimestamp: string;
  lastUpdateUserID: string;
  serviceTypeCode: string;
  serviceTypeDescription: string;
  status: string;
  applicableTo: string;
}

export interface StopServiceListAddModel {
  stopServiceTypeDescription: string;
  stopServiceTypeCode: string;
  stopserviceTypeCategory?: string;
}

export interface StopServiceActiveInactiveModel {
  stopServiceTypeCode: string;
}
export interface ApplicableTo {
  label: string;
  value: string;
}

export interface DropdownLabels {
  label: string;
  value: string;
}
