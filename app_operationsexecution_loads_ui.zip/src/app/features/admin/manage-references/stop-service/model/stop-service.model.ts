import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';
import * as LodashUtils from 'lodash';

import { StopServiceListModel, TableColumnModel, ApplicableTo, DropdownLabels } from './stop-service.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class StopServiceModel {
  items: Array<MenuItem>;
  splitView: boolean;
  stopServiceList: Array<StopServiceListModel>;
  applicableTo: Array<ApplicableTo>;
  applicableToItems: Array<ApplicableTo>;
  stopServiceSelectedList: Array<StopServiceListModel>;
  paginatorFlag: boolean;
  totalRecords: number;
  pageStart: number;
  tableSize: number;
  queryString: string;
  searchText: string;
  subscriberFlag: boolean;
  dropdownLabels: Array<DropdownLabels>;
  tableColumns: Array<TableColumnModel>;
  userInputSearchSubject: Subject<string>;
  addStopServiceStatusForm: FormGroup;
  inactiveLabel: string;
  activeLabel: string;
  selectedRowContent: StopServiceListModel;
  operationalWorkOrderLabel: string;
  operationalPlanLabel: string;
  gridLoaderFlag: boolean;
  successMessage: string;
  referenceData: string;
  sortField: string;
  sortOrder: string;
  title: string;
  addNewButton: SecureModel;
  inactivateButton: SecureModel;
  activateButton: SecureModel;
  saveButton: SecureModel;
  appConfig;
  isSectionLoaderEnabled: boolean;

  constructor() {
    this.splitView = false;
    this.stopServiceList = [];
    this.stopServiceSelectedList = [];
    this.paginatorFlag = false;
    this.totalRecords = 0;
    this.pageStart = 0;
    this.tableSize = 25;
    this.queryString = '';
    this.searchText = '';
    this.subscriberFlag = true;
    this.userInputSearchSubject = new Subject<string>();
    this.selectedRowContent = null;
    this.inactiveLabel = 'inactive';
    this.activeLabel = 'active';
    this.gridLoaderFlag = true;
    this.successMessage = 'ADMIN_MODULE_COMMON.REFERENCE_DATA';
    this.referenceData = 'STOPSERVICE.REFERENCEDATA_DETAIL';
    this.sortField = 'defaultSort';
    this.sortOrder = 'asc';
    this.title = 'Stop Service';
    this.isSectionLoaderEnabled = false;
    this.tableColumns = [
      {
        'label': 'Name',
        'key': 'serviceTypeDescription',
        'esKey': 'ServiceTypeDescription'
      },
      {
        'label': 'Identifier',
        'key': 'serviceTypeCode',
        'esKey': 'ServiceTypeCode'
      },
      {
        'label': 'Applicable to',
        'key': 'applicableTo',
        'esKey': 'ApplicableTo'
      },
      {
        'label': 'Last Updated',
        'key': 'lastUpdateTimestamp',
        'esKey': 'LastUpdateTimestamp'
      },
      {
        'label': 'Last Updated By',
        'key': 'lastUpdatedBy',
        'esKey': 'LastUpdateProgramName'
      },
      {
        'label': 'Status',
        'key': 'status',
        'esKey': 'Status'
      }];

    this.operationalPlanLabel = 'Operational Plan';
    this.operationalWorkOrderLabel = 'Operational Work Order';
    this.appConfig = AppConfig.getConfig();
    this.addNewButton = { url: this.appConfig.api.admin.saveStopService, operation: 'C' };
    this.inactivateButton = { url: this.appConfig.api.admin.inactivateStopServiceStatusOwo, operation: 'C' };
    this.activateButton = { url: this.appConfig.api.admin.reactivateStopServiceStatusOwo, operation: 'C' };
    this.saveButton = { url: this.appConfig.api.admin.saveStopServiceOwo, operation: 'C' };
  }
  getDropdownValues() {
    this.dropdownLabels = [
      { label: this.operationalPlanLabel, value: this.operationalPlanLabel },
      { label: this.operationalWorkOrderLabel, value: this.operationalWorkOrderLabel }
    ];
    this.applicableToItems = LodashUtils.cloneDeep(this.dropdownLabels);
  }

}
