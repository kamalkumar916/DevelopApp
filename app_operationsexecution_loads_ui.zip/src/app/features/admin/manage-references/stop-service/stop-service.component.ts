import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import * as LodashUtils from 'lodash';
import * as moment from 'moment';

import { StopServiceModel } from './model/stop-service.model';
import { StopServiceService } from './services/stop-service.service';
import { StopServiceUtils } from './services/stop-service-utils';
import { StopServiceQuery } from './query/stop-service.query';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { StopServiceListModel, DropdownLabels, StopServiceListAddModel } from './model/stop-service.interface';

@Component({
  selector: 'app-stop-service',
  templateUrl: './stop-service.component.html',
  styleUrls: ['./stop-service.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class StopServiceComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('stopServiceDownloadExcel') stopServiceDownloadExcel: ElementRef;
  stopServiceModel: StopServiceModel;
  applicableTo: FormGroup;
  defaultSort = 'Status';

  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly confirmationService: ConfirmationService,
    private readonly stopServiceService: StopServiceService,
    private readonly messageService: MessageService,
    private readonly formBuilder: FormBuilder) {
    this.stopServiceModel = new StopServiceModel();
  }

  ngOnInit() {
    this.searchInput();
    this.overFlowMenuOptions();
  }

  ngOnDestroy() {
    this.stopServiceModel.subscriberFlag = false;
  }

  get addStopServiceStatusFormControls() {
    return this.stopServiceModel.addStopServiceStatusForm.controls;
  }

  onPage(thisEvent) {
    this.getCurrentScrollPosition();
    this.stopServiceModel.pageStart = thisEvent['first'];
    this.stopServiceModel.tableSize = thisEvent['rows'];
    this.stopServiceModel.sortField = thisEvent.sortField;
    this.stopServiceModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchStopServiceListData();
  }

  onAddStopServiceForm(): FormGroup {
    return this.formBuilder.group({
      owoTypeDescription: ['', Validators.required],
      owoTypeCode: ['', Validators.required],
      applicableTo: ['', Validators.required]
    });
  }
  onAddNew() {
    this.stopServiceModel.addStopServiceStatusForm = this.onAddStopServiceForm();
    this.stopServiceModel.splitView = true;
    this.stopServiceModel.getDropdownValues();
  }

  setFilteredContent(userSearchInput: string) {
    this.stopServiceModel.applicableToItems = Object.assign([], this.stopServiceModel.dropdownLabels).filter(
      thisDropdownContent => thisDropdownContent.label.toLowerCase().indexOf(userSearchInput.toLowerCase()) > -1
    );
  }
  setFilteredContentClear() {
    this.stopServiceModel.addStopServiceStatusForm.controls.applicableTo.setErrors({ 'incorrect': true });
  }

  overFlowMenuOptions() {
    this.stopServiceModel.items = [
      {
        label: 'Export to Excel',
        command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }

  exportToExcel() {
    this.stopServiceService.stopServiceExcelDownload(StopServiceUtils.getExcelDownloadRequestBody(
      StopServiceQuery.getStopServiceListFromES(this.stopServiceModel.queryString,
        this.stopServiceModel.pageStart, this.stopServiceModel.tableSize,
        this.stopServiceModel.sortOrder, this.stopServiceModel.sortField)))
      .pipe(
        takeWhile(() => this.stopServiceModel.subscriberFlag),
      ).subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `${
            this.stopServiceModel.title} ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.stopServiceDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }

  downloadThisExcelFile(data: Blob, stopServiceDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      stopServiceDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      stopServiceDownloadExcel.nativeElement.download = fileName;
      stopServiceDownloadExcel.nativeElement.click();
    }
  }

  fetchStopServiceListData() {
    this.stopServiceService.getStopServiceList(StopServiceQuery.getStopServiceListFromES(
      this.stopServiceModel.queryString, this.stopServiceModel.pageStart, this.stopServiceModel.tableSize
      , this.stopServiceModel.sortOrder, this.stopServiceModel.sortField))
      .pipe(
        takeWhile(() => this.stopServiceModel.subscriberFlag),
        finalize(() => {
          this.stopServiceModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        })
      ).subscribe((stopServiceList: ElasticResponseModel) => {
        if (!LodashUtils.isEmpty(stopServiceList) && !LodashUtils.isEmpty(stopServiceList['hits'])
          && LodashUtils.isEmpty(stopServiceList['hits']['total'])) {
          this.stopServiceModel.gridLoaderFlag = !(this.stopServiceModel.stopServiceList.length > 0);
          this.stopServiceModel.totalRecords = stopServiceList.hits.total;
          this.stopServiceModel.stopServiceList = StopServiceUtils.getStopServiceListData(stopServiceList);
          this.stopServiceModel.paginatorFlag = this.stopServiceModel.stopServiceList.length > 0;
        }
      }, (error: Error) => {
        this.stopServiceModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }

  onSearch() {
    this.stopServiceModel.pageStart = 0;
    this.stopServiceModel.userInputSearchSubject.next(this.stopServiceModel.searchText);
  }

  searchInput() {
    this.stopServiceModel.userInputSearchSubject.pipe(debounceTime(300), distinctUntilChanged(),
      takeWhile(() => this.stopServiceModel.subscriberFlag))
      .subscribe(() => {
        if (this.stopServiceModel.searchText.length === 0 || this.stopServiceModel.searchText.length > 2) {
          if (this.stopServiceModel.searchText.match('^[0-9,]*$')) {
            this.stopServiceModel.queryString = this.stopServiceModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
            this.stopServiceModel.queryString = this.stopServiceModel.queryString.replace(/\,/g, '');
          } else {
            this.stopServiceModel.queryString = this.stopServiceModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
          }
          this.fetchStopServiceListData();
        } else if (this.stopServiceModel.queryString) {
          this.stopServiceModel.queryString = '';
          this.fetchStopServiceListData();
        }
      });
  }
  onCompareOldData() {
    if (this.stopServiceModel.selectedRowContent) {
      const nameRowValue = this.stopServiceModel.selectedRowContent.serviceTypeDescription;
      const nameFieldValue = this.stopServiceModel.addStopServiceStatusForm.controls.owoTypeDescription.value;
      return (nameRowValue !== nameFieldValue);
    } else {
      return true;
    }
  }

  onSave() {
    if (this.stopServiceModel.addStopServiceStatusForm.valid &&
      (this.stopServiceModel.addStopServiceStatusForm.dirty || this.stopServiceModel.addStopServiceStatusForm.touched) &&
      this.onCompareOldData()) {
    this.stopServiceModel.isSectionLoaderEnabled = true;
    if (this.stopServiceModel.selectedRowContent) {
        this.editServicePlanOrWorkOrder();
      } else {
        this.saveServicePlanOrWorkOrder();
      }
    } else if (this.stopServiceModel.selectedRowContent) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'info',
        summary: 'No Changes Detected',
        detail: `You've not done any changes to Stop Service.`
      });
    } else {
      this.stopServiceModel.addStopServiceStatusForm.controls.owoTypeCode.markAsTouched();
      this.stopServiceModel.addStopServiceStatusForm.controls.owoTypeDescription.markAsTouched();
      this.stopServiceModel.addStopServiceStatusForm.controls.applicableTo.markAsTouched();
    }
  }

  editServicePlanOrWorkOrder() {
    this.stopServiceModel.isSectionLoaderEnabled = false;
    if (this.addStopServiceStatusFormControls.applicableTo.value.toString() === this.stopServiceModel.operationalPlanLabel) {
      const editDetailsPlan: StopServiceListAddModel = {
        stopServiceTypeDescription: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeDescription,
        stopServiceTypeCode: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeCode,
        stopserviceTypeCategory: 'StopServ'
      };
      this.stopServiceService.editStopServiceList(editDetailsPlan)
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag), finalize(() => {
          this.stopServiceModel.isSectionLoaderEnabled = false;
        }))
        .subscribe(() => {
          this.fetchAllData();
          this.showToastMessage(true);
        });
    }
    if (this.addStopServiceStatusFormControls.applicableTo.value.toString() === this.stopServiceModel.operationalWorkOrderLabel) {
      const editDetailsWorkOrder: StopServiceListAddModel = {
        stopServiceTypeDescription: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeDescription,
        stopServiceTypeCode: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeCode
      };
      this.stopServiceService.editStopServiceListWorkOrder(editDetailsWorkOrder)
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag))
        .subscribe(() => {
          this.fetchAllData();
          this.showToastMessage(true);
        });
    }
  }

  saveServicePlanOrWorkOrder() {
    if (this.addStopServiceStatusFormControls.applicableTo.value.label === this.stopServiceModel.operationalPlanLabel) {
      const saveDetailsPlan: StopServiceListAddModel = {
        stopServiceTypeDescription: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeDescription,
        stopServiceTypeCode: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeCode,
        stopserviceTypeCategory: 'StopServ'
      };
      this.stopServiceService.saveStopServiceList(saveDetailsPlan)
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag)).subscribe(() => {
          this.fetchAllData();
          this.showToastMessage(false);
        }, (err: Error) => {
          this.onServiceError(err);
        });
    this.stopServiceModel.isSectionLoaderEnabled = false;
    }
    if (this.addStopServiceStatusFormControls.applicableTo.value.label === this.stopServiceModel.operationalWorkOrderLabel) {
      const saveDetailsWorkOrder: StopServiceListAddModel = {
        stopServiceTypeDescription: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeDescription,
        stopServiceTypeCode: this.stopServiceModel.addStopServiceStatusForm.value.owoTypeCode
      };
      this.stopServiceService.saveStopServiceListWorkOrder(saveDetailsWorkOrder)
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag)).subscribe(() => {
          this.fetchAllData();
          this.showToastMessage(false);
        }, (err: Error) => {
          this.onServiceError(err);
        });
    }
  }

  onServiceError(err) {
    if (err['status'] === 409) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'error',
        summary: 'Duplicate Reference Data',
        detail: `The reference data already exists. So, you can't add this reference data.`
      });
    }
  }

  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isEditMode) ? 'Reference Data Updated' :
        'Reference Data Added',
      detail: (isEditMode) ? 'Stop Service has been successfully updated.' :
        'Stop Service has been successfully added.'
    });

    this.changeDetector.detectChanges();
  }

  fetchAllData() {
    this.stopServiceModel.searchText = '';
    this.stopServiceModel.queryString = '';
    this.fetchStopServiceListData();
    this.stopServiceModel.splitView = false;
    this.stopServiceModel.isSectionLoaderEnabled = false;
    this.changeDetector.detectChanges();
  }

  onCancel() {
    if (this.stopServiceModel.addStopServiceStatusForm.touched && this.stopServiceModel.addStopServiceStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'StopService',
        accept: (): void => {
          this.fetchStopServiceListData();
          this.closeAddEditPage();
          this.stopServiceModel.splitView = false;
        }
      });
    } else {
      this.fetchStopServiceListData();
      this.closeAddEditPage();
    }
  }

  onRowSelect(selectedRow: StopServiceListModel) {
    this.stopServiceModel.isSectionLoaderEnabled = true;
    if (this.stopServiceModel.selectedRowContent && selectedRow.serviceTypeCode !==
      this.stopServiceModel.selectedRowContent.serviceTypeCode) {
      this.selectedContentSplitScreen(selectedRow);
    } else if (!this.stopServiceModel.selectedRowContent) {
      this.selectedContentSplitScreen(selectedRow);
    }
  }

  selectedContentSplitScreen(selectedContent: StopServiceListModel) {
    this.stopServiceModel.selectedRowContent = selectedContent;
    this.stopServiceModel.addStopServiceStatusForm = this.onAddStopServiceForm();
    this.stopServiceModel.addStopServiceStatusForm.patchValue({
      owoTypeDescription: selectedContent.serviceTypeDescription,
      owoTypeCode: selectedContent.serviceTypeCode,
      applicableTo: selectedContent.applicableTo
    });
    this.stopServiceModel.splitView = true;
    this.stopServiceModel.isSectionLoaderEnabled = false;
  }

  closeAddEditPage() {
    this.stopServiceModel.selectedRowContent = null;
    this.stopServiceModel.splitView = false;
  }

  onActivate() {
    this.stopServiceModel.isSectionLoaderEnabled = true;
    if (this.addStopServiceStatusFormControls.applicableTo.value === this.stopServiceModel.operationalPlanLabel) {
      this.stopServiceService.reactivateStopServiceList(StopServiceUtils.activateInactivateContent
        (this.stopServiceModel.selectedRowContent.serviceTypeCode))
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag), finalize(() => {
          this.stopServiceModel.selectedRowContent = null;
        }))
        .subscribe(() => {
          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(false);

        });
    }
    if (this.addStopServiceStatusFormControls.applicableTo.value === this.stopServiceModel.operationalWorkOrderLabel) {
      this.stopServiceService.reactivateStopServiceListWorkOrder(StopServiceUtils.activateInactivateContent
        (this.stopServiceModel.selectedRowContent.serviceTypeCode))
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag))
        .subscribe(() => {
          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(false);
        });
    }

  }

  onInactivate() {
    this.stopServiceModel.addStopServiceStatusForm.patchValue({
      owoTypeDescription: this.stopServiceModel.selectedRowContent.serviceTypeDescription,
      owoTypeCode: this.stopServiceModel.selectedRowContent.serviceTypeCode,
      applicableTo: this.stopServiceModel.selectedRowContent.applicableTo
    });
    this.confirmationService.confirm({
      message: `Stop Service<br><b>${this.stopServiceModel.selectedRowContent.serviceTypeDescription}
       (${this.stopServiceModel.selectedRowContent.serviceTypeCode})</b><br><br>
       The reference data you\'re about to inactivate may be associated to active orders or
       other entities, inactivating the data will not impact current associations
        but <b>new entities can no longer reference this record.</b><br><br> Any other
         <b>reference data that has this record as an association will also be inactivated.</b><br><br> Do you wish to proceed ?`,
      header: 'Inactivate Stop Service',
      key: 'inactivateStopServiceStatus',
      accept: (): void => {
    this.stopServiceModel.isSectionLoaderEnabled = true;
    this.inactivatePlanOrWorkOrder();
      }
    });
  }

  inactivatePlanOrWorkOrder() {
    if (this.addStopServiceStatusFormControls.applicableTo.value === this.stopServiceModel.operationalPlanLabel) {
      this.stopServiceService.inactivateStopServiceList(StopServiceUtils.activateInactivateContent
        (this.stopServiceModel.selectedRowContent.serviceTypeCode))
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag), finalize(() => {
          this.stopServiceModel.selectedRowContent = null;
        }))
        .subscribe(() => {
          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(true);
        });
    }
    if (this.addStopServiceStatusFormControls.applicableTo.value === this.stopServiceModel.operationalWorkOrderLabel) {
      this.stopServiceService.inactivateStopServiceListWorkOrder(StopServiceUtils.activateInactivateContent
        (this.stopServiceModel.selectedRowContent.serviceTypeCode))
        .pipe(takeWhile(() => this.stopServiceModel.subscriberFlag))
        .subscribe(() => {
          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(true);
        });
    }
  }
  showToastMsgForReactivateInactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isDeactivateMode) ? 'Reference Data Inactivated' : 'Reference Data Activated',
      detail: (isDeactivateMode) ? 'Stop Service has been successfully inactivated.' :
        'Stop Service has been successfully activated.'
    });
    this.changeDetector.detectChanges();
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
}
