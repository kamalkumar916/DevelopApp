import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Observable, timer } from 'rxjs';

import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import * as LodashUtils from 'lodash';
import * as moment from 'moment';


import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';

import { AppointmentChangeReasonService } from './services/appointment-change-reason.service';
import { AppointmentChangeReasonUtils } from './services/appointment-change-reason-utils';
import { AppointmentChangeReasonQuery } from './query/appointment-change-reason.query';

import { AppointmentChangeModel } from './model/appointment-change-reason.model';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { AppointmentChangeReasonModel, DropdownLables } from './model/appointment-change-reason.interface';

@Component({
  selector: 'app-appointment-change-reason',
  templateUrl: './appointment-change-reason.component.html',
  styleUrls: ['./appointment-change-reason.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppointmentChangeReasonComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('appointmentChangeDownloadExcel') appointmentChangeDownloadExcel: ElementRef;
  appointmentChangeModel: AppointmentChangeModel;
  defaultSort = 'Status';

  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly messageService: MessageService,
    private readonly confirmationService: ConfirmationService,
    private readonly formBuilder: FormBuilder,
    private readonly appointmentChangeReasonService: AppointmentChangeReasonService) {
    this.appointmentChangeModel = new AppointmentChangeModel();
  }

  ngOnInit() {
    this.searchInputListener();
    this.initializeMenuItems();
    this.fetchAppointmentChangeList();
  }

  ngOnDestroy() {
    this.appointmentChangeModel.subscriberFlag = false;
  }

  onPage(thisEvent) {
    this.getCurrentScrollPosition();
    this.appointmentChangeModel.pageStart = thisEvent['first'];
    this.appointmentChangeModel.tableSize = thisEvent['rows'];
    this.appointmentChangeModel.sortField = thisEvent.sortField;
    this.appointmentChangeModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchAppointmentChangeList();
  }

  onSearch(event) {
    this.appointmentChangeModel.pageStart = 0;
    this.appointmentChangeModel.userInputSearchSubject.next(event);
  }

  onAddNew() {
    this.appointmentChangeModel.addAppointmentChangeReasonForm = this.initializeAddForm();
    this.appointmentChangeModel.splitView = true;
  }

  onClose() {
    if (this.appointmentChangeModel.addAppointmentChangeReasonForm.touched
      || this.appointmentChangeModel.addAppointmentChangeReasonForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'appointmentChangeAdd',
        accept: (): void => {
          this.fetchAppointmentChangeList();
          this.closeAddEditPage();
        }
      });
    } else {
      this.closeAddEditPage();
    }
  }

  get addAppointmentChangeReasonFormControl() {
    return this.appointmentChangeModel.addAppointmentChangeReasonForm.controls;
  }

  fetchAppointmentChangeList() {
    this.appointmentChangeReasonService.getAppointmentChangeReasonList(AppointmentChangeReasonQuery.getAppointmentChangeListFromES(
      this.appointmentChangeModel.queryString, this.appointmentChangeModel.pageStart, this.appointmentChangeModel.tableSize,
      this.appointmentChangeModel.sortOrder, this.appointmentChangeModel.sortField))
      .pipe(
        takeWhile(() => this.appointmentChangeModel.subscriberFlag),
        finalize(() => {
          this.appointmentChangeModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((appointmentChangeReasonList: ElasticResponseModel) => {
        this.appointmentChangeModel.gridLoaderFlag =
          !(this.appointmentChangeModel.appointmentChangeReasonList.length > 0);
        this.appointmentChangeModel.totalRecords = appointmentChangeReasonList.hits.total;
        this.appointmentChangeModel.appointmentChangeReasonList = AppointmentChangeReasonUtils.getListData(appointmentChangeReasonList);
        this.appointmentChangeModel.paginatorFlag =
          (this.appointmentChangeModel.appointmentChangeReasonList.length !== 0);
      }, (error: Error) => {
        this.appointmentChangeModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }
  onCompareOldData() {
    if (this.appointmentChangeModel.selectedRowContent) {
      const nameRowValue = this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeDescription;
      const nameFieldValue = this.appointmentChangeModel.addAppointmentChangeReasonForm.controls.
        operationalPlanAppointmentChangeDescription.value;
      const categoryRowValue = this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeCategoryDescription;
      const categoryFieldValue = this.appointmentChangeModel.addAppointmentChangeReasonForm.controls.
        operationalPlanAppointmentChangeCategoryDescription.value.label;
      return !((nameRowValue === nameFieldValue) && (categoryRowValue === categoryFieldValue));
    } else {
      return true;
    }
  }
  onSave() {
    if (this.appointmentChangeModel.addAppointmentChangeReasonForm.valid &&
      (this.addAppointmentChangeReasonFormControl
        .operationalPlanAppointmentChangeCategoryDescription.value !== '') &&
      (this.appointmentChangeModel.addAppointmentChangeReasonForm.dirty ||
        this.appointmentChangeModel.addAppointmentChangeReasonForm.touched) && this.onCompareOldData()) {
      this.appointmentChangeModel.isSectionLoaderEnabled = true;
      if (this.appointmentChangeModel.selectedRowContent) {
        this.appointmentChangeReasonService.editAppointmentChangeReason
          (AppointmentChangeReasonUtils.addEditAppointmentForm
            (this.appointmentChangeModel.addAppointmentChangeReasonForm))
          .pipe(
            takeWhile(() => this.appointmentChangeModel.subscriberFlag),
            finalize(() => {
              this.appointmentChangeModel.selectedRowContent = null;
            })
          )
          .subscribe(() => {
            this.fetchAllData();
            this.showToastMessage(true);
          });
      } else {
        this.appointmentChangeReasonService.addAppointmentChangeReason(AppointmentChangeReasonUtils.addEditAppointmentForm
          (this.appointmentChangeModel.addAppointmentChangeReasonForm))
          .pipe(
            takeWhile(() => this.appointmentChangeModel.subscriberFlag),
          )
          .subscribe(() => {
            this.fetchAllData();
            this.showToastMessage(false);
          }, (error: Error) => {
            this.appointmentChangeModel.isSectionLoaderEnabled = false;
            this.changeDetector.detectChanges();

            if (error['status'] === 409) {
              this.messageService.clear();
              this.messageService.add({
                severity: 'error',
                summary: 'Duplicate Reference Data',
                detail: `The reference data already exists. So, you can't add this reference data.`,
              });
            }
          });
      }
    } else if (this.appointmentChangeModel.addAppointmentChangeReasonForm.valid && this.appointmentChangeModel.selectedRowContent) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'info',
        summary: 'No Changes Detected',
        detail: `You've not done any changes to Appointment Change Reason.`
      });
    } else {
      this.addAppointmentChangeReasonFormControl.operationalPlanAppointmentChangeCode.markAsTouched();
      this.addAppointmentChangeReasonFormControl.operationalPlanAppointmentChangeDescription.markAsTouched();
      this.addAppointmentChangeReasonFormControl
        .operationalPlanAppointmentChangeCategoryDescription.markAsTouched();
    }
  }

  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isEditMode) ? 'Reference Data Updated' :
        'Reference Data Added',
      detail: (isEditMode) ? 'Appointment Change Reason has been successfully updated.' :
        'Appointment Change Reason has been successfully added.'
    });

    this.changeDetector.detectChanges();
  }

  fetchAllData() {
    timer(1000)
      .pipe(
        takeWhile(() => this.appointmentChangeModel.subscriberFlag),
      )
      .subscribe(() => {
        this.appointmentChangeModel.searchText = this.appointmentChangeModel.queryString = '';
        this.fetchAppointmentChangeList();
        this.appointmentChangeModel.splitView = false;
        this.appointmentChangeModel.isSectionLoaderEnabled = false;
        this.changeDetector.detectChanges();
      });
  }

  onRowSelect(thisSelectedRow: AppointmentChangeReasonModel) {
    this.appointmentChangeModel.isSectionLoaderEnabled = true;
    if (this.appointmentChangeModel.selectedRowContent && thisSelectedRow.operationalPlanAppointmentChangeCode !==
      this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeCode) {
      this.setContentAndLoadSplitScreen(thisSelectedRow);
    } else if (!this.appointmentChangeModel.selectedRowContent) {
      this.setContentAndLoadSplitScreen(thisSelectedRow);
    }
  }

  setContentAndLoadSplitScreen(selectedContent: AppointmentChangeReasonModel) {
    this.appointmentChangeModel.selectedRowContent = selectedContent;
    this.appointmentChangeModel.addAppointmentChangeReasonForm = this.initializeAddForm();
    let operationalPlanAppointmentChangeCategoryDescription: DropdownLables = null;
    this.appointmentChangeModel.dropdownLables.forEach((thisObj: DropdownLables) => {
      if (thisObj.label === selectedContent.operationalPlanAppointmentChangeCategoryDescription) {
        operationalPlanAppointmentChangeCategoryDescription = thisObj;
      }
    });
    this.appointmentChangeModel.addAppointmentChangeReasonForm.patchValue({
      operationalPlanAppointmentChangeDescription: selectedContent.operationalPlanAppointmentChangeDescription,
      operationalPlanAppointmentChangeCode: selectedContent.operationalPlanAppointmentChangeCode,
      operationalPlanAppointmentChangeCategoryDescription
    });
    this.appointmentChangeModel.splitView = true;
    this.appointmentChangeModel.isSectionLoaderEnabled = false;
  }

  initializeMenuItems() {
    this.appointmentChangeModel.menuItems = [
      {
        label: 'Export to Excel', command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }

  searchInputListener() {
    this.appointmentChangeModel.userInputSearchSubject
      .pipe(
        debounceTime(300), distinctUntilChanged(),
        takeWhile(() => this.appointmentChangeModel.subscriberFlag),
      )
      .subscribe(() => {
        if (this.appointmentChangeModel.searchText.length === 0 || this.appointmentChangeModel.searchText.length > 2) {
          this.appointmentChangeModel.pageStart = 0;
          if (this.appointmentChangeModel.searchText.match('^[0-9,]*$')) {
            this.appointmentChangeModel.queryString = this.appointmentChangeModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
            this.appointmentChangeModel.queryString = this.appointmentChangeModel.queryString.replace(/\,/g, '');
          } else {
            this.appointmentChangeModel.queryString = this.appointmentChangeModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
          }
          this.fetchAppointmentChangeList();
        } else if (this.appointmentChangeModel.queryString) {
          this.appointmentChangeModel.queryString = '';
          this.fetchAppointmentChangeList();
        }
      });
  }

  showToastMessageForInactivateReactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isDeactivateMode) ? 'Reference Data Inactivated' : 'Reference Data Activated',
      detail: (isDeactivateMode) ?
        'Appointment Change Reason has been successfully inactivated.' : 'Appointment Change Reason has been successfully activated.'
    });
    this.changeDetector.detectChanges();
  }

  onInactivate() {
    let operationalPlanAppointmentChangeCategoryDescription: DropdownLables = null;
    this.appointmentChangeModel.dropdownLables.forEach((thisObj: DropdownLables) => {
      if (thisObj.label === this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeCategoryDescription) {
        operationalPlanAppointmentChangeCategoryDescription = thisObj;
      }
    });
    this.appointmentChangeModel.addAppointmentChangeReasonForm.patchValue({
      operationalPlanAppointmentChangeDescription:
        this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeDescription,
      operationalPlanAppointmentChangeCode: this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeCode,
      operationalPlanAppointmentChangeCategoryDescription: operationalPlanAppointmentChangeCategoryDescription
    });
    this.confirmationService.confirm({
      message: `Appointment Change Reason<br><b>
      ${this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeDescription}
      (${this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeCode})
      </b><br><br>The reference data you're about to inactivate may be associated to active orders
       or other entities, inactivating the data will not impact current associations but <b>new
       entities can no longer reference this record.</b><br><br> Any other <b>reference data that has this record
       as an association will also be inactivated.</b><br><br> Do you wish to proceed ?`,
      header: 'Inactivate Appointment Change Reason',
      key: 'inactivateappointmentChangeModelStatus',
      accept: (): void => {
        this.appointmentChangeModel.isSectionLoaderEnabled = true;
        this.appointmentChangeReasonService.inactivateAppointmentChangeReason(AppointmentChangeReasonUtils.formActivateInactivateBodyParam
          (this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeCode))
          .pipe(
            takeWhile(() => this.appointmentChangeModel.subscriberFlag),
            finalize(() => {
              this.appointmentChangeModel.isSectionLoaderEnabled = false;
              this.appointmentChangeModel.selectedRowContent = null;
            })
          )
          .subscribe(() => {
            this.fetchAllData();
            this.showToastMessageForInactivateReactivate(true);
          });
      }
    });
  }

  onActivate() {
    this.appointmentChangeModel.isSectionLoaderEnabled = true;
    this.appointmentChangeReasonService.reactivateAppointmentChangeReason(AppointmentChangeReasonUtils.formActivateInactivateBodyParam
      (this.appointmentChangeModel.selectedRowContent.operationalPlanAppointmentChangeCode))
      .pipe(
        takeWhile(() => this.appointmentChangeModel.subscriberFlag),
        finalize(() => {
          this.appointmentChangeModel.isSectionLoaderEnabled = false;
          this.appointmentChangeModel.selectedRowContent = null;
        })
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMessageForInactivateReactivate(false);
      });
  }

  closeAddEditPage() {
    this.appointmentChangeModel.selectedRowContent = null;
    this.appointmentChangeModel.splitView = false;
    this.appointmentChangeModel.appointmentChangeReasonSelectedList = null;
  }

  setFilteredContent(userSearchInput: string) {
    if (userSearchInput === '') {
      this.appointmentChangeModel.filteredDropdownLables = LodashUtils.cloneDeep(this.appointmentChangeModel.dropdownLables);
    } else {
      this.appointmentChangeModel.filteredDropdownLables = Object.assign([], this.appointmentChangeModel.dropdownLables).filter(
        thisDropdownContent => thisDropdownContent.label.toLowerCase().indexOf(userSearchInput.toLowerCase()) > -1
      );
    }
  }

  initializeAddForm(): FormGroup {
    return this.formBuilder.group({
      operationalPlanAppointmentChangeCode: ['', Validators.required],
      operationalPlanAppointmentChangeDescription: ['', Validators.required],
      operationalPlanAppointmentChangeCategoryDescription: ['', Validators.required]
    });
  }

  setFilteredContentClear() {
    this.addAppointmentChangeReasonFormControl
      .operationalPlanAppointmentChangeCategoryDescription.setErrors({ 'incorrect': true });
  }

  exportToExcel() {
    this.appointmentChangeReasonService.appointmentChangeReasonExcelDownload(AppointmentChangeReasonUtils.getExcelDownloadRequestBody(
      AppointmentChangeReasonQuery.getAppointmentChangeListFromES(this.appointmentChangeModel.queryString,
        this.appointmentChangeModel.pageStart, this.appointmentChangeModel.tableSize,
        this.appointmentChangeModel.sortOrder, this.appointmentChangeModel.sortField)))
      .pipe(
        takeWhile(() => this.appointmentChangeModel.subscriberFlag),
      )
      .subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `Appointment Change Reason ${moment().format('YYYY-MM-DD')}
          at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.appointmentChangeDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }


  downloadThisExcelFile(data: Blob, appointmentChangeDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      appointmentChangeDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      appointmentChangeDownloadExcel.nativeElement.download = fileName;
      appointmentChangeDownloadExcel.nativeElement.click();
    }
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
}
