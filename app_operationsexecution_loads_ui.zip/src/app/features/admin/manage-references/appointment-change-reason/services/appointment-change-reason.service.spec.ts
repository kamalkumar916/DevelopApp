import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { AppointmentChangeReasonService } from './appointment-change-reason.service';
import { configureTestSuite } from 'ng-bullet';

describe('AppointmentChangeReasonService', () => {
  let httpTestingController: HttpTestingController;
  let service: AppointmentChangeReasonService;
  configureTestSuite(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [AppConfigService, AppointmentChangeReasonService]
  }));

  beforeEach(() => {
    service = TestBed.get(AppointmentChangeReasonService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('check getAppointmentChangeReasonList is calling method is "post"', () => {
    service.getAppointmentChangeReasonList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getAppointmentChangeList);
    expect(req.request.method).toEqual('POST');
  });

});

