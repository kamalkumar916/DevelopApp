import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import {
  AppointmentChangeReasonModel,
  AppointmentChangeActiveInactiveModel, AppointmentChangeReasonAddModel, DropdownLables, AppointmentChangeExcelDownloadModel
} from '../model/appointment-change-reason.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class AppointmentChangeReasonUtils {

  constructor() { }

  static getListData(AppointmentChangeList: ElasticResponseModel): Array<AppointmentChangeReasonModel> {
    const thisEsList: Array<HitsModel> = (AppointmentChangeList && AppointmentChangeList.hits && AppointmentChangeList.hits.hits) ?
      AppointmentChangeList.hits.hits : [];
    if (!thisEsList || thisEsList.length === 0) {
      return [];
    }

    return thisEsList.map((thisUtilStatus: HitsModel) => {
      return {
        'lastUpdateProgramName': thisUtilStatus._source['LastUpdateProgramName'],
        'lastUpdateTimestamp':
          DateUtils.convertOffsetDateByDefaultTimeZone(thisUtilStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
        'lastUpdateUserID': thisUtilStatus._source['LastUpdateUserID'],
        'status': thisUtilStatus._source['Status'],
        'operationalPlanAppointmentChangeCode':
          thisUtilStatus._source['OperationalPlanStopAppointmentChangeReasonCode'],
        'operationalPlanAppointmentChangeDescription':
          thisUtilStatus._source['OperationalPlanStopAppointmentChangeReasonDescription'],
        'operationalPlanAppointmentChangeCategoryDescription':
          thisUtilStatus._source['OperationalPlanStopAppointmentReasonCategoryDescription'],
        'operationalPlanAppointmentChangeCategoryCode':
          thisUtilStatus._source['OperationalPlanStopAppointmentChangeReasonCategoryCode'],
        'lastUpdatedBy': `${thisUtilStatus._source['LastUpdateProgramName']}
                          (${thisUtilStatus._source['LastUpdateUserID']})`
      };
    });
  }

  static formActivateInactivateBodyParam(thisCode: string): AppointmentChangeActiveInactiveModel {
    return {
      'appointmentChangeReasonCode': thisCode
    };
  }

  static addEditAppointmentForm(formValue: FormGroup): AppointmentChangeReasonAddModel {
    return {
      operationalPlanAppointmentChangeCode: formValue.value.operationalPlanAppointmentChangeCode,
      operationalPlanAppointmentChangeDescription: formValue.value.operationalPlanAppointmentChangeDescription,
      operationalPlanAppointmentChangeCategoryCode: formValue.value.operationalPlanAppointmentChangeCategoryDescription.value
    };
  }

  static getExcelDownloadRequestBody(esQuery: object): AppointmentChangeExcelDownloadModel {
    return {
      headerDetails: {
        'Name': 'OperationalPlanStopAppointmentChangeReasonDescription',
        'Identifier': 'OperationalPlanStopAppointmentChangeReasonCode',
        'Category': 'OperationalPlanStopAppointmentReasonCategoryDescription',
        'Last Updated': 'LastUpdateTimestamp',
        'Last Updated By': 'LastUpdateProgramName, LastUpdateUserID',
        'Status': 'Status'
      },
      elasticSearchQuery: {
        query: esQuery['query'],
        sort: esQuery['sort']
      }
    };
  }

}
