import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import {
  AppointmentChangeReasonAddModel,
  AppointmentChangeActiveInactiveModel, AppointmentChangeExcelDownloadModel
} from '../model/appointment-change-reason.interface';
import { AppConfigService } from '../../../../../shared/service/app-config.service';


@Injectable()
export class AppointmentChangeReasonService {
  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }

  /* Elastic Search - POST API
    Params - Input : Elastic Search Query
  */
  getAppointmentChangeReasonList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getAppointmentChangeList, query);
  }

  addAppointmentChangeReason(queryParam: AppointmentChangeReasonAddModel): Observable<boolean> {
    return this.http.post<boolean>(this.endpoint.addAppointmentChangeReason, queryParam);
  }

  editAppointmentChangeReason(queryParam: AppointmentChangeReasonAddModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.addAppointmentChangeReason, queryParam);
  }

  inactivateAppointmentChangeReason(appointmentChangeActivateReactivateModel: AppointmentChangeActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.inactivateAppointmentChangeReason, appointmentChangeActivateReactivateModel);
  }

  reactivateAppointmentChangeReason(appointmentChangeActivateReactivateModel: AppointmentChangeActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.reactivateAppointmentChangeReason, appointmentChangeActivateReactivateModel);
  }

  appointmentChangeReasonExcelDownload(requestParam: AppointmentChangeExcelDownloadModel, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoint.referenceDataExcelDownload, requestParam, { headers, responseType: 'blob' });
  }

}
