import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { PaginatorModule, TooltipModule } from 'primeng/primeng';
import { ButtonModule } from 'primeng/button';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { configureTestSuite } from 'ng-bullet';

import { AppointmentChangeReasonComponent } from './appointment-change-reason.component';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { AppointmentChangeReasonService } from './services/appointment-change-reason.service';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { Validators, FormBuilder, FormGroup, } from '@angular/forms';
import { AppointmentChangeActiveInactiveModel, AppointmentChangeReasonAddModel } from './model/appointment-change-reason.interface';
import { UserService } from './../../../../shared/jbh-esa';
import { of } from 'rxjs/internal/observable/of';

class MockAppointmentChangeService {
  constructor() { }
  getAppointmentChangeReasonList(value: object) {
    return of(null);
  }
  reactivateAppointmentChangeReason(typeCode: AppointmentChangeActiveInactiveModel) {
    return of({});
  }
  appointmentChangeReasonExcelDownload(value: AppointmentChangeActiveInactiveModel) {
    return of(null);
  }
  inactivateAppointmentChangeReason(value: AppointmentChangeActiveInactiveModel) {
    return of({});
  }
  editAppointmentChangeReason(value: AppointmentChangeReasonAddModel) {
    return of({});
  }
  addAppointmentChangeReason(value: AppointmentChangeReasonAddModel) {
    return of({});
  }
}


describe('AppointmentChangeReasonComponent', () => {
  let component: AppointmentChangeReasonComponent;
  let fixture: ComponentFixture<AppointmentChangeReasonComponent>;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  const appointmentChangeReasonModel = {
    lastUpdateProgramName: 'string',
    lastUpdateTimestamp: 'string',
    lastUpdateUserID: 'string',
    operationalPlanAppointmentChangeCode: 'string',
    operationalPlanAppointmentChangeDescription: 'string',
    operationalPlanAppointmentChangeCategoryCode: 'string',
    operationalPlanAppointmentChangeCategoryDescription: 'string',
    status: 'string',
    lastUpdatedBy: 'string'
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NoopAnimationsModule,
        BreadcrumbModule, TableModule, FormsModule, ReactiveFormsModule, MenuModule, PaginatorModule, ButtonModule,
        JbhLoaderModule, AutoCompleteModule, PipesModule, ConfirmDialogModule, TooltipModule, DirectivesModule],
      providers: [AppConfigService, MessageService, ConfirmationService, UserService,
        { provide: AppointmentChangeReasonService, useClass: MockAppointmentChangeService }],
      declarations: [AppointmentChangeReasonComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppointmentChangeReasonComponent);
    component = fixture.componentInstance;
    formGroup = formBuilder.group({
      operationalPlanAppointmentChangeCode: ['string', Validators.required],
      operationalPlanAppointmentChangeDescription: ['', Validators.required],
      operationalPlanAppointmentChangeCategoryDescription: ['', Validators.required]
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.appointmentChangeModel.splitView).toBe(false);
  });

  it('initializeMenuItems have been called', () => {
    const menuItem = [];
    component.initializeMenuItems();
    expect(component.appointmentChangeModel.menuItems).toBeDefined(menuItem);
  });
  it('checking sortOrder value when desc', () => {
    spyOn(component, 'fetchAppointmentChangeList');
    const thisEvent = { sortOrder: -1 };
    component.onPage(thisEvent);
    expect(component.appointmentChangeModel.sortOrder).toBe('desc');
    expect(component.fetchAppointmentChangeList).toHaveBeenCalled();
  });
  it('checking sortOrder value when asc', () => {
    spyOn(component, 'fetchAppointmentChangeList');
    const thisEvent = { sortOrder: 0 };
    component.onPage(thisEvent);
    expect(component.appointmentChangeModel.sortOrder).toBe('asc');
    expect(component.fetchAppointmentChangeList).toHaveBeenCalled();
  });
  it('getCurrentScrollPosition have been called', () => {
    spyOn(component, 'fetchAppointmentChangeList');
    spyOn(component, 'getCurrentScrollPosition');
    component.onPage({});
    expect(component.getCurrentScrollPosition).toHaveBeenCalled();
    expect(component.fetchAppointmentChangeList).toHaveBeenCalled();
  });
  it('onAddNew have been called expect split tobe true', () => {
    component.onAddNew();
    expect(component.appointmentChangeModel.splitView).toBe(true);
  });
  it('onCompareOldData have been called', () => {
    const checkReturn = component.onCompareOldData();
    expect(checkReturn).toBe(true);
  });
  it('onSearch have been called and expect pagestart 0', () => {
    component.onSearch('');
    expect(component.appointmentChangeModel.pageStart).toBe(0);
  });
  it('should call fetchAllData and expect split tobe false', () => {
    component.fetchAllData();
    expect(component.appointmentChangeModel.splitView).toBe(false);
  });
  it('should call onRowSelect wiyh null', () => {
    spyOn(component, 'setContentAndLoadSplitScreen');
    component.appointmentChangeModel.selectedRowContent = null;
    component.onRowSelect(appointmentChangeReasonModel);
    expect(component.setContentAndLoadSplitScreen).toHaveBeenCalled();
  });
  it('should call onRowSelect with data', () => {
    const appointmentChange = {
      lastUpdateProgramName: 'string',
      lastUpdateTimestamp: 'string',
      lastUpdateUserID: 'string',
      operationalPlanAppointmentChangeCode: 'ssss',
      operationalPlanAppointmentChangeDescription: 'string',
      operationalPlanAppointmentChangeCategoryCode: 'string',
      operationalPlanAppointmentChangeCategoryDescription: 'string',
      status: 'string',
      lastUpdatedBy: 'string'
    };
    spyOn(component, 'setContentAndLoadSplitScreen');
    component.appointmentChangeModel.selectedRowContent = appointmentChange;
    component.onRowSelect(appointmentChangeReasonModel);
    expect(component.setContentAndLoadSplitScreen).toHaveBeenCalled();
  });
  it('should call setContentAndLoadSplitScreen and check selectRowcontent', () => {
    component.setContentAndLoadSplitScreen(appointmentChangeReasonModel);
    expect(component.appointmentChangeModel.selectedRowContent).toEqual(appointmentChangeReasonModel);
  });
  it('should call setFilteredContent with empty', () => {
    component.setFilteredContent('');
    expect(component.appointmentChangeModel.filteredDropdownLables).toBeTruthy();
  });
  it('should call setFilteredContent with string', () => {
    component.setFilteredContent('string');
    expect(component.appointmentChangeModel.filteredDropdownLables).toBeTruthy();
  });
  it('should call onClose with empty', () => {
    spyOn(component, 'closeAddEditPage');
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.appointmentChangeModel.addAppointmentChangeReasonForm.markAsUntouched();
    component.onClose();
    expect(component.closeAddEditPage).toHaveBeenCalled();
  });

  it('should call onClose with data', () => {
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.appointmentChangeModel.addAppointmentChangeReasonForm.markAsTouched();
    component.appointmentChangeModel.addAppointmentChangeReasonForm.markAsDirty();
    component.onClose();
    expect(component.onClose).toBeTruthy();
  });

  it('onCompareOldData have been called', () => {
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.appointmentChangeModel.selectedRowContent = appointmentChangeReasonModel;
    const checkReturn = component.onCompareOldData();
    expect(checkReturn).toBe(true);
  });
  it('showToastMessage have been called with input true', () => {
    component.showToastMessage(true);
    expect(component.showToastMessage).toBeTruthy();
  });
  it('showToastMessage have been called with input false', () => {
    component.showToastMessage(false);
    expect(component.showToastMessage).toBeTruthy();
  });

  it('showToastMessageForInactivateReactivate have been called with input true', () => {
    component.showToastMessageForInactivateReactivate(true);
    expect(component.showToastMessageForInactivateReactivate).toBeTruthy();
  });
  it('showToastMessageForInactivateReactivate have been called with input false', () => {
    component.showToastMessageForInactivateReactivate(false);
    expect(component.showToastMessageForInactivateReactivate).toBeTruthy();
  });

  it('should call selectedContentSplitScreen with value', () => {
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.setContentAndLoadSplitScreen(appointmentChangeReasonModel);
    expect(component.appointmentChangeModel.splitView).toBe(true);
  });

  it('setFilteredContentClear have been called', () => {
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.setFilteredContentClear();
    expect(component.setFilteredContentClear).toBeTruthy();
  });

  it('onSave have been called with selectedRowContent', () => {
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.appointmentChangeModel.selectedRowContent = appointmentChangeReasonModel;
    component.onSave();
    expect(component.appointmentChangeModel.isSectionLoaderEnabled).toBe(false);
  });
  it('onSave have been called without selectedRowContent', () => {
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.onSave();
    expect(component.appointmentChangeModel.isSectionLoaderEnabled).toBe(false);
  });
  it('onActivate have been called', () => {
    component.appointmentChangeModel.selectedRowContent = appointmentChangeReasonModel;
    component.onActivate();
    expect(component.appointmentChangeModel.isSectionLoaderEnabled).toBeFalsy();
  });
  it('onInactivate have been called', () => {
    component.appointmentChangeModel.selectedRowContent = appointmentChangeReasonModel;
    component.appointmentChangeModel.addAppointmentChangeReasonForm = formGroup;
    component.onInactivate();
    expect(component.onInactivate).toBeTruthy();
  });
});
