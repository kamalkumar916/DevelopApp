import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TooltipModule } from 'primeng/tooltip';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { ConfirmationService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { PaginatorModule } from 'primeng/paginator';

import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';

import { AppointmentChangeReasonComponent } from './appointment-change-reason.component';
import { AppointmentChangeReasonService } from './services/appointment-change-reason.service';
import { AppointmentChangeReasonRoutingModule } from './appointment-change-reason-routing.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';


@NgModule({
  imports: [
    CommonModule,
    AppointmentChangeReasonRoutingModule,
    AutoCompleteModule,
    BreadcrumbModule,
    ButtonModule,
    ConfirmDialogModule,
    FormsModule,
    TooltipModule,
    InputTextModule,
    JbhLoaderModule,
    MenuModule,
    PanelModule,
    PipesModule,
    ReactiveFormsModule,
    TableModule,
    MessagesModule,
    MessageModule,
    PaginatorModule,
    DirectivesModule
  ],
  declarations: [AppointmentChangeReasonComponent],
  providers: [ConfirmationService, AppointmentChangeReasonService]
})
export class AppointmentChangeReasonModule { }

