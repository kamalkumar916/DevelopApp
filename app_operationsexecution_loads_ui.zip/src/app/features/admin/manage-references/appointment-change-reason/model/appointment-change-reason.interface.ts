export interface TableColumnModel {
    label: string;
    key: string;
    esKey?: string;
}

export interface AppointmentChangeReasonModel {
    lastUpdateProgramName: string;
    lastUpdateTimestamp: string;
    lastUpdateUserID: string;
    operationalPlanAppointmentChangeCode: string;
    operationalPlanAppointmentChangeDescription: string;
    operationalPlanAppointmentChangeCategoryCode: string;
    operationalPlanAppointmentChangeCategoryDescription: string;
    status: string;
    lastUpdatedBy: string;
}

export interface AppointmentChangeReasonAddModel {
    operationalPlanAppointmentChangeCode: string;
    operationalPlanAppointmentChangeDescription: string;
    operationalPlanAppointmentChangeCategoryCode: string;
}

export interface AppointmentChangeActiveInactiveModel {
    appointmentChangeReasonCode: string;
}

export interface DropdownLables {
    label: string;
    value: string;
}

export interface AppointmentChangeExcelDownloadModel {
    headerDetails: object;
    elasticSearchQuery: object;
}


