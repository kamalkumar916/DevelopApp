import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';

import * as _ from 'lodash';

import { TableColumnModel, AppointmentChangeReasonModel, DropdownLables } from './appointment-change-reason.interface';
import { FormGroup } from '@angular/forms/src/model';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class AppointmentChangeModel {
  breadCrumbList: Array<MenuItem>;
  splitView: boolean;
  appointmentChangeReasonList: Array<AppointmentChangeReasonModel>;
  appointmentChangeReasonSelectedList: Array<AppointmentChangeReasonModel>;
  totalRecords: number;
  paginatorFlag: boolean;
  searchText: string;
  pageStart: number;
  tableSize: number;
  menuItems: Array<MenuItem>;
  queryString: string;
  dropdownLables: Array<DropdownLables>;
  filteredDropdownLables: Array<DropdownLables>;
  subscriberFlag: boolean;
  gridLoaderFlag: boolean;
  isSectionLoaderEnabled: boolean;
  selectedRowContent: AppointmentChangeReasonModel;
  userInputSearchSubject: Subject<string>;
  tableColumns: Array<TableColumnModel>;

  addAppointmentChangeReasonForm: FormGroup;
  editAppointmentChangeReasonForm: FormGroup;

  inactiveLabel: string;
  activeLabel: string;

  translateVariableRefDataToastHeader: string;
  translateVariableRefDataToastSummary: string;
  sortField: string;
  sortOrder: string;
  addNewButton: SecureModel;
  inactivateButton: SecureModel;
  activateButton: SecureModel;
  appConfig;

  constructor() {
    this.translateVariableRefDataToastHeader = 'ADMIN_MODULE_COMMON.REFERENCE_DATA';
    this.translateVariableRefDataToastSummary = 'APPOINTMENTCHANGEREASON_MODULE.REFERENCEDATA_DETAIL';

    this.sortField = 'defaultSort';
    this.sortOrder = 'asc';

    this.breadCrumbList = [
      { label: 'Manage References', routerLink: ['/managereferences'] },
      { label: 'Appointment Change Reason', routerLink: ['/managereferences/appointment-change-reason'] }
    ];

    this.tableColumns = [{
      'label': 'Name',
      'key': 'operationalPlanAppointmentChangeDescription',
      'esKey': 'OperationalPlanStopAppointmentChangeReasonDescription'
    },
    {
      'label': 'Identifier',
      'key': 'operationalPlanAppointmentChangeCode',
      'esKey': 'OperationalPlanStopAppointmentChangeReasonCode'
    },
    {
      'label': 'Category',
      'key': 'operationalPlanAppointmentChangeCategoryDescription',
      'esKey': 'OperationalPlanStopAppointmentReasonCategoryDescription'
    },
    {
      'label': 'Last Updated',
      'key': 'lastUpdateTimestamp',
      'esKey': 'LastUpdateTimestamp'
    },
    {
      'label': 'Last Updated By',
      'key': 'lastUpdatedBy',
      'esKey': 'LastUpdateProgramName'
    },
    {
      'label': 'Status',
      'key': 'status',
      'esKey': 'Status'
    }];

    this.dropdownLables = [{
      label: 'J.B. Hunt',
      value: 'JBH'
    }, {
      label: 'Mechanical',
      value: 'Mechanical'
    }, {
      label: 'Other',
      value: 'Other'
    }, {
      label: 'Performance',
      value: 'Performanc'
    }, {
      label: 'Rail',
      value: 'Rail'
    }, {
      label: 'Road Conditions',
      value: 'RoadCndtns'
    }, {
      label: 'Weather',
      value: 'Weather'
    }];

    this.filteredDropdownLables = _.cloneDeep(this.dropdownLables);
    this.isSectionLoaderEnabled = false;
    this.gridLoaderFlag = true;
    this.splitView = false;
    this.appointmentChangeReasonList = [];
    this.appointmentChangeReasonSelectedList = [];
    this.totalRecords = 0;
    this.paginatorFlag = false;
    this.searchText = '';
    this.pageStart = 0;
    this.tableSize = 25;
    this.menuItems = [];
    this.queryString = '';
    this.subscriberFlag = true;
    this.selectedRowContent = null;
    this.userInputSearchSubject = new Subject<string>();

    this.inactiveLabel = 'inactive';
    this.activeLabel = 'active';
    this.appConfig = AppConfig.getConfig();
    this.addNewButton = { url: this.appConfig.api.admin.addAppointmentChangeReason, operation: 'C' };
    this.inactivateButton = { url: this.appConfig.api.admin.inactivateAppointmentChangeReason, operation: 'C' };
    this.activateButton = { url: this.appConfig.api.admin.reactivateAppointmentChangeReason, operation: 'C' };
  }
}
