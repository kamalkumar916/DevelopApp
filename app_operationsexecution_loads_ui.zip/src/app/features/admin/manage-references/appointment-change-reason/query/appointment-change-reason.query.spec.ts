import { AppointmentChangeReasonQuery } from './appointment-change-reason.query';

describe('AppointmentChangeReasonQuery', () => {
    it('getAppointmentChangeListFromES have been called', () => {
        const result = AppointmentChangeReasonQuery.getAppointmentChangeListFromES('string', 11, 11, 'string', 'string');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = AppointmentChangeReasonQuery.getSortQuery('12', 'OperationalPlanStopAppointmentChangeReasonCode');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = AppointmentChangeReasonQuery.getSortQuery('12', 'LastUpdateProgramName');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = AppointmentChangeReasonQuery.getSortQuery('12', 'LastUpdateTimestamp');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = AppointmentChangeReasonQuery.getSortQuery('12', 'defaultSort');
        expect(result).toBeTruthy();
    });
});
