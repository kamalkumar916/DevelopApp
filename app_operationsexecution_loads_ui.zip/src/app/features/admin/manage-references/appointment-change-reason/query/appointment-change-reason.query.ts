export class AppointmentChangeReasonQuery {
  static getAppointmentChangeListFromES(searchString: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size,
      query: {
        bool: {
          should: [
            {
              query_string: {
                fields: [
                  'LastUpdateProgramName',
                  'LastUpdateTimestamp.text',
                  'LastUpdateUserID',
                  'OperationalPlanStopAppointmentChangeReasonCode',
                  'OperationalPlanStopAppointmentChangeReasonDescription',
                  'OperationalPlanStopAppointmentChangeReasonCategoryCode',
                  'OperationalPlanStopAppointmentReasonCategoryDescription',
                  'Status'
                ],
                query: `*${searchString}*`,
                default_operator: 'AND'
              }
            }
          ]
        }
      },
      sort: this.getSortQuery(sortOrder, sortField),
      _source: [
        'LastUpdateProgramName',
        'LastUpdateTimestamp',
        'LastUpdateUserID',
        'OperationalPlanStopAppointmentChangeReasonCode',
        'OperationalPlanStopAppointmentChangeReasonDescription',
        'OperationalPlanStopAppointmentChangeReasonCategoryCode',
        'OperationalPlanStopAppointmentReasonCategoryDescription',
        'Status'
      ]
    };
  }

  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'OperationalPlanStopAppointmentChangeReasonCode':
      case 'OperationalPlanStopAppointmentChangeReasonDescription':
      case 'OperationalPlanStopAppointmentReasonCategoryDescription':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'OperationalPlanStopAppointmentChangeReasonDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }

}
