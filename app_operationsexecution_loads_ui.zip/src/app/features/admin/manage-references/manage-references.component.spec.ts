import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageReferencesComponent } from './manage-references.component';
import { configureTestSuite } from 'ng-bullet';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../shared/service/app-config.service';
import { ManageReferencesModule } from './manage-references.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ManageReferencesComponent', () => {
  let component: ManageReferencesComponent;
  let fixture: ComponentFixture<ManageReferencesComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ManageReferencesModule, NoopAnimationsModule, HttpClientTestingModule],
      providers: [AppConfigService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageReferencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('onSearch have been called', () => {
    const rowData = {
      label: 'Utilization Status',
      value: 'utilization-status'
    };
    component.searchText = 'Utilization Status';
    component.onSearch();
    expect(rowData.label).toBe(component.searchText);
  });
});
