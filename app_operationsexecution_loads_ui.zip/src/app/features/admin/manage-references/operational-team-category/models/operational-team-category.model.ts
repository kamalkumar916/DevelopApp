import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';

import { OperationalTeamCategoryListModel, TableColumnModel } from './operational-team-category.interface';
import { AppConfig } from '../../../../../../config/app.config';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';

export class OperationalTeamCategoryModel {
  items: Array<MenuItem>;
  splitView: boolean;
  operationalTeamCategoryList: Array<OperationalTeamCategoryListModel>;
  operationalTeamCategorySelectedList: Array<OperationalTeamCategoryListModel>;
  paginatorFlag: boolean;
  totalRecords: number;
  pageStart: number;
  tableSize: number;
  queryString: string;
  searchText: string;
  subscriberFlag: boolean;
  isSectionLoaderEnabled: boolean;
  tableColumns: Array<TableColumnModel>;
  userInputSearchSubject: Subject<string>;
  addOperationalTeamCategoryStatusForm: FormGroup;
  inactiveLabel: string;
  activeLabel: string;
  selectedRowContent: OperationalTeamCategoryListModel;
  operationalWorkOrderLabel: string;
  operationalPlanLabel: string;
  lableValue: boolean;
  sortOrder: string;
  sortField: string;
  gridLoaderFlag: boolean;
  information: string;
  successMessage: string;
  referenceData: string;
  title: string;
  addNewButton: SecureModel;
  inactivateButton: SecureModel;
  activateButton: SecureModel;
  appConfig;

  constructor() {
    this.splitView = false;
    this.operationalTeamCategoryList = [];
    this.operationalTeamCategorySelectedList = [];
    this.paginatorFlag = false;
    this.totalRecords = 0;
    this.pageStart = 0;
    this.tableSize = 25;
    this.queryString = '';
    this.searchText = '';
    this.subscriberFlag = true;
    this.isSectionLoaderEnabled = false;
    this.userInputSearchSubject = new Subject<string>();
    this.selectedRowContent = null;
    this.inactiveLabel = 'inactive';
    this.activeLabel = 'active';
    this.sortField = 'defaultSort';
    this.sortOrder = 'asc';
    this.gridLoaderFlag = true;
    this.title = 'Operational Team Category';
    this.information = 'ADMIN_MODULE_COMMON.INFORMATION';
    this.successMessage = 'ADMIN_MODULE_COMMON.REFERENCE_DATA';
    this.referenceData = 'TYPECATEGORY.REFERENCEDATA_DETAIL';
    this.tableColumns = [
      { 'label': 'Name', 'key': 'operationalGroupTypeDescription', 'esKey': 'OperationalGroupTypeDescription' },
      { 'label': 'Identifier', 'key': 'operationalGroupTypeCode', 'esKey': 'OperationalGroupTypeCode' },
      { 'label': 'Last Updated', 'key': 'lastUpdateTimestamp', 'esKey': 'LastUpdateTimestamp' },
      { 'label': 'Last Updated By', 'key': 'lastUpdatedBy', 'esKey': 'LastUpdateProgramName' },
      { 'label': 'Status', 'key': 'status', 'esKey': 'Status' }];
    this.appConfig = AppConfig.getConfig();
    this.addNewButton = { url: this.appConfig.api.admin.saveOperationalTeamCategory, operation: 'C' };
    this.inactivateButton = { url: this.appConfig.api.admin.inactivateOperationalTeamCategoryStatus, operation: 'C' };
    this.activateButton = { url: this.appConfig.api.admin.reactivateOperationalTeamCategoryStatus, operation: 'C' };
  }

}
