export interface TableColumnModel {
  label: string;
  key: string;
  esKey: string;
}

export interface OperationalTeamCategoryListModel {
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateProgramName: string;
  lastUpdateTimestamp: string;
  lastUpdateUserID: string;
  operationalGroupTypeCode: string;
  operationalGroupTypeDescription: string;
  status: string;
}

export interface OperationalTeamCategoryListAddModel {
  operationalGroupTypeDescription: string;
  operationalGroupTypeCode: string;
}

export interface OperationalTeamCategoryActiveInactiveModel {
  operationalGroupTypeCode: string;
}

export interface InactiveData {
  operationalGroupTypeCode: boolean;
  _links: Links;
}

export interface Links {
  self: Self;
}

export interface Self {
  href: string;
}

export interface SortView {
  first: number;
  rows: number;
  sortField: string;
  sortOrder: number;
}
