import { OperationalTeamCategoryUtils } from './operational-team-category-utils';


describe('OperationalTeamCategoryUtils', () => {
    const elasticResponse = {
        hits: {
            hits: [{
                sort: [
                    'string',
                ],
                _id: 'string',
                _index: 'string',
                _score: 1,
                _source: {
                    EffectiveTimestamp: 'string',
                    ExpirationTimestamp: 'string',
                    LastUpdateProgramName: 'string',
                    LastUpdateTimestamp: 'string',
                    LastUpdateUserID: 'string',
                    Status: 'string',
                    OperationalGroupSubtypeCode: 'string',
                    ServiceOfferingCode: 'string',
                    FinanceBusinessUnitCode: 'string',
                    CapacityEvaluationAssociationID: 'string',
                },
                _type: 'string',
            }],
            max_score: 1,
            total: 1,
        },
        timed_out: true,
        took: 1,
        _shards: {
            total: 1,
            successful: 1,
            skipped: 1,
            failed: 1,
        },
    };
    it('getOperationalTeamCategoryListData have been called', () => {
        const result = OperationalTeamCategoryUtils.getOperationalTeamCategoryListData(elasticResponse);
        expect(result).toBeTruthy();
    });

    it('activateInactivateContent have been called with string', () => {
        const result = OperationalTeamCategoryUtils.activateInactivateContent('string');
        expect(result).toBeTruthy();
    });


    it('getExcelDownloadRequestBody have been called', () => {
        const data = {
            query: 'string',
            sort: 'string'
        };
        const result = OperationalTeamCategoryUtils.getExcelDownloadRequestBody(data);
        expect(result).toBeTruthy();
    });
});
