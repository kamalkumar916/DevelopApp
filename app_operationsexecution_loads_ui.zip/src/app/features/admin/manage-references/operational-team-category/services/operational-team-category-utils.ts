import {
  OperationalTeamCategoryListModel, OperationalTeamCategoryActiveInactiveModel
} from '../models/operational-team-category.interface';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class OperationalTeamCategoryUtils {

  constructor() { }

  static getOperationalTeamCategoryListData(operationalTeamCategoryList: ElasticResponseModel): OperationalTeamCategoryListModel[] {
    let returnData: OperationalTeamCategoryListModel[] = [];
    if (operationalTeamCategoryList && operationalTeamCategoryList.hits && operationalTeamCategoryList.hits.hits) {
      returnData = operationalTeamCategoryList.hits.hits.map((operationalTeamCategoryStatus: HitsModel) => {
        return {
          'effectiveTimestamp': operationalTeamCategoryStatus._source.EffectiveTimestamp,
          'expirationTimestamp': operationalTeamCategoryStatus._source.ExpirationTimestamp,
          'lastUpdateProgramName': operationalTeamCategoryStatus._source.LastUpdateProgramName,
          'lastUpdateTimestamp':
          DateUtils.convertOffsetDateByDefaultTimeZone(
            operationalTeamCategoryStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
          'lastUpdateUserID': operationalTeamCategoryStatus._source.LastUpdateUserID,
          'status': operationalTeamCategoryStatus._source.Status,
          'operationalGroupTypeCode': operationalTeamCategoryStatus._source.OperationalGroupTypeCode,
          'operationalGroupTypeDescription': operationalTeamCategoryStatus._source.OperationalGroupTypeDescription,
          'lastUpdatedBy': `${operationalTeamCategoryStatus._source.LastUpdateProgramName}
          ${'('}${operationalTeamCategoryStatus._source.LastUpdateUserID}${')'}`
        };
      });
    }
    return returnData;
  }

  static activateInactivateContent(typeCode: string): OperationalTeamCategoryActiveInactiveModel {
    return {
      'operationalGroupTypeCode': typeCode
    };
  }

  static getExcelDownloadRequestBody(esQuery: object) {
    return {
        query: esQuery['query'],
        sort: esQuery['sort']
    };
  }
}
