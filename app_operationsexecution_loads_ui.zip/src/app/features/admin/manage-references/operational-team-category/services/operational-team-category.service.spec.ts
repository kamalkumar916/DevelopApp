import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { OperationalTeamCategoryService } from './operational-team-category.service';
import { configureTestSuite } from 'ng-bullet';

describe('OperationalTeamCategoryService', () => {
  configureTestSuite(() => TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AppConfigService, OperationalTeamCategoryService]
    }));

  it('should be created', () => {
    const service: OperationalTeamCategoryService = TestBed.get(OperationalTeamCategoryService);
    expect(service).toBeTruthy();
  });
});
