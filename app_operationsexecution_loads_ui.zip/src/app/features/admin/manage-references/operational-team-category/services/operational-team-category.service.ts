import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import {
  OperationalTeamCategoryListAddModel, OperationalTeamCategoryActiveInactiveModel, InactiveData
} from '../models/operational-team-category.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';


@Injectable()
export class OperationalTeamCategoryService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }

  /* Elastic Search - POST API
      Params - Input : Elastic Search Query
    */
  getOperationalTeamCategoryList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getOperationalTeamCategoryList, query);
  }

  saveOperationalTeamCategoryList(query: OperationalTeamCategoryListAddModel): Observable<boolean> {
    return this.http.post<boolean>(this.endpoint.saveOperationalTeamCategory, query);
  }

  editOperationalTeamCategoryList(query: OperationalTeamCategoryListAddModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.saveOperationalTeamCategory, query);
  }

  inactivateOperationalTeamCategoryList(operationalTeamCategoryCodeModel: OperationalTeamCategoryActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.inactivateOperationalTeamCategoryStatus, operationalTeamCategoryCodeModel);
  }

  reactivateOperationalTeamCategoryList(operationalTeamCategoryCodeModel: OperationalTeamCategoryActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.reactivateOperationalTeamCategoryStatus, operationalTeamCategoryCodeModel);
  }

  inactiveError(identifier: string): Observable<InactiveData> {
    return this.http.get<InactiveData>(`${this.endpoint.saveOperationalTeamCategory}${'?operationalGroupTypeCode='}${identifier}`);
  }

  teamCategoryExcelDownload(requestParam, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoint.teamCategoryExportExcel, requestParam, { headers, responseType: 'blob' });
  }
}
