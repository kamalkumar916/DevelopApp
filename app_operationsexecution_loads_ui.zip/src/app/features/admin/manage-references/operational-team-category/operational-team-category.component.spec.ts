import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MessageModule } from 'primeng/message';
import { MessagesModule } from 'primeng/messages';
import { MessageService } from 'primeng/components/common/messageservice';
import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService, TooltipModule } from 'primeng/primeng';
import { configureTestSuite } from 'ng-bullet';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { OperationalTeamCategoryComponent } from './operational-team-category.component';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { OperationalTeamCategoryService } from './services/operational-team-category.service';
import { Validators, FormBuilder, FormGroup, } from '@angular/forms';
import { UserService } from './../../../../shared/jbh-esa';
import { of } from 'rxjs/internal/observable/of';
import { OperationalTeamCategoryActiveInactiveModel } from './models/operational-team-category.interface';

const inactivedata = {
  operationalGroupTypeCode: true,
  _links: {
    self: {
      href: 'string'
    }
  }
};

class MockOperationalTeamService {
  constructor() { }
  inactiveError(requestParam: string) {
    return of(inactivedata);
  }
  reactivateOperationalTeamCategoryList(value: OperationalTeamCategoryActiveInactiveModel) {
    return of({});
  }
  inactivateOperationalTeamCategoryList(value: OperationalTeamCategoryActiveInactiveModel) {
    return of({});
  }
  getOperationalTeamCategoryList(query: object) {
    return of(null);
  }
  teamCategoryExcelDownload(value: any) {
    return of(null);
  }
}

describe('OperationalTeamCategoryComponent', () => {
  let component: OperationalTeamCategoryComponent;
  let fixture: ComponentFixture<OperationalTeamCategoryComponent>;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  const operationalCategoryListModel = {
    effectiveTimestamp: 'string',
    expirationTimestamp: 'string',
    lastUpdateProgramName: 'string',
    lastUpdateTimestamp: 'string',
    lastUpdateUserID: 'string',
    operationalGroupTypeCode: 'string',
    operationalGroupTypeDescription: 'string',
    status: 'string',
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, DirectivesModule, NoopAnimationsModule,
        TableModule, FormsModule, MenuModule, ButtonModule, ReactiveFormsModule, JbhLoaderModule, MessageModule,
        MessagesModule, ConfirmDialogModule, PipesModule, TooltipModule],
      providers: [AppConfigService, MessageService, ConfirmationService,
        { provide: OperationalTeamCategoryService, useClass: MockOperationalTeamService }, UserService],
      declarations: [OperationalTeamCategoryComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OperationalTeamCategoryComponent);
    component = fixture.componentInstance;
    formGroup = formBuilder.group({
      owoTypeDescription: ['string', Validators.required],
      owoTypeCode: ['', Validators.required]
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.operationalTeamCategoryModel.splitView).toBe(false);
  });
  it('fetchAllData have been called', () => {
    spyOn(component, 'fetchOperationalTeamCategoryListData');
    component.fetchAllData();
    expect(component.operationalTeamCategoryModel.isSectionLoaderEnabled).toBe(false);
    expect(component.fetchOperationalTeamCategoryListData).toHaveBeenCalled();
  });

  it('onCompareOldData have been called', () => {
    expect(component.onCompareOldData()).toBe(true);
  });
  it('onAddNew have been called', () => {
    component.onAddNew();
    expect(component.operationalTeamCategoryModel.splitView).toBe(true);
  });
  it('onSearch have been called', () => {
    component.onSearch('string');
    expect(component.operationalTeamCategoryModel.pageStart).toBe(0);
  });
  it('showToastMsgForReactivateInactivate have been called', () => {
    component.showToastMsgForReactivateInactivate(true);
    expect(component.showToastMsgForReactivateInactivate).toBeTruthy();
  });
  it('showToastMsgForReactivateInactivate have been called', () => {
    component.showToastMsgForReactivateInactivate(false);
    expect(component.showToastMsgForReactivateInactivate).toBeTruthy();
  });
  it('showToastMessage have been called', () => {
    component.showToastMessage(true);
    expect(component.showToastMessage).toBeTruthy();
  });
  it('showToastMessage have been called', () => {
    component.showToastMessage(false);
    expect(component.showToastMessage).toBeTruthy();
  });
  it('should call closeSplitView and expect fetchlistdata method has called', () => {
    spyOn(component, 'fetchOperationalTeamCategoryListData');
    component.closeSplitView();
    expect(component.fetchOperationalTeamCategoryListData).toHaveBeenCalled();
  });
  it('checking sortOrder value when desc', () => {
    spyOn(component, 'fetchOperationalTeamCategoryListData');
    const thisEvent = {
      sortOrder: -1,
      first: 1,
      rows: 1,
      sortField: 'string'
    };
    component.onPage(thisEvent);
    expect(component.operationalTeamCategoryModel.sortOrder).toBe('desc');
    expect(component.fetchOperationalTeamCategoryListData).toHaveBeenCalled();
  });
  it('checking sortOrder value when asc', () => {
    spyOn(component, 'fetchOperationalTeamCategoryListData');
    const thisEvent = {
      sortOrder: 0,
      first: 1,
      rows: 1,
      sortField: 'string'
    };
    component.onPage(thisEvent);
    expect(component.operationalTeamCategoryModel.sortOrder).toBe('asc');
    expect(component.fetchOperationalTeamCategoryListData).toHaveBeenCalled();
  });
  it('onCompareOldData have been called', () => {
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.operationalTeamCategoryModel.selectedRowContent = operationalCategoryListModel;
    const checkReturn = component.onCompareOldData();
    expect(checkReturn).toBe(false);
  });
  it('onSave have been called with selectedRowContent', () => {
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.operationalTeamCategoryModel.selectedRowContent = operationalCategoryListModel;
    component.onSave();
    expect(component.operationalTeamCategoryModel.isSectionLoaderEnabled).toBe(false);
  });
  it('onSave have been called without selectedRowContent', () => {
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.onSave();
    expect(component.operationalTeamCategoryModel.isSectionLoaderEnabled).toBe(false);
  });
  it('should call onCancel with value', () => {
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.markAsTouched();
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.markAsDirty();
    component.onCancel();
    expect(component.operationalTeamCategoryModel.splitView).toBe(false);
  });
  it('should call onCancel with empty', () => {
    spyOn(component, 'closeSplitView');
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.markAsUntouched();
    component.onCancel();
    expect(component.closeSplitView).toHaveBeenCalled();
  });
  it('should call onRowSelect with value', () => {
    const data = {
      effectiveTimestamp: 'string',
      expirationTimestamp: 'string',
      lastUpdateProgramName: 'string',
      lastUpdateTimestamp: 'string',
      lastUpdateUserID: 'string',
      operationalGroupTypeCode: '',
      operationalGroupTypeDescription: 'string',
      status: 'string',
    };
    component.operationalTeamCategoryModel.selectedRowContent = data;
    spyOn(component, 'splitScreenEditAdd');
    component.onRowSelect(operationalCategoryListModel);
    expect(component.splitScreenEditAdd).toHaveBeenCalled();
  });
  it('should call onRowSelect with null', () => {
    component.operationalTeamCategoryModel.selectedRowContent = null;
    spyOn(component, 'splitScreenEditAdd');
    component.onRowSelect(operationalCategoryListModel);
    expect(component.splitScreenEditAdd).toHaveBeenCalled();
  });
  it('splitScreenEditAdd have been called', () => {
    component.splitScreenEditAdd(operationalCategoryListModel);
    expect(component.splitScreenEditAdd).toBeTruthy();
  });
  it('selectedContentSplitScreen have been called', () => {
    component.selectedContentSplitScreen(operationalCategoryListModel);
    expect(component.operationalTeamCategoryModel.isSectionLoaderEnabled).toBe(false);
  });
  it('exportToExcel have been called with operationalWorkOrderLabel', () => {
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.exportToExcel();
    expect(component.exportToExcel).toBeTruthy();
  });
  it('onInactivate have been called', () => {
    component.operationalTeamCategoryModel.selectedRowContent = operationalCategoryListModel;
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.onInactivate();
    expect(component.onInactivate).toBeTruthy();
  });
  it('onActivate have been called', () => {
    component.operationalTeamCategoryModel.selectedRowContent = operationalCategoryListModel;
    component.onActivate();
    expect(component.operationalTeamCategoryModel.isSectionLoaderEnabled).toBeTruthy();
  });
  it('inactivatePlanOrWorkOrder have been called', () => {
    component.operationalTeamCategoryModel.selectedRowContent = operationalCategoryListModel;
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.inactivatePlanOrWorkOrder();
    expect(component.inactivatePlanOrWorkOrder).toBeTruthy();
  });
  it('fetchOperationalTeamCategoryListData have been called', () => {
    component.fetchOperationalTeamCategoryListData();
    expect(component.fetchOperationalTeamCategoryListData).toBeTruthy();
  });
  it('editServicePlanOrWorkOrder have been called with operationalWorkOrderLabel', () => {
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.editServicePlanOrWorkOrder();
    expect(component.editServicePlanOrWorkOrder).toBeTruthy();
  });
  it('saveServicePlanOrWorkOrder have been called with operationalWorkOrderLabel', () => {
    component.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = formGroup;
    component.saveServicePlanOrWorkOrder();
    expect(component.saveServicePlanOrWorkOrder).toBeTruthy();
  });
});
