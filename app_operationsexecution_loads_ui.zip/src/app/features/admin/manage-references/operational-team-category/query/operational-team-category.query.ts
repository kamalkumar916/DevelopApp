export class OperationalTeamCategoryQuery {
  static getOperationalTeamCategoryListFromES(searchText: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      'from': start,
      'size': size,
      'query': {
        'bool': {
          'should': [
            {
              'query_string': {
                'fields': [
                  'LastUpdateTimestamp.text',
                  'LastUpdateProgramName',
                  'LastUpdateUserID'
                ],
                'query': `*${searchText.replace(/[[\]{}()*:\-'~&!\/?\\^$|]/g, '\\$&')}*`,
                'default_operator': 'AND'
              }
            },
            {
              'query_string': {
                'default_field': 'Status',
                'query': `*${searchText.replace(/[[\]{}()*:\-'~&!\/?\\^$|]/g, '\\$&')}*`,
                'default_operator': 'AND'
              }
            },
            {
              'query_string': {
                'fields': [
                  'OperationalGroupTypeCode'
                ],
                'query': `*${searchText.replace(/[[\]{}()*:\-'~&!\/?\\^$|]/g, '\\$&')}*`,
                'default_operator': 'AND'
              }
            },
            {
              'query_string': {
                'fields': [
                  'OperationalGroupTypeDescription'
                ],
                'query': `*${searchText.replace(/[[\]{}()*:\-'~&!\/?\\^$|]/g, '\\$&')}*`,
                'default_operator': 'AND'
              }
            }
          ]
        }
      },
      'sort': [
        this.getSortQuery(sortOrder, sortField)
      ],
      '_source': [
        'OperationalGroupTypeDescription',
        'OperationalGroupTypeCode',
        'LastUpdateTimestamp',
        'LastUpdateProgramName',
        'LastUpdateUserID',
        'Status'
      ]
    };
  }
  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'OperationalGroupTypeCode':
      case 'OperationalGroupTypeDescription':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'OperationalGroupTypeDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }

}

