import { OperationalTeamCategoryQuery } from './operational-team-category.query';

describe('OperationalTeamCategoryQuery', () => {
    it('getOperationalTeamCategoryListFromES have been called', () => {
        const result = OperationalTeamCategoryQuery.getOperationalTeamCategoryListFromES('string', 11, 11, 'string', 'string');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamCategoryQuery.getSortQuery('12', 'OperationalGroupTypeCode');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamCategoryQuery.getSortQuery('12', 'LastUpdateProgramName');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamCategoryQuery.getSortQuery('12', 'LastUpdateTimestamp');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamCategoryQuery.getSortQuery('12', 'defaultSort');
        expect(result).toBeTruthy();
    });
});
