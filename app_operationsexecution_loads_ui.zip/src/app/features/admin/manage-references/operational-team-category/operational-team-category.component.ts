import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import * as LodashUtils from 'lodash';
import * as moment from 'moment';

import { OperationalTeamCategoryModel } from './models/operational-team-category.model';
import { OperationalTeamCategoryService } from './services/operational-team-category.service';
import { OperationalTeamCategoryUtils } from './services/operational-team-category-utils';
import { OperationalTeamCategoryQuery } from './query/operational-team-category.query';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import {
  OperationalTeamCategoryListModel, OperationalTeamCategoryListAddModel, InactiveData, SortView
} from './models/operational-team-category.interface';

@Component({
  selector: 'app-operational-team-category',
  templateUrl: './operational-team-category.component.html',
  styleUrls: ['./operational-team-category.component.scss'],
  providers: [OperationalTeamCategoryService],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class OperationalTeamCategoryComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('teamCategoryDownloadExcel') teamCategoryDownloadExcel: ElementRef;
  operationalTeamCategoryModel: OperationalTeamCategoryModel;
  msgs: Message[] = [];
  defaultSort = 'Status';

  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly confirmationService: ConfirmationService,
    private readonly operationalTeamCategoryService: OperationalTeamCategoryService,
    private readonly messageService: MessageService,
    private readonly formBuilder: FormBuilder) {
    this.operationalTeamCategoryModel = new OperationalTeamCategoryModel();
  }

  ngOnInit() {
    this.searchInput();
    this.overFlowMenuOptions();
  }

  ngOnDestroy() {
    this.operationalTeamCategoryModel.subscriberFlag = false;
  }

  get teamCategoryControls() {
    return this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.controls;
  }
  onPage(thisEvent: SortView) {
    this.getCurrentScrollPosition();
    this.operationalTeamCategoryModel.pageStart = thisEvent.first;
    this.operationalTeamCategoryModel.tableSize = thisEvent.rows;
    this.operationalTeamCategoryModel.sortField = thisEvent.sortField;
    this.operationalTeamCategoryModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchOperationalTeamCategoryListData();
  }

  onAddOperationalTeamCategoryForm(): FormGroup {
    return this.formBuilder.group({
      owoTypeDescription: ['', Validators.required],
      owoTypeCode: ['', Validators.required]
    });
  }
  onAddNew() {
    this.msgs = [];
    this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = this.onAddOperationalTeamCategoryForm();
    this.operationalTeamCategoryModel.splitView = true;
  }

  overFlowMenuOptions() {
    this.operationalTeamCategoryModel.items = [
      {
        label: 'Export to Excel',
        command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }
  exportToExcel() {
    this.operationalTeamCategoryService.teamCategoryExcelDownload(OperationalTeamCategoryUtils.getExcelDownloadRequestBody(
      OperationalTeamCategoryQuery.getOperationalTeamCategoryListFromES(this.operationalTeamCategoryModel.queryString,
        this.operationalTeamCategoryModel.pageStart, this.operationalTeamCategoryModel.tableSize,
        this.operationalTeamCategoryModel.sortOrder, this.operationalTeamCategoryModel.sortField)))
      .pipe(
        takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag),
      ).subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `${
            this.operationalTeamCategoryModel.title} ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.teamCategoryDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }
  downloadThisExcelFile(data: Blob, teamCategoryDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      teamCategoryDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      teamCategoryDownloadExcel.nativeElement.download = fileName;
      teamCategoryDownloadExcel.nativeElement.click();
    }
  }
  fetchOperationalTeamCategoryListData() {
    this.operationalTeamCategoryService.getOperationalTeamCategoryList(OperationalTeamCategoryQuery.getOperationalTeamCategoryListFromES(
      this.operationalTeamCategoryModel.queryString, this.operationalTeamCategoryModel.pageStart
      , this.operationalTeamCategoryModel.tableSize, this.operationalTeamCategoryModel.sortOrder,
      this.operationalTeamCategoryModel.sortField)).pipe(takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag),
        finalize(() => {
          this.operationalTeamCategoryModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((operationalTeamCategoryList: ElasticResponseModel) => {
        if (!LodashUtils.isEmpty(operationalTeamCategoryList) && !LodashUtils.isEmpty(operationalTeamCategoryList.hits)
          && LodashUtils.isEmpty(operationalTeamCategoryList.hits.total)) {
          this.operationalTeamCategoryModel.gridLoaderFlag =
            !(this.operationalTeamCategoryModel.operationalTeamCategoryList.length > 0);
          this.operationalTeamCategoryModel.totalRecords = operationalTeamCategoryList.hits.total;
          this.operationalTeamCategoryModel.operationalTeamCategoryList =
            OperationalTeamCategoryUtils.getOperationalTeamCategoryListData(operationalTeamCategoryList);
          this.operationalTeamCategoryModel.paginatorFlag =
            this.operationalTeamCategoryModel.operationalTeamCategoryList.length > 0;
        }
      }, (error: Error) => {
        this.operationalTeamCategoryModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }

  onSearch(event) {
    this.operationalTeamCategoryModel.userInputSearchSubject.next(event);
    this.operationalTeamCategoryModel.pageStart = 0;
  }

  searchInput() {
    this.operationalTeamCategoryModel.userInputSearchSubject.
      pipe(debounceTime(300), distinctUntilChanged(), takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag))
      .subscribe(() => {
        if (this.operationalTeamCategoryModel.searchText.length === 0 || this.operationalTeamCategoryModel.searchText.length > 2) {
          this.operationalTeamCategoryModel.queryString = this.operationalTeamCategoryModel.searchText;
          this.fetchOperationalTeamCategoryListData();
        } else {
          this.operationalTeamCategoryModel.queryString = '';
          this.fetchOperationalTeamCategoryListData();
        }
      });
  }
  onCompareOldData() {
    if (this.operationalTeamCategoryModel.selectedRowContent) {
      const nameRowValue = this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeDescription;
      const nameFieldValue = this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.controls.
        owoTypeDescription.value;
      return (nameRowValue !== nameFieldValue);
    } else {
      return true;
    }
  }
  onSave() {
    if (this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.valid &&
      (this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.dirty
        &&
        this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.touched) && this.onCompareOldData()) {
      this.operationalTeamCategoryModel.isSectionLoaderEnabled = true;
      if (this.operationalTeamCategoryModel.selectedRowContent) {
        this.editServicePlanOrWorkOrder();
      } else {
        this.saveServicePlanOrWorkOrder();
      }
    } else if (this.operationalTeamCategoryModel.selectedRowContent) {
      if (this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.valid) {
        this.messageService.clear();
        this.messageService.add({
          severity: 'info',
          summary: 'No Changes Detected',
        detail: `You've not done any changes to Operational Team Category.`
        });
      }
    } else {
      this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.controls.owoTypeCode.markAsTouched();
      this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.controls.owoTypeDescription.markAsTouched();
    }
  }

  editServicePlanOrWorkOrder() {
    const editDetailsPlan: OperationalTeamCategoryListAddModel = {
      operationalGroupTypeDescription:
        this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.value.owoTypeDescription,
      operationalGroupTypeCode: this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.value.owoTypeCode
    };
    this.operationalTeamCategoryService.editOperationalTeamCategoryList(editDetailsPlan)
      .pipe(takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag),
        finalize(() => this.operationalTeamCategoryModel.selectedRowContent = null))
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(true);
      });
  }

  saveServicePlanOrWorkOrder() {
    const saveDetailsPlan: OperationalTeamCategoryListAddModel = {
      operationalGroupTypeDescription:
        this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.value.owoTypeDescription,
      operationalGroupTypeCode: this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.value.owoTypeCode
    };
    this.operationalTeamCategoryService.saveOperationalTeamCategoryList(saveDetailsPlan)
      .pipe(takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag)).subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(false);
      }, (err: Error) => {
        this.onServiceError(err);
      });
    this.operationalTeamCategoryModel.isSectionLoaderEnabled = false;
  }

  onServiceError(err: Error) {
    if (err['status'] === 409) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'error',
        summary: 'Duplicate Reference Data',
        detail: `The reference data already exists. So, you can't add this reference data.`
      });
    }
  }

  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isEditMode) ? 'Reference Data Updated' : 'Reference Data Added',
      detail: (isEditMode) ? 'Operational Team Category has been successfully updated.' :
        'Operational Team Category has been successfully added.'
    });
    this.changeDetector.detectChanges();
  }

  fetchAllData() {
    this.operationalTeamCategoryModel.searchText = this.operationalTeamCategoryModel.queryString = '';
    this.fetchOperationalTeamCategoryListData();
    this.operationalTeamCategoryModel.isSectionLoaderEnabled = false;
    this.operationalTeamCategoryModel.splitView = false;
    this.changeDetector.detectChanges();
  }

  onCancel() {
    if (this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.touched
      && this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'OperationalTeamCategory',
        accept: (): void => {
          this.closeSplitView();
          this.operationalTeamCategoryModel.splitView = false;
        }
      });
    } else {
      this.closeSplitView();
    }
  }
  closeSplitView() {
    this.fetchOperationalTeamCategoryListData();
    this.closeAddEditPage();
  }
  onRowSelect(selectedRow: OperationalTeamCategoryListModel) {
    this.operationalTeamCategoryModel.isSectionLoaderEnabled = true;
    if (this.operationalTeamCategoryModel.selectedRowContent && selectedRow.operationalGroupTypeCode !==
      this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeCode) {
      this.splitScreenEditAdd(selectedRow);
    } else if (!this.operationalTeamCategoryModel.selectedRowContent) {
      this.splitScreenEditAdd(selectedRow);
    }
  }
  splitScreenEditAdd(selectedRow: OperationalTeamCategoryListModel) {
    this.operationalTeamCategoryService.inactiveError(selectedRow.operationalGroupTypeCode)
      .pipe(takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag)).subscribe((inactivateData: InactiveData) => {
        this.operationalTeamCategoryModel.lableValue = inactivateData.operationalGroupTypeCode;
        if (this.operationalTeamCategoryModel.lableValue) {
          this.msgs = [];
          this.msgs.push({
            severity: 'info',
            summary: ' ',
            detail: 'You can\'t inactivate this reference data as it is currently associated to an active Operational Team'
          });
        }
        this.selectedContentSplitScreen(selectedRow);
        this.changeDetector.detectChanges();
      });
  }
  selectedContentSplitScreen(selectedContent: OperationalTeamCategoryListModel) {
    this.operationalTeamCategoryModel.selectedRowContent = selectedContent;
    this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm = this.onAddOperationalTeamCategoryForm();
    this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.patchValue({
      owoTypeDescription: selectedContent.operationalGroupTypeDescription,
      owoTypeCode: selectedContent.operationalGroupTypeCode
    });
    this.operationalTeamCategoryModel.splitView = true;
    this.operationalTeamCategoryModel.isSectionLoaderEnabled = false;
  }

  closeAddEditPage() {
    this.operationalTeamCategoryModel.selectedRowContent = null;
    this.operationalTeamCategoryModel.splitView = false;
  }

  onActivate() {
    this.operationalTeamCategoryModel.isSectionLoaderEnabled = true;
    this.operationalTeamCategoryService.reactivateOperationalTeamCategoryList(OperationalTeamCategoryUtils.activateInactivateContent
      (this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeCode))
      .pipe(takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag),
        finalize(() => {
          this.operationalTeamCategoryModel.selectedRowContent = null;
        }))
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(false);
      });
  }

  onInactivate() {
    this.operationalTeamCategoryModel.addOperationalTeamCategoryStatusForm.patchValue({
      owoTypeDescription: this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeDescription,
      owoTypeCode: this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeCode
    });
    this.confirmationService.confirm({
      message: `Operational Team Category<br><b>
      ${this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeDescription}
      (${this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeCode})
      </b><br><br>The reference data you're about to inactivate may be associated to
       active orders or other entities, inactivating the data will not impact current
       associations but <b>new entities can no longer reference this record.</b><br><br>
       Any other <b>reference data that has this record as an association will also be inactivated.</b><br><br> Do you wish to proceed ?`,
      header: 'Inactivate Operational Team Category',
      key: 'inactivateOperationalTeamCategoryStatus',
      accept: (): void => {
        this.operationalTeamCategoryModel.isSectionLoaderEnabled = true;
        this.inactivatePlanOrWorkOrder();
      }
    });
  }

  inactivatePlanOrWorkOrder() {
    this.operationalTeamCategoryService.inactivateOperationalTeamCategoryList(OperationalTeamCategoryUtils.activateInactivateContent
      (this.operationalTeamCategoryModel.selectedRowContent.operationalGroupTypeCode))
      .pipe(takeWhile(() => this.operationalTeamCategoryModel.subscriberFlag),
        finalize(() => {
          this.operationalTeamCategoryModel.selectedRowContent = null;
        }))
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(true);
      });
  }
  showToastMsgForReactivateInactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isDeactivateMode) ? 'Reference Data Inactivated' : 'Reference Data Activated',
      detail: (isDeactivateMode) ? 'Operational Team Category has been successfully inactivated.' :
        'Operational Team Category has been successfully activated.'
    });
    this.changeDetector.detectChanges();
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
}
