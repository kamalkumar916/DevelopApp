import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { Router } from '@angular/router';
import { SelectItem } from '../../../../../node_modules/primeng/components/common/api';

@Component({
  selector: 'app-manage-references',
  templateUrl: './manage-references.component.html',
  styleUrls: ['./manage-references.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ManageReferencesComponent {
  urlList: SelectItem[];
  dataList: SelectItem[];
  searchText: string;
  constructor(private readonly changeDetector: ChangeDetectorRef, private readonly router: Router) {
    this.urlList = [
      {
        'label': 'Appointment Change Reason',
        'value': 'appointment-change-reason'
      },
      {
        'label': 'Capacity Evaluation Association',
        'value': 'capacity-evaluation-association'
      },
      {
        'label': 'Driver Task Type and Sub Type',
        'value': 'driver-task-type-and-sub-type'
      },
      {
        'label': 'Operational Team Category and Type',
        'value': 'operational-team-category-and-team-type'
      },
      {
        'label': 'Stop Service and Stop Reason',
        'value': 'stop-service-and-stop-reason'
      }, {
        'label': 'Utilization Status',
        'value': 'utilization-status'
      }
    ];
    this.dataList = this.urlList;
  }

  onRowSelect(rowData) {
    this.router.navigate([rowData.value]);
  }
  onSearch() {
    this.dataList = [];
    this.urlList.forEach(rowData => {
      if (rowData.label.toLowerCase().search(this.searchText.toLowerCase()) !== -1) {
        this.dataList.push(rowData);
      }
    });
  }
}
