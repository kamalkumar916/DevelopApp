import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageReferencesComponent } from './manage-references.component';
import { ManageReferencesRoutingModule } from './manage-references-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';

@NgModule({
  imports: [
    CommonModule,
    ManageReferencesRoutingModule,
    FormsModule,
    ReactiveFormsModule, TableModule, MenuModule, InputTextModule
  ],
  declarations: [ManageReferencesComponent]
})
export class ManageReferencesModule { }
