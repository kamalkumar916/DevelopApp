import { FormGroup } from '@angular/forms/src/model';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';

import { UtilizationListModel } from './utilization-status.interface';
import { ListItem } from '../../../../model/listitem.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class UtilizationStatusModel {
    breadCrumbList: Array<MenuItem>;
    splitView: boolean;
    utilizationStatusList: Array<UtilizationListModel>;
    utilizationStatusSelectedList: Array<UtilizationListModel>;
    totalRecords: number;
    paginatorFlag: boolean;
    searchText: string;
    pageStart: number;
    tableSize: number;
    exportExcelSize: number;
    menuItems: Array<MenuItem>;
    queryString: string;
    searchFieldFocus: boolean;
    subscriberFlag: boolean;
    isSectionLoaderEnabled: boolean;
    selectedRowContent: UtilizationListModel;
    userInputSearchSubject: Subject<string>;
    tableColumns: ListItem[];

    addUtilizationStatusForm: FormGroup;
    editUtilizationStatusForm: FormGroup;

    inactiveLabel: string;
    activeLabel: string;
    sortOrder: string;
    sortField: string;
    gridLoaderFlag: boolean;
    addNewButton: SecureModel;
    inactivateButton: SecureModel;
    activateButton: SecureModel;
    appConfig;

    constructor() {
        this.initializedObject();
    }
    initializedObject() {
        this.breadCrumbList = [
            { label: 'Manage References', routerLink: ['/managereferences'] },
            { label: 'Utilization Status', routerLink: ['/managereferences/utilization-status'] }
        ];

        this.tableColumns = [
            { 'label': 'Name', 'value': 'utilizationStatusDescription', 'esKey': 'UtilizationStatusDescription' },
            { 'label': 'Identifier', 'value': 'utilizationStatusCode', 'esKey': 'UtilizationStatusCode' },
            { 'label': 'Last Updated', 'value': 'lastUpdateTimestamp', 'esKey': 'LastUpdateTimestamp' },
            { 'label': 'Last Updated By', 'value': 'lastUpdatedBy', 'esKey': 'LastUpdateProgramName' },
            { 'label': 'Status', 'value': 'status', 'esKey': 'Status' }
        ];

        this.splitView = false;
        this.utilizationStatusList = [];
        this.utilizationStatusSelectedList = [];
        this.totalRecords = 0;
        this.paginatorFlag = false;
        this.searchText = '';
        this.pageStart = 0;
        this.tableSize = 25;
        this.exportExcelSize = 5000;
        this.menuItems = [];
        this.queryString = '';
        this.subscriberFlag = true;
        this.searchFieldFocus = false;
        this.selectedRowContent = null;
        this.isSectionLoaderEnabled = false;
        this.userInputSearchSubject = new Subject<string>();

        this.inactiveLabel = 'inactive';
        this.activeLabel = 'active';
        this.sortField = 'defaultSort';
        this.sortOrder = 'asc';
        this.gridLoaderFlag = true;
        this.appConfig = AppConfig.getConfig();
        this.addNewButton = { url: this.appConfig.api.admin.addUtilizationStatus, operation: 'C' };
        this.inactivateButton = { url: this.appConfig.api.admin.inactivateUtilizationStatus, operation: 'C' };
        this.activateButton = { url: this.appConfig.api.admin.reactivateUtilizationStatus, operation: 'C' };
    }
}
