export interface UtilizationListModel {
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateProgramName: string;
    lastUpdateTimestamp: string;
    lastUpdateUserID: string;
    status: string;
    utilizationStatusCode: string;
    utilizationStatusDescription: string;
    lastUpdatedBy: string;
}

export interface UtilizationStatusAddModel {
    utilizationStatusCode: string;
    utilizationStatusDescription: string;
}

export interface UtilizationStatusActiveInactiveModel {
    utilizationStatusCode: string;
}

export interface UtilizationExcelDownloadModel {
    headerDetails: object;
    elasticSearchQuery: object;
}
export interface SortView {
    first: number;
    rows: number;
    sortField: string;
    sortOrder: number;
}
