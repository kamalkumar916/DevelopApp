import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { UtilizationStatusComponent } from './utilization-status.component';
import { UtilizationStatusModule } from './utilization-status.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { TooltipModule } from 'primeng/tooltip';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { SortView } from './model/utilization-status.interface';
import { UtilizationStatusService } from './services/utilization-status.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { UserService } from '../../../../shared/jbh-esa/user.service';

describe('UtilizationStatusComponent', () => {
  let component: UtilizationStatusComponent;
  let fixture: ComponentFixture<UtilizationStatusComponent>;
  let thisEvent: SortView;
  let service: UtilizationStatusService;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, UtilizationStatusModule, HttpClientTestingModule, TooltipModule,
        NoopAnimationsModule, DirectivesModule],
      providers: [MessageService, ConfirmationService, AppConfigService, UtilizationStatusService, UserService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UtilizationStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = TestBed.get(UtilizationStatusService);
    formGroup = formBuilder.group({
      utilizationStatusCode: ['', Validators.required],
      utilizationStatusDescription: ['', Validators.required]
    });

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('checking searchText length', () => {
    component.utilizationStatusModel.searchText = 'test';
    component.onSearchFocus();
    expect(component.utilizationStatusModel.searchFieldFocus).toBe(true);
  });
  it('checking searchText length', () => {
    component.utilizationStatusModel.searchText = '';
    component.onSearchFocus();
    expect(component.utilizationStatusModel.searchFieldFocus).toBe(false);
  });
  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.utilizationStatusModel.splitView).toBe(false);
  });
  it('onPage have been called', () => {
    thisEvent = {
      first: 1,
      rows: 10,
      sortOrder: 1,
      sortField: 'test'
    };
    spyOn(component, 'fetchUtilizationList');
    component.onPage(thisEvent);
    expect(component.utilizationStatusModel.pageStart).toBe(thisEvent.first);
    expect(component.utilizationStatusModel.tableSize).toBe(thisEvent.rows);
    expect(component.utilizationStatusModel.sortField).toBe(thisEvent.sortField);
    expect(component.utilizationStatusModel.sortOrder).toBe('asc');
    expect(component.fetchUtilizationList).toHaveBeenCalled();
  });
  it('onSearch have been called', () => {
    component.onSearch();
    expect(component.utilizationStatusModel.searchFieldFocus).toBe(true);
  });
  it('onAddNew have been called', () => {
    component.onAddNew();
    expect(component.utilizationStatusModel.splitView).toBe(true);
  });
  it('onSave have been called', () => {
    component.utilizationStatusModel.addUtilizationStatusForm = formGroup;
    component.onSave();
    expect(component.onSave).toBeTruthy();
  });

  it('onCompareOldData have been called', () => {
    component.utilizationStatusModel.addUtilizationStatusForm = formGroup;
    component.utilizationStatusModel.selectedRowContent = {
      effectiveTimestamp: '01-01-2018 00:00:00',
      expirationTimestamp: '12-31-2199 23:59:59',
      lastUpdateProgramName: 'SSIS',
      lastUpdateTimestamp: 'Sep 28,2019 12:25 AM CDT',
      lastUpdateUserID: 'PIDNEXT',
      lastUpdatedBy: 'SSIS (PIDNEXT)',
      status: 'Active',
      utilizationStatusCode: 'Regional',
      utilizationStatusDescription: 'Regional'
    };
    component.onCompareOldData();
    expect(component.onCompareOldData).toBeTruthy();
  });
  it('fetchUtilizationList have been called', () => {
    const response = {
      hits: {
        hits: [
          {
            sort: [],
            _id: 'Bobtail',
            _index: 'operationsexecution-referencedata-utilizationstatus-1-2019.05.15',
            _score: null,
            _source: {
              EffectiveTimestamp: '01-01-2018 00:00:00',
              ExpirationTimestamp: '12-31-2199 23:59:59',
              LastUpdateProgramName: 'SSIS',
              LastUpdateTimestamp: 'Sep 28,2019 05:25 AM UTC',
              LastUpdateUserID: 'PIDNEXT',
              Status: 'Active',
              UtilizationStatusCode: 'Bobtail',
              UtilizationStatusDescription: 'Bobtail'
            }
          }
        ],
        max_score: null,
        total: 10
      },
      timed_out: false,
      took: 24,
      _shards: {
        failed: 0,
        skipped: 0,
        successful: 3,
        total: 3
      }
    };
    spyOn(service, 'getUtilizationStatusList').and.returnValue(of(response));
    component.fetchUtilizationList();
    expect(service.getUtilizationStatusList).toHaveBeenCalled();
  });
  it('fetchUtilizationList error have been called', () => {
    spyOn(service, 'getUtilizationStatusList').and.returnValue(throwError({}));
    component.fetchUtilizationList();
    expect(component.utilizationStatusModel.gridLoaderFlag).toBe(false);
  });
  it('checking onClose if', () => {
    component.utilizationStatusModel.addUtilizationStatusForm = formGroup;
    component.utilizationStatusModel.addUtilizationStatusForm.markAsTouched();
    component.utilizationStatusModel.addUtilizationStatusForm.markAsDirty();
    component.onClose();
    expect(component.onSave).toBeTruthy();
  });

  it('checking onClose else', () => {
    component.utilizationStatusModel.addUtilizationStatusForm = formGroup;
    component.utilizationStatusModel.addUtilizationStatusForm.reset();
    spyOn(component, 'closeAddEditPage');
    component.onClose();
    expect(component.closeAddEditPage).toHaveBeenCalled();
  });
});
