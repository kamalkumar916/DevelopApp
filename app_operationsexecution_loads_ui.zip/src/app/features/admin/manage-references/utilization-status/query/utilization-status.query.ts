export class UtilizationStatusQuery {
  static getUtilizationStatusListFromES(searchString: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size,
      query: this.getQuery(searchString.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&')),
      sort: this.getSortQuery(sortOrder, sortField)
    };
  }

  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'UtilizationStatusCode':
      case 'UtilizationStatusDescription':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'UtilizationStatusDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }

  static getQuery(searchString: string) {
    return {
      bool: {
        should: [
          {
            query_string: {
              fields: [
                'UtilizationStatusCode',
                'UtilizationStatusDescription',
                'Status',
                'LastUpdateProgramName',
                'LastUpdateUserID',
                'LastUpdateTimestamp.text'
              ],
              query: `*${searchString}*`,
              default_operator: 'AND'
            }
          }
        ]
      }
    };
  }
}
