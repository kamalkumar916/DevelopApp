import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef,
  HostListener, OnDestroy, OnInit, ViewChild
} from '@angular/core';

import * as moment from 'moment';
import { timer } from 'rxjs';
import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';

import { UtilizationStatusService } from './services/utilization-status.service';
import { UtilizationStatusUtils } from './services/utilization-status-utils';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { UtilizationStatusModel } from './model/utilization-status.model';
import { UtilizationListModel, SortView } from './model/utilization-status.interface';
import { UtilizationStatusQuery } from './query/utilization-status.query';

@Component({
  selector: 'app-utilization-status',
  templateUrl: './utilization-status.component.html',
  styleUrls: ['./utilization-status.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UtilizationStatusComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('utilizationDownloadExcel') utilizationDownloadExcel: ElementRef;
  utilizationStatusModel: UtilizationStatusModel;
  defaultSort = 'Status';
  @HostListener('window:beforeunload', ['$event']) unloadNotification($event: any) {
    if (this.hasChangeDetected()) {
      $event.returnValue = true;
    }
  }
  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly messageService: MessageService,
    private readonly confirmationService: ConfirmationService,
    private readonly utilizationStatusService: UtilizationStatusService) {
    this.utilizationStatusModel = new UtilizationStatusModel();
  }

  ngOnInit() {
    this.utilizationStatusModel.initializedObject();
    this.searchInputListener();
    this.initializeMenuItems();
    this.fetchUtilizationList();
  }

  ngOnDestroy() {
    this.utilizationStatusModel.subscriberFlag = false;
  }
  hasChangeDetected() {
    if (this.utilizationStatusModel && this.utilizationStatusModel.addUtilizationStatusForm &&
      this.utilizationStatusModel.addUtilizationStatusForm.dirty) {
      return true;
    }
    return false;
  }
  onPage(thisEvent: SortView) {
    this.getCurrentScrollPosition();
    this.utilizationStatusModel.pageStart = thisEvent.first;
    this.utilizationStatusModel.tableSize = thisEvent.rows;
    this.utilizationStatusModel.sortField = thisEvent.sortField;
    this.utilizationStatusModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchUtilizationList();
  }

  onSearchFocus() {
    if (this.utilizationStatusModel.searchText && this.utilizationStatusModel.searchText.length > 0) {
      this.utilizationStatusModel.searchFieldFocus = true;
    } else {
      this.utilizationStatusModel.searchFieldFocus = false;
    }
  }
  onSearch() {
    this.utilizationStatusModel.searchFieldFocus = true;
    this.utilizationStatusModel.userInputSearchSubject.next(this.utilizationStatusModel.searchText);
  }

  onAddNew() {
    this.utilizationStatusModel.addUtilizationStatusForm = UtilizationStatusUtils.initializeAddForm();
    this.utilizationStatusModel.splitView = true;
  }

  onClose() {
    if (this.utilizationStatusModel.addUtilizationStatusForm.touched || this.utilizationStatusModel.addUtilizationStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'utilizationAdd',
        accept: (): void => {
          this.fetchUtilizationList();
          this.closeAddEditPage();
        }
      });
    } else {
      this.utilizationStatusModel.addUtilizationStatusForm.reset();
      this.closeAddEditPage();
    }
  }
  onCompareOldData() {
    if (this.utilizationStatusModel.selectedRowContent) {
      const nameRowValue = this.utilizationStatusModel.selectedRowContent.utilizationStatusDescription;
      const nameFieldValue = this.utilizationStatusModel.addUtilizationStatusForm.controls.utilizationStatusDescription.value;
      return nameRowValue !== nameFieldValue;
    } else {
      return true;
    }
  }
  onSave() {
    if (this.utilizationStatusModel.addUtilizationStatusForm.valid &&
      (this.utilizationStatusModel.addUtilizationStatusForm.dirty || this.utilizationStatusModel.addUtilizationStatusForm.touched) &&
      this.onCompareOldData()) {
      this.utilizationStatusModel.isSectionLoaderEnabled = true;
      if (this.utilizationStatusModel.selectedRowContent) {
        // Edit API Call
        this.utilizationStatusService.editUtilizationStatus(this.utilizationStatusModel.addUtilizationStatusForm.value)
          .pipe(
            takeWhile(() => this.utilizationStatusModel.subscriberFlag),
            finalize(() => this.utilizationStatusModel.selectedRowContent = null)
          )
          .subscribe(() => {
            this.fetchAllData();
            this.showToastMessage(true);
          });
      } else {
        // Add API Call
        this.utilizationStatusService.addUtilizationStatus
          (this.utilizationStatusModel.addUtilizationStatusForm.value)
          .pipe(
            takeWhile(() => this.utilizationStatusModel.subscriberFlag),
          )
          .subscribe(() => {
            this.fetchAllData();
            this.showToastMessage(false);
          }, (error: Error) => {
            this.utilizationStatusModel.isSectionLoaderEnabled = false;
            this.changeDetector.detectChanges();

            if (error['status'] === 409) {
              this.messageService.clear();
              this.messageService.add({
                severity: 'error',
                summary: 'Duplicate Reference Data',
                detail: 'There is already a reference data of this type with the same identifier. Please designate a different identifier.'
              });
            }
          });
      }
    } else if (this.utilizationStatusModel.addUtilizationStatusForm.valid && this.utilizationStatusModel.selectedRowContent) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'info',
        summary: 'No Changes Found',
        detail: 'There are no changes detected in the current action.'
      });
    } else {
      this.utilizationStatusModel.addUtilizationStatusForm.controls.utilizationStatusCode.markAsTouched();
      this.utilizationStatusModel.addUtilizationStatusForm.controls.utilizationStatusDescription.markAsTouched();
    }
  }

  onRowSelect(thisSelectedRow: UtilizationListModel) {
    if (this.utilizationStatusModel.selectedRowContent && thisSelectedRow.utilizationStatusCode !==
      this.utilizationStatusModel.selectedRowContent.utilizationStatusCode) {
      this.setContentAndLoadSplitScreen(thisSelectedRow);
    } else if (!this.utilizationStatusModel.selectedRowContent) {
      this.setContentAndLoadSplitScreen(thisSelectedRow);
    }
  }

  onInactivate() {
    this.confirmationService.confirm({
      message: `Utilization Status<br><b>${this.utilizationStatusModel.selectedRowContent.utilizationStatusDescription}
      (${this.utilizationStatusModel.selectedRowContent.utilizationStatusCode})</b><br><br>
      The reference data you're about to inactivate may be associated to active orders or other entities, inactivating the
      data will not impact current associations but <b>new entities can no longer reference this record.</b><br><br>
      Any other <b>reference data that has this record as an association will also be inactivated.</b><br><br>
      Do you wish to proceed ?`,
      header: 'Inactivate Utilization Status',
      key: 'inactivateUtilizationStatus',
      accept: (): void => {
        this.utilizationStatusModel.isSectionLoaderEnabled = true;
        this.utilizationStatusService.inactivateUtilizationStatus(UtilizationStatusUtils.formActivateInactivateBodyParam
          (this.utilizationStatusModel.selectedRowContent.utilizationStatusCode))
          .pipe(
            takeWhile(() => this.utilizationStatusModel.subscriberFlag),
            finalize(() => this.utilizationStatusModel.selectedRowContent = null)
          )
          .subscribe(() => {
            this.fetchAllData();
            this.showToastMessageForInactivateReactivate(true);
          });
      }
    });
  }

  onActivate() {
    this.utilizationStatusModel.isSectionLoaderEnabled = true;
    this.utilizationStatusService.reactivateUtilizationStatus(UtilizationStatusUtils.formActivateInactivateBodyParam
      (this.utilizationStatusModel.selectedRowContent.utilizationStatusCode))
      .pipe(
        takeWhile(() => this.utilizationStatusModel.subscriberFlag),
        finalize(() => this.utilizationStatusModel.selectedRowContent = null)
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMessageForInactivateReactivate(false);
      });
  }

  setContentAndLoadSplitScreen(selectedContent: UtilizationListModel) {
    this.utilizationStatusModel.selectedRowContent = selectedContent;
    this.utilizationStatusModel.addUtilizationStatusForm = UtilizationStatusUtils.initializeAddForm();
    this.utilizationStatusModel.addUtilizationStatusForm.patchValue({
      utilizationStatusDescription: selectedContent.utilizationStatusDescription,
      utilizationStatusCode: selectedContent.utilizationStatusCode
    });
    this.utilizationStatusModel.splitView = true;
  }

  initializeMenuItems() {
    this.utilizationStatusModel.menuItems = [
      {
        label: 'Export to Excel', command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }

  exportToExcel() {
    this.utilizationStatusService.utilizationExcelDownload(UtilizationStatusUtils.getExcelDownloadRequestBody(
      UtilizationStatusQuery.getUtilizationStatusListFromES(this.utilizationStatusModel.queryString, this.utilizationStatusModel.pageStart,
        this.utilizationStatusModel.exportExcelSize, this.utilizationStatusModel.sortOrder,
        this.utilizationStatusModel.sortField)))
      .pipe(
        takeWhile(() => this.utilizationStatusModel.subscriberFlag),
      )
      .subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `Utilization Status ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.utilizationDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }

  fetchUtilizationList() {
    this.utilizationStatusService.getUtilizationStatusList(UtilizationStatusQuery.getUtilizationStatusListFromES(
      this.utilizationStatusModel.queryString, this.utilizationStatusModel.pageStart, this.utilizationStatusModel.tableSize,
      this.utilizationStatusModel.sortOrder,
      this.utilizationStatusModel.sortField))
      .pipe(
        takeWhile(() => this.utilizationStatusModel.subscriberFlag),
        finalize(() => {
          this.utilizationStatusModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((utilizationStatusList: ElasticResponseModel) => {
        this.utilizationStatusModel.gridLoaderFlag = (this.utilizationStatusModel.utilizationStatusList.length === 0);
        this.utilizationStatusModel.totalRecords = utilizationStatusList.hits.total;
        this.utilizationStatusModel.utilizationStatusList = UtilizationStatusUtils.getListData(utilizationStatusList);
        this.utilizationStatusModel.paginatorFlag = (this.utilizationStatusModel.utilizationStatusList.length > 0);
      }, (error: Error) => {
        this.utilizationStatusModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }

  searchInputListener() {
    this.utilizationStatusModel.userInputSearchSubject
      .pipe(
        debounceTime(300), distinctUntilChanged(),
        takeWhile(() => this.utilizationStatusModel.subscriberFlag),
        finalize(() => this.utilizationStatusModel.selectedRowContent = null)
      )
      .subscribe(() => {
        if (this.utilizationStatusModel.searchText.length === 0 || this.utilizationStatusModel.searchText.length > 2) {
          this.utilizationStatusModel.queryString = this.utilizationStatusModel.searchText;
          this.utilizationStatusModel.pageStart = 0;
          this.fetchUtilizationList();
        } else {
          this.utilizationStatusModel.queryString = '';
          this.fetchUtilizationList();
        }
      });
  }

  fetchAllData() {
    timer(1000)
      .pipe(
        takeWhile(() => this.utilizationStatusModel.subscriberFlag),
      )
      .subscribe(() => {
        this.utilizationStatusModel.searchText = this.utilizationStatusModel.queryString = '';
        this.fetchUtilizationList();
        this.utilizationStatusModel.isSectionLoaderEnabled = false;
        this.utilizationStatusModel.splitView = false;
        this.changeDetector.detectChanges();
      });
  }

  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: `Reference Data ${isEditMode ? 'Updated' : 'Added'}`,
      detail: `Utilization Status has been successfully ${isEditMode ? 'updated' : 'added'}.`
    });

    this.changeDetector.detectChanges();
  }

  showToastMessageForInactivateReactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: `Reference Data ${isDeactivateMode ? 'Inactivated' : 'Activated'}`,
      detail: `Utilization Status has been successfully ${isDeactivateMode ? 'inactivated' : 'activated'}.`
    });

    this.changeDetector.detectChanges();
  }

  closeAddEditPage() {
    this.utilizationStatusModel.selectedRowContent = null;
    this.utilizationStatusModel.splitView = false;
    this.utilizationStatusModel.utilizationStatusSelectedList = null;
  }

  downloadThisExcelFile(data: Blob, utilizationDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      utilizationDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      utilizationDownloadExcel.nativeElement.download = fileName;
      utilizationDownloadExcel.nativeElement.click();
    }
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
}
