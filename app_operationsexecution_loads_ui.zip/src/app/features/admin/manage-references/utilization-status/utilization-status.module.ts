import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TooltipModule } from 'primeng/tooltip';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { ConfirmationService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { PaginatorModule } from 'primeng/paginator';
import { ButtonModule } from 'primeng/button';

import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';

import { UtilizationStatusComponent } from './utilization-status.component';
import { UtilizationStatusService } from './services/utilization-status.service';

import { UtilizationStatusRoutingModule } from './utilization-status-routing.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

@NgModule({
  declarations: [UtilizationStatusComponent],
  providers: [ConfirmationService, UtilizationStatusService],
  imports: [
    AutoCompleteModule,
    BreadcrumbModule,
    CommonModule,
    ConfirmDialogModule,
    FormsModule,
    InputTextModule,
    JbhLoaderModule,
    MenuModule,
    PipesModule,
    ReactiveFormsModule,
    TableModule,
    MessagesModule,
    MessageModule,
    PaginatorModule,
    ButtonModule,
    UtilizationStatusRoutingModule,
    DirectivesModule,
    TooltipModule
  ]
})
export class UtilizationStatusModule { }
