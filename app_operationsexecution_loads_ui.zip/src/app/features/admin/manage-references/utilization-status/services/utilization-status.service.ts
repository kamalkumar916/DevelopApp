import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import {
    UtilizationExcelDownloadModel, UtilizationStatusAddModel, UtilizationStatusActiveInactiveModel
} from '../model/utilization-status.interface';

@Injectable()
export class UtilizationStatusService {

    endpoint: any;

    constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
        this.endpoint = appConfigService.getApi('admin');
    }

    /* Elastic Search - POST API
      Params - Input : Elastic Search Query
    */
    getUtilizationStatusList(query: object): Observable<ElasticResponseModel> {
        return this.http.post<ElasticResponseModel>(this.endpoint.getUtilizationList, query);
    }

    addUtilizationStatus(queryParam: UtilizationStatusAddModel): Observable<boolean> {
        return this.http.post<boolean>(this.endpoint.addUtilizationStatus, queryParam);
    }

    editUtilizationStatus(queryParam: UtilizationStatusAddModel): Observable<boolean> {
        return this.http.patch<boolean>(this.endpoint.addUtilizationStatus, queryParam);
    }

    inactivateUtilizationStatus(utilizationStatusCodeModel: UtilizationStatusActiveInactiveModel): Observable<boolean> {
        return this.http.patch<boolean>(this.endpoint.inactivateUtilizationStatus, utilizationStatusCodeModel);
    }

    reactivateUtilizationStatus(utilizationStatusCodeModel: UtilizationStatusActiveInactiveModel): Observable<boolean> {
        return this.http.patch<boolean>(this.endpoint.reactivateUtilizationStatus, utilizationStatusCodeModel);
    }

    utilizationExcelDownload(requestParam: UtilizationExcelDownloadModel, headers?: HttpHeaders | null): Observable<Blob> {
        return this.http.post(this.endpoint.referenceDataExcelDownload, requestParam, { headers, responseType: 'blob' });
    }
}
