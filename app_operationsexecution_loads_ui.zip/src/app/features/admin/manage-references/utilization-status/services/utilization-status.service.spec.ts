import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { UtilizationStatusService } from './utilization-status.service';
import { configureTestSuite } from 'ng-bullet';

describe('UtilizationStatusService', () => {
  let service: UtilizationStatusService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AppConfigService, UtilizationStatusService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(UtilizationStatusService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes getUtilizationStatusList expected calls', () => {
    service.getUtilizationStatusList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getUtilizationList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes addUtilizationStatus expected calls', () => {
    const queryParam = {
      utilizationStatusCode: 'test1',
      utilizationStatusDescription: 'test',
    };
    service.addUtilizationStatus(queryParam).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.addUtilizationStatus);
    expect(req.request.method).toEqual('POST');
  });
  it('makes editUtilizationStatus expected calls', () => {
    const queryParam = {
      utilizationStatusCode: 'test1',
      utilizationStatusDescription: 'test',
    };
    service.editUtilizationStatus(queryParam).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.addUtilizationStatus);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes inactivateUtilizationStatus expected calls', () => {
    const utilizationStatusCodeModel = {
      utilizationStatusCode: 'Test',
    };
    service.inactivateUtilizationStatus(utilizationStatusCodeModel).subscribe();
    const req =
      httpTestingController.expectOne(service.endpoint.inactivateUtilizationStatus);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes reactivateUtilizationStatus expected calls', () => {
    const utilizationStatusCodeModel = {
      utilizationStatusCode: 'Test1',
    };
    service.reactivateUtilizationStatus(utilizationStatusCodeModel).subscribe();
    const req =
      httpTestingController.expectOne(service.endpoint.reactivateUtilizationStatus);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes reactivateUtilizationStatus expected calls', () => {
    const requestParam = {
      headerDetails: {},
      elasticSearchQuery: {},
    };
    service.utilizationExcelDownload(requestParam).subscribe();
    const req =
      httpTestingController.expectOne(service.endpoint.referenceDataExcelDownload);
    expect(req.request.method).toEqual('POST');
  });
});

