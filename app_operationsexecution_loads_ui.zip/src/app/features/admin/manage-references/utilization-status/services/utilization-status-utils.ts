import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import {
  UtilizationExcelDownloadModel, UtilizationListModel, UtilizationStatusActiveInactiveModel
} from '../model/utilization-status.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class UtilizationStatusUtils {

  constructor() { }

  static getListData(utilizationStatusList: ElasticResponseModel): Array<UtilizationListModel> {
    const thisEsList: Array<HitsModel> = (utilizationStatusList && utilizationStatusList.hits && utilizationStatusList.hits.hits) ?
      utilizationStatusList.hits.hits : [];
    if (!thisEsList || thisEsList.length === 0) {
      return [];
    }

    return thisEsList.map((thisUtilStatus: HitsModel) => {
      return {
        'effectiveTimestamp': thisUtilStatus._source['EffectiveTimestamp'],
        'expirationTimestamp': thisUtilStatus._source['ExpirationTimestamp'],
        'lastUpdateProgramName': thisUtilStatus._source['LastUpdateProgramName'],
        'lastUpdateTimestamp':
          DateUtils.convertOffsetDateByDefaultTimeZone(thisUtilStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
        'lastUpdateUserID': thisUtilStatus._source['LastUpdateUserID'],
        'status': thisUtilStatus._source['Status'],
        'utilizationStatusCode': thisUtilStatus._source['UtilizationStatusCode'],
        'utilizationStatusDescription': thisUtilStatus._source['UtilizationStatusDescription'],
        'lastUpdatedBy': `${thisUtilStatus._source['LastUpdateProgramName']} (${thisUtilStatus._source['LastUpdateUserID'].toUpperCase()})`
      };
    });
  }

  static initializeAddForm(): FormGroup {
    return new FormGroup({
      utilizationStatusDescription: new FormControl('', Validators.required),
      utilizationStatusCode: new FormControl('', Validators.required)
    });
  }

  static formActivateInactivateBodyParam(thisCode: string): UtilizationStatusActiveInactiveModel {
    return {
      'utilizationStatusCode': thisCode
    };
  }

  static getExcelDownloadRequestBody(esQuery: object): UtilizationExcelDownloadModel {
    return {
      headerDetails: {
        'Name': 'UtilizationStatusDescription',
        'Identifier': 'UtilizationStatusCode',
        'Last Updated': 'LastUpdateTimestamp',
        'Last Updated By': 'LastUpdateProgramName, LastUpdateUserID',
        'Status': 'Status'
      },
      elasticSearchQuery: {
        query: esQuery['query'],
        sort: esQuery['sort'],
        size: esQuery['size']
      }
    };
  }
}
