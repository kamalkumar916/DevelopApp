export class CapacityEvaluationAssociationQuery {
  static getCapacityEvaluationAssociationListFromES(searchText: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size,
      query: {
        query_string: {
          fields: [
            'FinanceBusinessUnitCode',
            'ServiceOfferingCode',
            'OperationalGroupSubtypeCode',
            'LastUpdateTimestamp.text',
            'LastUpdateProgramName',
            'LastUpdateUserID',
            'Status',
            'CapacityEvaluationAssociationID.text'
          ],
          query: `*${searchText}*`,
          default_operator: 'AND'
        }
      },
      sort: this.getSortQuery(sortOrder, sortField),
      _source: [
        'FinanceBusinessUnitCode',
        'ServiceOfferingCode',
        'OperationalGroupSubtypeCode',
        'LastUpdateTimestamp',
        'LastUpdateProgramName',
        'LastUpdateUserID',
        'Status',
        'CapacityEvaluationAssociationID'
      ]
    };
  }


  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'FinanceBusinessUnitCode':
      case 'ServiceOfferingCode':
      case 'OperationalGroupSubtypeCode':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          },
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }
}
