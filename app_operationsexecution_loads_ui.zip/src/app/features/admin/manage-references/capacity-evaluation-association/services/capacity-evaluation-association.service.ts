import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConfigService } from '../../../../../shared/service/app-config.service';

import {
  CapacityEvaluationAssociationListAddModel, CapacityEvaluationAssociationActiveInactiveModel, TeamType, BusinessType
} from '../model/capacity-evaluation-association.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';

@Injectable()
export class CapacityEvaluationAssociationService {
  endpoints: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoints = appConfigService.getApi('admin');
  }

  getCapacityEvaluationAssociationList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoints.getCapacityEvaluationAssociationList, query);
  }

  getTeamTypeList(query: string): Observable<TeamType> {
    return this.http.get<TeamType>(`${this.endpoints.getTeamTypeCode}?projection=groupSubTypeCode&expirationTimestamp=${query}`);
  }

  saveCapacityEvaluationAssociationList(query: CapacityEvaluationAssociationListAddModel): Observable<boolean> {
    return this.http.post<boolean>(this.endpoints.saveCapacityEvaluationAssociation, query);
  }

  editCapacityEvaluationAssociationList(query: CapacityEvaluationAssociationListAddModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoints.saveCapacityEvaluationAssociation, query);
  }

  inactivateCapacityEvaluationAssociationList(capacityCodeModel: CapacityEvaluationAssociationActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoints.inactivateCapacityEvaluationAssociationStatus, capacityCodeModel);
  }

  reactivateCapacityEvaluationAssociationList(capacityCodeModel: CapacityEvaluationAssociationActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoints.reactivateCapacityEvaluationAssociationStatus, capacityCodeModel);
  }

  getBusinessUnitDropdownValues(): Observable<BusinessType> {
    return this.http.get<BusinessType>(this.endpoints.getBusinessUnit);
  }

  getServiceOfferingDropdownValues(query: string): Observable<BusinessType> {
    return this.http.get<BusinessType>(`${this.endpoints.getServiceOffering}?financeBusinessUnitCode=${query}`);
  }

  capacityExcelDownload(requestParam, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoints.capacityAssociationExportExcel, requestParam, { headers, responseType: 'blob' });
  }

}
