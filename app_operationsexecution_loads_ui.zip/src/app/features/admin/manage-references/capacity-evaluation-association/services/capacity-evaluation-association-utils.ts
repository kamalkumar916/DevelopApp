import {
  CapacityEvaluationAssociationListModel, CapacityEvaluationAssociationActiveInactiveModel, BusinessType, TeamType
} from '../model/capacity-evaluation-association.interface';
import { CapacityEvaluationAssociationModel } from '../model/capacity-evaluation-association.model';
import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import * as LodashUtils from 'lodash';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class CapacityEvaluationAssociationUtils {

  constructor() { }

  static getCapacityEvaluationAssociationListData(capacityList: ElasticResponseModel): CapacityEvaluationAssociationListModel[] {
    let returnData: CapacityEvaluationAssociationListModel[] = [];
    if (capacityList && capacityList.hits && capacityList.hits.hits) {
      returnData = capacityList.hits.hits.map((capacityStatus: HitsModel) => {
        return {
          'effectiveTimestamp': capacityStatus._source.EffectiveTimestamp,
          'expirationTimestamp': capacityStatus._source.ExpirationTimestamp,
          'lastUpdateProgramName': capacityStatus._source.LastUpdateProgramName,
          'lastUpdateTimestamp':
            DateUtils.convertOffsetDateByDefaultTimeZone(capacityStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
          'lastUpdateUserID': capacityStatus._source.LastUpdateUserID,
          'status': capacityStatus._source.Status,
          'operationalGroupSubtypeCode': capacityStatus._source.OperationalGroupSubtypeCode,
          'serviceOfferingCode': capacityStatus._source.ServiceOfferingCode,
          'businessUnitCode': capacityStatus._source.FinanceBusinessUnitCode,
          'lastUpdatedBy': `${capacityStatus._source.LastUpdateProgramName}
          ${'('}${capacityStatus._source.LastUpdateUserID}${')'}`,
          'capacityEvaluationAssociationID': capacityStatus._source.CapacityEvaluationAssociationID
        };
      });
    }

    return returnData;
  }

  static activateInactivateContent(typeCode: string,
    capacityEvaluationAssociationID: number): CapacityEvaluationAssociationActiveInactiveModel {
    return {
      'operationalGroupSubTypeCode': typeCode,
      'capacityEvaluationAssociationID': capacityEvaluationAssociationID
    };
  }

  static setFilteredContentBU(userSearchInput: string, capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel) {
    capacityEvaluationAssociationModel.businessUnitItems = capacityEvaluationAssociationModel.dropdownLabels.filter(
      thisDropdownContent => thisDropdownContent.label.toLowerCase().indexOf(userSearchInput.toLowerCase()) > -1
    );
  }

  static setFilteredContentClearBU(capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel) {
    capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.businessUnit.setErrors(
      { 'incorrect': true });
  }

  static setFilteredContentServiceOffering(userSearchInput: string,
    capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel) {
    capacityEvaluationAssociationModel.serviceOfferingItems =
      capacityEvaluationAssociationModel.dropdownLabelsService.filter(
        thisDropdownContent => thisDropdownContent.label.toLowerCase().indexOf(userSearchInput.toLowerCase()) > -1
      );
    capacityEvaluationAssociationModel.serviceOfferingItems.sort((element1, element2) => {
      if (element1.label < element2.label) {
        return -1;
      }
    });
  }

  static setFilteredContentClearServiceOffering(capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel) {
    capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.serviceOffering.setErrors(
      { 'incorrect': true });
  }

  static setFilteredContentTeamType(userSearchInput: string, capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel) {
    capacityEvaluationAssociationModel.teamTypeItems =
      capacityEvaluationAssociationModel.dropdownLabelsType.filter(
        thisDropdownContent => thisDropdownContent.label.toLowerCase().indexOf(userSearchInput.toLowerCase()) > -1
      );
  }

  static setFilteredContentClearTeamType(capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel) {
    capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.operationalGroupSubtypeCode.setErrors(
      { 'incorrect': true });
  }

  static getServiceDropdownValues(data: BusinessType, capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel,
    changeDetector) {
    if (data && data._embedded && data._embedded.serviceOfferingBusinessUnitTransitModeAssociations) {
      const listData = data._embedded.serviceOfferingBusinessUnitTransitModeAssociations;
      capacityEvaluationAssociationModel.dropdownLabelsService = listData.map((element) => {
        return {
          label: element.financeBusinessUnitServiceOfferingAssociation.serviceOfferingCode,
          value: element.financeBusinessUnitServiceOfferingAssociation.serviceOfferingCode
        };
      });
      capacityEvaluationAssociationModel.serviceOfferingItems =
        LodashUtils.cloneDeep(capacityEvaluationAssociationModel.dropdownLabelsService);
      changeDetector.detectChanges();
    }
  }

  static getBUDropdownValues(data: BusinessType, capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel,
    changeDetector) {
    if (data && data._embedded && data._embedded.serviceOfferingBusinessUnitTransitModeAssociations) {
      const listData = data._embedded.serviceOfferingBusinessUnitTransitModeAssociations;
      capacityEvaluationAssociationModel.dropdownLabels = listData.map((element) => {
        return {
          label: element.financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode,
          value: element.financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode
        };
      });
      capacityEvaluationAssociationModel.businessUnitItems =
        LodashUtils.cloneDeep(capacityEvaluationAssociationModel.dropdownLabels);
      changeDetector.detectChanges();
    }
  }

  static getExcelDownloadRequestBody(esQuery: object) {
    return {
      query: esQuery['query'],
      sort: esQuery['sort']
    };
  }

}
