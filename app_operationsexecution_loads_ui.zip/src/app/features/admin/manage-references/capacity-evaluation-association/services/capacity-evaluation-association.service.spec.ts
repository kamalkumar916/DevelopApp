import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { CapacityEvaluationAssociationService } from './capacity-evaluation-association.service';
import { configureTestSuite } from 'ng-bullet';

describe('CapacityEvaluationAssociationService', () => {
  configureTestSuite(() => TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AppConfigService, CapacityEvaluationAssociationService]
    }));

  it('should be created', () => {
    const service: CapacityEvaluationAssociationService = TestBed.get(CapacityEvaluationAssociationService);
    expect(service).toBeTruthy();
  });
});
