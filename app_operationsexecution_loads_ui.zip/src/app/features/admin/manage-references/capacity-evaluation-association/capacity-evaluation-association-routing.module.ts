import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CapacityEvaluationAssociationComponent } from './capacity-evaluation-association.component';

const routes: Routes = [
  { path: '', component: CapacityEvaluationAssociationComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CapacityEvaluationAssociationRoutingModule { }
