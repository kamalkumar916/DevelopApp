import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { ConfirmationService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { PaginatorModule } from 'primeng/paginator';
import { TooltipModule } from 'primeng/tooltip';


import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { CapacityEvaluationAssociationComponent } from './capacity-evaluation-association.component';
import { CapacityEvaluationAssociationService } from './services/capacity-evaluation-association.service';

import { CapacityEvaluationAssociationRoutingModule } from './capacity-evaluation-association-routing.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

@NgModule({
  imports: [
    AutoCompleteModule,
    BreadcrumbModule,
    ButtonModule,
    CommonModule,
    ConfirmDialogModule,
    FormsModule,
    InputTextModule,
    JbhLoaderModule,
    MenuModule,
    PipesModule,
    ReactiveFormsModule,
    TableModule,
    MessagesModule,
    MessageModule,
    PaginatorModule,
    CapacityEvaluationAssociationRoutingModule,
    TooltipModule,
    DirectivesModule
  ],
  declarations: [
    CapacityEvaluationAssociationComponent
  ],
  providers: [ConfirmationService, CapacityEvaluationAssociationService]
})
export class CapacityEvaluationAssociationModule { }
