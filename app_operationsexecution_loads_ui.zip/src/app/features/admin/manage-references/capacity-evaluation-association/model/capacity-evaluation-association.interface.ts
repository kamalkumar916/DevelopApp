export interface CapacityEvaluationAssociationListModel {
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateProgramName: string;
  lastUpdateTimestamp: string;
  lastUpdateUserID: string;
  serviceOfferingCode: string;
  businessUnitCode: string;
  status: string;
  operationalGroupSubtypeCode: string;
  operationalWorkOrderTypeDescription?: string;
  lastUpdatedBy: string;
  capacityEvaluationAssociationID: number;
}
export interface CapacityEvaluationAssociationListAddModel {
  financeBusinessUnitCode: string;
  serviceOfferingCode: string;
  operationalGroupSubtypeCode?: string;
  capacityEvaluationAssociationID?: number;
}
export interface TeamTypeCodeModel {
  operationalGroupSubtypeCode: string;
  operationalWorkOrderTypeDescription?: string;
}
export interface CapacityEvaluationAssociationActiveInactiveModel {
  operationalGroupSubTypeCode: string;
  capacityEvaluationAssociationID?: number;
}
export interface PageEvent {
  first: number;
  rows: number;
  sortOrder: number;
  sortField: string;
}
export interface TeamType {
  _embedded: Embedded;
  _links: Links;
}
export interface Embedded {
  operationalGroupSubtypes: OperationalGroupSubtypesItem[];
}
export interface OperationalGroupSubtypesItem {
  operationalGroupSubtypeCode: string;
  _links: Links;
}
export interface Links {
  self: Self;
  operationalGroupSubtype?: OperationalGroupSubtype;
}
export interface Self {
  href: string;
}
export interface OperationalGroupSubtype {
  href: string;
  templated: boolean;
}
export interface BusinessType {
  _embedded: EmbeddedBusinessType;
  _links: LinksBusinessType;
}
export interface EmbeddedBusinessType {
  serviceOfferingBusinessUnitTransitModeAssociations: ServiceOfferingBusinessUnitTransitModeAssociationsItem[];
}
export interface ServiceOfferingBusinessUnitTransitModeAssociationsItem {
  financeBusinessUnitServiceOfferingAssociation: FinanceBusinessUnitServiceOfferingAssociation;
  _links: LinksBusinessType;
}
export interface FinanceBusinessUnitServiceOfferingAssociation {
  financeBusinessUnitServiceOfferingAssociationID: string;
  financeBusinessUnitCode: string;
  serviceOfferingCode: string;
}
export interface LinksBusinessType {
  self: Self;
  serviceOfferingBusinessUnitTransitModeAssociation?: ServiceOfferingBusinessUnitTransitModeAssociation;
}
export interface ServiceOfferingBusinessUnitTransitModeAssociation {
  href: string;
  templated: boolean;
}
