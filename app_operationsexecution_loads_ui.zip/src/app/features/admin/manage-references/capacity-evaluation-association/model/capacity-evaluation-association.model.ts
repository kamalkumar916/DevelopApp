import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';

import { CapacityEvaluationAssociationListModel, TeamTypeCodeModel } from './capacity-evaluation-association.interface';
import { ListItem } from './../../../../model/listitem.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class CapacityEvaluationAssociationModel {
  items: MenuItem[];
  splitView: boolean;
  capacityEvaluationAssociationList: CapacityEvaluationAssociationListModel[];
  operationalGroupSubtypeCode: ListItem[];
  operationalGroupSubtypeCodeItems: ListItem[];
  capacityEvaluationAssociationSelectedList: CapacityEvaluationAssociationListModel[];
  paginatorFlag: boolean;
  totalRecords: number;
  totalCodeRecords: number;
  pageStart: number;
  tableSize: number;
  queryString: string;
  searchText: string;
  subscriberFlag: boolean;
  isSectionLoaderEnabled: boolean;
  dropdownLabels: ListItem[];
  dropdownLabelsService: ListItem[];
  dropdownLabelsType: ListItem[];
  tableColumns: ListItem[];
  userInputSearchSubject: Subject<string>;
  addCapacityEvaluationAssociationStatusForm: FormGroup;
  inactiveLabel: string;
  activeLabel: string;
  selectedRowContent: CapacityEvaluationAssociationListModel;
  driverTaskTypeCodeList: TeamTypeCodeModel[];
  lableValue: boolean;
  translateVariableRefDataToastHeader: string;
  translateVariableRefDataToastSummary: string;
  breadCrumbList: MenuItem[];
  businessUnitCode: ListItem[];
  businessUnitItems: ListItem[];
  serviceOfferingCode: ListItem[];
  serviceOfferingItems: ListItem[];
  teamTypeCode: ListItem[];
  teamTypeItems: ListItem[];
  gridLoaderFlag: boolean;
  information: string;
  successMessage: string;
  sortField: string;
  sortOrder: string;
  title: string;
  addNewButton: SecureModel;
  inactivateButton: SecureModel;
  activateButton: SecureModel;
  appConfig;

  constructor() {
    this.splitView = false;
    this.capacityEvaluationAssociationList = [];
    this.driverTaskTypeCodeList = [];
    this.businessUnitItems = [];
    this.serviceOfferingItems = [];
    this.teamTypeItems = [];
    this.capacityEvaluationAssociationSelectedList = [];
    this.paginatorFlag = false;
    this.totalRecords = 0;
    this.pageStart = 0;
    this.tableSize = 25;
    this.queryString = '';
    this.searchText = '';
    this.subscriberFlag = true;
    this.isSectionLoaderEnabled = false;
    this.userInputSearchSubject = new Subject<string>();
    this.selectedRowContent = null;
    this.gridLoaderFlag = true;
    this.sortField = 'defaultSort';
    this.sortOrder = 'asc';
    this.inactiveLabel = 'inactive';
    this.activeLabel = 'active';
    this.translateVariableRefDataToastHeader = 'Reference Data {{updateMode}}';
    this.translateVariableRefDataToastSummary = 'Appointment Change Reason has been successfully {{updateMode}}';
    this.information = 'info';
    this.successMessage = 'Capacity Evaluation Association has been successfully {{updateMode}}';
    this.title = 'Capacity Evaluation Association';
    this.breadCrumbList = [
      {
        label: 'Manage References',
        routerLink: ['/managereferences']
      },
      {
        label: 'Capacity Evaluation Association',
        routerLink: ['/managereferences/capacity-evaluation-association']
      }
    ];
    this.tableColumns = [
      {
        'label': 'Business Unit',
        'value': 'businessUnitCode',
        'esKey': 'FinanceBusinessUnitCode'
      },
      {
        'label': 'Service Offering',
        'value': 'serviceOfferingCode',
        'esKey': 'ServiceOfferingCode'
      },
      {
        'label': 'Operational Team Type',
        'value': 'operationalGroupSubtypeCode',
        'esKey': 'OperationalGroupSubtypeCode'
      },
      {
        'label': 'Last Updated',
        'value': 'lastUpdateTimestamp',
        'esKey': 'LastUpdateTimestamp'
      },
      {
        'label': 'Last Updated By',
        'value': 'lastUpdatedBy',
        'esKey': 'LastUpdateProgramName'
      },
      {
        'label': 'Status',
        'value': 'status',
        'esKey': 'Status'
      }];
    this.appConfig = AppConfig.getConfig();
    this.addNewButton = { url: this.appConfig.api.admin.saveCapacityEvaluationAssociation, operation: 'C' };
    this.inactivateButton = { url: this.appConfig.api.admin.inactivateCapacityEvaluationAssociationStatus, operation: 'C' };
    this.activateButton = { url: this.appConfig.api.admin.reactivateCapacityEvaluationAssociationStatus, operation: 'C' };
  }

}
