import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessageService } from 'primeng/components/common/messageservice';
import { configureTestSuite } from 'ng-bullet';
import { TooltipModule } from 'primeng/tooltip';
import { DirectivesModule } from './../../../../shared/directives/directives.module';


import { CapacityEvaluationAssociationComponent } from './capacity-evaluation-association.component';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { CapacityEvaluationAssociationService } from './services/capacity-evaluation-association.service';
import { CapacityEvaluationAssociationUtils } from './services/capacity-evaluation-association-utils';
import { Validators, FormBuilder, FormGroup, } from '@angular/forms';
import { of } from 'rxjs/internal/observable/of';
import { CapacityEvaluationAssociationActiveInactiveModel } from './model/capacity-evaluation-association.interface';
import { UserService } from './../../../../shared/jbh-esa';

class MockCapacityEvaluationService {
  constructor() { }
  capacityExcelDownload(requestParam: any) {
    return of(null);
  }
  inactivateCapacityEvaluationAssociationList(typeCode: CapacityEvaluationAssociationActiveInactiveModel) {
    return of({});
  }
  getServiceOfferingDropdownValues(value: string) {
    return of(null);
  }
  getBusinessUnitDropdownValues() {
    return of(null);
  }
  getTeamTypeList(value: string) {
    return of(null);
  }
  reactivateCapacityEvaluationAssociationList(value: CapacityEvaluationAssociationActiveInactiveModel) {
    return of({});
  }
  getCapacityEvaluationAssociationList(value: object) {
    return of(null);
  }
}


describe('CapacityEvaluationAssociationComponent', () => {
  let component: CapacityEvaluationAssociationComponent;
  let fixture: ComponentFixture<CapacityEvaluationAssociationComponent>;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  const capacityEvaluationListModel = {
    effectiveTimestamp: 'string',
    expirationTimestamp: 'string',
    lastUpdateProgramName: 'string',
    lastUpdateTimestamp: 'string',
    lastUpdateUserID: 'string',
    serviceOfferingCode: 'string',
    businessUnitCode: 'string',
    status: 'string',
    operationalGroupSubtypeCode: 'string',
    lastUpdatedBy: 'string',
    capacityEvaluationAssociationID: 10,
    operationalWorkOrderTypeDescription: 'string'
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NoopAnimationsModule,
        BreadcrumbModule, TableModule, FormsModule, ReactiveFormsModule, MenuModule, ButtonModule,
        JbhLoaderModule, MessagesModule, MessageModule, AutoCompleteModule, PipesModule, ConfirmDialogModule, TooltipModule,
        DirectivesModule],

      providers: [AppConfigService, MessageService, ConfirmationService,
        { provide: CapacityEvaluationAssociationService, useClass: MockCapacityEvaluationService }, CapacityEvaluationAssociationUtils,
         UserService],
      declarations: [CapacityEvaluationAssociationComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CapacityEvaluationAssociationComponent);
    component = fixture.componentInstance;
    formGroup = formBuilder.group({
      businessUnit: ['', Validators.required],
      serviceOffering: ['', Validators.required],
      operationalGroupSubtypeCode: ['', Validators.required]
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('unableToAdd have been called', () => {
    component.unableToAdd();
    expect(component.capacityEvaluationAssociationModel.lableValue).toBe(true);
  });

  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.capacityEvaluationAssociationModel.splitView).toBe(false);
  });
  it('onSearch have been called', () => {
    component.onSearch();
    expect(component.capacityEvaluationAssociationModel.pageStart).toEqual(0);
  });
  it('onCompareOldData have been called', () => {
    const checkReturn = component.onCompareOldData();
    expect(checkReturn).toBe(true);
  });
  it('should call closeSplitView and expect fetchlistdata method has called', () => {
    spyOn(component, 'fetchCapacityEvaluationAssociationListData');
    component.closeSplitView();
    expect(component.fetchCapacityEvaluationAssociationListData).toHaveBeenCalled();
  });

  it('should call onRowSelect with value', () => {
    const data = {
      effectiveTimestamp: 'string',
      expirationTimestamp: 'string',
      lastUpdateProgramName: 'string',
      lastUpdateTimestamp: 'string',
      lastUpdateUserID: 'string',
      serviceOfferingCode: 'ssss',
      businessUnitCode: 'string',
      status: 'string',
      operationalGroupSubtypeCode: 'string',
      lastUpdatedBy: 'string',
      capacityEvaluationAssociationID: 10,
      operationalWorkOrderTypeDescription: 'string'
    };
    component.capacityEvaluationAssociationModel.selectedRowContent = data;
    spyOn(component, 'selectedContentSplitScreen');
    component.onRowSelect(capacityEvaluationListModel);
    expect(component.selectedContentSplitScreen).toHaveBeenCalled();
  });
  it('should call onRowSelect with null', () => {
    component.capacityEvaluationAssociationModel.selectedRowContent = null;
    spyOn(component, 'selectedContentSplitScreen');
    component.onRowSelect(capacityEvaluationListModel);
    expect(component.selectedContentSplitScreen).toHaveBeenCalled();
  });
  it('should call fetchAllData', () => {
    spyOn(component, 'fetchCapacityEvaluationAssociationListData');
    component.fetchAllData();
    expect(component.fetchCapacityEvaluationAssociationListData).toHaveBeenCalled();
  });
  it('setFilteredContentBU have been called', () => {
    spyOn(CapacityEvaluationAssociationUtils, 'setFilteredContentBU');
    component.setFilteredContentBU('string');
    expect(CapacityEvaluationAssociationUtils.setFilteredContentBU).toHaveBeenCalled();
  });
  it('setFilteredContentClearBU have been called', () => {
    spyOn(CapacityEvaluationAssociationUtils, 'setFilteredContentClearBU');
    component.setFilteredContentClearBU();
    expect(CapacityEvaluationAssociationUtils.setFilteredContentClearBU).toHaveBeenCalled();
  });
  it('setFilteredContentServiceOffering have been called', () => {
    spyOn(CapacityEvaluationAssociationUtils, 'setFilteredContentServiceOffering');
    component.setFilteredContentServiceOffering('string');
    expect(CapacityEvaluationAssociationUtils.setFilteredContentServiceOffering).toHaveBeenCalled();
  });
  it('setFilteredContentClearServiceOffering have been called', () => {
    spyOn(CapacityEvaluationAssociationUtils, 'setFilteredContentClearServiceOffering');
    component.setFilteredContentClearServiceOffering();
    expect(CapacityEvaluationAssociationUtils.setFilteredContentClearServiceOffering).toHaveBeenCalled();
  });
  it('setFilteredContentTeamType have been called', () => {
    spyOn(CapacityEvaluationAssociationUtils, 'setFilteredContentTeamType');
    component.setFilteredContentTeamType('string');
    expect(CapacityEvaluationAssociationUtils.setFilteredContentTeamType).toHaveBeenCalled();
  });
  it('setFilteredContentClearTeamType have been called', () => {
    spyOn(CapacityEvaluationAssociationUtils, 'setFilteredContentClearTeamType');
    component.setFilteredContentClearTeamType();
    expect(CapacityEvaluationAssociationUtils.setFilteredContentClearTeamType).toHaveBeenCalled();
  });
  it('should call onAddNew', () => {
    component.onAddNew();
    expect(component.capacityEvaluationAssociationModel.splitView).toBe(true);
  });
  it('showToastMsgForReactivateInactivate have been called', () => {
    component.showToastMsgForReactivateInactivate(true);
    expect(component.showToastMsgForReactivateInactivate).toBeTruthy();
  });
  it('showToastMsgForReactivateInactivate have been called', () => {
    component.showToastMsgForReactivateInactivate(false);
    expect(component.showToastMsgForReactivateInactivate).toBeTruthy();
  });
  it('showToastMessage have been called', () => {
    component.showToastMessage(true);
    expect(component.showToastMessage).toBeTruthy();
  });
  it('showToastMessage have been called', () => {
    component.showToastMessage(false);
    expect(component.showToastMessage).toBeTruthy();
  });
  it('onCompareOldData have been called', () => {
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = formGroup;
    component.capacityEvaluationAssociationModel.selectedRowContent = capacityEvaluationListModel;
    const checkReturn = component.onCompareOldData();
    expect(checkReturn).toBe(true);
  });
  it('onSave have been called with totalrecords', () => {
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = formGroup;
    component.capacityEvaluationAssociationModel.totalCodeRecords = 0;
    spyOn(component, 'unableToAdd');
    component.onSave();
    expect(component.unableToAdd).toHaveBeenCalled();
  });
  it('onSave have been called with selectedRowContent', () => {
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = formGroup;
    component.capacityEvaluationAssociationModel.selectedRowContent = capacityEvaluationListModel;
    component.onSave();
    expect(component.capacityEvaluationAssociationModel.isSectionLoaderEnabled).toBe(false);
  });
  it('should call selectedContentSplitScreen with value', () => {
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = formGroup;
    component.selectedContentSplitScreen(capacityEvaluationListModel);
    expect(component.capacityEvaluationAssociationModel.splitView).toBe(true);
  });
  it('should call onCancel with value', () => {
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = formGroup;
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.markAsTouched();
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.markAsDirty();
    component.onCancel();
    expect(component.capacityEvaluationAssociationModel.splitView).toBe(false);
  });
  it('should call onCancel with empty', () => {
    spyOn(component, 'closeSplitView');
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = formGroup;
    component.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.markAsUntouched();
    component.onCancel();
    expect(component.closeSplitView).toHaveBeenCalled();
  });
});
