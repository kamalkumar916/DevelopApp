import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';
import * as LodashUtils from 'lodash';
import * as moment from 'moment';

import { CapacityEvaluationAssociationModel } from './model/capacity-evaluation-association.model';
import { CapacityEvaluationAssociationService } from './services/capacity-evaluation-association.service';
import { CapacityEvaluationAssociationUtils } from './services/capacity-evaluation-association-utils';
import { CapacityEvaluationAssociationQuery } from './query/capacity-evaluation-association.query';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import {
  CapacityEvaluationAssociationListModel, CapacityEvaluationAssociationListAddModel, PageEvent, TeamType, BusinessType
} from './model/capacity-evaluation-association.interface';
import { ListItem } from '../../../model/listitem.interface';
import { DateUtils } from './../../../../shared/jbh-app-services/date-utils';

@Component({
  selector: 'app-capacity-evaluation-association',
  templateUrl: './capacity-evaluation-association.component.html',
  styleUrls: ['./capacity-evaluation-association.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class CapacityEvaluationAssociationComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('capacityDownloadExcel') capacityDownloadExcel: ElementRef;
  capacityEvaluationAssociationModel: CapacityEvaluationAssociationModel;
  operationalGroupSubtypeCode: FormGroup;
  message: Message[] = [];
  defaultSort = 'Status';
  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly confirmationService: ConfirmationService,
    private readonly capacityEvaluationAssociationService: CapacityEvaluationAssociationService,
    private readonly messageService: MessageService,
    private readonly formBuilder: FormBuilder) {
    this.capacityEvaluationAssociationModel = new CapacityEvaluationAssociationModel();
  }
  ngOnInit() {
    this.searchInput();
    this.overFlowMenuOptions();
  }
  ngOnDestroy() {
    this.capacityEvaluationAssociationModel.subscriberFlag = false;
  }
  get addCapacityEvaluationAssociationStatusFormControls() {
    return this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls;
  }
  onPage(thisEvent: PageEvent) {
    this.getCurrentScrollPosition();
    this.capacityEvaluationAssociationModel.pageStart = thisEvent.first;
    this.capacityEvaluationAssociationModel.tableSize = thisEvent.rows;
    this.capacityEvaluationAssociationModel.sortField = thisEvent.sortField;
    this.capacityEvaluationAssociationModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchCapacityEvaluationAssociationListData();
  }
  onAddCapacityEvaluationAssociationForm(): FormGroup {
    return this.formBuilder.group({
      businessUnit: ['', Validators.required],
      serviceOffering: ['', Validators.required],
      operationalGroupSubtypeCode: ['', Validators.required]
    });
  }
  onAddNew() {
    this.message = [];
    this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = this.onAddCapacityEvaluationAssociationForm();
    this.capacityEvaluationAssociationModel.splitView = true;
    this.getBusinessUnitDropdownValues();
    this.getTeamTypeDropdownValues();
  }
  overFlowMenuOptions() {
    this.capacityEvaluationAssociationModel.items = [{
      label: 'Export to Excel',
      command: (onclick) => {
        this.exportToExcel();
      }
    }];
  }
  exportToExcel() {
    this.capacityEvaluationAssociationService.capacityExcelDownload(CapacityEvaluationAssociationUtils.getExcelDownloadRequestBody(
      CapacityEvaluationAssociationQuery.getCapacityEvaluationAssociationListFromES(this.capacityEvaluationAssociationModel.queryString,
        this.capacityEvaluationAssociationModel.pageStart, this.capacityEvaluationAssociationModel.tableSize,
        this.capacityEvaluationAssociationModel.sortOrder, this.capacityEvaluationAssociationModel.sortField)))
      .pipe(
        takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
      ).subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `${
            this.capacityEvaluationAssociationModel.title} ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.capacityDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }
  downloadThisExcelFile(data: Blob, stopReasonDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      stopReasonDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      stopReasonDownloadExcel.nativeElement.download = fileName;
      stopReasonDownloadExcel.nativeElement.click();
    }
  }
  fetchCapacityEvaluationAssociationListData() {
    this.capacityEvaluationAssociationService.getCapacityEvaluationAssociationList(
      CapacityEvaluationAssociationQuery.getCapacityEvaluationAssociationListFromES(
        this.capacityEvaluationAssociationModel.queryString, this.capacityEvaluationAssociationModel.pageStart,
        this.capacityEvaluationAssociationModel.tableSize, this.capacityEvaluationAssociationModel.sortOrder,
        this.capacityEvaluationAssociationModel.sortField))
      .pipe(
        takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
        finalize(() => {
          this.capacityEvaluationAssociationModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        })
      ).subscribe((capacityEvaluationAssociationList: ElasticResponseModel) => {
        this.capacityEvaluationAssociationModel.gridLoaderFlag = false;
        if (!LodashUtils.isEmpty(capacityEvaluationAssociationList) && !LodashUtils.isEmpty(capacityEvaluationAssociationList.hits)
          && LodashUtils.isEmpty(capacityEvaluationAssociationList.hits.total)) {
          this.capacityEvaluationAssociationModel.gridLoaderFlag =
            !(this.capacityEvaluationAssociationModel.capacityEvaluationAssociationList.length > 0);
          this.capacityEvaluationAssociationModel.totalRecords = capacityEvaluationAssociationList.hits.total;
          this.capacityEvaluationAssociationModel.capacityEvaluationAssociationList =
            CapacityEvaluationAssociationUtils.getCapacityEvaluationAssociationListData(capacityEvaluationAssociationList);
          this.capacityEvaluationAssociationModel.paginatorFlag =
            (this.capacityEvaluationAssociationModel.capacityEvaluationAssociationList.length !== 0);
        }
      }, (error: Error) => {
        this.capacityEvaluationAssociationModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }
  onSearch() {
    this.capacityEvaluationAssociationModel.pageStart = 0;
    this.capacityEvaluationAssociationModel.userInputSearchSubject.next(this.capacityEvaluationAssociationModel.searchText);
  }
  searchInput() {
    this.capacityEvaluationAssociationModel.userInputSearchSubject
      .pipe(
        debounceTime(300), distinctUntilChanged(),
        takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
      ).subscribe(() => {
        if (this.capacityEvaluationAssociationModel.searchText.length === 0 ||
          this.capacityEvaluationAssociationModel.searchText.length > 2) {
          if (this.capacityEvaluationAssociationModel.searchText.match('^[0-9,]*$')) {
            this.capacityEvaluationAssociationModel.queryString =
              this.capacityEvaluationAssociationModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
            this.capacityEvaluationAssociationModel.queryString = this.capacityEvaluationAssociationModel.queryString.replace(/\,/g, '');
          } else {
            this.capacityEvaluationAssociationModel.queryString =
              this.capacityEvaluationAssociationModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
          }
          this.fetchCapacityEvaluationAssociationListData();
        } else if (this.capacityEvaluationAssociationModel.queryString) {
          this.capacityEvaluationAssociationModel.queryString = '';
          this.fetchCapacityEvaluationAssociationListData();
        }
      });
  }
  onCompareOldData() {
    if (this.capacityEvaluationAssociationModel.selectedRowContent) {
      const businessUnitRowValue = this.capacityEvaluationAssociationModel.selectedRowContent.businessUnitCode;
      const businessUnitFieldValue = this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.
        businessUnit.value.label;
      const serviceOfferingRowValue = this.capacityEvaluationAssociationModel.selectedRowContent.serviceOfferingCode;
      const serviceOfferingFieldValue = this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.
        serviceOffering.value.label;
      const operationalTypeRowValue = this.capacityEvaluationAssociationModel.selectedRowContent.operationalGroupSubtypeCode;
      const operationalTypeFieldValue = this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.
        operationalGroupSubtypeCode.value.label;
      return !((businessUnitRowValue === businessUnitFieldValue) && (serviceOfferingRowValue === serviceOfferingFieldValue) && (
        operationalTypeRowValue === operationalTypeFieldValue));
    } else {
      return true;
    }
  }
  onSave() {
    if (this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.valid &&
      (this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.dirty
        && this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.touched) && this.onCompareOldData()) {
      this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = true;
      if (this.capacityEvaluationAssociationModel.selectedRowContent) {
        this.editServicePlanOrWorkOrder();
      } else {
        this.saveServicePlanOrWorkOrder();
      }
    } else if (this.capacityEvaluationAssociationModel.selectedRowContent) {
      if (this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.valid) {
        this.messageService.clear();
        this.messageService.add({
          severity: 'info',
          summary: 'No Changes Detected',
        detail: `You've not done any changes to Capacity Evaluation Association.`
        });
      }
    } else {
      this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.serviceOffering.markAsTouched();
      this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.businessUnit.markAsTouched();
      this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.controls.
        operationalGroupSubtypeCode.markAsTouched();
      if (this.capacityEvaluationAssociationModel.totalCodeRecords === 0) {
        this.unableToAdd();
      }
    }
  }
  editServicePlanOrWorkOrder() {
    const editDetailsPlan: CapacityEvaluationAssociationListAddModel = {
      financeBusinessUnitCode:
        this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.value.businessUnit.label,
      serviceOfferingCode:
        this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.value.serviceOffering.label,
      operationalGroupSubtypeCode:
        this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.value.operationalGroupSubtypeCode.label,
      capacityEvaluationAssociationID: this.capacityEvaluationAssociationModel.selectedRowContent.capacityEvaluationAssociationID
    };
    this.capacityEvaluationAssociationService.editCapacityEvaluationAssociationList(editDetailsPlan)
      .pipe(
        takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(true);
      }, (err: Error) => {
        this.onServiceError(err);
      });
  }
  saveServicePlanOrWorkOrder() {
    const saveDetailsPlan: CapacityEvaluationAssociationListAddModel = {
      financeBusinessUnitCode:
        this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.value.businessUnit.label,
      serviceOfferingCode:
        this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.value.serviceOffering.label,
      operationalGroupSubtypeCode:
        this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.value.operationalGroupSubtypeCode.label
    };
    this.capacityEvaluationAssociationService.saveCapacityEvaluationAssociationList(saveDetailsPlan)
      .pipe(
        takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(false);
      }, (err: Error) => {
        this.onServiceError(err);
      });
    this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = false;
  }
  onServiceError(err: Error) {
    if (err['status'] === 409) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'error',
        summary: 'Duplicate Reference Data',
        detail: `The reference data already exists. So, you can't add this reference data.`
      });
    }
  }
  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isEditMode) ? 'Reference Data Updated' : 'Reference Data Added',
      detail: (isEditMode) ? 'Capacity Evaluation Association has been successfully updated.' :
        'Capacity Evaluation Association has been successfully added..'
    });
    this.changeDetector.detectChanges();
  }
  fetchAllData() {
    this.capacityEvaluationAssociationModel.searchText = '';
    this.capacityEvaluationAssociationModel.queryString = '';
    this.fetchCapacityEvaluationAssociationListData();
    this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = false;
    this.capacityEvaluationAssociationModel.splitView = false;
    this.changeDetector.detectChanges();
  }
  onCancel() {
    if (this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.touched
      && this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'CapacityEvaluationAssociation',
        accept: (): void => {
          this.closeSplitView();
          this.capacityEvaluationAssociationModel.splitView = false;
        }
      });
    } else {
      this.closeSplitView();
    }
  }
  closeSplitView() {
    this.fetchCapacityEvaluationAssociationListData();
    this.closeAddEditPage();
  }
  onRowSelect(selectedRow: CapacityEvaluationAssociationListModel) {
    this.message = [];
    this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = true;
    if (this.capacityEvaluationAssociationModel.selectedRowContent && selectedRow.serviceOfferingCode !==
      this.capacityEvaluationAssociationModel.selectedRowContent.serviceOfferingCode) {
      this.selectedContentSplitScreen(selectedRow);
    } else if (!this.capacityEvaluationAssociationModel.selectedRowContent) {
      this.selectedContentSplitScreen(selectedRow);
    }
  }
  selectedContentSplitScreen(selectedContent: CapacityEvaluationAssociationListModel) {
    this.capacityEvaluationAssociationModel.selectedRowContent = selectedContent;
    this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm = this.onAddCapacityEvaluationAssociationForm();
    this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.patchValue({
      businessUnit: { label: selectedContent.businessUnitCode },
      serviceOffering: { label: selectedContent.serviceOfferingCode },
      operationalGroupSubtypeCode: { label: selectedContent.operationalGroupSubtypeCode }
    });
    this.getBusinessUnitDropdownValues();
    this.getServiceOfferingDropdownValues(selectedContent.businessUnitCode);
    this.getTeamTypeDropdownValues();
    this.capacityEvaluationAssociationModel.splitView = true;
    this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = false;
  }
  closeAddEditPage() {
    this.capacityEvaluationAssociationModel.selectedRowContent = null;
    this.capacityEvaluationAssociationModel.splitView = false;
  }
  onActivate() {
    this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = true;
    this.capacityEvaluationAssociationService.reactivateCapacityEvaluationAssociationList(
      CapacityEvaluationAssociationUtils.activateInactivateContent
        (this.capacityEvaluationAssociationModel.selectedRowContent.operationalGroupSubtypeCode,
          this.capacityEvaluationAssociationModel.selectedRowContent.capacityEvaluationAssociationID))
      .pipe(
        takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(false);
      }, (err: Error) => {
        this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = false;
        this.messageService.clear();
        this.messageService.add({
          severity: 'info',
          summary: 'Activate Unsuccessful',
          detail: `The reference data can\'t be activated as one or more Driver Task Type associated to the reference data is
           inactive. Please activate the Driver Task Type and try again.`
        });
        this.changeDetector.detectChanges();
      }
      );
  }
  onInactivate() {
    this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.patchValue({
      businessUnit: { label: this.capacityEvaluationAssociationModel.selectedRowContent.businessUnitCode },
      serviceOffering: { label: this.capacityEvaluationAssociationModel.selectedRowContent.serviceOfferingCode },
      operationalGroupSubtypeCode: { label: this.capacityEvaluationAssociationModel.selectedRowContent.operationalGroupSubtypeCode }
    });
    this.confirmationService.confirm({
      message: `Business Unit <b>${this.capacityEvaluationAssociationModel.selectedRowContent.businessUnitCode}</b><br>Service Offering
      <b>${this.capacityEvaluationAssociationModel.selectedRowContent.serviceOfferingCode}</b>
      <br>Operaional Team Type <b>
      ${this.capacityEvaluationAssociationModel.selectedRowContent.operationalGroupSubtypeCode}</b><br><br><br>The
       reference data you're about to inactivate may be associated to active orders or other entities,
       inactivating the data will not impact current associations but <b>new entities can no longer reference this record.
      </b><br><br> Any other <b>reference data that has
       this record as an association will also be inactivated.</b><br><br> Do you wish to proceed ?`,
      header: 'Inactivate Capacity Evaluation Association',
      key: 'inactivateCapacityEvaluationAssociationStatus',
      accept: (): void => {
        this.capacityEvaluationAssociationModel.isSectionLoaderEnabled = true;
        this.inactivatePlanOrWorkOrder();
      }
    });
  }
  inactivatePlanOrWorkOrder() {
    this.capacityEvaluationAssociationService.inactivateCapacityEvaluationAssociationList(
      CapacityEvaluationAssociationUtils.activateInactivateContent
        (this.capacityEvaluationAssociationModel.selectedRowContent.operationalGroupSubtypeCode,
          this.capacityEvaluationAssociationModel.selectedRowContent.capacityEvaluationAssociationID))
      .pipe(
        takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
      ).subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(true);
      });
  }
  showToastMsgForReactivateInactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isDeactivateMode) ? 'Reference Data Inactivated' : 'Reference Data Activated',
      detail: (isDeactivateMode) ? 'Capacity Evaluation Association has been successfully inactivated.' :
        'Capacity Evaluation Association has been successfully activated.'
    });
    this.changeDetector.detectChanges();
  }
  getBusinessUnitDropdownValues() {
    this.capacityEvaluationAssociationService.getBusinessUnitDropdownValues().pipe(
      takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
    ).subscribe((data: BusinessType) => {
      CapacityEvaluationAssociationUtils.getBUDropdownValues(data, this.capacityEvaluationAssociationModel, this.changeDetector);
      this.changeDetector.detectChanges();
    });
  }
  selectBusinessUnit(businessUnit: ListItem) {
    this.capacityEvaluationAssociationModel.addCapacityEvaluationAssociationStatusForm.patchValue({
      serviceOffering: { label: '', value: '' },
    });
    this.getServiceOfferingDropdownValues(businessUnit.label);
  }
  getServiceOfferingDropdownValues(selectedBU: string) {
    this.capacityEvaluationAssociationService.getServiceOfferingDropdownValues(selectedBU).pipe(
      takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
    ).subscribe((data: BusinessType) => {
      CapacityEvaluationAssociationUtils.getServiceDropdownValues(data, this.capacityEvaluationAssociationModel, this.changeDetector);
      this.changeDetector.detectChanges();
    });
  }
  getTeamTypeDropdownValues() {
    const teamTypeDate = DateUtils.dateTimeZone(new Date());
    this.capacityEvaluationAssociationService.getTeamTypeList(teamTypeDate).pipe(
      takeWhile(() => this.capacityEvaluationAssociationModel.subscriberFlag),
    ).subscribe((data: TeamType) => {
      if (data && data._embedded && data._embedded.operationalGroupSubtypes) {
        if (data._embedded.operationalGroupSubtypes.length > 0) {
          const listData = data._embedded.operationalGroupSubtypes;
          this.capacityEvaluationAssociationModel.dropdownLabelsType = listData.map((element) => {
            return {
              label: element.operationalGroupSubtypeCode, value: element.operationalGroupSubtypeCode
            };
          });
          this.capacityEvaluationAssociationModel.teamTypeItems =
            LodashUtils.cloneDeep(this.capacityEvaluationAssociationModel.dropdownLabelsType);
          this.changeDetector.detectChanges();
        } else {
          this.unableToAdd();
          this.changeDetector.detectChanges();
        }
      }
    }, (err: Error) => {
      this.unableToAdd();
    });
  }
  unableToAdd() {
    this.capacityEvaluationAssociationModel.totalCodeRecords = 0;
    this.capacityEvaluationAssociationModel.lableValue = true;
    this.message = [];
    this.message.push({
      severity: this.capacityEvaluationAssociationModel.information,
      summary: ' ',
      detail: 'You can\'t add Driver Task Sub Type as there is no active Driver Task Type'
    });
  }
  setFilteredContentBU(userSearchInput: string) {
    CapacityEvaluationAssociationUtils.setFilteredContentBU(userSearchInput, this.capacityEvaluationAssociationModel);
  }
  setFilteredContentClearBU() {
    CapacityEvaluationAssociationUtils.setFilteredContentClearBU(this.capacityEvaluationAssociationModel);
  }
  setFilteredContentServiceOffering(userSearchInput: string) {
    CapacityEvaluationAssociationUtils.setFilteredContentServiceOffering(userSearchInput, this.capacityEvaluationAssociationModel);
  }
  setFilteredContentClearServiceOffering() {
    CapacityEvaluationAssociationUtils.setFilteredContentClearServiceOffering(this.capacityEvaluationAssociationModel);
  }
  setFilteredContentTeamType(userSearchInput: string) {
    CapacityEvaluationAssociationUtils.setFilteredContentTeamType(userSearchInput, this.capacityEvaluationAssociationModel);
  }
  setFilteredContentClearTeamType() {
    CapacityEvaluationAssociationUtils.setFilteredContentClearTeamType(this.capacityEvaluationAssociationModel);
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
}
