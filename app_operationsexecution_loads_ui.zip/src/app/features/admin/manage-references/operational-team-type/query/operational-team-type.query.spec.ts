import { OperationalTeamTypeQuery } from './operational-team-type.query';

describe('OperationalTeamTypeQuery', () => {
    it('getOperationalTeamTypeListFromES have been called', () => {
        const result = OperationalTeamTypeQuery.getOperationalTeamTypeListFromES('string', 11, 11, 'string', 'string');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamTypeQuery.getSortQuery('12', 'OperationalGroupSubtypeCode');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamTypeQuery.getSortQuery('12', 'LastUpdateProgramName');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamTypeQuery.getSortQuery('12', 'LastUpdateTimestamp');
        expect(result).toBeTruthy();
    });
    it('getSortQuery have been called', () => {
        const result = OperationalTeamTypeQuery.getSortQuery('12', 'defaultSort');
        expect(result).toBeTruthy();
    });
});
