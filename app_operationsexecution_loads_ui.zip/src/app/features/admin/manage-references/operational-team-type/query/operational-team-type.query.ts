export class OperationalTeamTypeQuery {
  static getOperationalTeamTypeListFromES(searchText: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size,
      query: {
        query_string: {
          fields: [
            'OperationalGroupSubtypeCode',
            'OperationalGroupSubtypeDescription',
            'LastUpdateTimestamp.text',
            'LastUpdateProgramName',
            'LastUpdateUserID',
            'Status'
          ],
          query: `*${searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&')}*`,
          default_operator: 'AND'
        }
      },
      sort: this.getSortQuery(sortOrder, sortField),
      _source: [
        'OperationalGroupSubtypeDescription',
        'OperationalGroupSubtypeCode',
        'LastUpdateTimestamp',
        'LastUpdateProgramName',
        'LastUpdateUserID',
        'Status'
      ]
    };
  }
  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'OperationalGroupSubtypeCode':
      case 'OperationalGroupSubtypeDescription':
      case 'Status':
      sortObject[`${sortField}.keyword`] = {
        order: sortOrder
      };
      break;
      case 'LastUpdateProgramName':
      sortObject = [{
        'LastUpdateProgramName.keyword': {
          order: sortOrder
              }
            },
            {
        'LastUpdateUserID.keyword': {
          order: sortOrder
        }
      }];
      break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'OperationalGroupSubtypeDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }
}
