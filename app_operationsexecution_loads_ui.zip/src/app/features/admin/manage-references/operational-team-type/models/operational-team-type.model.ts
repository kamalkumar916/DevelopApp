import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';

import { OperationalTeamTypeListModel, TableColumnModel } from './operational-team-type.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class OperationalTeamTypeModel {
  items: Array<MenuItem>;
  splitView: boolean;
  operationalTeamTypeList: Array<OperationalTeamTypeListModel>;
  operationalTeamTypeSelectedList: Array<OperationalTeamTypeListModel>;
  paginatorFlag: boolean;
  totalRecords: number;
  pageStart: number;
  tableSize: number;
  queryString: string;
  searchText: string;
  subscriberFlag: boolean;
  isSectionLoaderEnabled: boolean;
  tableColumns: Array<TableColumnModel>;
  userInputSearchSubject: Subject<string>;
  addOperationalTeamTypeStatusForm: FormGroup;
  inactiveLabel: string;
  activeLabel: string;
  selectedRowContent: OperationalTeamTypeListModel;
  operationalWorkOrderLabel: string;
  operationalPlanLabel: string;
  lableValue: boolean;
  sortOrder: string;
  sortField: string;
  gridLoaderFlag: boolean;
  information: string;
  successMessage: string;
  referenceData: string;
  title: string;
  addNewButton: SecureModel;
  inactivateButton: SecureModel;
  activateButton: SecureModel;
  appConfig;

  constructor() {
    this.splitView = false;
    this.operationalTeamTypeList = [];
    this.operationalTeamTypeSelectedList = [];
    this.paginatorFlag = false;
    this.totalRecords = 0;
    this.pageStart = 0;
    this.tableSize = 25;
    this.queryString = '';
    this.searchText = '';
    this.subscriberFlag = true;
    this.isSectionLoaderEnabled = false;
    this.userInputSearchSubject = new Subject<string>();
    this.selectedRowContent = null;
    this.inactiveLabel = 'inactive';
    this.activeLabel = 'active';
    this.sortField = 'defaultSort';
    this.sortOrder = 'asc';
    this.gridLoaderFlag = true;
    this.title = 'Operational Team Type';
    this.information = 'ADMIN_MODULE_COMMON.INFORMATION';
    this.successMessage = 'ADMIN_MODULE_COMMON.REFERENCE_DATA';
    this.referenceData = 'TEAMTYPE.REFERENCEDATA_DETAIL';
    this.tableColumns = [
      { 'label': 'Name', 'key': 'operationalGroupSubtypeDescription', 'esKey': 'OperationalGroupSubtypeDescription' },
      { 'label': 'Identifier', 'key': 'operationalGroupSubtypeCode', 'esKey': 'OperationalGroupSubtypeCode' },
      { 'label': 'Last Updated', 'key': 'lastUpdateTimestamp', 'esKey': 'LastUpdateTimestamp' },
      { 'label': 'Last Updated By', 'key': 'lastUpdatedBy', 'esKey': 'LastUpdateProgramName' },
      { 'label': 'Status', 'key': 'status', 'esKey': 'Status' }];
    this.appConfig = AppConfig.getConfig();
    this.addNewButton = { url: this.appConfig.api.admin.saveOperationalTeamType, operation: 'C' };
    this.inactivateButton = { url: this.appConfig.api.admin.inactivateOperationalTeamTypeStatus, operation: 'C' };
    this.activateButton = { url: this.appConfig.api.admin.reactivateOperationalTeamTypeStatus, operation: 'C' };
  }

}
