export interface TableColumnModel {
  label: string;
  key: string;
  esKey: string;
}

export interface OperationalTeamTypeListModel {
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateProgramName: string;
  lastUpdateTimestamp: string;
  lastUpdateUserID: string;
  operationalGroupSubtypeCode: string;
  operationalGroupSubtypeDescription: string;
  status: string;
}

export interface OperationalTeamTypeListAddModel {
  operationalGroupSubtypeDescription: string;
  operationalGroupSubtypeCode: string;
}

export interface OperationalTeamTypeActiveInactiveModel {
  operationalGroupSubtypeCode: string;
}

export interface InactiveData {
  operationalGroupSubtypeCode: boolean;
  _links: Links;
}

export interface Links {
  self: Self;
}

export interface Self {
  href: string;
}

export interface SortView {
  first: number;
  rows: number;
  sortField: string;
  sortOrder: number;
}
