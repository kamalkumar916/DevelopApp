import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { configureTestSuite } from 'ng-bullet';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { OperationalTeamTypeComponent } from './operational-team-type.component';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { OperationalTeamTypeService } from '../operational-team-type/services/operational-team-type.service';
import { TooltipModule } from 'primeng/tooltip';
import { Validators, FormBuilder, FormGroup, } from '@angular/forms';
import { UserService } from './../../../../shared/jbh-esa';
import { of } from 'rxjs/internal/observable/of';
import { OperationalTeamTypeActiveInactiveModel } from './models/operational-team-type.interface';

const inactivedata = {
  operationalGroupTypeCode: true,
  _links: {
    self: {
      href: 'string'
    }
  }
};

class MockOperationalTeamService {
  constructor() { }
  inactiveError(requestParam: string) {
    return of(inactivedata);
  }
  reactivateOperationalTeamTypeList(value: OperationalTeamTypeActiveInactiveModel) {
    return of({});
  }
  inactivateOperationalTeamTypeList(value: OperationalTeamTypeActiveInactiveModel) {
    return of({});
  }
  getOperationalTeamTypeList(query: object) {
    return of(null);
  }
  teamTypeExcelDownload(value: any) {
    return of(null);
  }
}

describe('OperationalTeamTypeComponent', () => {
  let component: OperationalTeamTypeComponent;
  let fixture: ComponentFixture<OperationalTeamTypeComponent>;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  const operationalCategoryListModel = {
    effectiveTimestamp: 'string',
    expirationTimestamp: 'string',
    lastUpdateProgramName: 'string',
    lastUpdateTimestamp: 'string',
    lastUpdateUserID: 'string',
    operationalGroupSubtypeCode: 'string',
    operationalGroupSubtypeDescription: 'string',
    status: 'string',
  };


  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, DirectivesModule, NoopAnimationsModule,
        TableModule, ReactiveFormsModule, FormsModule, MenuModule, ButtonModule, JbhLoaderModule, MessagesModule,
        MessageModule, PipesModule, PipesModule, ConfirmDialogModule, TooltipModule],


      providers: [AppConfigService, MessageService, ConfirmationService,
        { provide: OperationalTeamTypeService, useClass: MockOperationalTeamService }, UserService],
      declarations: [OperationalTeamTypeComponent]

    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OperationalTeamTypeComponent);
    component = fixture.componentInstance;
    formGroup = formBuilder.group({
      owoTypeDescription: ['string', Validators.required],
      owoTypeCode: ['', Validators.required]
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('fetchAllData have been called', () => {
    spyOn(component, 'fetchOperationalTeamTypeListData');
    component.fetchAllData();
    expect(component.operationalTeamTypeModel.isSectionLoaderEnabled).toBe(false);
    expect(component.fetchOperationalTeamTypeListData).toHaveBeenCalled();
  });

  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.operationalTeamTypeModel.splitView).toBe(false);
  });

  it('onAddNew have been called', () => {
    component.onAddNew();
    expect(component.operationalTeamTypeModel.splitView).toBe(true);
  });

  it('sortOrder to be desc', () => {
    spyOn(component, 'fetchOperationalTeamTypeListData');
    component.onPage({ first: 1, rows: 10, sortField: 'test', sortOrder: -1 });
    expect(component.operationalTeamTypeModel.sortOrder).toBe('desc');
    expect(component.fetchOperationalTeamTypeListData).toHaveBeenCalled();

  });

  it('onSearch to be called', () => {
    component.onSearch({});
    expect(component.operationalTeamTypeModel.pageStart).toBe(0);
  });

  it('onCompareOldData have been called', () => {
    component.operationalTeamTypeModel.selectedRowContent = null;
    component.onCompareOldData();
    expect(component.operationalTeamTypeModel.splitView).toBe(false);
  });
  it('showToastMsgForReactivateInactivate have been called', () => {
    component.showToastMsgForReactivateInactivate(true);
    expect(component.showToastMsgForReactivateInactivate).toBeTruthy();
  });
  it('showToastMsgForReactivateInactivate have been called', () => {
    component.showToastMsgForReactivateInactivate(false);
    expect(component.showToastMsgForReactivateInactivate).toBeTruthy();
  });
  it('showToastMessage have been called', () => {
    component.showToastMessage(true);
    expect(component.showToastMessage).toBeTruthy();
  });
  it('showToastMessage have been called', () => {
    component.showToastMessage(false);
    expect(component.showToastMessage).toBeTruthy();
  });
  it('should call closeSplitView and expect fetchlistdata method has called', () => {
    spyOn(component, 'fetchOperationalTeamTypeListData');
    component.closeSplitView();
    expect(component.fetchOperationalTeamTypeListData).toHaveBeenCalled();
  });
  it('onCompareOldData have been called', () => {
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = formGroup;
    component.operationalTeamTypeModel.selectedRowContent = operationalCategoryListModel;
    const checkReturn = component.onCompareOldData();
    expect(checkReturn).toBe(false);
  });
  it('onSave have been called with selectedRowContent', () => {
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = formGroup;
    component.operationalTeamTypeModel.selectedRowContent = operationalCategoryListModel;
    component.onSave();
    expect(component.operationalTeamTypeModel.isSectionLoaderEnabled).toBe(false);
  });
  it('onSave have been called without selectedRowContent', () => {
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = formGroup;
    component.onSave();
    expect(component.operationalTeamTypeModel.isSectionLoaderEnabled).toBe(false);
  });
  it('should call onCancel with value', () => {
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = formGroup;
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.markAsTouched();
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.markAsDirty();
    component.onCancel();
    expect(component.operationalTeamTypeModel.splitView).toBe(false);
  });
  it('should call onCancel with empty', () => {
    spyOn(component, 'closeSplitView');
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = formGroup;
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.markAsUntouched();
    component.onCancel();
    expect(component.closeSplitView).toHaveBeenCalled();
  });
  it('should call onRowSelect with value', () => {
    const data = {
      effectiveTimestamp: 'string',
      expirationTimestamp: 'string',
      lastUpdateProgramName: 'string',
      lastUpdateTimestamp: 'string',
      lastUpdateUserID: 'string',
      operationalGroupSubtypeCode: '',
      operationalGroupSubtypeDescription: 'string',
      status: 'string',
    };
    component.operationalTeamTypeModel.selectedRowContent = data;
    spyOn(component, 'splitScreenEditAdd');
    component.onRowSelect(operationalCategoryListModel);
    expect(component.splitScreenEditAdd).toHaveBeenCalled();
  });
  it('should call onRowSelect with null', () => {
    component.operationalTeamTypeModel.selectedRowContent = null;
    spyOn(component, 'splitScreenEditAdd');
    component.onRowSelect(operationalCategoryListModel);
    expect(component.splitScreenEditAdd).toHaveBeenCalled();
  });
  it('selectedContentSplitScreen have been called', () => {
    component.selectedContentSplitScreen(operationalCategoryListModel);
    expect(component.operationalTeamTypeModel.isSectionLoaderEnabled).toBe(false);
  });
  it('onInactivate have been called', () => {
    component.operationalTeamTypeModel.selectedRowContent = operationalCategoryListModel;
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = formGroup;
    component.onInactivate();
    expect(component.onInactivate).toBeTruthy();
  });
  it('onActivate have been called', () => {
    component.operationalTeamTypeModel.selectedRowContent = operationalCategoryListModel;
    component.onActivate();
    expect(component.operationalTeamTypeModel.isSectionLoaderEnabled).toBeFalsy();
  });
  it('inactivatePlanOrWorkOrder have been called', () => {
    component.operationalTeamTypeModel.selectedRowContent = operationalCategoryListModel;
    component.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = formGroup;
    component.inactivatePlanOrWorkOrder();
    expect(component.inactivatePlanOrWorkOrder).toBeTruthy();
  });
  it('fetchOperationalTeamTypeListData have been called', () => {
    component.fetchOperationalTeamTypeListData();
    expect(component.fetchOperationalTeamTypeListData).toBeTruthy();
  });
});
