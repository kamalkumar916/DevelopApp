import {
  OperationalTeamTypeListModel, OperationalTeamTypeActiveInactiveModel
} from '../models/operational-team-type.interface';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class OperationalTeamTypeUtils {

  constructor() { }

  static getOperationalTeamTypeListData(operationalTeamTypeList: ElasticResponseModel): OperationalTeamTypeListModel[] {
    let returnData: OperationalTeamTypeListModel[] = [];
    if (operationalTeamTypeList && operationalTeamTypeList.hits && operationalTeamTypeList.hits.hits) {
      returnData = operationalTeamTypeList.hits.hits.map((operationalTeamTypeStatus: HitsModel) => {
        return {
          'effectiveTimestamp': operationalTeamTypeStatus._source.EffectiveTimestamp,
          'expirationTimestamp': operationalTeamTypeStatus._source.ExpirationTimestamp,
          'lastUpdateProgramName': operationalTeamTypeStatus._source.LastUpdateProgramName,
          'lastUpdateTimestamp':
          DateUtils.convertOffsetDateByDefaultTimeZone(operationalTeamTypeStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
          'lastUpdateUserID': operationalTeamTypeStatus._source.LastUpdateUserID,
          'status': operationalTeamTypeStatus._source.Status,
          'operationalGroupSubtypeCode': operationalTeamTypeStatus._source.OperationalGroupSubtypeCode,
          'operationalGroupSubtypeDescription': operationalTeamTypeStatus._source.OperationalGroupSubtypeDescription,
          'lastUpdatedBy': `${operationalTeamTypeStatus._source.LastUpdateProgramName}
        ${'('}${operationalTeamTypeStatus._source.LastUpdateUserID}${')'}`
        };
      });
    }
    return returnData;
  }

  static activateInactivateContent(typeCode: string): OperationalTeamTypeActiveInactiveModel {
    return {
      'operationalGroupSubtypeCode': typeCode
    };
  }

  static getExcelDownloadRequestBody(esQuery: object) {
    return {
        query: esQuery['query'],
        sort: esQuery['sort']
    };
  }
}
