import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import {
  OperationalTeamTypeListAddModel, OperationalTeamTypeActiveInactiveModel, InactiveData
} from '../models/operational-team-type.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';


@Injectable()
export class OperationalTeamTypeService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
}

  /* Elastic Search - POST API
      Params - Input : Elastic Search Query
    */
  getOperationalTeamTypeList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getOperationalTeamTypeList, query);
  }

  saveOperationalTeamTypeList(query: OperationalTeamTypeListAddModel): Observable<boolean> {
    return this.http.post<boolean>(this.endpoint.saveOperationalTeamType, query);
  }

  editOperationalTeamTypeList(query: OperationalTeamTypeListAddModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.saveOperationalTeamType, query);
  }

  inactivateOperationalTeamTypeList(operationalTeamTypeCodeModel: OperationalTeamTypeActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.inactivateOperationalTeamTypeStatus, operationalTeamTypeCodeModel);
  }

  reactivateOperationalTeamTypeList(operationalTeamTypeCodeModel: OperationalTeamTypeActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.reactivateOperationalTeamTypeStatus, operationalTeamTypeCodeModel);
  }

  inactiveError(identifier: string): Observable<InactiveData> {
    return this.http.get<InactiveData>(`${this.endpoint.saveOperationalTeamType}${'?operationalGroupSubtypeCode='}${identifier}`);
  }

  teamTypeExcelDownload(requestParam, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoint.teamTypeExportExcel, requestParam, { headers, responseType: 'blob' });
  }
}
