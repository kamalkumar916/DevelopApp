import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { OperationalTeamTypeService } from './operational-team-type.service';
import { configureTestSuite } from 'ng-bullet';

describe('OperationalTeamTypeService', () => {
  let httpTestingController: HttpTestingController;
  let service: OperationalTeamTypeService;
  configureTestSuite(() => TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule],
      providers: [AppConfigService, OperationalTeamTypeService]
  }));

  beforeEach(() => {
    service = TestBed.get(OperationalTeamTypeService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('check getOperationalTeamTypeList is calling method is "post"', () => {
    service.getOperationalTeamTypeList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalTeamTypeList);
    expect(req.request.method).toEqual('POST');
  });
});
