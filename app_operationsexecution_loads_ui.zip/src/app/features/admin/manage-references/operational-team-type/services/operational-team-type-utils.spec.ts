import { OperationalTeamTypeUtils } from './operational-team-type-utils';


describe('OperationalTeamTypeUtils', () => {
    const elasticResponse = {
        hits: {
            hits: [{
                sort: [
                    'string',
                ],
                _id: 'string',
                _index: 'string',
                _score: 1,
                _source: {
                    EffectiveTimestamp: 'string',
                    ExpirationTimestamp: 'string',
                    LastUpdateProgramName: 'string',
                    LastUpdateTimestamp: 'string',
                    LastUpdateUserID: 'string',
                    Status: 'string',
                    OperationalGroupSubtypeCode: 'string',
                    ServiceOfferingCode: 'string',
                    FinanceBusinessUnitCode: 'string',
                    CapacityEvaluationAssociationID: 'string',
                },
                _type: 'string',
            }],
            max_score: 1,
            total: 1,
        },
        timed_out: true,
        took: 1,
        _shards: {
            total: 1,
            successful: 1,
            skipped: 1,
            failed: 1,
        },
    };
    it('getOperationalTeamTypeListData have been called', () => {
        const result = OperationalTeamTypeUtils.getOperationalTeamTypeListData(elasticResponse);
        expect(result).toBeTruthy();
    });

    it('getExcelDownloadRequestBody have been called', () => {
        const data = {
            query: 'string',
            sort: 'string'
        };
        const result = OperationalTeamTypeUtils.getExcelDownloadRequestBody(data);
        expect(result).toBeTruthy();
    });
});
