import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import * as LodashUtils from 'lodash';
import * as moment from 'moment';

import { OperationalTeamTypeModel } from './models/operational-team-type.model';
import { OperationalTeamTypeService } from './services/operational-team-type.service';
import { OperationalTeamTypeUtils } from './services/operational-team-type-utils';
import { OperationalTeamTypeQuery } from './query/operational-team-type.query';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import {
  OperationalTeamTypeListModel, OperationalTeamTypeListAddModel, InactiveData, SortView
} from './models/operational-team-type.interface';

@Component({
  selector: 'app-operational-team-type',
  templateUrl: './operational-team-type.component.html',
  styleUrls: ['./operational-team-type.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class OperationalTeamTypeComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('teamTypeDownloadExcel') teamTypeDownloadExcel: ElementRef;
  operationalTeamTypeModel: OperationalTeamTypeModel;
  msgs: Message[] = [];
  defaultSort = 'Status';

  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly confirmationService: ConfirmationService,
    private readonly operationalTeamTypeService: OperationalTeamTypeService,
    private readonly messageService: MessageService,
    private readonly formBuilder: FormBuilder) {
    this.operationalTeamTypeModel = new OperationalTeamTypeModel();
  }

  ngOnInit() {
    this.searchInput();
    this.overFlowMenuOptions();
  }

  ngOnDestroy() {
    this.operationalTeamTypeModel.subscriberFlag = false;
  }

  get teamTypeControls() {
    return this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.controls;
  }
  onPage(thisEvent: SortView) {
    this.getCurrentScrollPosition();
    this.operationalTeamTypeModel.pageStart = thisEvent.first;
    this.operationalTeamTypeModel.tableSize = thisEvent.rows;
    this.operationalTeamTypeModel.sortField = thisEvent.sortField;
    this.operationalTeamTypeModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchOperationalTeamTypeListData();
  }

  onAddOperationalTeamTypeForm(): FormGroup {
    return this.formBuilder.group({
      owoTypeDescription: ['', Validators.required],
      owoTypeCode: ['', Validators.required]
    });
  }
  onAddNew() {
    this.msgs = [];
    this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = this.onAddOperationalTeamTypeForm();
    this.operationalTeamTypeModel.splitView = true;
  }

  overFlowMenuOptions() {
    this.operationalTeamTypeModel.items = [
      {
        label: 'Export to Excel',
        command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }
  exportToExcel() {
    this.operationalTeamTypeService.teamTypeExcelDownload(OperationalTeamTypeUtils.getExcelDownloadRequestBody(
      OperationalTeamTypeQuery.getOperationalTeamTypeListFromES(this.operationalTeamTypeModel.queryString,
        this.operationalTeamTypeModel.pageStart, this.operationalTeamTypeModel.tableSize,
        this.operationalTeamTypeModel.sortOrder, this.operationalTeamTypeModel.sortField)))
      .pipe(
        takeWhile(() => this.operationalTeamTypeModel.subscriberFlag),
      ).subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `${
            this.operationalTeamTypeModel.title} ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.teamTypeDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }
  downloadThisExcelFile(data: Blob, teamTypeDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      teamTypeDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      teamTypeDownloadExcel.nativeElement.download = fileName;
      teamTypeDownloadExcel.nativeElement.click();
    }
  }
  fetchOperationalTeamTypeListData() {
    this.operationalTeamTypeService.getOperationalTeamTypeList(OperationalTeamTypeQuery.getOperationalTeamTypeListFromES(
      this.operationalTeamTypeModel.queryString, this.operationalTeamTypeModel.pageStart
      , this.operationalTeamTypeModel.tableSize, this.operationalTeamTypeModel.sortOrder,
      this.operationalTeamTypeModel.sortField)).
      pipe(takeWhile(() => this.operationalTeamTypeModel.subscriberFlag),
        finalize(() => {
          this.operationalTeamTypeModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((operationalTeamTypeList: ElasticResponseModel) => {
        if (!LodashUtils.isEmpty(operationalTeamTypeList) && !LodashUtils.isEmpty(operationalTeamTypeList.hits)
          && LodashUtils.isEmpty(operationalTeamTypeList.hits.total)) {
          this.operationalTeamTypeModel.gridLoaderFlag =
            !(this.operationalTeamTypeModel.operationalTeamTypeList.length > 0);
          this.operationalTeamTypeModel.totalRecords = operationalTeamTypeList.hits.total;
          this.operationalTeamTypeModel.operationalTeamTypeList =
            OperationalTeamTypeUtils.getOperationalTeamTypeListData(operationalTeamTypeList);
          this.operationalTeamTypeModel.paginatorFlag =
            this.operationalTeamTypeModel.operationalTeamTypeList.length > 0;
        }
      }, (error: Error) => {
        this.operationalTeamTypeModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }

  onSearch(event) {
    this.operationalTeamTypeModel.userInputSearchSubject.next(event);
    this.operationalTeamTypeModel.pageStart = 0;
  }

  searchInput() {
    this.operationalTeamTypeModel.userInputSearchSubject.
      pipe(debounceTime(300),
        takeWhile(() => this.operationalTeamTypeModel.subscriberFlag))
      .subscribe(() => {
        if (this.operationalTeamTypeModel.searchText.length === 0 || this.operationalTeamTypeModel.searchText.length > 2) {
          this.operationalTeamTypeModel.queryString = this.operationalTeamTypeModel.searchText;
          this.fetchOperationalTeamTypeListData();
        } else {
          this.operationalTeamTypeModel.queryString = '';
          this.fetchOperationalTeamTypeListData();
        }
      });
  }

  onCompareOldData() {
    if (this.operationalTeamTypeModel.selectedRowContent) {
      const nameRowValue = this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeDescription;
      const nameFieldValue = this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.controls.
        owoTypeDescription.value;
      return (nameRowValue !== nameFieldValue);
    } else {
      return true;
    }
  }
  onSave() {
    if (this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.valid &&
      (this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.dirty &&
        this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.touched) && this.onCompareOldData()) {
      this.operationalTeamTypeModel.isSectionLoaderEnabled = true;
      if (this.operationalTeamTypeModel.selectedRowContent) {
        this.editServicePlanOrWorkOrder();
      } else {
        this.saveServicePlanOrWorkOrder();
      }
    } else if (this.operationalTeamTypeModel.selectedRowContent) {
      if (this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.valid) {
        this.messageService.clear();
        this.messageService.add({
          severity: 'info',
          summary: 'No Changes Detected',
          detail: `You've not done any changes to Operational Team Type.`
        });
      }
    } else {
      this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.controls.owoTypeCode.markAsTouched();
      this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.controls.owoTypeDescription.markAsTouched();
    }
  }

  editServicePlanOrWorkOrder() {
    const editDetailsPlan: OperationalTeamTypeListAddModel = {
      operationalGroupSubtypeDescription:
        this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.value.owoTypeDescription,
      operationalGroupSubtypeCode: this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.value.owoTypeCode
    };
    this.operationalTeamTypeService.editOperationalTeamTypeList(editDetailsPlan)
      .pipe(
        takeWhile(() => this.operationalTeamTypeModel.subscriberFlag),
        finalize(() => this.operationalTeamTypeModel.selectedRowContent = null)
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(true);
      });
  }

  saveServicePlanOrWorkOrder() {
    const saveDetailsPlan: OperationalTeamTypeListAddModel = {
      operationalGroupSubtypeDescription:
        this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.value.owoTypeDescription,
      operationalGroupSubtypeCode: this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.value.owoTypeCode
    };
    this.operationalTeamTypeService.saveOperationalTeamTypeList(saveDetailsPlan)
      .pipe(
        takeWhile(() => this.operationalTeamTypeModel.subscriberFlag)
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(false);
      }, (err: Error) => {
        this.onServiceError(err);
      });
    this.operationalTeamTypeModel.isSectionLoaderEnabled = false;
  }

  onServiceError(err: Error) {
    if (err['status'] === 409) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'error',
        summary: 'Duplicate Reference Data',
        detail: `The reference data already exists. So, you can't add this reference data.`
      });
    }
  }

  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isEditMode) ? 'Reference Data Updated' : 'Reference Data Added',
      detail: (isEditMode) ? 'Operational Team Type has been successfully updated.' :
        'Operational Team Type has been successfully added.'
    });
    this.changeDetector.detectChanges();
  }

  fetchAllData() {
    this.operationalTeamTypeModel.searchText = this.operationalTeamTypeModel.queryString = '';
    this.fetchOperationalTeamTypeListData();
    this.operationalTeamTypeModel.isSectionLoaderEnabled = false;
    this.operationalTeamTypeModel.splitView = false;
    this.changeDetector.detectChanges();
  }

  onCancel() {
    if (this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.touched
      && this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'OperationalTeamType',
        accept: (): void => {
          this.closeSplitView();
          this.operationalTeamTypeModel.splitView = false;
        }
      });
    } else {
      this.closeSplitView();
    }
  }
  closeSplitView() {
    this.fetchOperationalTeamTypeListData();
    this.closeAddEditPage();
  }
  onRowSelect(selectedRow: OperationalTeamTypeListModel) {
    this.operationalTeamTypeModel.isSectionLoaderEnabled = true;
    if (this.operationalTeamTypeModel.selectedRowContent && selectedRow.operationalGroupSubtypeCode !==
      this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeCode) {
      this.splitScreenEditAdd(selectedRow);
    } else if (!this.operationalTeamTypeModel.selectedRowContent) {
      this.splitScreenEditAdd(selectedRow);
    }
  }
  splitScreenEditAdd(selectedRow: OperationalTeamTypeListModel) {
    const msg = 'associated to an active Operational Team or Capacity Evaluation Association';
    this.operationalTeamTypeService.inactiveError(selectedRow.operationalGroupSubtypeCode)
      .pipe(
        takeWhile(() => this.operationalTeamTypeModel.subscriberFlag)
      )
      .subscribe((inactivateData: InactiveData) => {
        this.operationalTeamTypeModel.lableValue = inactivateData.operationalGroupSubtypeCode;
        if (this.operationalTeamTypeModel.lableValue) {
          this.msgs = [];
          this.msgs.push({
            severity: 'info',
            summary: ' ',
            detail: `You can\'t inactivate this reference data as it is currently ${msg}`
          });
        }
        this.selectedContentSplitScreen(selectedRow);
        this.changeDetector.detectChanges();
      });
  }
  selectedContentSplitScreen(selectedContent: OperationalTeamTypeListModel) {
    this.operationalTeamTypeModel.selectedRowContent = selectedContent;
    this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm = this.onAddOperationalTeamTypeForm();
    this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.patchValue({
      owoTypeDescription: selectedContent.operationalGroupSubtypeDescription,
      owoTypeCode: selectedContent.operationalGroupSubtypeCode
    });
    this.operationalTeamTypeModel.splitView = true;
    this.operationalTeamTypeModel.isSectionLoaderEnabled = false;
  }

  closeAddEditPage() {
    this.operationalTeamTypeModel.selectedRowContent = null;
    this.operationalTeamTypeModel.splitView = false;
  }

  onActivate() {
    this.operationalTeamTypeModel.isSectionLoaderEnabled = true;
    this.operationalTeamTypeService.reactivateOperationalTeamTypeList(OperationalTeamTypeUtils.activateInactivateContent
      (this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeCode))
      .pipe(
        takeWhile(() => this.operationalTeamTypeModel.subscriberFlag),
        finalize(() => {
          this.operationalTeamTypeModel.selectedRowContent = null;
        })
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(false);
      });
  }

  onInactivate() {
    this.operationalTeamTypeModel.addOperationalTeamTypeStatusForm.patchValue({
      owoTypeDescription: this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeDescription,
      owoTypeCode: this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeCode
    });
    this.confirmationService.confirm({
      message: `Operational Team Type<br><b>
      ${this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeDescription}
      (${this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeCode})
      </b><br><br>The reference data you're about to inactivate may be \
       associated to active orders or other entities, inactivating the data will not \
       impact current associations but <b>new entities can no longer reference this \
       record.</b><br><br> Any other <b>reference data that has this record as an association \
       will also be inactivated.</b><br><br> Do you wish to proceed ?`,
      header: 'Inactivate Operational Team Type',
      key: 'inactivateOperationalTeamTypeStatus',
      accept: (): void => {
        this.operationalTeamTypeModel.isSectionLoaderEnabled = true;
        this.inactivatePlanOrWorkOrder();
      }
    });
  }

  inactivatePlanOrWorkOrder() {
    this.operationalTeamTypeService.inactivateOperationalTeamTypeList(OperationalTeamTypeUtils.activateInactivateContent
      (this.operationalTeamTypeModel.selectedRowContent.operationalGroupSubtypeCode))
      .pipe(
        takeWhile(() => this.operationalTeamTypeModel.subscriberFlag),
        finalize(() => {
          this.operationalTeamTypeModel.selectedRowContent = null;
        })
      )
      .subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(true);
      });
  }
  showToastMsgForReactivateInactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isDeactivateMode) ? 'Reference Data Inactivated' :
        'Reference Data Aactivated',
      detail: (isDeactivateMode) ? 'Operational Team Type has been successfully inactivated.' :
        'Operational Team Type has been successfully activated.'
    });
    this.changeDetector.detectChanges();
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
}
