import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageReferencesComponent } from './manage-references.component';

const routes: Routes = [
  { path: '', component: ManageReferencesComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageReferencesRoutingModule { }
