import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';

import { DriverTaskTypeAndSubTypeModel } from './model/driver-task-type-and-sub-type.model';

@Component({
  selector: 'app-driver-task-type-and-sub-type',
  templateUrl: './driver-task-type-and-sub-type.component.html',
  styleUrls: ['./driver-task-type-and-sub-type.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DriverTaskTypeAndSubTypeComponent implements OnInit {
  @ViewChild('driverTaskTypeSubType') tabSelection;
  @ViewChild('driverTaskType') driverTaskType;
  @ViewChild('driverTaskSubType') driverTaskSubType;
  driverTaskTypeAndSubTypeModel: DriverTaskTypeAndSubTypeModel;

  constructor() {
    this.driverTaskTypeAndSubTypeModel = new DriverTaskTypeAndSubTypeModel();
  }

  ngOnInit() {
  }
  hasChangeDetected() {
    if ((this.driverTaskType && this.driverTaskType.hasChangeDetected()) ||
      (this.driverTaskSubType && this.driverTaskSubType.hasChangeDetected())) {
      return true;
    }
    return false;
  }
}
