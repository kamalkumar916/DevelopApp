import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { DriverTaskTypeAndSubTypeComponent } from './driver-task-type-and-sub-type.component';
import { DriverTaskTypeAndSubTypeModule } from './driver-task-type-and-sub-type.module';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { AppConfigService } from '../../../../shared/service/app-config.service';


describe('DriverTaskTypeAndSubTypeComponent', () => {
  let component: DriverTaskTypeAndSubTypeComponent;
  let fixture: ComponentFixture<DriverTaskTypeAndSubTypeComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, DriverTaskTypeAndSubTypeModule, DirectivesModule, HttpClientTestingModule,
        NoopAnimationsModule],
      providers: [MessageService, ConfirmationService, AppConfigService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverTaskTypeAndSubTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
