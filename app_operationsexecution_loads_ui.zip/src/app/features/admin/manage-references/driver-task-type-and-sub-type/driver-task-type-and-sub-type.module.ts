import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DriverTaskTypeAndSubTypeRoutingModule } from './driver-task-type-and-sub-type-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ConfirmationService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { PaginatorModule } from 'primeng/paginator';
import { MultiSelectModule } from 'primeng/multiselect';
import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { TooltipModule } from 'primeng/tooltip';


import { DriverTaskTypeAndSubTypeComponent } from './driver-task-type-and-sub-type.component';
import { DriverTaskTypeComponent } from '../driver-task-type/driver-task-type.component';
import { DriverTaskSubTypeComponent } from '../driver-task-sub-type/driver-task-sub-type.component';
import { DriverTaskTypeService } from '../driver-task-type/services/driver-task-type.service';
import { DriverTaskSubTypeService } from '../driver-task-sub-type/services/driver-task-sub-type.service';
import { DirectivesModule } from '../../../../shared/directives/directives.module';

@NgModule({
  imports: [
    AutoCompleteModule,
    BreadcrumbModule,
    ButtonModule,
    ConfirmDialogModule,
    FormsModule,
    InputTextModule,
    JbhLoaderModule,
    MenuModule,
    PanelModule,
    PipesModule,
    ReactiveFormsModule,
    TableModule,
    TabViewModule,
    MessagesModule,
    MessageModule,
    PaginatorModule,
    MultiSelectModule,
    CommonModule,
    TooltipModule,
    DriverTaskTypeAndSubTypeRoutingModule,
    DirectivesModule
  ],
  declarations: [DriverTaskTypeAndSubTypeComponent, DriverTaskTypeComponent, DriverTaskSubTypeComponent],
  providers: [ConfirmationService, DriverTaskTypeService, DriverTaskSubTypeService]
})

export class DriverTaskTypeAndSubTypeModule { }

