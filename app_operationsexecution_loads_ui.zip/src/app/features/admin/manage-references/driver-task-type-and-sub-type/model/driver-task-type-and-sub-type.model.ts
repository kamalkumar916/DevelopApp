
import { Breadcrumb } from './../../../../model/breadcrumb.interface';

export class DriverTaskTypeAndSubTypeModel {
  breadCrumbList: Breadcrumb[];

  constructor() {
    this.breadCrumbList = [
      { label: 'Manage References', routerLink: ['/managereferences'] },
      { label: 'Driver Task Type and Sub Type', routerLink: ['/managereferences/driver-task-type-and-sub-type'] }
    ];
  }
}
