export interface RouterValue {
    label: string;
    routerLink: Array<string>;
}
