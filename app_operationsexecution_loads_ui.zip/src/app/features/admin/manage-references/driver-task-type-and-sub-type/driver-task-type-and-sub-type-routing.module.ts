import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DriverTaskTypeAndSubTypeComponent } from './driver-task-type-and-sub-type.component';
import { UnsavedChangesGuard } from '../../../../shared/unsaved-changes.guard';
const routes: Routes = [
  { path: '', component: DriverTaskTypeAndSubTypeComponent, canDeactivate: [UnsavedChangesGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DriverTaskTypeAndSubTypeRoutingModule { }
