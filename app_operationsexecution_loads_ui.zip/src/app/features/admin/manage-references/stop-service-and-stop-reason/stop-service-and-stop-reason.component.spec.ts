import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TabViewModule } from 'primeng/tabview';
import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { TranslateModule, TranslateService, TranslateLoader, TranslateFakeLoader } from '@ngx-translate/core';
import { configureTestSuite } from 'ng-bullet';
import { TooltipModule } from 'primeng/tooltip';

import { StopServiceAndStopReasonComponent } from './stop-service-and-stop-reason.component';
import { StopServiceComponent } from '../stop-service/stop-service.component';
import { StopReasonComponent } from '../stop-reason/stop-reason.component';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { StopServiceService } from '../stop-service/services/stop-service.service';
import { DirectivesModule } from '../../../../shared/directives/directives.module';

describe('StopServiceAndStopReasonComponent', () => {
  let component: StopServiceAndStopReasonComponent;
  let fixture: ComponentFixture<StopServiceAndStopReasonComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule,
        NoopAnimationsModule, HttpClientTestingModule, TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: TranslateFakeLoader }
        }), BreadcrumbModule, TabViewModule, TableModule, FormsModule, ReactiveFormsModule, MenuModule, ButtonModule, AutoCompleteModule,
        PipesModule, ConfirmDialogModule, JbhLoaderModule, MultiSelectModule, TooltipModule, DirectivesModule],
      providers: [AppConfigService, MessageService, TranslateService, ConfirmationService, StopServiceService],
      declarations: [StopServiceAndStopReasonComponent, StopServiceComponent, StopReasonComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StopServiceAndStopReasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
