import { Breadcrumb } from './../../../../model/breadcrumb.interface';

export class StopServiceAndStopReason {
  breadCrumbList: Breadcrumb[];

  constructor() {
    this.breadCrumbList = [
      { label: 'Manage References', routerLink: ['/managereferences'] },
      { label: 'Stop Service and Stop Reason', routerLink: ['/managereferences/stop-service-and-stop-reason'] }
    ];
  }
}
