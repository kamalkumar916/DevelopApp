import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StopServiceAndStopReasonComponent } from './stop-service-and-stop-reason.component';

const routes: Routes = [
  { path: '', component: StopServiceAndStopReasonComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StopServiceAndStopReasonRoutingModule { }
