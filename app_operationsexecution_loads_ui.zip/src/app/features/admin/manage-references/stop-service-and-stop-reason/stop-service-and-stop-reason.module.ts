import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ConfirmationService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { PaginatorModule } from 'primeng/paginator';
import { MultiSelectModule } from 'primeng/multiselect';
import { TooltipModule } from 'primeng/tooltip';

import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';

import { StopReasonComponent } from '../stop-reason/stop-reason.component';
import { StopServiceComponent } from '../stop-service/stop-service.component';
import { StopServiceAndStopReasonComponent } from './stop-service-and-stop-reason.component';
import { StopServiceService } from '../stop-service/services/stop-service.service';
import { StopReasonService } from '../stop-reason/services/stop-reason.service';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { StopServiceAndStopReasonRoutingModule } from './stop-service-and-stop-reason-routing.module';

@NgModule({
  declarations: [StopReasonComponent,
    StopServiceComponent, StopServiceAndStopReasonComponent
  ],
  providers: [ConfirmationService, StopServiceService, StopReasonService],
  imports: [
    CommonModule,
    StopServiceAndStopReasonRoutingModule,
    AutoCompleteModule,
    BreadcrumbModule,
    ButtonModule,
    ConfirmDialogModule,
    FormsModule,
    InputTextModule,
    JbhLoaderModule,
    MenuModule,
    PanelModule,
    PipesModule,
    ReactiveFormsModule,
    TableModule,
    TabViewModule,
    MessagesModule,
    MessageModule,
    PaginatorModule,
    MultiSelectModule,
    TooltipModule,
    DirectivesModule
  ]
})
export class StopServiceAndStopReasonModule { }


