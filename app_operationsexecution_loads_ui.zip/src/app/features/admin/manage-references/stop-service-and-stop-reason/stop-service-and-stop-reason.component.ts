import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';

import { StopServiceAndStopReason } from './models/stop-service-and-stop-reason.model';

@Component({
  selector: 'app-stop-service-and-stop-reason',
  templateUrl: './stop-service-and-stop-reason.component.html',
  styleUrls: ['./stop-service-and-stop-reason.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StopServiceAndStopReasonComponent implements OnInit {
  @ViewChild('stopReasonStopService') tabSelection;
  stopServiceAndStopReason: StopServiceAndStopReason;

  constructor() {
    this.stopServiceAndStopReason = new StopServiceAndStopReason();
  }

  ngOnInit() {
  }

}
