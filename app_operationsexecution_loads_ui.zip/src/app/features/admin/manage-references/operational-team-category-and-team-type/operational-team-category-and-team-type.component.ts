import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';

import { OperationalTeamCategoryAndTeamType } from './models/operational-team-category-and-team-type.model';

@Component({
  selector: 'app-operational-team-category-and-team-type',
  templateUrl: './operational-team-category-and-team-type.component.html',
  styleUrls: ['./operational-team-category-and-team-type.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OperationalTeamCategoryAndTeamTypeComponent implements OnInit {
  operationalTeamCategoryAndTeamType: OperationalTeamCategoryAndTeamType;
  @ViewChild('operationalType') tabSelection;

  constructor() {
    this.operationalTeamCategoryAndTeamType = new OperationalTeamCategoryAndTeamType();
  }

  ngOnInit() {
  }


}
