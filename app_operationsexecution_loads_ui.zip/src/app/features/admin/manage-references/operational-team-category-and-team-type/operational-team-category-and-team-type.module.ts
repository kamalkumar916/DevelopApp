import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ConfirmationService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { PaginatorModule } from 'primeng/paginator';
import { TooltipModule } from 'primeng/tooltip';

import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';

import { OperationalTeamCategoryAndTeamTypeComponent } from './operational-team-category-and-team-type.component';
import { OperationalTeamCategoryComponent } from '../operational-team-category/operational-team-category.component';
import { OperationalTeamTypeComponent } from '../operational-team-type/operational-team-type.component';
import { OperationalTeamCategoryService } from '../operational-team-category/services/operational-team-category.service';
import { OperationalTeamTypeService } from '../operational-team-type/services/operational-team-type.service';

import { OperationalTeamCategoryAndTeamTypeRoutingModule } from './operational-team-category-and-team-type-routing.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

@NgModule({
  declarations: [
    OperationalTeamCategoryAndTeamTypeComponent, OperationalTeamCategoryComponent, OperationalTeamTypeComponent],
  providers: [ConfirmationService,
    OperationalTeamCategoryService, OperationalTeamTypeService],
  imports: [
    CommonModule,
    OperationalTeamCategoryAndTeamTypeRoutingModule,
    AutoCompleteModule,
    BreadcrumbModule,
    ButtonModule,
    ConfirmDialogModule,
    FormsModule,
    InputTextModule,
    JbhLoaderModule,
    MenuModule,
    PanelModule,
    PipesModule,
    ReactiveFormsModule,
    TableModule,
    TabViewModule,
    MessagesModule,
    MessageModule,
    PaginatorModule,
    TooltipModule,
    DirectivesModule
  ]
})
export class OperationalTeamCategoryAndTeamTypeModule { }
