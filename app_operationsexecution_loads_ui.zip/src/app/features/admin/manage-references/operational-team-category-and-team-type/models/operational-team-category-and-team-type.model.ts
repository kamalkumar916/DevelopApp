import { Breadcrumb } from './../../../../model/breadcrumb.interface';

export class OperationalTeamCategoryAndTeamType {
  breadCrumbList: Breadcrumb[];

  constructor() {
    this.breadCrumbList = [
      { label: 'Manage References', routerLink: ['/managereferences'] },
      { label: 'Operational Team Category And Type', routerLink: ['/managereferences/operational-team-category-and-team-type'] }
    ];
  }
}
