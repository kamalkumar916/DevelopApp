import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TabViewModule } from 'primeng/tabview';
import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { MessagesModule } from 'primeng/messages';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { configureTestSuite } from 'ng-bullet';
import { TooltipModule } from 'primeng/tooltip';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { OperationalTeamCategoryAndTeamTypeComponent } from './operational-team-category-and-team-type.component';
import { OperationalTeamCategoryComponent } from '../operational-team-category/operational-team-category.component';
import { OperationalTeamTypeComponent } from '../operational-team-type/operational-team-type.component';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { OperationalTeamCategoryService } from '../operational-team-category/services/operational-team-category.service';
import { OperationalTeamTypeService } from '../operational-team-type/services/operational-team-type.service';

describe('OperationalTeamCategoryAndTeamTypeComponent', () => {
  let component: OperationalTeamCategoryAndTeamTypeComponent;
  let fixture: ComponentFixture<OperationalTeamCategoryAndTeamTypeComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NoopAnimationsModule,
        BreadcrumbModule, TabViewModule,
        TableModule, FormsModule, TooltipModule, DirectivesModule, MenuModule, ReactiveFormsModule, ButtonModule, JbhLoaderModule,
        MessageModule, MessagesModule, PipesModule, ConfirmDialogModule],
      providers: [AppConfigService, MessageService, ConfirmationService,
        OperationalTeamTypeService, OperationalTeamCategoryService],
      declarations: [OperationalTeamCategoryAndTeamTypeComponent, OperationalTeamCategoryComponent, OperationalTeamTypeComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OperationalTeamCategoryAndTeamTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
