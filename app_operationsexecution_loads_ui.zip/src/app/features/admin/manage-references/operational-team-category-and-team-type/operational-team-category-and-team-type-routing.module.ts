import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OperationalTeamCategoryAndTeamTypeComponent } from './operational-team-category-and-team-type.component';

const routes: Routes = [
  { path: '', component: OperationalTeamCategoryAndTeamTypeComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OperationalTeamCategoryAndTeamTypeRoutingModule { }
