export class StopReasonQuery {
  static getStopReasonListFromES(searchText: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size,
      query: {
        query_string: {
          fields: [
            'StopReasonDescription',
            'StopReasonCode',
            'ApplicableTo',
            'LastUpdateTimestamp.text',
            'LastUpdateProgramName',
            'LastUpdateUserID',
            'Status'
          ],
          query: `*${searchText}*`,
          default_operator: 'AND'
        }
      },
      sort: this.getSortQuery(sortOrder, sortField),
      _source: [
        'StopReasonDescription',
        'StopReasonCode',
        'ApplicableTo',
        'LastUpdateTimestamp',
        'LastUpdateProgramName',
        'LastUpdateUserID',
        'Status'
      ]
    };
  }

  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'StopReasonDescription':
      case 'StopReasonCode':
      case 'ApplicableTo':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'LastUpdateTimestamp': {
            order: 'desc'
          },
          'StopReasonDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }
}
