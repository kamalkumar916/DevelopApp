import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';
import * as LodashUtils from 'lodash';

import { StopReasonListModel } from './stop-reason.interface';
import { ListItem } from './../../../../model/listitem.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class StopReasonModel {
  items: MenuItem[];
  splitView: boolean;
  stopReasonList: StopReasonListModel[];
  applicableTo: ListItem[];
  applicableToItems: ListItem[];
  stopReasonSelectedList: StopReasonListModel[];
  paginatorFlag: boolean;
  totalRecords: number;
  pageStart: number;
  tableSize: number;
  queryString: string;
  searchText: string;
  subscriberFlag: boolean;
  isSectionLoaderEnabled: boolean;
  dropdownLabels: ListItem[];
  tableColumns: ListItem[];
  userInputSearchSubject: Subject<string>;
  addStopReasonStatusForm: FormGroup;
  inactiveLabel: string;
  activeLabel: string;
  selectedRowContent: StopReasonListModel;
  operationalWorkOrderLabel: string;
  operationalPlanLabel: string;
  gridLoaderFlag: boolean;
  successMessage: string;
  referenceData: string;
  sortField: string;
  sortOrder: string;
  title: string;
  addNewButton: SecureModel;
  inactivateButton: SecureModel;
  activateButton: SecureModel;
  appConfig;
  constructor() {
    this.splitView = false;
    this.stopReasonList = [];
    this.stopReasonSelectedList = [];
    this.paginatorFlag = false;
    this.totalRecords = 0;
    this.pageStart = 0;
    this.tableSize = 25;
    this.queryString = '';
    this.searchText = '';
    this.subscriberFlag = true;
    this.isSectionLoaderEnabled = false;
    this.userInputSearchSubject = new Subject<string>();
    this.selectedRowContent = null;
    this.inactiveLabel = 'inactive';
    this.activeLabel = 'active';
    this.operationalPlanLabel = 'Operational Plan';
    this.operationalWorkOrderLabel = 'Operational Work Order';
    this.gridLoaderFlag = true;
    this.referenceData = 'STOPREASON.REFERENCEDATA_DETAIL';
    this.sortField = 'defaultSort';
    this.sortOrder = 'asc';
    this.title = 'Stop Reason';
    this.tableColumns = [
      {
        'label': 'Name',
        'value': 'stopReasonDescription',
        'esKey': 'StopReasonDescription'
      },
      {
        'label': 'Identifier',
        'value': 'stopReasonCode',
        'esKey': 'StopReasonCode'
      },
      {
        'label': 'Applicable to',
        'value': 'applicableTo',
        'esKey': 'ApplicableTo'
      },
      {
        'label': 'Last Updated',
        'value': 'lastUpdateTimestamp',
        'esKey': 'LastUpdateTimestamp'
      },
      {
        'label': 'Last Updated By',
        'value': 'lastUpdatedBy',
        'esKey': 'LastUpdateProgramName'
      },
      {
        'label': 'Status',
        'value': 'status',
        'esKey': 'Status'
      }];
    this.appConfig = AppConfig.getConfig();
    this.addNewButton = { url: this.appConfig.api.admin.saveStopReason, operation: 'C' };
    this.inactivateButton = { url: this.appConfig.api.admin.inactivateStopReasonStatus, operation: 'C' };
    this.activateButton = { url: this.appConfig.api.admin.reactivateStopReasonStatus, operation: 'C' };
  }

  getDropdownValues() {
    this.dropdownLabels = [
      { label: this.operationalPlanLabel, value: this.operationalPlanLabel },
      { label: this.operationalWorkOrderLabel, value: this.operationalWorkOrderLabel }
    ];
    this.applicableToItems = LodashUtils.cloneDeep(this.dropdownLabels);
  }

}
