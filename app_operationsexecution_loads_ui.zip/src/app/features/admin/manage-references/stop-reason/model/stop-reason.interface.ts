export interface StopReasonListModel {
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateProgramName: string;
  lastUpdateTimestamp: string;
  lastUpdateUserID: string;
  stopReasonCode: string;
  stopReasonDescription: string;
  status: string;
  applicableTo: string;
}

export interface StopReasonListAddModel {
  stopReasonDescription: string;
  stopReasonCode: string;
  applicableTos?: string;
}

export interface StopReasonActiveInactiveModel {
  stopReasonCode: string;
}

export interface PageEvent {
  first: number;
  rows: number;
  sortOrder: number;
  sortField: string;
}
