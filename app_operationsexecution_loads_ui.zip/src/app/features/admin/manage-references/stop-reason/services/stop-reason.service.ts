import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { StopReasonListAddModel, StopReasonActiveInactiveModel } from '../model/stop-reason.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';


@Injectable()
export class StopReasonService {
  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }

  getStopReasonList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getStopReasonList, query);
  }

  saveStopReasonList(query: StopReasonListAddModel): Observable<boolean> {
    return this.http.post<boolean>(this.endpoint.saveStopReason, query);
  }

  editStopReasonList(query: StopReasonListAddModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.saveStopReason, query);
  }

  inactivateStopReasonList(stopReasonCodeModel: StopReasonActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.inactivateStopReasonStatus, stopReasonCodeModel);
  }

  reactivateStopReasonList(stopReasonCodeModel: StopReasonActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.reactivateStopReasonStatus, stopReasonCodeModel);
  }

  stopReasonExcelDownload(requestParam, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoint.stopReasonExportExcel, requestParam, { headers, responseType: 'blob' });
  }
}
