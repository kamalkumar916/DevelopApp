import { StopReasonListModel, StopReasonActiveInactiveModel } from '../model/stop-reason.interface';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class StopReasonUtils {

  constructor() { }

  static getStopReasonListData(stopReasonList: ElasticResponseModel): StopReasonListModel[] {
    let returnData: StopReasonListModel[] = [];
    if (stopReasonList && stopReasonList.hits && stopReasonList.hits.hits) {
      returnData = stopReasonList.hits.hits.map((stopReasonStatus: HitsModel) => {
        return {
          'effectiveTimestamp': stopReasonStatus._source.EffectiveTimestamp,
          'expirationTimestamp': stopReasonStatus._source.ExpirationTimestamp,
          'lastUpdateProgramName': stopReasonStatus._source.LastUpdateProgramName,
          'lastUpdateTimestamp':
          DateUtils.convertOffsetDateByDefaultTimeZone(stopReasonStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
          'lastUpdateUserID': stopReasonStatus._source.LastUpdateUserID,
          'status': stopReasonStatus._source.Status,
          'applicableTo': stopReasonStatus._source.ApplicableTo,
          'stopReasonCode': stopReasonStatus._source.StopReasonCode,
          'stopReasonDescription': stopReasonStatus._source.StopReasonDescription,
          'lastUpdatedBy': `${stopReasonStatus._source.LastUpdateProgramName} ${'('}${stopReasonStatus._source.LastUpdateUserID}${')'}`
        };
      });
    }

    return returnData;
  }

  static activateInactivateContent(typeCode: string): StopReasonActiveInactiveModel {
    return {
      'stopReasonCode': typeCode
    };
  }

  static getExcelDownloadRequestBody(esQuery: object) {
    return {
        query: esQuery['query'],
        sort: esQuery['sort']
    };
  }
}
