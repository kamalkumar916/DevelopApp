import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { StopReasonService } from './stop-reason.service';
import { configureTestSuite } from 'ng-bullet';

describe('StopReasonService', () => {
  configureTestSuite(() => TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AppConfigService, StopReasonService]
    }));

  it('should be created', () => {
    const service: StopReasonService = TestBed.get(StopReasonService);
    expect(service).toBeTruthy();
  });
});
