import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { takeWhile, finalize, distinctUntilChanged, debounceTime } from 'rxjs/operators';

import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import * as LodashUtils from 'lodash';
import * as moment from 'moment';

import { StopReasonModel } from './model/stop-reason.model';
import { StopReasonService } from './services/stop-reason.service';
import { StopReasonUtils } from './services/stop-reason-utils';
import { StopReasonQuery } from './query/stop-reason.query';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { StopReasonListModel, StopReasonListAddModel, PageEvent } from './model/stop-reason.interface';

@Component({
  selector: 'app-stop-reason',
  templateUrl: './stop-reason.component.html',
  styleUrls: ['./stop-reason.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class StopReasonComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('stopReasonDownloadExcel') stopReasonDownloadExcel: ElementRef;
  stopReasonModel: StopReasonModel;
  applicableTo: FormGroup;
  defaultSort = 'Status';

  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly confirmationService: ConfirmationService,
    private readonly stopReasonService: StopReasonService,
    private readonly messageService: MessageService,
    private readonly formBuilder: FormBuilder) {
    this.stopReasonModel = new StopReasonModel();
  }

  ngOnInit() {
    this.searchInput();
    this.overFlowMenuOptions();
  }
  ngOnDestroy() {
    this.stopReasonModel.subscriberFlag = false;
  }
  get addStopReasonStatusFormControls() {
    return this.stopReasonModel.addStopReasonStatusForm.controls;
  }
  onPage(thisEvent: PageEvent) {
    this.getCurrentScrollPosition();
    this.stopReasonModel.pageStart = thisEvent.first;
    this.stopReasonModel.tableSize = thisEvent.rows;
    this.stopReasonModel.sortField = thisEvent.sortField;
    this.stopReasonModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchStopReasonListData();
  }
  onAddStopReasonForm(): FormGroup {
    return this.formBuilder.group({
      owoTypeDescription: ['', Validators.required],
      owoTypeCode: ['', Validators.required],
      applicableTo: ['', Validators.required]
    });
  }
  onAddNew() {
    this.stopReasonModel.addStopReasonStatusForm = this.onAddStopReasonForm();
    this.stopReasonModel.splitView = true;
    this.stopReasonModel.getDropdownValues();
  }
  setFilteredContent(userSearchInput: string) {
    this.stopReasonModel.applicableToItems = Object.assign([], this.stopReasonModel.dropdownLabels).filter(
      thisDropdownContent => thisDropdownContent.label.toLowerCase().indexOf(userSearchInput.toLowerCase()) > -1
    );
  }
  setFilteredContentClear() {
    this.stopReasonModel.addStopReasonStatusForm.controls.applicableTo.setErrors({ 'incorrect': true });
  }
  overFlowMenuOptions() {
    this.stopReasonModel.items = [
      {
        label: 'Export to Excel',
        command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }
  exportToExcel() {
    this.stopReasonService.stopReasonExcelDownload(StopReasonUtils.getExcelDownloadRequestBody(
      StopReasonQuery.getStopReasonListFromES(this.stopReasonModel.queryString,
        this.stopReasonModel.pageStart, this.stopReasonModel.tableSize,
        this.stopReasonModel.sortOrder, this.stopReasonModel.sortField)))
      .pipe(
        takeWhile(() => this.stopReasonModel.subscriberFlag),
      ).subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `${
            this.stopReasonModel.title} ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.stopReasonDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }
  downloadThisExcelFile(data: Blob, stopReasonDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      stopReasonDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      stopReasonDownloadExcel.nativeElement.download = fileName;
      stopReasonDownloadExcel.nativeElement.click();
    }
  }
  fetchStopReasonListData() {
    this.stopReasonService.getStopReasonList(StopReasonQuery.getStopReasonListFromES(
      this.stopReasonModel.queryString, this.stopReasonModel.pageStart, this.stopReasonModel.tableSize
      , this.stopReasonModel.sortOrder, this.stopReasonModel.sortField))
      .pipe(
        takeWhile(() => this.stopReasonModel.subscriberFlag),
        finalize(() => {
          this.stopReasonModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((stopReasonList: ElasticResponseModel) => {
        if (!LodashUtils.isEmpty(stopReasonList) && !LodashUtils.isEmpty(stopReasonList.hits)
          && LodashUtils.isEmpty(stopReasonList.hits.total)) {
          this.stopReasonModel.gridLoaderFlag = !(this.stopReasonModel.stopReasonList.length > 0);
          this.stopReasonModel.totalRecords = stopReasonList.hits.total;
          this.stopReasonModel.stopReasonList = StopReasonUtils.getStopReasonListData(stopReasonList);
          this.stopReasonModel.paginatorFlag = this.stopReasonModel.stopReasonList.length > 0;
        }
      }, (error: Error) => {
        this.stopReasonModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }
  onSearch() {
    this.stopReasonModel.pageStart = 0;
    this.stopReasonModel.userInputSearchSubject.next(this.stopReasonModel.searchText);
  }
  searchInput() {
    this.stopReasonModel.userInputSearchSubject
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeWhile(() => this.stopReasonModel.subscriberFlag),
      ).subscribe(() => {
        if (this.stopReasonModel.searchText.length === 0 || this.stopReasonModel.searchText.length > 2) {
          if (this.stopReasonModel.searchText.match('^[0-9,]*$')) {
            this.stopReasonModel.queryString = this.stopReasonModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
            this.stopReasonModel.queryString = this.stopReasonModel.queryString.replace(/\,/g, '');
          } else {
            this.stopReasonModel.queryString = this.stopReasonModel.searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
          }
          this.fetchStopReasonListData();
        } else if (this.stopReasonModel.queryString) {
          this.stopReasonModel.queryString = '';
          this.fetchStopReasonListData();
        }
      });
  }
  onCompareOldData() {
    if (this.stopReasonModel.selectedRowContent) {
      const nameRowValue = this.stopReasonModel.selectedRowContent.stopReasonDescription;
      const nameFieldValue = this.stopReasonModel.addStopReasonStatusForm.controls.owoTypeDescription.value;
      const applicableToRowValue = this.stopReasonModel.selectedRowContent.applicableTo;
      const applicableToFieldValue = this.stopReasonModel.addStopReasonStatusForm.controls.applicableTo.value;
      return !((nameRowValue === nameFieldValue) && (JSON.stringify(applicableToRowValue) === JSON.stringify(applicableToFieldValue)));
    } else {
      return true;
    }
  }
  onSave() {
    if (this.stopReasonModel.addStopReasonStatusForm.valid &&
      (this.stopReasonModel.addStopReasonStatusForm.dirty && this.stopReasonModel.addStopReasonStatusForm.touched) &&
      this.onCompareOldData()) {
      this.stopReasonModel.isSectionLoaderEnabled = true;
      if (this.stopReasonModel.selectedRowContent) {
        this.editServicePlanOrWorkOrder();
      } else {
        this.saveServicePlanOrWorkOrder();
      }
    } else if (this.stopReasonModel.selectedRowContent) {
      if (this.stopReasonModel.addStopReasonStatusForm.valid) {
        this.messageService.clear();
        this.messageService.add({
          severity: 'info',
          summary: 'No Changes Detected',
        detail: `You've not done any changes to Stop Reason.`
        });
      }
    } else {
      this.stopReasonModel.addStopReasonStatusForm.controls.owoTypeCode.markAsTouched();
      this.stopReasonModel.addStopReasonStatusForm.controls.owoTypeDescription.markAsTouched();
      this.stopReasonModel.addStopReasonStatusForm.controls.applicableTo.markAsTouched();
    }
  }
  editServicePlanOrWorkOrder() {
    this.stopReasonModel.isSectionLoaderEnabled = false;
    const editDetailsPlan: StopReasonListAddModel = {
      stopReasonDescription: this.stopReasonModel.addStopReasonStatusForm.value.owoTypeDescription,
      stopReasonCode: this.stopReasonModel.addStopReasonStatusForm.value.owoTypeCode,
      applicableTos: this.stopReasonModel.addStopReasonStatusForm.value.applicableTo
    };
    this.stopReasonService.editStopReasonList(editDetailsPlan)
      .pipe(
        takeWhile(() => this.stopReasonModel.subscriberFlag),
        finalize(() => {
          this.stopReasonModel.isSectionLoaderEnabled = false;
        })
      ).subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(true);
      });
  }
  saveServicePlanOrWorkOrder() {
    const saveDetailsPlan: StopReasonListAddModel = {
      stopReasonDescription: this.stopReasonModel.addStopReasonStatusForm.value.owoTypeDescription,
      stopReasonCode: this.stopReasonModel.addStopReasonStatusForm.value.owoTypeCode,
      applicableTos: this.stopReasonModel.addStopReasonStatusForm.value.applicableTo
    };
    this.stopReasonService.saveStopReasonList(saveDetailsPlan)
      .pipe(
        takeWhile(() => this.stopReasonModel.subscriberFlag),
      ).subscribe(() => {
        this.fetchAllData();
        this.showToastMessage(false);
      }, (err: Error) => {
        this.onServiceError(err);
      });
    this.stopReasonModel.isSectionLoaderEnabled = false;
  }
  onServiceError(err: Error) {
    if (err['status'] === 409) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'error',
        summary: 'Duplicate Reference Data',
        detail: `The reference data already exists. So, you can't add this reference data.`
      });
    }
  }
  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isEditMode) ? 'Reference Data Updated' : 'Reference Data Added',
      detail: (isEditMode) ? 'Stop Reason has been successfully updated.' : 'Stop Reason has been successfully added.'
    });
    this.changeDetector.detectChanges();
  }
  fetchAllData() {
    this.stopReasonModel.searchText = '';
    this.stopReasonModel.queryString = '';
    this.fetchStopReasonListData();
    this.stopReasonModel.isSectionLoaderEnabled = false;
    this.stopReasonModel.splitView = false;
    this.changeDetector.detectChanges();
  }
  onCancel() {
    if (this.stopReasonModel.addStopReasonStatusForm.touched && this.stopReasonModel.addStopReasonStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'StopReason',
        accept: (): void => {
          this.closeSplitView();
          this.stopReasonModel.splitView = false;
        }
      });
    } else {
      this.closeSplitView();
    }
  }
  closeSplitView() {
    this.fetchStopReasonListData();
    this.closeAddEditPage();
  }
  onRowSelect(selectedRow: StopReasonListModel) {
    this.stopReasonModel.isSectionLoaderEnabled = true;
    if (this.stopReasonModel.selectedRowContent && selectedRow.stopReasonCode !==
      this.stopReasonModel.selectedRowContent.stopReasonCode) {
      this.selectedContentSplitScreen(selectedRow);
    } else if (!this.stopReasonModel.selectedRowContent) {
      this.selectedContentSplitScreen(selectedRow);
    }
  }
  selectedContentSplitScreen(selectedContent: StopReasonListModel) {
    this.stopReasonModel.selectedRowContent = selectedContent;
    this.stopReasonModel.addStopReasonStatusForm = this.onAddStopReasonForm();
    this.stopReasonModel.addStopReasonStatusForm.patchValue({
      owoTypeDescription: selectedContent.stopReasonDescription,
      owoTypeCode: selectedContent.stopReasonCode,
      applicableTo: selectedContent.applicableTo
    });
    this.stopReasonModel.splitView = true;
    this.stopReasonModel.isSectionLoaderEnabled = false;
    this.stopReasonModel.getDropdownValues();
  }
  closeAddEditPage() {
    this.stopReasonModel.selectedRowContent = null;
    this.stopReasonModel.splitView = false;
  }
  onActivate() {
    this.stopReasonModel.isSectionLoaderEnabled = true;
    this.stopReasonService.reactivateStopReasonList(StopReasonUtils.activateInactivateContent
      (this.stopReasonModel.selectedRowContent.stopReasonCode))
      .pipe(
        takeWhile(() => this.stopReasonModel.subscriberFlag),
        finalize(() => {
          this.stopReasonModel.selectedRowContent = null;
        })
      ).subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(false);
      });
  }
  onInactivate() {
    this.stopReasonModel.addStopReasonStatusForm.patchValue({
      owoTypeDescription: this.stopReasonModel.selectedRowContent.stopReasonDescription,
      owoTypeCode: this.stopReasonModel.selectedRowContent.stopReasonCode,
      applicableTo: this.stopReasonModel.selectedRowContent.applicableTo
    });
    this.confirmationService.confirm({
      message: `Stop Reason<br><b>
      ${this.stopReasonModel.selectedRowContent.stopReasonDescription}(${this.stopReasonModel.selectedRowContent.stopReasonCode})
      </b><br><br>The reference data you're about to inactivate may be associated
      to active orders or other entities, inactivating the data will not impact current
      associations but <b>new entities can no longer reference this record.</b><br><br>
      Any other <b>reference data that has this record as an association will also be inactivated.</b><br><br> Do you wish to proceed ?`,
      header: 'Inactivate Stop Reason',
      key: 'inactivateStopReasonStatus',
      accept: (): void => {
        this.stopReasonModel.isSectionLoaderEnabled = true;
        this.inactivatePlanOrWorkOrder();
      }
    });
  }

  inactivatePlanOrWorkOrder() {
    this.stopReasonService.inactivateStopReasonList(StopReasonUtils.activateInactivateContent
      (this.stopReasonModel.selectedRowContent.stopReasonCode))
      .pipe(
        takeWhile(() => this.stopReasonModel.subscriberFlag),
        finalize(() => {
          this.stopReasonModel.selectedRowContent = null;
        })
      ).subscribe(() => {
        this.fetchAllData();
        this.showToastMsgForReactivateInactivate(true);
      });
  }
  showToastMsgForReactivateInactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isDeactivateMode) ? 'Reference Data Inactivated' : 'Reference Data Activated',
      detail: (isDeactivateMode) ? 'Stop Reason has been successfully inactivated.' : 'Stop Reason has been successfully activated.'
    });
    this.changeDetector.detectChanges();
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
}
