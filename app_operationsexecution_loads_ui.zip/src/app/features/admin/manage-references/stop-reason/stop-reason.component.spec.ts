import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { MultiSelectModule } from 'primeng/multiselect';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { configureTestSuite } from 'ng-bullet';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { StopReasonComponent } from './stop-reason.component';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { StopReasonService } from './services/stop-reason.service';
import { TooltipModule } from 'primeng/tooltip';
import { PageEvent } from './model/stop-reason.interface';

describe('StopReasonComponent', () => {
  let component: StopReasonComponent;
  let fixture: ComponentFixture<StopReasonComponent>;
  let thisEvent: PageEvent;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule,
        NoopAnimationsModule, DirectivesModule, HttpClientTestingModule,
        TableModule, FormsModule, ReactiveFormsModule, MenuModule, ButtonModule, MultiSelectModule, PipesModule,
        ConfirmDialogModule, JbhLoaderModule, TooltipModule],

      providers: [AppConfigService, MessageService, StopReasonService, ConfirmationService],
      declarations: [StopReasonComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StopReasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.stopReasonModel.splitView).toBe(false);
  });
  it('onAddNew have been called', () => {
    component.onAddNew();
    expect(component.stopReasonModel.splitView).toBe(true);
  });
  it('onPage have been called', () => {
    thisEvent = {
      first: 1,
      rows: 10,
      sortOrder: 1,
      sortField: 'test'
    };
    spyOn(component, 'fetchStopReasonListData');
    component.onPage(thisEvent);
    expect(component.stopReasonModel.pageStart).toBe(thisEvent.first);
    expect(component.stopReasonModel.tableSize).toBe(thisEvent.rows);
    expect(component.stopReasonModel.sortField).toBe(thisEvent.sortField);
    expect(component.stopReasonModel.sortOrder).toBe('asc');
    expect(component.fetchStopReasonListData).toHaveBeenCalled();
  });

});

