import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import {
  DriverTaskExcelDownloadModel, DriverTaskTypeListAddModel, DriverTaskActiveInactiveModel
} from '../model/driver-task-type.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';


@Injectable()
export class DriverTaskTypeService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }

  /* Elastic Search - POST API
      Params - Input : Elastic Search Query
    */
  getDriverTasKTypeList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getDriverTaskTypeList, query);
  }

  saveDriverTasKTypeList(query: DriverTaskTypeListAddModel): Observable<boolean> {
    return this.http.post<boolean>(this.endpoint.saveDriverTaskType, query);
  }

  editDriverTaskTypeList(query: DriverTaskTypeListAddModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.saveDriverTaskType, query);
  }

  inactivateDriverTaskTypeList(driverTaskTypeCodeModel: DriverTaskActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.inactivateDriverTaskTypeStatus, driverTaskTypeCodeModel);
  }

  reactivateDriverTaskTypeList(driverTaskTypeCodeModel: DriverTaskActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoint.reactivateDriverTaskTypeStatus, driverTaskTypeCodeModel);
  }

  driverTaskExcelDownload(requestParam: DriverTaskExcelDownloadModel, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoint.referenceDataExcelDownload, requestParam, { headers, responseType: 'blob' });
  }
  getDriverTaskSubTypeList(typeCode: any): Observable<any> {
    return this.http.post<any>(this.endpoint.getInfoDriverTaskTypeList, typeCode);
  }
}
