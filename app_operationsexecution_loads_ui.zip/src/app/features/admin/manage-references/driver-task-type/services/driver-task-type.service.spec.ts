import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { TooltipModule } from 'primeng/tooltip';
import { DriverTaskTypeService } from './driver-task-type.service';
import { configureTestSuite } from 'ng-bullet';

describe('DriverTaskTypeService', () => {
  let service: DriverTaskTypeService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AppConfigService, DriverTaskTypeService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(DriverTaskTypeService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes expected getDriverTasKTypeList calls', () => {
    service.getDriverTasKTypeList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getDriverTaskTypeList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getDriverTaskSubTypeList calls', () => {
    service.getDriverTaskSubTypeList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getInfoDriverTaskTypeList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected driverTaskExcelDownload calls', () => {
    const requestparm = {
      headerDetails: {},
      elasticSearchQuery: {}
    };
    service.driverTaskExcelDownload(requestparm).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.referenceDataExcelDownload);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected editDriverTaskTypeList calls', () => {
    const requestparm = {
      owoTypeCode: 'Owoc',
      owoTypeDescription: 'OWOtd'
    };
    service.editDriverTaskTypeList(requestparm).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.saveDriverTaskType);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes expected saveDriverTasKTypeList calls', () => {
    const requestparm = {
      owoTypeCode: 'Owoc',
      owoTypeDescription: 'OWOtd'
    };
    service.saveDriverTasKTypeList(requestparm).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.saveDriverTaskType);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected inactivateDriverTaskTypeList calls', () => {
    const requestparm = {
      owoTypeCode: 'Owoc'
    };
    service.inactivateDriverTaskTypeList(requestparm).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.inactivateDriverTaskTypeStatus);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes expected reactivateDriverTaskTypeList calls', () => {
    const requestparm = {
      owoTypeCode: 'Owoc'
    };
    service.reactivateDriverTaskTypeList(requestparm).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.reactivateDriverTaskTypeStatus);
    expect(req.request.method).toEqual('PATCH');
  });
});

