import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import { DriverTaskExcelDownloadModel, DriverTaskTypeListModel, DriverTaskActiveInactiveModel } from '../model/driver-task-type.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class DriverTaskTypeUtils {

  constructor() { }

  static getDriverTaskListData(driverTaskTypeList: ElasticResponseModel): Array<DriverTaskTypeListModel> {
    const thisEsList: Array<HitsModel> = (driverTaskTypeList && driverTaskTypeList.hits && driverTaskTypeList.hits.hits) ?
      driverTaskTypeList.hits.hits : [];
    if (!thisEsList || thisEsList.length === 0) {
      return [];
    }

    return thisEsList.map((driverStatus: HitsModel) => {
      return {
        'effectiveTimestamp': driverStatus._source['EffectiveTimestamp'],
        'expirationTimestamp': driverStatus._source['ExpirationTimestamp'],
        'lastUpdateProgramName': driverStatus._source['LastUpdateProgramName'],
        'lastUpdateTimestamp':
          DateUtils.convertOffsetDateByDefaultTimeZone(driverStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
        'lastUpdateUserID': driverStatus._source['LastUpdateUserID'],
        'status': driverStatus._source['Status'],
        'operationalWorkOrderTypeCode': driverStatus._source['OperationalWorkOrderTypeCode'],
        'operationalWorkOrderTypeDescription': driverStatus._source['OperationalWorkOrderTypeDescription'],
        'lastUpdatedBy': `${driverStatus._source['LastUpdateProgramName']} (${driverStatus._source['LastUpdateUserID'].toUpperCase()})`
      };
    });
  }

  static onAddDriverTaskTypeForm(): FormGroup {
    return new FormGroup({
      owoTypeDescription: new FormControl('', Validators.required),
      owoTypeCode: new FormControl('', Validators.required),
    });
  }

  static activateInactivateContent(typeCode: string): DriverTaskActiveInactiveModel {
    return {
      'owoTypeCode': typeCode
    };
  }


  static getExcelDownloadRequestBody(esQuery: object): DriverTaskExcelDownloadModel {
    return {
      headerDetails: {
        'Name': 'OperationalWorkOrderTypeDescription',
        'Identifier': 'OperationalWorkOrderTypeCode',
        'Last Updated': 'LastUpdateTimestamp',
        'Last Updated By': 'LastUpdateProgramName, LastUpdateUserID',
        'Status': 'Status'
      },
      elasticSearchQuery: {
        query: esQuery['query'],
        sort: esQuery['sort'],
        size: esQuery['size']
      }
    };
  }
}
