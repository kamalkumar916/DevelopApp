import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { DriverTaskTypeComponent } from './driver-task-type.component';
import { DriverTaskTypeAndSubTypeModule } from '../driver-task-type-and-sub-type/driver-task-type-and-sub-type.module';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { DriverTaskTypeService } from './services/driver-task-type.service';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { UserService } from '../../../../shared/jbh-esa/user.service';
import { DriverTaskActiveInactiveModel } from './model/driver-task-type.interface';

const elasticResponse = {
  'took': 6,
  'timed_out': false,
  'hits': {
    'total': 1,
    'max_score': null,
    'hits': [
      {
        '_index': 'loadplanning-operationalworkorder-drivertasktype-1-2019.05.15',
        '_type': 'doc',
        '_id': 'Reposition',
        '_score': null,
        '_source': {
          'OperationalWorkOrderTypeCode': 'Reposition',
          'OperationalWorkOrderTypeDescription': 'Reposition',
          'LastUpdateUserID': 'PIDNEXT',
          'LastUpdateProgramName': 'SSIS',
          'EffectiveTimestamp': '01-01-2018 00:00:00',
          'ExpirationTimestamp': '12-31-2199 23:59:59',
          'LastUpdateTimestamp': 'Sep 28,2019 05:25 AM UTC',
          'Status': 'Active'
        },
        'sort': [
          'Active'
        ]
      }
    ]
  }
};
const subTypeData = ['Truck', 'TralEquip', 'IntmEmpPl', 'ChassPlan'];
const inactivateResponse = {
  'owoTypeCode': 'res12',
  '_links': {
    'self': {
      'href': 'https://opex-test.nonprod.jbhunt.com/api/operationalWorkOrderTypes/res12'
    }
  }
};
const rowContent = {
  effectiveTimestamp: 'test',
  expirationTimestamp: 'test',
  lastUpdateProgramName: 'test',
  lastUpdateTimestamp: 'test',
  lastUpdateUserID: 'test',
  operationalWorkOrderTypeCode: 'test',
  operationalWorkOrderTypeDescription: 'test',
  status: 'test',
  lastUpdatedBy: 'test',
};
class MockDriverTaskTypeService {
  constructor() { }
  getDriverTasKTypeList() {
    return of(elasticResponse);
  }
  getDriverTaskSubTypeList(typeCode: any) {
    return of(subTypeData);
  }
  inactivateDriverTaskTypeList(driverTaskTypeCodeModel: DriverTaskActiveInactiveModel) {
    return of(inactivateResponse);
  }
}
describe('DriverTaskTypeComponent', () => {
  let component: DriverTaskTypeComponent;
  let fixture: ComponentFixture<DriverTaskTypeComponent>;
  let messageService: MessageService;
  let service: DriverTaskTypeService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, DriverTaskTypeAndSubTypeModule, HttpClientTestingModule, NoopAnimationsModule],
      providers: [MessageService, ConfirmationService, AppConfigService, UserService,
        { provide: DriverTaskTypeService, useClass: MockDriverTaskTypeService }]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverTaskTypeComponent);
    component = fixture.componentInstance;
    messageService = TestBed.get(MessageService);
    service = TestBed.get(DriverTaskTypeService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('checking searchText length', () => {
    component.driverTaskTypeModel.searchText = 'test';
    component.onSearchFocus();
    expect(component.driverTaskTypeModel.searchFieldFocus).toBe(true);
  });
  it('checking searchText length', () => {
    component.driverTaskTypeModel.searchText = '';
    component.onSearchFocus();
    expect(component.driverTaskTypeModel.searchFieldFocus).toBe(false);
  });
  it('getCurrentScrollPosition have been called', () => {
    const checkEL = component.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
    component.getCurrentScrollPosition();
    expect(checkEL.scrollTop).toBe(0);
  });

  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.driverTaskTypeModel.splitView).toBe(false);
  });
  it('onAddNew have been called', () => {
    component.onAddNew();
    expect(component.driverTaskTypeModel.splitView).toBe(true);
  });
  it('showToastMsgForReactivateInactivate have been called', () => {
    spyOn(messageService, 'clear');
    spyOn(messageService, 'add');
    component.showToastMsgForReactivateInactivate(true);
    expect(messageService.clear).toHaveBeenCalled();
  });
  it('showToastMessage have been called', () => {
    spyOn(messageService, 'clear');
    spyOn(messageService, 'add');
    component.showToastMessage(true);
    expect(messageService.clear).toHaveBeenCalled();
  });
  it('getValidationErrorResponse have been called', () => {
    spyOn(messageService, 'clear');
    spyOn(messageService, 'add');
    const response = {
      'traceid': 'f6ee1af2826b0936',
      'status': 400,
      'errors': [
        {
          'fieldErrorFlag': false,
          'errorMessage': 'The action cannot be performed. Please refresh the page and try again.',
          'errorType': 'Business Validation Error',
          'fieldName': null,
          'code': 'EX_TYPE_ALREADY_ACTIVATED',
          'errorSeverity': 'ERROR'
        }
      ]
    };
    component.getValidationErrorResponse(response);
    expect(messageService.clear).toHaveBeenCalled();
  });
  it('fetchDriverTaskTypeListData error block called', () => {
    spyOn(service, 'getDriverTasKTypeList').and.returnValue(throwError(null));
    component.fetchDriverTaskTypeListData();
    expect(component.driverTaskTypeModel.gridLoaderFlag).toEqual(false);
  });
  it('getAssociatedSubType else part called', () => {
    spyOn(service, 'getDriverTaskSubTypeList').and.returnValue(of(null));
    component.getAssociatedSubType('test');
    expect(component.driverTaskTypeModel.displayInfoMsg).toEqual(false);
  });
  it('getAssociatedSubType if part called', () => {
    spyOn(service, 'getDriverTaskSubTypeList').and.returnValue(of(subTypeData));
    component.getAssociatedSubType('test');
    expect(component.driverTaskTypeModel.displayInfoMsg).toEqual(true);
  });
  it('selectedContentSplitScreen have been called', () => {
    component.selectedContentSplitScreen(rowContent);
    expect(component.driverTaskTypeModel.splitView).toBe(true);
    expect(component.driverTaskTypeModel.selectedRowContent).toEqual(rowContent);
  });
  it('onSearch have been called', () => {
    component.onSearch('test');
    expect(component.driverTaskTypeModel.searchFieldFocus).toBe(true);
  });
  it('fetchAllData have been called', () => {
    component.driverTaskTypeModel.subscriberFlag = true;
    component.fetchAllData();
    expect(component.driverTaskTypeModel.splitView).toBe(false);
    expect(component.driverTaskTypeModel.isSectionLoaderEnabled).toBe(false);
  });
});
