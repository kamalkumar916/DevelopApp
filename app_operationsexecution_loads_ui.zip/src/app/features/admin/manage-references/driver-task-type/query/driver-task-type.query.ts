export class DriverTaskTypeQuery {
  static getDriverTasKTypeListFromES(searchText: string, start: number, querySize: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size: querySize,
      query: {
        bool: {
          should: [
            {
              query_string: {
                fields: [
                  'OperationalWorkOrderTypeCode',
                  'OperationalWorkOrderTypeDescription',
                  'Status',
                  'LastUpdateProgramName',
                  'LastUpdateUserID',
                  'LastUpdateTimestamp.text',
                ],
                query: `*${searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&')}*`,
                default_operator: 'AND',
              },
            },
          ],
        },
      },
      sort: this.getSortQuery(sortOrder, sortField)
    };
  }
  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'OperationalWorkOrderTypeCode':
      case 'OperationalWorkOrderTypeDescription':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'OperationalWorkOrderTypeDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }

}
