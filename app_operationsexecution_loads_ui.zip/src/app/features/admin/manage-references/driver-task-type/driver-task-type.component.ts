import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, HostListener,
  OnDestroy, OnInit, ViewChild
} from '@angular/core';

import { Observable, timer } from 'rxjs';
import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import * as moment from 'moment';

import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';

import { DriverTaskTypeModel } from './model/driver-task-type.model';
import { DriverTaskTypeService } from './services/driver-task-type.service';
import { DriverTaskTypeUtils } from './services/driver-task-type-utils';
import { DriverTaskTypeQuery } from './query/driver-task-type.query';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { DriverTaskTypeListModel, SortView } from './model/driver-task-type.interface';

@Component({
  selector: 'app-driver-task-type',
  templateUrl: './driver-task-type.component.html',
  styleUrls: ['./driver-task-type.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class DriverTaskTypeComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('driverTaskDownloadExcel') driverTaskDownloadExcel: ElementRef;
  driverTaskTypeModel: DriverTaskTypeModel;
  defaultSort = 'Status';
  message = [];
  @HostListener('window:beforeunload', ['$event']) unloadNotification($event: any) {
    if (this.hasChangeDetected()) {
      $event.returnValue = true;
    }
  }
  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly confirmationService: ConfirmationService,
    private readonly driverTaskTypeService: DriverTaskTypeService,
    private readonly messageService: MessageService
  ) {
    this.driverTaskTypeModel = new DriverTaskTypeModel();
  }

  ngOnInit() {
    this.searchInput();
    this.overFlowMenuOptions();
  }

  ngOnDestroy() {
    this.driverTaskTypeModel.subscriberFlag = false;
    if (this.driverTaskTypeModel.driverTypeSplitInformation) {
      this.driverTaskTypeModel.driverTypeSplitInformation.unsubscribe();
    }
  }
  hasChangeDetected() {
    if (this.driverTaskTypeModel && this.driverTaskTypeModel.addDriverTaskStatusForm &&
      this.driverTaskTypeModel.addDriverTaskStatusForm.dirty) {
      return true;
    }
    return false;
  }
  onPage(thisEvent: SortView) {
    this.getCurrentScrollPosition();
    this.driverTaskTypeModel.pageStart = thisEvent.first;
    this.driverTaskTypeModel.tableSize = thisEvent.rows;
    this.driverTaskTypeModel.sortField = thisEvent.sortField;
    this.driverTaskTypeModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchDriverTaskTypeListData();
  }

  onAddNew() {
    this.driverTaskTypeModel.addDriverTaskStatusForm = DriverTaskTypeUtils.onAddDriverTaskTypeForm();
    this.driverTaskTypeModel.splitView = true;
  }

  overFlowMenuOptions() {
    this.driverTaskTypeModel.items = [
      {
        label: 'Export to Excel', command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }

  exportToExcel() {
    this.driverTaskTypeService.driverTaskExcelDownload(DriverTaskTypeUtils.getExcelDownloadRequestBody(
      DriverTaskTypeQuery.getDriverTasKTypeListFromES(this.driverTaskTypeModel.queryString, this.driverTaskTypeModel.pageStart,
        this.driverTaskTypeModel.exportExcelSize, this.driverTaskTypeModel.sortOrder,
        this.driverTaskTypeModel.sortField)))
      .pipe(
        takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
      ).subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `Driver Task Type ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.driverTaskDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }

  fetchDriverTaskTypeListData() {
    this.driverTaskTypeService.getDriverTasKTypeList(DriverTaskTypeQuery.getDriverTasKTypeListFromES(
      this.driverTaskTypeModel.queryString, this.driverTaskTypeModel.pageStart, this.driverTaskTypeModel.tableSize,
      this.driverTaskTypeModel.sortOrder,
      this.driverTaskTypeModel.sortField))
      .pipe(
        takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
        finalize(() => {
          this.driverTaskTypeModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((driverTaskTypeList: ElasticResponseModel) => {
        this.driverTaskTypeModel.gridLoaderFlag = !(this.driverTaskTypeModel.driverTaskTypeList.length > 0);
        this.driverTaskTypeModel.totalRecords = driverTaskTypeList.hits.total;
        this.driverTaskTypeModel.driverTaskTypeList = DriverTaskTypeUtils.getDriverTaskListData(driverTaskTypeList);
        this.driverTaskTypeModel.paginatorFlag = (this.driverTaskTypeModel.driverTaskTypeList.length !== 0);
      }, (error: Error) => {
        this.driverTaskTypeModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }
  onSearchFocus() {
    if (this.driverTaskTypeModel.searchText && this.driverTaskTypeModel.searchText.length > 0) {
      this.driverTaskTypeModel.searchFieldFocus = true;
    } else {
      this.driverTaskTypeModel.searchFieldFocus = false;
    }
  }
  onSearch(event) {
    this.driverTaskTypeModel.searchFieldFocus = true;
    this.driverTaskTypeModel.userInputSearchSubject.next(event);
  }

  searchInput() {
    this.driverTaskTypeModel.userInputSearchSubject
      .pipe(
        debounceTime(300), distinctUntilChanged(),
        takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
      ).subscribe(() => {
        if (this.driverTaskTypeModel.searchText.length >= 0) {
          this.driverTaskTypeModel.queryString = this.driverTaskTypeModel.searchText;
          this.fetchDriverTaskTypeListData();
        } else {
          this.driverTaskTypeModel.queryString = '';
        }
      });
  }
  onCompareOldData() {
    if (this.driverTaskTypeModel.selectedRowContent) {
      const nameRowValue = this.driverTaskTypeModel.selectedRowContent.operationalWorkOrderTypeDescription;
      const nameFieldValue = this.driverTaskTypeModel.addDriverTaskStatusForm.controls.owoTypeDescription.value;
      return (nameRowValue !== nameFieldValue);
    } else {
      return true;
    }
  }
  onSave() {
    if (this.driverTaskTypeModel.addDriverTaskStatusForm.valid &&
      (this.driverTaskTypeModel.addDriverTaskStatusForm.dirty || this.driverTaskTypeModel.addDriverTaskStatusForm.touched) &&
      this.onCompareOldData()) {
      this.driverTaskTypeModel.isSectionLoaderEnabled = true;
      if (this.driverTaskTypeModel.selectedRowContent) {
        this.driverTaskTypeService.editDriverTaskTypeList(this.driverTaskTypeModel.addDriverTaskStatusForm.value)
          .pipe(
            takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
            finalize(() => {
              this.driverTaskTypeModel.selectedRowContent = null;
            })
          ).subscribe(() => {
            timer(1000).subscribe(() => {
              this.fetchAllData();
              this.showToastMessage(true);
            });
          });
      } else {
        this.driverTaskTypeService.saveDriverTasKTypeList(this.driverTaskTypeModel.addDriverTaskStatusForm.value)
          .pipe(
            takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
          ).subscribe(() => {
            timer(1000).subscribe(() => {
              this.fetchAllData();
              this.showToastMessage(false);
            });
          }, (err: Error) => {
            this.driverTaskTypeModel.isSectionLoaderEnabled = false;
            this.changeDetector.detectChanges();

            if (err['status'] === 409) {
              this.messageService.clear();
              this.messageService.add({
                severity: 'error',
                summary: 'Duplicate Reference Data',
                detail: 'There is already a reference data of this type with the same identifier. Please designate a different identifier.'
              });
            }
          });
      }
    } else if (this.driverTaskTypeModel.addDriverTaskStatusForm.valid && this.driverTaskTypeModel.selectedRowContent) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'info',
        summary: 'No Changes Found',
        detail: 'There are no changes detected in the current action.'
      });
    } else {
      this.driverTaskTypeModel.addDriverTaskStatusForm.controls.owoTypeCode.markAsTouched();
      this.driverTaskTypeModel.addDriverTaskStatusForm.controls.owoTypeDescription.markAsTouched();
    }
  }

  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: `Reference Data ${isEditMode ? 'Updated' : 'Added'}`,
      detail: `Driver Task Type has been successfully ${isEditMode ? 'updated' : 'added'}.`
    });

    this.changeDetector.detectChanges();
  }

  fetchAllData() {
    timer(1000)
      .pipe(
        takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
      ).subscribe(() => {
        this.driverTaskTypeModel.searchText = this.driverTaskTypeModel.queryString = '';
        this.fetchDriverTaskTypeListData();
        this.driverTaskTypeModel.isSectionLoaderEnabled = false;
        this.driverTaskTypeModel.splitView = false;
        this.changeDetector.detectChanges();
      });
  }

  onCancel() {
    if (this.driverTaskTypeModel.addDriverTaskStatusForm.touched || this.driverTaskTypeModel.addDriverTaskStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'DriverTaskType',
        accept: (): void => {
          this.fetchDriverTaskTypeListData();
          this.closeAddEditPage();
          this.driverTaskTypeModel.splitView = false;
        }
      });
    } else {
      this.driverTaskTypeModel.addDriverTaskStatusForm.reset();
      this.closeAddEditPage();
    }
  }

  onRowSelect(selectedRow: DriverTaskTypeListModel) {
    this.message = [];
    this.getAssociatedSubType(selectedRow.operationalWorkOrderTypeCode);
    if (this.driverTaskTypeModel.selectedRowContent && selectedRow.operationalWorkOrderTypeCode !==
      this.driverTaskTypeModel.selectedRowContent.operationalWorkOrderTypeCode) {
      this.selectedContentSplitScreen(selectedRow);
    } else if (!this.driverTaskTypeModel.selectedRowContent) {
      this.selectedContentSplitScreen(selectedRow);
    }
  }

  selectedContentSplitScreen(selectedContent: DriverTaskTypeListModel) {
    this.driverTaskTypeModel.selectedRowContent = selectedContent;
    this.driverTaskTypeModel.addDriverTaskStatusForm = DriverTaskTypeUtils.onAddDriverTaskTypeForm();
    this.driverTaskTypeModel.addDriverTaskStatusForm.patchValue({
      owoTypeDescription: selectedContent.operationalWorkOrderTypeDescription,
      owoTypeCode: selectedContent.operationalWorkOrderTypeCode
    });
    this.driverTaskTypeModel.splitView = true;
  }

  closeAddEditPage() {
    this.driverTaskTypeModel.selectedRowContent = null;
    this.driverTaskTypeModel.splitView = false;
    this.driverTaskTypeModel.driverTaskTypeSelectedList = null;
  }

  onActivate() {
    this.driverTaskTypeModel.isSectionLoaderEnabled = true;
    this.driverTaskTypeService.reactivateDriverTaskTypeList(DriverTaskTypeUtils.activateInactivateContent
      (this.driverTaskTypeModel.selectedRowContent.operationalWorkOrderTypeCode))
      .pipe(
        takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      ).subscribe(() => {
        timer(1000).subscribe(() => {
          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(false);
          this.driverTaskTypeModel.selectedRowContent = null;
        });
      }, (validationError) => {
        this.driverTaskTypeModel.isSectionLoaderEnabled = false;
        this.getValidationErrorResponse(validationError);
      });
  }

  onInactivate() {
    this.driverTaskTypeModel.isSectionLoaderEnabled = true;
    this.driverTaskTypeService.inactivateDriverTaskTypeList(DriverTaskTypeUtils.activateInactivateContent
      (this.driverTaskTypeModel.selectedRowContent.operationalWorkOrderTypeCode))
      .pipe(
        takeWhile(() => this.driverTaskTypeModel.subscriberFlag),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      ).subscribe(() => {
        timer(1000).subscribe(() => {
          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(true);
          this.driverTaskTypeModel.selectedRowContent = null;
        });
      }, (validationError) => {
        this.driverTaskTypeModel.isSectionLoaderEnabled = false;
        this.getValidationErrorResponse(validationError);
      });
  }
  showToastMsgForReactivateInactivate(isDeactivateMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: `Reference Data ${isDeactivateMode ? 'Inactivated' : 'Activated'}`,
      detail: `Driver Task Type has been successfully ${isDeactivateMode ? 'inactivated' : 'activated'}.`
    });

    this.changeDetector.detectChanges();
  }

  downloadThisExcelFile(data: Blob, utilizationDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      utilizationDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      utilizationDownloadExcel.nativeElement.download = fileName;
      utilizationDownloadExcel.nativeElement.click();
    }
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
  getAssociatedSubType(typeCode: string) {
    if (this.driverTaskTypeModel.driverTypeSplitInformation) {
      this.driverTaskTypeModel.driverTypeSplitInformation.unsubscribe();
    }
    this.driverTaskTypeModel.isSectionLoaderEnabled = true;
    const requestParam = {
      'owoTypeCode': typeCode
    };
    this.driverTaskTypeModel.driverTypeSplitInformation = this.driverTaskTypeService.getDriverTaskSubTypeList(requestParam)
      .pipe(finalize(() => {
        this.driverTaskTypeModel.isSectionLoaderEnabled = false;
        this.changeDetector.detectChanges();
      })
      ).subscribe((data: any) => {
        if (data) {
          this.driverTaskTypeModel.displayInfoMsg = true;
          this.message = [];
          this.message.push({
            severity: 'info',
            summary: ' ',
            detail: 'You can\'t inactivate this reference data as it is currently associated to a active Driver Task Sub Type.'
          });
        } else {
          this.driverTaskTypeModel.displayInfoMsg = false;
          this.message = [];
        }
      });
  }
  getValidationErrorResponse(validationError: any) {
    if (validationError.status === 400) {
      const errorJson = typeof validationError.error === 'string' ? JSON.parse(validationError.error) : validationError.error;
      if (errorJson && errorJson.errors && errorJson.errors.length !== 0) {
        this.driverTaskTypeModel.staleRecordErrMsg = errorJson.errors[0].errorMessage;
      }
      this.messageService.clear();
      this.messageService.add({
        severity: 'error',
        summary: 'Action can\'t be performed',
        detail: this.driverTaskTypeModel.staleRecordErrMsg
      });
    }
  }
}
