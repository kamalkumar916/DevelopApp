export interface DriverTaskTypeListModel {
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateProgramName: string;
    lastUpdateTimestamp: string;
    lastUpdateUserID: string;
    operationalWorkOrderTypeCode: string;
    operationalWorkOrderTypeDescription: string;
    status: string;
    lastUpdatedBy: string;
}

export interface DriverTaskTypeListAddModel {
    owoTypeCode: string;
    owoTypeDescription: string;
}

export interface DriverTaskActiveInactiveModel {
    owoTypeCode: string;
}

export interface DriverTaskExcelDownloadModel {
    headerDetails: object;
    elasticSearchQuery: object;
}

export interface SortView {
    first: number;
    rows: number;
    sortField: string;
    sortOrder: number;
}
