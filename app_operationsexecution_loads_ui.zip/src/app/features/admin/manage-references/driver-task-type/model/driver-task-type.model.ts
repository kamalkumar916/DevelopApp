import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';

import { DriverTaskTypeListModel } from './driver-task-type.interface';
import { ListItem } from '../../../../model/listitem.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class DriverTaskTypeModel {
    items: Array<MenuItem>;
    splitView: boolean;
    driverTaskTypeList: Array<DriverTaskTypeListModel>;
    driverTaskTypeSelectedList: Array<DriverTaskTypeListModel>;
    paginatorFlag: boolean;
    totalRecords: number;
    pageStart: number;
    tableSize: number;
    queryString: string;
    searchText: string;
    subscriberFlag: boolean;
    isSectionLoaderEnabled: boolean;
    tableColumns: ListItem[];
    userInputSearchSubject: Subject<string>;
    addDriverTaskStatusForm: FormGroup;
    inactiveLabel: string;
    activeLabel: string;
    sortOrder: string;
    sortField: string;
    driverTypeSplitInformation: any;
    gridLoaderFlag: boolean;
    exportExcelSize: number;
    selectedRowContent: DriverTaskTypeListModel;
    addNewButton: SecureModel;
    inactivateButton: SecureModel;
    activateButton: SecureModel;
    displayInfoMsg: boolean;
    staleRecordErrMsg: string;
    searchFieldFocus: boolean;
    appConfig;

    constructor() {
        this.splitView = false;
        this.driverTaskTypeList = [];
        this.driverTaskTypeSelectedList = [];
        this.paginatorFlag = false;
        this.totalRecords = 0;
        this.pageStart = 0;
        this.tableSize = 25;
        this.exportExcelSize = 5000;
        this.queryString = '';
        this.searchText = '';
        this.subscriberFlag = true;
        this.isSectionLoaderEnabled = false;
        this.userInputSearchSubject = new Subject<string>();
        this.selectedRowContent = null;
        this.inactiveLabel = 'inactive';
        this.activeLabel = 'active';
        this.sortField = 'defaultSort';
        this.sortOrder = 'asc';
        this.gridLoaderFlag = true;
        this.displayInfoMsg = false;
        this.searchFieldFocus = false;
        this.staleRecordErrMsg = '';

        this.tableColumns = [{
            'label': 'Name', 'value': 'operationalWorkOrderTypeDescription',
            'esKey': 'OperationalWorkOrderTypeDescription'
        },
        { 'label': 'Identifier', 'value': 'operationalWorkOrderTypeCode', 'esKey': 'OperationalWorkOrderTypeCode' },
        { 'label': 'Last Updated', 'value': 'lastUpdateTimestamp', 'esKey': 'LastUpdateTimestamp' },
        {
            'label': 'Last Updated By', 'value': 'lastUpdatedBy',
            'esKey': 'LastUpdateProgramName'
        },
        { 'label': 'Status', 'value': 'status', 'esKey': 'Status' }];
        this.appConfig = AppConfig.getConfig();
        this.addNewButton = { url: this.appConfig.api.admin.saveDriverTaskType, operation: 'C' };
        this.inactivateButton = { url: this.appConfig.api.admin.inactivateDriverTaskTypeStatus, operation: 'C' };
        this.activateButton = { url: this.appConfig.api.admin.reactivateDriverTaskTypeStatus, operation: 'C' };
    }
}
