export class DriverTaskSubTypeQuery {
  static getDriverTaskSubTypeListFromES(searchText: string, start: number, size: number, sortOrder: string, sortField: string) {
    return {
      from: start,
      size,
      query: {
        bool: {
          should: [
            {
              query_string: {
                fields: [
                  'OperationalWorkOrderSubTypeCode',
                  'OperationalWorkOrderSubTypeDescription',
                  'Status',
                  'LastUpdateProgramName',
                  'LastUpdateUserID',
                  'LastUpdateTimestamp.text'
                ],
                query: `*${searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&')}*`,
                default_operator: 'AND'
              }
            },
            {
              'nested': {
                'path': 'OperationalWorkOrderType',
                'query': {
                  'query_string': {
                    'fields': [
                      'OperationalWorkOrderType.OperationalWorkOrderTypeCode',
                      'OperationalWorkOrderType.OperationalWorkOrderTypeDescription'
                    ],
                    query: `*${searchText.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&')}*`,
                    default_operator: 'AND'
                  }
                }
              }
            }
          ]
        }
      },
      sort: this.getSortQuery(sortOrder, sortField)
    };
  }
  static getSortQuery(sortOrder: string, sortField: string) {
    let sortObject = {};
    switch (sortField) {
      case 'OperationalWorkOrderSubTypeCode':
      case 'OperationalWorkOrderTypeCode':
      case 'OperationalWorkOrderTypeDescription':
      case 'OperationalWorkOrderSubTypeDescription':
      case 'Status':
        sortObject[`${sortField}.keyword`] = {
          order: sortOrder
        };
        break;
      case 'LastUpdateProgramName':
        sortObject = [{
          'LastUpdateProgramName.keyword': {
            order: sortOrder
          }
        },
        {
          'LastUpdateUserID.keyword': {
            order: sortOrder
          }
        }];
        break;
      case 'LastUpdateTimestamp':
        sortObject[`LastUpdateTimestamp`] = {
          order: sortOrder
        };
        break;
      case 'OperationalWorkOrderType':
        sortObject[`OperationalWorkOrderType.OperationalWorkOrderTypeCode.keyword`] = {
          'nested_path': 'OperationalWorkOrderType',
          order: sortOrder
        };
        break;
      case 'defaultSort':
        sortObject = [{
          'Status.keyword': {
            order: 'asc'
          },
          'OperationalWorkOrderSubTypeDescription.keyword': {
            order: 'asc'
          }
        }];
        break;
      default:
        break;
    }
    return sortObject;
  }

  static getDriverTaskTypeListFromES() {
    return {
      size: 1000,
      query: {
        match: {
          Status: 'Active'
        }
      },
      sort: [
        {
          'OperationalWorkOrderTypeDescription.keyword': {
            order: 'asc'
          }
        }
      ],
      _source: [
        'OperationalWorkOrderTypeDescription',
        'OperationalWorkOrderTypeCode'
      ]
    };
  }
}
