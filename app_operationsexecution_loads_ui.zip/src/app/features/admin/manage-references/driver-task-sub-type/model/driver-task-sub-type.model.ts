import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';

import { DriverTaskSubTypeListModel, DriverTaskTypeCodeModel } from './driver-task-sub-type.interface';
import { ListItem } from './../../../../model/listitem.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class DriverTaskSubTypeModel {
  items: MenuItem[];
  splitView: boolean;
  driverTaskSubTypeList: DriverTaskSubTypeListModel[];
  operationalWorkOrderTypeCode: ListItem[];
  operationalWorkOrderTypeCodeItems: ListItem[];
  driverTaskSubTypeSelectedList: DriverTaskSubTypeListModel[];
  paginatorFlag: boolean;
  isSectionLoaderEnabled: boolean;
  totalRecords: number;
  totalCodeRecords: number;
  pageStart: number;
  tableSize: number;
  exportExcelSize: number;
  queryString: string;
  searchText: string;
  subscriberFlag: boolean;
  dropdownLabels: ListItem[];
  tableColumns: ListItem[];
  userInputSearchSubject: Subject<string>;
  addDriverTaskSubTypeStatusForm: FormGroup;
  inactiveLabel: string;
  activeLabel: string;
  selectedRowContent: DriverTaskSubTypeListModel;
  driverTaskTypeCodeList: DriverTaskTypeCodeModel[];
  lableValue: boolean;
  gridLoaderFlag: boolean;
  sortField: string;
  sortOrder: string;
  title: string;
  information: string;
  successMessage: string;
  referenceDetail: string;
  addNewButton: SecureModel;
  inactivateButton: SecureModel;
  activateButton: SecureModel;
  displayInfoMsg: boolean;
  driverSubTypeSplitInformation: any;
  staleRecordErrMsg: string;
  searchFieldFocus: boolean;
  appConfig;

  constructor() {
    this.searchFieldFocus = false;
    this.splitView = false;
    this.displayInfoMsg = false;
    this.staleRecordErrMsg = '';
    this.driverTaskSubTypeList = [];
    this.driverTaskTypeCodeList = [];
    this.driverTaskSubTypeSelectedList = [];
    this.paginatorFlag = false;
    this.totalRecords = 0;
    this.pageStart = 0;
    this.tableSize = 25;
    this.exportExcelSize = 5000;
    this.queryString = '';
    this.searchText = '';
    this.subscriberFlag = true;
    this.userInputSearchSubject = new Subject<string>();
    this.selectedRowContent = null;
    this.gridLoaderFlag = true;
    this.isSectionLoaderEnabled = false;
    this.inactiveLabel = 'inactive';
    this.activeLabel = 'active';
    this.sortField = 'defaultSort';
    this.sortOrder = 'asc';
    this.title = 'DRIVERSUBTYPE.TITLE';
    this.information = 'ADMIN_MODULE_COMMON.INFORMATION';
    this.successMessage = 'ADMIN_MODULE_COMMON.REFERENCE_DATA';
    this.referenceDetail = 'DRIVERSUBTYPE.REFERENCEDATA_DETAIL';
    this.tableColumns = [
      {
        'label': 'Name',
        'value': 'operationalWorkOrderSubTypeDescription',
        'esKey': 'OperationalWorkOrderSubTypeDescription'
      },
      {
        'label': 'Identifier',
        'value': 'operationalWorkOrderSubTypeCode',
        'esKey': 'OperationalWorkOrderSubTypeCode'
      },
      {
        'label': 'Driver Task Type',
        'value': 'operationalWorkOrderType',
        'esKey': 'OperationalWorkOrderType'
      },
      {
        'label': 'Last Updated',
        'value': 'lastUpdateTimestamp',
        'esKey': 'LastUpdateTimestamp'
      },
      {
        'label': 'Last Updated By',
        'value': 'lastUpdatedBy',
        'esKey': 'LastUpdateProgramName'
      },
      {
        'label': 'Status',
        'value': 'status',
        'esKey': 'Status'
      }];
    this.appConfig = AppConfig.getConfig();
    this.addNewButton = { url: this.appConfig.api.admin.saveDriverTaskSubType, operation: 'C' };
    this.inactivateButton = { url: this.appConfig.api.admin.inactivateDriverTaskSubTypeStatus, operation: 'C' };
    this.activateButton = { url: this.appConfig.api.admin.reactivateDriverTaskSubTypeStatus, operation: 'C' };

  }

}
