export interface DriverTaskSubTypeListModel {
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateProgramName: string;
  lastUpdateTimestamp: string;
  lastUpdateUserID: string;
  operationalWorkOrderSubTypeCode: string;
  operationalWorkOrderSubTypeDescription: string;
  status: string;
  operationalWorkOrderTypeCode?: string;
  operationalWorkOrderTypeDescription?: string;
  operationalWorkorderType?: string[];
  lastUpdatedBy: string;
}

export interface DriverTaskSubTypeListAddModel {
  operationalWorkOrderSubtypeDescription: string;
  operationalWorkOrderSubtypeCode: string;
  operationalWorkOrderTypeCode?: string;
}

export interface DriverTaskTypeCodeModel {
  operationalWorkOrderTypeCode: string;
  operationalWorkOrderTypeDescription?: string;
}

export interface DriverTaskSubTypeActiveInactiveModel {
  operationalWorkOrderSubtypeDescription: string;
  operationalWorkOrderSubtypeCode: string;
  operationalWorkOrderTypeCode?: string[];
}

export interface SortView {
  first: number;
  rows: number;
  sortOrder: number;
  sortField: string;
}

export interface OwoSubTypeExcelDownloadModel {
  headerDetails: string[];
  elasticSearchQuery: object;
}
export interface OWOType {
  operationalWorkOrderTypeCode?: string;
  operationalWorkOrderTypeDescription?: string;
}
