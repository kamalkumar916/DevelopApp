import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit, ViewChild, ElementRef
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { timer } from 'rxjs';

import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';
import * as LodashUtils from 'lodash';
import * as moment from 'moment';

import { DriverTaskSubTypeModel } from './model/driver-task-sub-type.model';
import { DriverTaskSubTypeService } from './services/driver-task-sub-type.service';
import { DriverTaskSubTypeUtils } from './services/driver-task-sub-type-utils';
import { DriverTaskSubTypeQuery } from './query/driver-task-sub-type.query';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { DriverTaskSubTypeListModel, DriverTaskSubTypeListAddModel, SortView } from './model/driver-task-sub-type.interface';

@Component({
  selector: 'app-driver-task-sub-type',
  templateUrl: './driver-task-sub-type.component.html',
  styleUrls: ['./driver-task-sub-type.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class DriverTaskSubTypeComponent implements OnInit, OnDestroy {
  @ViewChild('tableContent') tableContent: ElementRef;
  @ViewChild('owoSubTypeDownloadExcel') owoSubTypeDownloadExcel: ElementRef;
  driverTaskSubTypeModel: DriverTaskSubTypeModel;
  operationalWorkOrderTypeCode: FormGroup;
  message: Message[] = [];
  defaultSort = 'Status';
  @HostListener('window:beforeunload', ['$event']) unloadNotification($event: any) {
    if (this.hasChangeDetected()) {
      $event.returnValue = true;
    }
  }
  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly confirmationService: ConfirmationService,
    private readonly driverTaskSubTypeService: DriverTaskSubTypeService,
    private readonly messageService: MessageService,
    private readonly formBuilder: FormBuilder) {
    this.driverTaskSubTypeModel = new DriverTaskSubTypeModel();
  }

  ngOnInit() {
    this.searchInput();
    this.overFlowMenuOptions();
    this.dropdownValues();
  }
  ngOnDestroy() {
    this.driverTaskSubTypeModel.subscriberFlag = false;
    if (this.driverTaskSubTypeModel.driverSubTypeSplitInformation) {
      this.driverTaskSubTypeModel.driverSubTypeSplitInformation.unsubscribe();
    }
  }
  get addDriverTaskSubTypeStatusFormControls() {
    return this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.controls;
  }
  hasChangeDetected() {
    if (this.driverTaskSubTypeModel && this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm &&
      this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.dirty) {
      return true;
    }
    return false;
  }
  onPage(thisEvent: SortView) {
    this.getCurrentScrollPosition();
    this.driverTaskSubTypeModel.pageStart = thisEvent.first;
    this.driverTaskSubTypeModel.tableSize = thisEvent.rows;
    this.driverTaskSubTypeModel.sortField = thisEvent.sortField;
    this.driverTaskSubTypeModel.sortOrder = (thisEvent.sortOrder === -1) ? 'desc' : 'asc';
    this.fetchDriverTaskSubTypeListData();
  }
  onAddDriverTaskSubTypeForm(): FormGroup {
    return this.formBuilder.group({
      owoTypeDescription: ['', Validators.required],
      owoTypeCode: ['', Validators.required],
      operationalWorkOrderTypeCode: ['', Validators.required]
    });
  }
  onAddNew() {
    this.message = [];
    this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm = this.onAddDriverTaskSubTypeForm();
    this.driverTaskSubTypeModel.splitView = true;
    this.dropdownValues();
  }
  setFilteredContent(userSearchInput: string) {
    if (userSearchInput === '') {
      this.driverTaskSubTypeModel.operationalWorkOrderTypeCodeItems = this.driverTaskSubTypeModel.dropdownLabels;
    } else {
      this.driverTaskSubTypeModel.operationalWorkOrderTypeCodeItems = Object.assign([], this.driverTaskSubTypeModel.dropdownLabels).filter(
        thisDropdownContent => thisDropdownContent.label.toLowerCase().indexOf(userSearchInput.toLowerCase()) > -1
      );
    }
  }
  setFilteredContentClear() {
    this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.controls.operationalWorkOrderTypeCode.setErrors({ 'incorrect': true });
  }
  overFlowMenuOptions() {
    this.driverTaskSubTypeModel.items = [
      {
        label: 'Export to Excel',
        command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }
  exportToExcel() {
    this.driverTaskSubTypeService.owoSubTypeExcelDownload(DriverTaskSubTypeUtils.getExcelDownloadRequestBody(
      DriverTaskSubTypeQuery.getDriverTaskSubTypeListFromES(this.driverTaskSubTypeModel.queryString,
        this.driverTaskSubTypeModel.pageStart, this.driverTaskSubTypeModel.exportExcelSize,
        this.driverTaskSubTypeModel.sortOrder, this.driverTaskSubTypeModel.sortField)))
      .pipe(
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
      ).subscribe((responseContent: Blob) => {
        if (responseContent) {
          const fileName = `${this.driverTaskSubTypeModel.title} ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
          this.downloadThisExcelFile(responseContent, this.owoSubTypeDownloadExcel, fileName);
        }
        this.changeDetector.detectChanges();
      });
  }
  downloadThisExcelFile(data: Blob, owoSubTypeDownloadExcel: ElementRef, fileName: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      owoSubTypeDownloadExcel.nativeElement.href = URL.createObjectURL(data);
      owoSubTypeDownloadExcel.nativeElement.download = fileName;
      owoSubTypeDownloadExcel.nativeElement.click();
    }
  }
  fetchDriverTaskSubTypeListData() {
    this.driverTaskSubTypeService.getDriverTaskSubTypeList(DriverTaskSubTypeQuery.getDriverTaskSubTypeListFromES(
      this.driverTaskSubTypeModel.queryString, this.driverTaskSubTypeModel.pageStart,
      this.driverTaskSubTypeModel.tableSize, this.driverTaskSubTypeModel.sortOrder, this.driverTaskSubTypeModel.sortField))
      .pipe(
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
        finalize(() => {
          this.driverTaskSubTypeModel.gridLoaderFlag = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((driverTaskSubTypeList: ElasticResponseModel) => {
        if (!LodashUtils.isEmpty(driverTaskSubTypeList) && !LodashUtils.isEmpty(driverTaskSubTypeList.hits)
          && LodashUtils.isEmpty(driverTaskSubTypeList.hits.total)) {
          this.driverTaskSubTypeModel.gridLoaderFlag = !(this.driverTaskSubTypeModel.driverTaskSubTypeList.length > 0);
          this.driverTaskSubTypeModel.totalRecords = driverTaskSubTypeList.hits.total;
          this.driverTaskSubTypeModel.driverTaskSubTypeList = DriverTaskSubTypeUtils.getDriverTaskSubTypeListData(driverTaskSubTypeList);
          this.driverTaskSubTypeModel.paginatorFlag = (this.driverTaskSubTypeModel.driverTaskSubTypeList.length > 0);
        }
      }, (error: Error) => {
        this.driverTaskSubTypeModel.gridLoaderFlag = false;
        this.changeDetector.detectChanges();
      });
  }
  onSearchFocus() {
    if (this.driverTaskSubTypeModel.searchText && this.driverTaskSubTypeModel.searchText.length > 0) {
      this.driverTaskSubTypeModel.searchFieldFocus = true;
    } else {
      this.driverTaskSubTypeModel.searchFieldFocus = false;
    }
  }
  onSearch(event) {
    this.driverTaskSubTypeModel.searchFieldFocus = true;
    this.driverTaskSubTypeModel.userInputSearchSubject.next(event);
  }
  searchInput() {
    this.driverTaskSubTypeModel.userInputSearchSubject
      .pipe(
        debounceTime(300), distinctUntilChanged(),
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
      )
      .subscribe(() => {
        if (this.driverTaskSubTypeModel.searchText.length >= 0) {
          this.driverTaskSubTypeModel.queryString = this.driverTaskSubTypeModel.searchText;
          this.fetchDriverTaskSubTypeListData();
        } else {
          this.driverTaskSubTypeModel.queryString = '';
        }
      });
  }
  onCompareOldData() {
    if (this.driverTaskSubTypeModel.selectedRowContent) {
      const nameRowValue = this.driverTaskSubTypeModel.selectedRowContent.operationalWorkOrderSubTypeDescription;
      const nameFieldValue = this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.controls.owoTypeDescription.value;
      const driverTaskTypeRowValue = this.driverTaskSubTypeModel.selectedRowContent.operationalWorkOrderTypeCode;
      const driverTaskTypeFieldValue = this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.controls.
        operationalWorkOrderTypeCode.value;
      return !((nameRowValue === nameFieldValue) &&
        (JSON.stringify(driverTaskTypeRowValue) === JSON.stringify(driverTaskTypeFieldValue)));
    } else {
      return true;
    }
  }
  onSave() {
    this.message = [];
    if (this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.valid &&
      (this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.dirty
        && this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.touched) && this.onCompareOldData()) {
      this.driverTaskSubTypeModel.isSectionLoaderEnabled = true;
      if (this.driverTaskSubTypeModel.selectedRowContent) {
        this.editServicePlanOrWorkOrder();
      } else {
        this.saveServicePlanOrWorkOrder();
      }
    } else if (this.driverTaskSubTypeModel.selectedRowContent) {
      if (this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.valid) {
        this.messageService.clear();
        this.messageService.add({
          severity: 'info',
          summary: 'No Changes Found',
          detail: 'There are no changes detected in the current action.',
        });
      }
    } else {
      this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.controls.owoTypeCode.markAsTouched();
      this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.controls.owoTypeDescription.markAsTouched();
      this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.controls.operationalWorkOrderTypeCode.markAsTouched();
      if (this.driverTaskSubTypeModel.totalCodeRecords === 0) {
        this.unableToAdd();
      }
    }
  }
  editServicePlanOrWorkOrder() {
    const editDetailsPlan: DriverTaskSubTypeListAddModel = {
      operationalWorkOrderSubtypeDescription: this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.value.owoTypeDescription,
      operationalWorkOrderSubtypeCode: this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.value.owoTypeCode,
      operationalWorkOrderTypeCode: this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.value.operationalWorkOrderTypeCode
    };
    this.driverTaskSubTypeService.editDriverTaskSubTypeList(editDetailsPlan)
      .pipe(
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
        finalize(() => {
          this.driverTaskSubTypeModel.driverTaskSubTypeSelectedList = [];
          this.driverTaskSubTypeModel.selectedRowContent = null;
        })
      )
      .subscribe(() => {
        timer(1000).subscribe(() => {
          this.fetchAllData();
          this.showToastMessage(true);
        });
      });
  }
  saveServicePlanOrWorkOrder() {
    const saveDetailsPlan: DriverTaskSubTypeListAddModel = {
      operationalWorkOrderSubtypeDescription: this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.value.owoTypeDescription,
      operationalWorkOrderSubtypeCode: this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.value.owoTypeCode,
      operationalWorkOrderTypeCode: this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.value.operationalWorkOrderTypeCode
    };
    this.driverTaskSubTypeService.saveDriverTaskSubTypeList(saveDetailsPlan)
      .pipe(
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
        finalize(() => {
          this.driverTaskSubTypeModel.driverTaskSubTypeSelectedList = [];
          this.driverTaskSubTypeModel.selectedRowContent = null;
        })
      )
      .subscribe(() => {
        timer(1000).subscribe(() => {
          this.fetchAllData();
          this.showToastMessage(false);
        });
      }, (err: Error) => {
        this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
        this.changeDetector.detectChanges();
        this.onServiceError(err);
      });
  }
  onServiceError(err: any) {
    if (err['status'] === 409) {
      this.messageService.clear();
      this.messageService.add({
        severity: 'error',
        summary: 'Duplicate Reference Data',
        detail: 'There is already a reference data of this type with the same identiﬁer. Please designate a different identiﬁer.'
      });
    }
  }
  showToastMessage(isEditMode: boolean) {
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isEditMode) ? 'Reference Data Updated' : 'Reference Data Added',
      detail: (isEditMode) ? 'Driver Task Sub Type has been successfully updated.' :
        'Driver Task Sub Type has been successfully added.'
    });
    this.changeDetector.detectChanges();
  }
  fetchAllData() {
    this.driverTaskSubTypeModel.searchText = '';
    this.driverTaskSubTypeModel.queryString = '';
    this.fetchDriverTaskSubTypeListData();
    this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
    this.driverTaskSubTypeModel.splitView = false;
    this.changeDetector.detectChanges();
  }
  onCancel() {
    if (this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.touched
      && this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.dirty) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed ?',
        header: 'Confirmation',
        key: 'DriverTaskSubType',
        accept: (): void => {
          this.closeSplitView();
          this.driverTaskSubTypeModel.splitView = false;
        }
      });
    } else {
      this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.reset();
      this.closeSplitView();
    }
  }
  closeSplitView() {
    this.fetchDriverTaskSubTypeListData();
    this.closeAddEditPage();
  }
  onRowSelect(selectedRow: DriverTaskSubTypeListModel) {
    this.message = [];
    this.getAssociatedOWO(selectedRow.operationalWorkOrderSubTypeCode);
    if (this.driverTaskSubTypeModel.selectedRowContent && selectedRow.operationalWorkOrderSubTypeCode !==
      this.driverTaskSubTypeModel.selectedRowContent.operationalWorkOrderSubTypeCode) {
      this.selectedContentSplitScreen(selectedRow);
    } else if (!this.driverTaskSubTypeModel.selectedRowContent) {
      this.selectedContentSplitScreen(selectedRow);
    }
  }
  selectedContentSplitScreen(selectedContent: DriverTaskSubTypeListModel) {
    this.driverTaskSubTypeModel.selectedRowContent = selectedContent;
    this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm = this.onAddDriverTaskSubTypeForm();
    this.driverTaskSubTypeModel.addDriverTaskSubTypeStatusForm.patchValue({
      owoTypeDescription: selectedContent.operationalWorkOrderSubTypeDescription,
      owoTypeCode: selectedContent.operationalWorkOrderSubTypeCode,
      operationalWorkOrderTypeCode: selectedContent.operationalWorkorderType
    });
    this.driverTaskSubTypeModel.splitView = true;
    this.dropdownValues();
  }
  closeAddEditPage() {
    this.driverTaskSubTypeModel.driverTaskSubTypeSelectedList = [];
    this.driverTaskSubTypeModel.selectedRowContent = null;
    this.driverTaskSubTypeModel.splitView = false;
  }
  onActivate() {
    this.driverTaskSubTypeModel.isSectionLoaderEnabled = true;
    this.driverTaskSubTypeService.reactivateDriverTaskSubTypeList(DriverTaskSubTypeUtils.activateInactivateContent
      (this.driverTaskSubTypeModel.selectedRowContent))
      .pipe(
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
        finalize(() => {
          this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe(() => {
        timer(1000).subscribe(() => {
          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(false);
          this.driverTaskSubTypeModel.driverTaskSubTypeSelectedList = [];
          this.driverTaskSubTypeModel.selectedRowContent = null;
        });
      }, (validationError) => {
        this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
        this.getValidationErrorResponse(validationError);
      });
  }
  onInactivate() {
    if (this.driverTaskSubTypeModel.displayInfoMsg) {
      this.confirmationService.confirm({
        message: `Driver Task Sub Type<br><b>${this.driverTaskSubTypeModel.selectedRowContent.operationalWorkOrderSubTypeDescription}
        (${this.driverTaskSubTypeModel.selectedRowContent.operationalWorkOrderSubTypeCode})</b><br><br>
        The reference data you’re about to inactivate may be associated to active orders or other entities,
        inactivating the  data will not impact current associations but <b>new entities can no longer reference this record.</b><br><br>
        Any other <b>reference data that has this record as an association will also be inactivated.</b><br><br>
        Do you wish to proceed ?`,
        header: 'Inactivate Driver Task SubType',
        key: 'inactivateDriverTaskSubTypeStatus',
        accept: (): void => {
          this.driverTaskSubTypeModel.isSectionLoaderEnabled = true;
          this.inactivatePlanOrWorkOrder();
        }
      });
    } else {
      this.driverTaskSubTypeModel.isSectionLoaderEnabled = true;
      this.inactivatePlanOrWorkOrder();
    }
  }

  inactivatePlanOrWorkOrder() {
    this.driverTaskSubTypeService.inactivateDriverTaskSubTypeList(DriverTaskSubTypeUtils.activateInactivateContent
      (this.driverTaskSubTypeModel.selectedRowContent))
      .pipe(
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      )
      .subscribe(() => {
        timer(1000).subscribe(() => {

          this.fetchAllData();
          this.showToastMsgForReactivateInactivate(true);
          this.driverTaskSubTypeModel.driverTaskSubTypeSelectedList = [];
          this.driverTaskSubTypeModel.selectedRowContent = null;
        });
      }, (validationError) => {
        this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
        this.getValidationErrorResponse(validationError);
      });
  }
  showToastMsgForReactivateInactivate(isDeactivateMode: boolean) {
    this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
    this.messageService.clear();
    this.messageService.add({
      severity: 'success',
      summary: (isDeactivateMode) ? 'Reference Data Inactivated.' : 'Reference Data Activated.',
      detail: (isDeactivateMode) ? 'Driver Task Sub Type has been successfully inactivated.' :
        'Driver Task Sub Type has been successfully activated.'
    });
    this.changeDetector.detectChanges();
  }
  dropdownValues() {
    this.driverTaskSubTypeModel.dropdownLabels = [];
    this.driverTaskSubTypeService.getDriverTasKTypeList(DriverTaskSubTypeQuery.getDriverTaskTypeListFromES())
      .pipe(
        takeWhile(() => this.driverTaskSubTypeModel.subscriberFlag),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((driverTaskTypeCode: ElasticResponseModel) => {
        if (!LodashUtils.isEmpty(driverTaskTypeCode) && !LodashUtils.isEmpty(driverTaskTypeCode.hits)
          && LodashUtils.isEmpty(driverTaskTypeCode.hits.total)) {
          this.driverTaskSubTypeModel.totalCodeRecords = driverTaskTypeCode.hits.total;
          if (driverTaskTypeCode.hits.total === 0) {
            this.unableToAdd();
          }
          this.driverTaskSubTypeModel.dropdownLabels = DriverTaskSubTypeUtils.getDriverTaskTypeCode(driverTaskTypeCode);
          this.driverTaskSubTypeModel.operationalWorkOrderTypeCodeItems = LodashUtils.cloneDeep(this.driverTaskSubTypeModel.dropdownLabels);
        }
      }, (err: Error) => {
        this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
        this.unableToAdd();
      });
  }

  unableToAdd() {
    this.driverTaskSubTypeModel.totalCodeRecords = 0;
    this.driverTaskSubTypeModel.lableValue = true;
    this.message = [];
    this.message.push({
      severity: 'info',
      summary: ' ',
      detail: 'You can\'t add Driver Task Sub Type as there is no active Driver Task Type'
    });
  }

  getCurrentScrollPosition() {
    if (this.tableContent && this.tableContent['el']) {
      const scrollableElement = this.tableContent['el'].nativeElement.querySelector('.ui-table-scrollable-body');
      if (scrollableElement) {
        scrollableElement.scrollTop = 0;
      }
    }
  }
  getValidationErrorResponse(validationError: any) {
    if (validationError.status === 400) {
      let summaryMsg = 'Action can\'t be performed';
      let severityMsg = 'error';
      const errorJson = typeof validationError.error === 'string' ? JSON.parse(validationError.error) : validationError.error;
      if (errorJson && errorJson.errors && errorJson.errors.length !== 0) {
        this.driverTaskSubTypeModel.staleRecordErrMsg = errorJson.errors[0].errorMessage;
        if (errorJson.errors[0].code === 'EX_SUBTYPE_HAS_INACTIVE_ASSOCIATED_TYPE') {
          summaryMsg = 'Activate Unsuccessful';
          severityMsg = 'info';
        }
      }
      this.messageService.clear();
      this.messageService.add({
        severity: severityMsg,
        summary: summaryMsg,
        detail: this.driverTaskSubTypeModel.staleRecordErrMsg
      });
    }
  }
  getAssociatedOWO(subTypeCode: string) {
    if (this.driverTaskSubTypeModel.driverSubTypeSplitInformation) {
      this.driverTaskSubTypeModel.driverSubTypeSplitInformation.unsubscribe();
    }
    this.driverTaskSubTypeModel.isSectionLoaderEnabled = true;
    const requestParam = [subTypeCode];
    this.driverTaskSubTypeModel.driverSubTypeSplitInformation =
      this.driverTaskSubTypeService.getDriverTaskList(requestParam)
        .pipe(finalize(() => {
          this.driverTaskSubTypeModel.isSectionLoaderEnabled = false;
          this.changeDetector.detectChanges();
        })
        ).subscribe((data: any) => {
          if (data) {
            this.driverTaskSubTypeModel.displayInfoMsg = true;
          } else {
            this.driverTaskSubTypeModel.displayInfoMsg = false;
          }
        });
  }
}
