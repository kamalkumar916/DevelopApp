import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DriverTaskSubTypeComponent } from './driver-task-sub-type.component';
import { DriverTaskTypeAndSubTypeModule } from '../driver-task-type-and-sub-type/driver-task-type-and-sub-type.module';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { TooltipModule } from 'primeng/tooltip';
import { SortView } from './model/driver-task-sub-type.interface';
import { UserService } from '../../../../shared/jbh-esa/index';
import { throwError, of } from 'rxjs';
import { DriverTaskSubTypeService } from './services/driver-task-sub-type.service';

const elasticresponsemodel = {
  took: 41,
  timed_out: false,
  _shards: {
    'total': 3,
    'successful': 3,
    'skipped': 0,
    'failed': 0
  },
  hits: {
    'total': 1,
    'max_score': null,
    'hits': [{
      '_index': 'loadplanning-operationalworkorder-drivertasktype',
      '_type': 'doc',
      '_id': 'Reposition',
      '_score': null,
      '_source': {
        'OperationalWorkOrderTypeCode': 'Reposition',
        'OperationalWorkOrderTypeDescription': 'Reposition',
        'LastUpdateUserID': 'PIDNEXT',
        'LastUpdateProgramName': 'SSIS',
        'EffectiveTimestamp': '01-01-2018 00:00:00',
        'ExpirationTimestamp': '12-31-2199 23:59:59',
        'LastUpdateTimestamp': 'Sep 28,2019 05:25 AM UTC',
        'Status': 'Active'
      },
      'sort': ['Active']
    }]
  }
};
class MockDriverTaskSubTypeService {
  constructor() { }
  getDriverTaskSubTypeList() {
    return of(elasticresponsemodel);
  }
  getDriverTasKTypeList() {
    return of(elasticresponsemodel);
  }
}

describe('DriverTaskSubTypeComponent', () => {
  let component: DriverTaskSubTypeComponent;
  let fixture: ComponentFixture<DriverTaskSubTypeComponent>;
  let thisEvent: SortView;
  let serviceMesg: MessageService;
  let service: DriverTaskSubTypeService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, DriverTaskTypeAndSubTypeModule, HttpClientTestingModule, TooltipModule,
        NoopAnimationsModule],
      providers: [UserService, MessageService, ConfirmationService, AppConfigService,
        { provide: DriverTaskSubTypeService, useClass: MockDriverTaskSubTypeService }]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverTaskSubTypeComponent);
    serviceMesg = TestBed.get(MessageService);
    service = TestBed.get(DriverTaskSubTypeService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('unableToAdd have been called', () => {
    component.unableToAdd();
    expect(component.driverTaskSubTypeModel.lableValue).toBe(true);
  });
  it('checking serachFieldFocus to be true', () => {
    const event = ' ';
    component.driverTaskSubTypeModel.searchFieldFocus = true;
    component.onSearch(event);
    expect(component.driverTaskSubTypeModel.searchFieldFocus).toBe(true);
  });
  it('checking searchText length', () => {
    component.driverTaskSubTypeModel.searchText = 'test';
    component.onSearchFocus();
    expect(component.driverTaskSubTypeModel.searchFieldFocus).toBe(true);
  });
  it('checking searchText length', () => {
    component.driverTaskSubTypeModel.searchText = '';
    component.onSearchFocus();
    expect(component.driverTaskSubTypeModel.searchFieldFocus).toBe(false);
  });
  it('closeAddEditPage have been called', () => {
    component.closeAddEditPage();
    expect(component.driverTaskSubTypeModel.splitView).toBe(false);
  });
  it('setFilteredContent have been called', () => {
    component.setFilteredContent('');
    expect(component.driverTaskSubTypeModel.operationalWorkOrderTypeCodeItems).toBe(component.driverTaskSubTypeModel.dropdownLabels);
  });
  it('onPage have been called', () => {
    thisEvent = {
      first: 1,
      rows: 10,
      sortOrder: 1,
      sortField: 'test'
    };
    spyOn(component, 'fetchDriverTaskSubTypeListData');
    component.onPage(thisEvent);
    expect(component.driverTaskSubTypeModel.pageStart).toBe(thisEvent.first);
    expect(component.driverTaskSubTypeModel.tableSize).toBe(thisEvent.rows);
    expect(component.driverTaskSubTypeModel.sortField).toBe(thisEvent.sortField);
    expect(component.driverTaskSubTypeModel.sortOrder).toBe('asc');
    expect(component.fetchDriverTaskSubTypeListData).toHaveBeenCalled();
  });

  it('onAddNew have been called', () => {
    component.onAddNew();
    expect(component.driverTaskSubTypeModel.splitView).toBe(true);
  });
  it('fetchAllData have been called', () => {
    component.fetchAllData();
    expect(component.driverTaskSubTypeModel.searchText).toEqual('');
  });
  it('closeSplitView have been called', () => {
    spyOn(component, 'fetchDriverTaskSubTypeListData');
    component.closeSplitView();
    expect(component.fetchDriverTaskSubTypeListData).toHaveBeenCalled();
  });
  it('selectedContentSplitScreen have been called', () => {
    const param = {
      effectiveTimestamp: 'ab',
      expirationTimestamp: 'ab',
      lastUpdateProgramName: 'ab',
      lastUpdateTimestamp: 'ab',
      lastUpdateUserID: 'ab',
      operationalWorkOrderSubTypeCode: 'ab',
      operationalWorkOrderSubTypeDescription: 'ab',
      status: 'available',
      operationalWorkOrderTypeCode: 'ab',
      operationalWorkOrderTypeDescription: 'available',
      operationalWorkorderType: ['ab', 'bc'],
      lastUpdatedBy: 'abc'
    };
    component.selectedContentSplitScreen(param);
    expect(component.driverTaskSubTypeModel.selectedRowContent).toEqual(param);
    expect(component.driverTaskSubTypeModel.splitView).toBe(true);
  });
  it('showToastMessage throwing Error', () => {
    const isEditMode: boolean = true;
    spyOn(serviceMesg, 'clear');
    spyOn(serviceMesg, 'add');
    component.showToastMessage(isEditMode);
    expect(serviceMesg.clear).toHaveBeenCalled();
  });
  it('showToastMsgForReactivateInactivate throwing Error', () => {
    const isDeactiveMode: boolean = true;
    spyOn(serviceMesg, 'clear');
    spyOn(serviceMesg, 'add');
    component.showToastMsgForReactivateInactivate(isDeactiveMode);
    expect(serviceMesg.clear).toHaveBeenCalled();
  });
  it('ngOnInit have been called', () => {
    spyOn(component, 'dropdownValues');
    component.ngOnInit();
    expect(component.dropdownValues).toHaveBeenCalled();
  });
  it('onCompareOldData have been called', () => {
    component.onCompareOldData();
    expect(component.onCompareOldData).toBeTruthy();
  });
  it('onRowselect have been called', () => {
    const param = {
      effectiveTimestamp: 'ab',
      expirationTimestamp: 'ab',
      lastUpdateProgramName: 'ab',
      lastUpdateTimestamp: 'ab',
      lastUpdateUserID: 'ab',
      operationalWorkOrderSubTypeCode: 'ab',
      operationalWorkOrderSubTypeDescription: 'ab',
      status: 'available',
      operationalWorkOrderTypeCode: 'ab',
      operationalWorkOrderTypeDescription: 'available',
      operationalWorkorderType: ['ab', 'bc'],
      lastUpdatedBy: 'abc'
    };
    spyOn(component, 'getAssociatedOWO');
    spyOn(component, 'selectedContentSplitScreen');
    component.onRowSelect(param);
    expect(component.getAssociatedOWO).toHaveBeenCalled();
  });
  it('fetchDriverTaskSubTypeListData have been called', () => {
    spyOn(service, 'getDriverTaskSubTypeList').and.returnValue(of(elasticresponsemodel));
    component.fetchDriverTaskSubTypeListData();
    expect(component.driverTaskSubTypeModel.subscriberFlag).toBe(true);
    expect(component.driverTaskSubTypeModel.gridLoaderFlag).toBe(false);
    expect(component.driverTaskSubTypeModel.totalRecords).toEqual(elasticresponsemodel.hits.total);
    expect(component.driverTaskSubTypeModel.paginatorFlag).toBe(true);
  });
  it('fetchDriverTaskSubTypeListData error block called', () => {
    spyOn(service, 'getDriverTaskSubTypeList').and.returnValue(throwError(null));
    component.fetchDriverTaskSubTypeListData();
    expect(component.driverTaskSubTypeModel.subscriberFlag).toBe(true);
    expect(component.driverTaskSubTypeModel.gridLoaderFlag).toEqual(false);
  });
  it('dropdownValues have been called', () => {
    spyOn(service, 'getDriverTasKTypeList').and.returnValue(of(elasticresponsemodel));
    component.dropdownValues();
    expect(component.driverTaskSubTypeModel.subscriberFlag).toBe(true);
    expect(component.driverTaskSubTypeModel.totalRecords).toEqual(elasticresponsemodel.hits.total);
    expect(component.driverTaskSubTypeModel.dropdownLabels.length).toEqual(1);
    expect(component.driverTaskSubTypeModel.operationalWorkOrderTypeCodeItems.length).toEqual(1);
  });
  it('dropdownValues error block called', () => {
    spyOn(service, 'getDriverTasKTypeList').and.returnValue(throwError(null));
    component.dropdownValues();
    expect(component.driverTaskSubTypeModel.subscriberFlag).toBe(true);
    expect(component.driverTaskSubTypeModel.isSectionLoaderEnabled).toEqual(false);
  });
  it('onServiceError throwing Error', () => {
    spyOn(serviceMesg, 'clear');
    spyOn(serviceMesg, 'add');
    const errorResp = {
      status: 409
    };
    component.onServiceError(errorResp);
    expect(serviceMesg.clear).toHaveBeenCalled();
  });
});
