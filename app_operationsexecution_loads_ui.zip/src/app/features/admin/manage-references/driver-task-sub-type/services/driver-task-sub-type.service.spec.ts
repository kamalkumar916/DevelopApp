import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { DriverTaskSubTypeService } from './driver-task-sub-type.service';
import { configureTestSuite } from 'ng-bullet';

describe('DriverTaskSubTypeService', () => {
  let service: DriverTaskSubTypeService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [DriverTaskSubTypeService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(DriverTaskSubTypeService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes expected getDriverTasKTypeList calls', () => {
    service.getDriverTasKTypeList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.getDriverTaskTypeList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getDriverTasKSubTypeList calls', () => {
    service.getDriverTaskSubTypeList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.getDriverTaskSubTypeList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected saveDriverTaskSubTypeList calls', () => {
    const param = {
      operationalWorkOrderSubtypeDescription: 'Available',
      operationalWorkOrderSubtypeCode: 'Available',
      operationalWorkOrderTypeCode: 'Available'
    };
    service.saveDriverTaskSubTypeList(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.saveDriverTaskSubType);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected editDriverTaskSubTypeList calls', () => {
    const param = {
      operationalWorkOrderSubtypeDescription: 'Available',
      operationalWorkOrderSubtypeCode: 'Available',
      operationalWorkOrderTypeCode: 'Available'
    };
    service.editDriverTaskSubTypeList(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.saveDriverTaskSubType);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes expected getDriverTaskList calls', () => {
    const param = ['Test1', 'Test2'];
    service.getDriverTaskList(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.getInfoDriverTaskSubTypeList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected inactivateDriverTaskSubTypeList calls', () => {
    const param = {
      operationalWorkOrderSubtypeDescription: 'Available',
      operationalWorkOrderSubtypeCode: 'OG'
    };
    service.inactivateDriverTaskSubTypeList(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.inactivateDriverTaskSubTypeStatus);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes expected reactivateDriverTaskSubTypeList calls', () => {
    const param = {
      operationalWorkOrderSubtypeDescription: 'Available',
      operationalWorkOrderSubtypeCode: 'OG'
    };
    service.reactivateDriverTaskSubTypeList(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.reactivateDriverTaskSubTypeStatus);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes expected owoSubTypeExcelDownload calls', () => {
    const param = {
      headerDetails: ['Test1', 'Test2'],
      elasticSearchQuery: {}
    };
    service.owoSubTypeExcelDownload(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoints.driverTaskSubTypeExcelDownload);
    expect(req.request.method).toEqual('POST');
  });
});


