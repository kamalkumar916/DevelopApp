

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConfigService } from '../../../../../shared/service/app-config.service';

import {
  OwoSubTypeExcelDownloadModel, DriverTaskSubTypeListAddModel, DriverTaskSubTypeActiveInactiveModel
} from '../model/driver-task-sub-type.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';

@Injectable()
export class DriverTaskSubTypeService {
  endpoints: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoints = appConfigService.getApi('admin');
  }

  getDriverTasKTypeList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoints.getDriverTaskTypeList, query);
  }

  getDriverTaskSubTypeList(query: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoints.getDriverTaskSubTypeList, query);
  }

  saveDriverTaskSubTypeList(query: DriverTaskSubTypeListAddModel): Observable<boolean> {
    return this.http.post<boolean>(this.endpoints.saveDriverTaskSubType, query);
  }

  editDriverTaskSubTypeList(query: DriverTaskSubTypeListAddModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoints.saveDriverTaskSubType, query);
  }

  inactivateDriverTaskSubTypeList(driverTaskSubTypeCodeModel: DriverTaskSubTypeActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoints.inactivateDriverTaskSubTypeStatus, driverTaskSubTypeCodeModel);
  }

  reactivateDriverTaskSubTypeList(driverTaskSubTypeCodeModel: DriverTaskSubTypeActiveInactiveModel): Observable<boolean> {
    return this.http.patch<boolean>(this.endpoints.reactivateDriverTaskSubTypeStatus, driverTaskSubTypeCodeModel);
  }

  owoSubTypeExcelDownload(requestParam: OwoSubTypeExcelDownloadModel, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoints.driverTaskSubTypeExcelDownload, requestParam, { headers, responseType: 'blob' });
  }
  getDriverTaskList(subTypeCode: string[]): Observable<any>  {
    return this.http.post<any>(this.endpoints.getInfoDriverTaskSubTypeList, subTypeCode);
  }
}
