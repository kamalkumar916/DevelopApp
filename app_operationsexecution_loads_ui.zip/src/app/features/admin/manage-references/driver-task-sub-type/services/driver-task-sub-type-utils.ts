import {
  DriverTaskSubTypeListModel, DriverTaskSubTypeActiveInactiveModel, DriverTaskTypeCodeModel,
  OwoSubTypeExcelDownloadModel, OWOType
} from '../model/driver-task-sub-type.interface';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import * as LodashUtils from 'lodash';
import { ListItem } from './../../../../model/listitem.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';

export class DriverTaskSubTypeUtils {

  constructor() { }

  static getDriverTaskSubTypeListData(driverTaskSubTypeList: ElasticResponseModel): DriverTaskSubTypeListModel[] {
    let returnData: DriverTaskSubTypeListModel[] = [];
    if (driverTaskSubTypeList && driverTaskSubTypeList.hits && driverTaskSubTypeList.hits.hits) {
      returnData = driverTaskSubTypeList.hits.hits.map((driverTaskSubTypeStatus: HitsModel) => {
        return {
          'effectiveTimestamp': driverTaskSubTypeStatus._source.EffectiveTimestamp,
          'expirationTimestamp': driverTaskSubTypeStatus._source.ExpirationTimestamp,
          'lastUpdateProgramName': driverTaskSubTypeStatus._source.LastUpdateProgramName,
          'lastUpdateTimestamp':
            DateUtils.convertOffsetDateByDefaultTimeZone(driverTaskSubTypeStatus._source['LastUpdateTimestamp'], 'MMM DD,YYYY hh:mm A z'),
          'lastUpdateUserID': driverTaskSubTypeStatus._source.LastUpdateUserID,
          'status': driverTaskSubTypeStatus._source.Status,
          'operationalWorkorderType': this.getOperationalWorkOrderType(driverTaskSubTypeStatus._source.OperationalWorkOrderType),
          'operationalWorkOrderSubTypeCode': driverTaskSubTypeStatus._source.OperationalWorkOrderSubTypeCode,
          'operationalWorkOrderSubTypeDescription': driverTaskSubTypeStatus._source.OperationalWorkOrderSubTypeDescription,
          'lastUpdatedBy': `${driverTaskSubTypeStatus._source.LastUpdateProgramName}
         (${driverTaskSubTypeStatus._source.LastUpdateUserID.toUpperCase()})`
        };
      });
    }

    return returnData;
  }
  static getOperationalWorkOrderType(owoType: OWOType[]): string[] {
    let owoTypeList = LodashUtils.map(owoType, 'OperationalWorkOrderTypeCode');
    owoTypeList = (owoTypeList.every(LodashUtils.isNull)) ? ['- - -'] : owoTypeList;
    return owoTypeList;
  }
  static getDriverTaskTypeCode(driverTaskTypeCode: ElasticResponseModel): ListItem[] {
    const returnDriverTaskTypeCode: ListItem[] = [];
    if (driverTaskTypeCode && driverTaskTypeCode.hits && driverTaskTypeCode.hits.hits) {
      driverTaskTypeCode.hits.hits.forEach(codeList => {
        if (codeList && codeList._source && codeList._source.OperationalWorkOrderTypeCode) {
          if (LodashUtils.isString(codeList._source.OperationalWorkOrderTypeCode)) {
            this.operationalWorkOrderTypeCode(returnDriverTaskTypeCode, codeList);
          } else if (LodashUtils.isArray(codeList._source.OperationalWorkOrderTypeCode)) {
            this.operationalWorkOrder(returnDriverTaskTypeCode, codeList);
          }
        }
      });
      return returnDriverTaskTypeCode;
    }

    return returnDriverTaskTypeCode;
  }

  static operationalWorkOrderTypeCode(returnDriverTaskTypeCode: ListItem[], codeList) {
    const matchedObject = LodashUtils.filter(returnDriverTaskTypeCode, ['label', codeList._source.OperationalWorkOrderTypeCode]);
    if (LodashUtils.isEmpty(matchedObject)) {
      const codeValue = {
        label: codeList._source.OperationalWorkOrderTypeCode,
        value: codeList._source.OperationalWorkOrderTypeCode
      };
      returnDriverTaskTypeCode.push(codeValue);
    }
  }

  static operationalWorkOrder(returnDriverTaskTypeCode: ListItem[], codeList) {
    codeList._source.OperationalWorkOrderTypeCode.forEach(workOrderTypeCode => {
      const matchedObject = LodashUtils.filter(returnDriverTaskTypeCode, ['label', workOrderTypeCode]);
      if (LodashUtils.isEmpty(matchedObject)) {
        const codeValue = {
          label: workOrderTypeCode,
          value: workOrderTypeCode
        };
        returnDriverTaskTypeCode.push(codeValue);
      }
    });
  }

  static activateInactivateContent(typeCode: DriverTaskSubTypeListModel): DriverTaskSubTypeActiveInactiveModel {
    return {
      'operationalWorkOrderSubtypeCode': typeCode.operationalWorkOrderSubTypeCode,
      'operationalWorkOrderSubtypeDescription': typeCode.operationalWorkOrderSubTypeDescription,
      'operationalWorkOrderTypeCode': typeCode.operationalWorkorderType
    };
  }

  static getExcelDownloadRequestBody(esQuery: object): OwoSubTypeExcelDownloadModel {
    return {
      headerDetails: [
        'operationalWorkOrderSubTypeDescription',
        'operationalWorkOrderSubTypeCode',
        'operationalWorkOrderTypeCode',
        'owoSubtypeLastUpdateUserID',
        'owoSubtypeLastUpdateProgramName',
        'owoSubtypeStatus'
      ],
      elasticSearchQuery: {
        query: esQuery['query'],
        sort: esQuery['sort'],
        size: esQuery['size']
      }
    };
  }
}
