import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { TabViewModule } from 'primeng/tabview';
import { CheckboxModule } from 'primeng/checkbox';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { DialogModule } from 'primeng/dialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { AccordionModule } from 'primeng/accordion';
import { PipesModule } from '../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from '../../../shared/directives/directives.module';

import { OperationalTeamManagementRoutingModule } from './operational-team-management-routing.module';
import { TeamListComponent } from './team-list/team-list.component';
import { TeamFilterComponent } from './team-list/team-filter/team-filter.component';
import { TeamDetailsComponent } from './team-list/team-details/team-details.component';
import { DriverDetailsComponent } from './team-list/team-details/driver-details/driver-details.component';
import { TruckDetailsComponent } from './team-list/team-details/truck-details/truck-details.component';
import { CarrierDetailsComponent } from './team-list/team-details/carrier-details/carrier-details.component';
import { TrailingDetailsComponent } from './team-list/team-details/trailing-details/trailing-details.component';

import { OperationalTeamUtilityService } from './services/operational-team-utility.service';
import { TeamListService } from './team-list/services/team-list.service';
import { TeamListUtilityService } from './team-list/services/team-list-utility.service';
import { TeamFilterService } from './team-list/team-filter/services/team-filter.service';
import { TeamDetailsService } from './team-list/team-details/services/team-details.service';
import { TeamDetailsUtilityService } from './team-list/team-details/services/team-details-utility.service';
import { DriverDetailsService } from './team-list/team-details/driver-details/services/driver-details.service';
import { DriverDetailsUtilityService } from './team-list/team-details/driver-details/services/driver-details-utility.service';
import { DriverSortSearchService } from './team-list/team-details/driver-details/services/driver-sort-search.service';
import { TruckDetailsUtilityService } from './team-list/team-details/truck-details/services/truck-details-utility.service';
import { TruckDetailsService } from './team-list/team-details/truck-details/services/truck-details.service';
import { CarrierDetailsService } from './team-list/team-details/carrier-details/services/carrier-details.service';
import { TrailingDetailsService } from './team-list/team-details/trailing-details/services/trailing-details.service';
import { TrailingDetailsUtilityService } from './team-list/team-details/trailing-details/services/trailing-details-utility.service';
import { JbhFiltersModule } from '../../../shared/jbh-filters/jbh-filters.module';
import { CarrierDetailsUtilityService } from './team-list/team-details/carrier-details/services/carrier-details-utility.service';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { ViewProfileUtilityService } from './view-profile/services/view-profile-utility.service';
import { ViewProfileService } from './view-profile/services/view-profile.service';
import { ViewAuditComponent } from './view-profile/view-audit/view-audit/view-audit.component';
import { ViewAuditService } from './view-profile/view-audit/service/view-audit.service';

@NgModule({
  imports: [
    CommonModule,
    DirectivesModule,
    PipesModule,
    BreadcrumbModule,
    ButtonModule,
    InputTextModule,
    MenuModule,
    PanelModule,
    TooltipModule,
    TableModule,
    PaginatorModule,
    OperationalTeamManagementRoutingModule,
    TabViewModule,
    CheckboxModule,
    JbhLoaderModule,
    JbhFiltersModule,
    CalendarModule,
    FormsModule,
    ReactiveFormsModule,
    AutoCompleteModule,
    DialogModule,
    MultiSelectModule,
    AccordionModule
  ],
  declarations: [
    TeamListComponent,
    TeamFilterComponent,
    TeamDetailsComponent,
    DriverDetailsComponent,
    TruckDetailsComponent,
    CarrierDetailsComponent,
    TrailingDetailsComponent,
    ViewProfileComponent,
    ViewAuditComponent
  ],
  providers: [
    OperationalTeamUtilityService,
    TeamListService,
    TeamFilterService,
    TeamDetailsService,
    DriverDetailsService,
    DriverSortSearchService,
    TruckDetailsService,
    CarrierDetailsService,
    TrailingDetailsService,
    TrailingDetailsUtilityService,
    TeamListUtilityService,
    TeamDetailsUtilityService,
    DriverDetailsUtilityService,
    TruckDetailsUtilityService,
    CarrierDetailsUtilityService,
    ViewProfileService,
    ViewProfileUtilityService,
    ViewAuditService
  ]
})
export class OperationalTeamManagementModule { }
