export class OperationalTeam {
    validationErrMsgTitle: any;
    constructor() {
        this.validationErrMsgTitle = {
            EX_MEMBER_EXISTS_IN_SAME_OG: 'Member already selected',
            EX_TRUCK_ADD_HAVING_PARIING_DRIVER: 'Unable to Add Truck',
            EX_PERMANENT_DRIVER_NOT_EXISTS: 'Unable to Add Driver',
            EX_TRUCK_REMOVE_HAVING_PARIING_DRIVER: 'Unable to Remove Truck',
            EX_MEMBER_EXISTS_IN_SINGLE_TRUCK_OG: 'Unable to Remove Truck',
            EX_MEMBER_EXISTS_IN_SINGLE_TRAIL_OG: 'Unable to Remove Trailing Equipment'
        };
    }
}
