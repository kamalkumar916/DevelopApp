export interface OperationalGroupDriverAssignment {
    driverPersonID: number;
    driverFirstName: string;
    driverMiddleName?: any;
    driverLastName: string;
    driverPreferredName: string;
    driverUserId: string;
    driverPositionDescription: string;
    operationalGroupDriverAssignmentTypeCode: string;
    overrideDriverValidations: string;
    overridePairedValidations: string;
    expirationTimestamp: string;
}

export interface OperationalGroupTruckAssignment {
    equipmentId: number;
    equipmentUnitId: string;
    equipmentClassificationCode: string;
    overrideTruckValidations: string;
}

export interface OperationalGroupTrailingEquipmentAssignment {
    equipmentId: number;
    equipmentUnitId: string;
    equipmentClassificationCode: string;
    overrideTrailingEquipmentValidations: string;
}

export interface OperationalGroupCarrierAssignment {
    carrierId: number;
    carrierName: string;
    carrierCode: string;
}

export interface PostableOperationalGroup {
    operationalGroupCode: string;
    operationalGroupDescription: string;
    operationalGroupTypeCode: string;
    operationalGroupTypeDescription: string;
    operationalGroupSubTypeCode: string;
    operationalGroupSubTypeDescription: string;
    businessUnit: string;
    addingSource?: string;
    isAddMemberClicked?: boolean;
    isRemoveMemberClicked?: boolean;
    financeBusinessUnitCode?: string;
    utilizationStatus: UtilizationStatus[];
    operationalGroupDriverAssignments?: OperationalGroupDriverAssignment[];
    operationalGroupUnAssignmentPersonIds?: number[];
    operationalGroupTruckAssignments?: OperationalGroupTruckAssignment[];
    operationalGroupUnAssignmentTruckEquipmentIds?: number[];
    operationalGroupTrailingEquipmentAssignments?: OperationalGroupTrailingEquipmentAssignment[];
    operationalGroupUnAssignmentTrailingEquipmentIds?: number[];
    operationalGroupCarrierAssignments?: OperationalGroupCarrierAssignment[];
    operationalGroupUnAssignmentCarrierIds?: number[];

}

export interface UtilizationStatus {
    utilizationStatusCode: string;
    utilizationStatusDescription: string;
}

export interface MemberValidationInput {
    memberIds: string;
    operationalGroupType: string;
    action: string;
    memberName?: string;
}

export interface MemberValidationCustomOutput {
    isOverridedValidation?: boolean;
    memberValidationMsgs: string[];
    validationMsgType: string;
    validationMsgCode: string;
    validationMsgTitle: string;
}

export interface ErrorMsg {
    fieldErrorFlag: boolean;
    errorMessage: string;
    errorType: string;
    fieldName?: any;
    code: string;
    errorSeverity: string;
}

export interface MemberValidationError {
    traceid: string;
    errors: ErrorMsg[];
}

export interface OGMemberValidation {
    isMemberExistsOverLimit: boolean;
    memberExistsToastMsg: any;
}

export interface TeamMemberScrollInformation {
    scrollTop: number;
    currentTabSelectionIdx: number;
    isMemberServiceNeedsToCall: boolean;
}
