import { Injectable } from '@angular/core';
import * as lodashutils from 'lodash';
import { Router } from '@angular/router';
import { from } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserService } from '../../../../shared/jbh-esa/index';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import {
  MemberValidationCustomOutput, MemberValidationError, ErrorMsg, OperationalGroupCarrierAssignment,
  OperationalGroupDriverAssignment, OperationalGroupTruckAssignment, OGMemberValidation,
  OperationalGroupTrailingEquipmentAssignment, PostableOperationalGroup
} from '../model/operational-team.interface';
import { OperationalTeam } from '../model/operational-team.model';

@Injectable()
export class OperationalTeamUtilityService {
  appConfigURL: string;
  operationalTeamModel: OperationalTeam;
  constructor(private readonly localStorageService: LocalStorageService,
    public router: Router,
    private readonly userService: UserService) {
    this.operationalTeamModel = new OperationalTeam();
    this.appConfigURL = '/operationsexecutionadminoperationalgroup/operationalgroups';
  }

  private postableOperGroupData: PostableOperationalGroup;
  private maxMembersInOperationalGroup: number;

  setOperationalGroupData(operGroupDataArg: PostableOperationalGroup) {
    this.postableOperGroupData = operGroupDataArg;
    this.setDefaultLocalStorageData(operGroupDataArg.operationalGroupCode);
  }

  setMaxMembersInOG(maxMemberCount: number) {
    this.maxMembersInOperationalGroup = maxMemberCount;
  }

  setLocalStorageData(operationalGroupCode: string, tabDataMember: string,
    tabDataToPost: any) {
    const localStorageData = this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
    const clonedLocalStorageData = (localStorageData) ?
      lodashutils.cloneDeep(localStorageData) : this.getDefaultPostableData(operationalGroupCode);
    clonedLocalStorageData[tabDataMember] = tabDataToPost;
    this.localStorageService.setItem('OperationalTeamGroup', 'PostableOperationalGroup', clonedLocalStorageData);
  }

  setDefaultLocalStorageData(operationalGroupCode: string) {
    this.localStorageService.setItem('OperationalTeamGroup', 'PostableOperationalGroup',
      this.getDefaultPostableData(operationalGroupCode));
  }

  setIsAddMemberClicked(isAddMemberClickedArg: boolean, operationalGroupCode: string) {
    const localStorageData = this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
    const clonedLocalStorageData = (localStorageData) ?
      lodashutils.cloneDeep(localStorageData) : this.getDefaultPostableData(operationalGroupCode);
    clonedLocalStorageData.isAddMemberClicked = isAddMemberClickedArg;
    this.localStorageService.setItem('OperationalTeamGroup', 'PostableOperationalGroup', clonedLocalStorageData);
  }

  setIsRemoveMemberClicked(isRemoveMemberClickedArg: boolean, operationalGroupCode: string) {
    const localStorageData = this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
    const clonedLocalStorageData = (localStorageData) ?
      lodashutils.cloneDeep(localStorageData) : this.getDefaultPostableData(operationalGroupCode);
    clonedLocalStorageData.isRemoveMemberClicked = isRemoveMemberClickedArg;
    this.localStorageService.setItem('OperationalTeamGroup', 'PostableOperationalGroup', clonedLocalStorageData);
  }

  getLocalStorageData(operationalGroupCode: string, tabDataMember: string) {
    const localStorageData = this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
    if (localStorageData && localStorageData[tabDataMember]) {
      return localStorageData[tabDataMember];
    }
    return this.getDefaultPostableData(operationalGroupCode)[tabDataMember];
  }

  getLocalStorageDataToPost() {
    return this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
  }

  getDefaultPostableData(operationalCode: string): PostableOperationalGroup {
    return lodashutils.assign(this.postableOperGroupData, {
      operationalGroupCode: operationalCode,
      addingSource: 'Manual',
      isAddMemberClicked: false, isRemoveMemberClicked: false,
      operationalGroupDriverAssignments: [], operationalGroupUnAssignmentPersonIds: [],
      operationalGroupTruckAssignments: [], operationalGroupUnAssignmentTruckEquipmentIds: [],
      operationalGroupTrailingEquipmentAssignments: [], operationalGroupUnAssignmentTrailingEquipmentIds: [],
      operationalGroupCarrierAssignments: [], operationalGroupUnAssignmentCarrierIds: []
    });
  }

  getIsAddMemberClicked(): boolean {
    const localStorageData = this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
    return localStorageData && localStorageData['isAddMemberClicked'];
  }

  getIsRemoveMemberClicked(): boolean {
    const localStorageData = this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
    return localStorageData && localStorageData['isRemoveMemberClicked'];
  }

  getActionReqdError() {
    return {
      'severity': 'error',
      'summary': 'Action Required',
      'detail': 'Please complete the current operation'
    };
  }

  getAssignedMembersCount(localStoreData: PostableOperationalGroup): number {
    return Number(localStoreData.operationalGroupDriverAssignments.length) +
      Number(localStoreData.operationalGroupTruckAssignments.length) +
      Number(localStoreData.operationalGroupTrailingEquipmentAssignments.length) +
      Number(localStoreData.operationalGroupCarrierAssignments.length);
  }

  getUnAssignedMembersCount(localStoreData: PostableOperationalGroup): number {
    return Number(localStoreData.operationalGroupUnAssignmentPersonIds.length) +
      Number(localStoreData.operationalGroupUnAssignmentTruckEquipmentIds.length) +
      Number(localStoreData.operationalGroupUnAssignmentTrailingEquipmentIds.length) +
      Number(localStoreData.operationalGroupUnAssignmentCarrierIds.length);
  }

  checkMaxMembersInOperationalGroup(operatioanlGroupCode: string, existingMembersCount: number): OGMemberValidation {
    const maxMembersInOperationalGroup = this.maxMembersInOperationalGroup;
    const localStorageData = this.localStorageService.getItem('OperationalTeamGroup', 'PostableOperationalGroup');
    const clonedLocalStorageData = (localStorageData) ?
      lodashutils.cloneDeep(localStorageData) : this.getDefaultPostableData(operatioanlGroupCode);
    const ogMemberCount = this.getAssignedMembersCount(clonedLocalStorageData);
    const ogMaxMemberErr = `You cannot manually add more than ${maxMembersInOperationalGroup} resources at once. ` +
      `Please save before continuing to add.`;
    return {
      isMemberExistsOverLimit: ((ogMemberCount + 1) > maxMembersInOperationalGroup),
      memberExistsToastMsg: { 'severity': 'error', 'summary': 'Error', 'detail': ogMaxMemberErr }
    };
  }

  clearAllLocalStorageData() {
    this.localStorageService.setItem('OperationalTeamGroup', 'PostableOperationalGroup', null);
  }

  getMemberValidationResponse(validationError: MemberValidationError): MemberValidationCustomOutput {
    const memberValidationOutput = {
      isOverridedValidation: null, validationMsgType: null,
      validationMsgCode: null, memberValidationMsgs: [], validationMsgTitle: null
    };
    if (validationError && validationError.errors && validationError.errors.length !== 0) {
      const validationErrorMsg = validationError.errors[0];
      memberValidationOutput.isOverridedValidation = (validationErrorMsg.errorSeverity.toUpperCase() !== 'ERROR');
      memberValidationOutput.validationMsgCode = validationErrorMsg.code;
      memberValidationOutput.validationMsgType = validationErrorMsg.errorType;
      memberValidationOutput.validationMsgTitle = this.operationalTeamModel.validationErrMsgTitle[validationErrorMsg.code] || '';
      from(validationError.errors).pipe(map((errResponse: ErrorMsg) => errResponse.errorMessage))
        .subscribe(errMsg => memberValidationOutput.memberValidationMsgs.push(errMsg));
    }
    return memberValidationOutput;
  }
  hasAccess(operation: string): boolean {
    const userDetails = this.userService.getDetails();
    let ogUserRecord = [];
    const ogMemberUserSecurityConfig = { accessUrl: this.appConfigURL, adminAccessLevel: 3 };
    if (userDetails && userDetails.urlAccessList) {
      ogUserRecord = lodashutils.filter(userDetails.urlAccessList, function (accessInfo: any) {
        return accessInfo.uri === ogMemberUserSecurityConfig.accessUrl;
      });
    }
    if (ogUserRecord && ogUserRecord.length > 0) {
      return this.userService.hasAccess(ogMemberUserSecurityConfig.accessUrl, operation) &&
        ogUserRecord[0].accessLevel !== ogMemberUserSecurityConfig.adminAccessLevel;
    }
    return false;
  }
  hasESAAccess(operation: string): boolean {
    return this.userService.hasAccess(this.appConfigURL, operation);
  }
}
