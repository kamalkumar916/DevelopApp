import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { UserService } from '../../../../shared/jbh-esa/index';
import { OperationalTeamUtilityService } from './operational-team-utility.service';
import { configureTestSuite } from 'ng-bullet';

describe('OperationalTeamUtilityService', () => {
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [OperationalTeamUtilityService, AppConfigService, LocalStorageService, UserService]
    });
  });

  it('should be created', inject([OperationalTeamUtilityService], (service: OperationalTeamUtilityService) => {
    expect(service).toBeTruthy();
  }));
});
