export class TeamListQuery {
    static readonly utilization = 'UtilizationStatus.UtilizationStatusDescription';
    static getOperationalTeamListQuery(startArg: number, sizeArg: number) {
        return {
            from: startArg,
            size: sizeArg,
            _source: [
                'OperationalGroupCode',
                'OperationalGroupDescription',
                'OperationalGroupTypeCode',
                'OperationalGroupTypeDescription',
                'OperationalGroupSubtypeCode',
                'OperationalGroupSubtypeDescription',
                'FinanceBusinessUnitCode',
                'UtilizationStatus.UtilizationStatusCode',
                this.utilization,
                'LastUpdateProgramName',
                'LastUpdateUserID',
                'LastUpdateTimestamp',
                'Status'
            ]
        };
    }
    static getSortableQuery(sortableMember: string, sortableEvent: any) {
        if (sortableMember === `${this.utilization}.keyword`) {
            return {
                'sort': [

                    {
                        [`${this.utilization}.keyword`]: {
                            'order': (sortableEvent.sortOrder === -1) ? 'desc' : 'asc',
                            'nested_path': 'UtilizationStatus'
                        }
                    }
                ]
            };
        } else if (sortableMember === 'OperationalGroupDescription.keyword') {
            return {
                'sort': [
                    {
                        '_script': {
                            'script': 'doc[\'OperationalGroupDescription.keyword\'].value.toLowerCase()',
                            'type': 'string',
                            'order': (sortableEvent.sortOrder === -1) ? 'desc' : 'asc'
                        }
                    }
                ]
            };
        }
        return {
            'sort': [{ [sortableMember]: (sortableEvent.sortOrder === -1) ? 'desc' : 'asc' }]
        };
    }
    static getSearchTxtQuery(searchTxt: string) {
        return {
            query: {
                query_string: {
                    fields: [
                        'OperationalGroupCode',
                        'OperationalGroupDescription',
                        'OperationalGroupTypeDescription',
                        'OperationalGroupSubtypeDescription',
                        'FinanceBusinessUnitCode',
                        this.utilization,
                        'LastUpdateProgramName',
                        'LastUpdateUserID',
                        'LastUpdateTimestamp.text',
                        'Status'
                    ],
                    query: `*${searchTxt}*`,
                    default_operator: 'AND'
                }
            },
        };
    }
    static getSearchAndFilterQuery(searchTxt: string, filterParam: object): object {
        return {
            'query': {
                'bool': {
                    'must': [
                        {
                            'bool': {
                                'should': [
                                    {
                                        'query_string': {
                                            'fields': [
                                                'OperationalGroupDescription',
                                                'OperationalGroupCode',
                                                'OperationalGroupTypeDescription',
                                                'OperationalGroupSubtypeDescription',
                                                'FinanceBusinessUnitCode',
                                                this.utilization,
                                                'LastUpdateTimestamp.text',
                                                'LastUpdateProgramName',
                                                'LastUpdateUserID',
                                                'Status'
                                            ],
                                            'query': `*${searchTxt}*`,
                                            'default_operator': 'AND'
                                        }
                                    },
                                    {
                                        'nested': {
                                            'path': 'UtilizationStatus',
                                            'query': {
                                                'query_string': {
                                                    'default_field': this.utilization,
                                                    'query': `*${searchTxt}*`,
                                                    'default_operator': 'AND'
                                                }
                                            }
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            'bool': {
                                'must': [
                                    {
                                        'bool': {
                                            'should': [
                                                {
                                                    'query_string': {
                                                        'default_field': 'OperationalGroupTypeDescription',
                                                        'query': `${filterParam['selectedCategoryEmpty']}`
                                                    }
                                                },
                                                {
                                                    'terms': {
                                                        'OperationalGroupTypeDescription.keyword': filterParam['selectedCategory']
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    {
                                        'bool': {
                                            'should': this.getOGSubType(filterParam)
                                        }
                                    },
                                    {
                                        'bool': {
                                            'should': [
                                                {
                                                    'query_string': {
                                                        'default_field': 'FinanceBusinessUnitCode',
                                                        'query': `${filterParam['selectedBUEmpty']}`
                                                    }
                                                },
                                                {
                                                    'terms': {
                                                        'FinanceBusinessUnitCode.keyword': filterParam['selectedBU']
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    {
                                        'bool': {
                                            'should': [
                                                {
                                                    'query_string': {
                                                        'default_field': 'Status',
                                                        'query': `${filterParam['selectedStatusEmpty']}`
                                                    }
                                                },
                                                {
                                                    'terms': {
                                                        'Status.keyword': filterParam['selectedStatus']
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    {
                                        'bool': {
                                            'should': this.getUtilizationStatus(filterParam)
                                        }
                                    },
                                    {
                                        'range': {
                                            'LastUpdateTimestamp': this.onLastUpdateValue(filterParam)
                                        }
                                    },
                                    {
                                        'bool': {
                                            'must': [
                                                {
                                                    'bool': {
                                                        'should': [
                                                            {
                                                                'query_string': {
                                                                    'default_field': 'LastUpdateProgramName',
                                                                    'query': `${filterParam['selectedLastUpdatedByEmpty']}`
                                                                }
                                                            },
                                                            {
                                                                'terms': {
                                                                    'LastUpdateProgramName.keyword': filterParam['selectedLastUpdatedBy']
                                                                }
                                                            },
                                                            {
                                                                'query_string': {
                                                                    'default_field': 'LastUpdateUserID',
                                                                    'query': `${filterParam['selectedLastUpdatedByUserIdEmpty']}`
                                                                }
                                                            },
                                                            {
                                                                'terms': {
                                                                    'LastUpdateUserID.keyword': filterParam['selectedLastUpdatedByUserId']
                                                                }
                                                            }
                                                        ]
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                }
            },
        };
    }
    static getOGSubType(filterParam) {
        if (filterParam.selectedType && filterParam.selectedType.length !== 0) {
            return [
                {
                    'query_string': {
                        'default_field': 'OperationalGroupSubtypeDescription',
                        'query': `${filterParam['selectedTypeEmpty']}`
                    }
                },
                {
                    'terms': {
                        'OperationalGroupSubtypeDescription.keyword': filterParam['selectedType']
                    }
                }
            ];
        }
        return [];
    }
    static getUtilizationStatus(filterParam) {
        if (filterParam.selectedUtilizationStatus && filterParam.selectedUtilizationStatus.length !== 0) {
            return [
                {
                    'nested': {
                        'path': 'UtilizationStatus',
                        'query': {
                            'query_string': {
                                'default_field': this.utilization,
                                'query': `${filterParam['selectedUtilizationStatusEmpty']}`
                            }
                        }
                    }
                },
                {
                    'nested': {
                        'path': 'UtilizationStatus',
                        'query': {
                            'terms': {
                                [`${this.utilization}.keyword`]:
                                    filterParam['selectedUtilizationStatus']
                            }
                        }
                    }
                }
            ];
        }
        return [];
    }
    static onLastUpdateValue(filterParam): object {
        if (filterParam && filterParam['lastUpdated']) {
            return {
                'gte': filterParam['lastUpdated']['startTime'],
                'lte': filterParam['lastUpdated']['endTime']
            };
        } else {
            return {};
        }
    }
}
