import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { TrailingDetailsComponent } from './trailing-details.component';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfigService } from '../../../../../../shared/service/app-config.service';

import { LocalStorageService } from '../../../../../../shared/jbh-app-services/local-storage.service';
import { UserService } from '../../../../../../shared/jbh-esa/index';
import { TableModule } from 'primeng/table';
import { CheckboxModule, PaginatorModule, AutoCompleteModule, DialogModule } from 'primeng/primeng';
import { TrailingDetailsService } from './services/trailing-details.service';
import { TrailingDetailsUtilityService } from './services/trailing-details-utility.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OperationalTeamUtilityService } from '../../../services/operational-team-utility.service';
import { PipesModule } from '../../../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from '../../../../../../shared/directives/directives.module';
import { FormBuilder, FormGroup } from '@angular/forms';
import { throwError } from 'rxjs/internal/observable/throwError';

describe('TrailingDetailsComponent', () => {
  let component: TrailingDetailsComponent;
  let fixture: ComponentFixture<TrailingDetailsComponent>;
  let service: TrailingDetailsService;
  let messageService: MessageService;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [TrailingDetailsComponent],
      imports: [RouterTestingModule, TableModule, FormsModule, ReactiveFormsModule, CheckboxModule, PaginatorModule,
        AutoCompleteModule, DialogModule, HttpClientTestingModule, NoopAnimationsModule, PipesModule,
        JbhLoaderModule, DirectivesModule],
      providers: [MessageService, AppConfigService,
        TrailingDetailsService, TrailingDetailsUtilityService, OperationalTeamUtilityService, LocalStorageService, UserService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrailingDetailsComponent);
    component = fixture.componentInstance;
    service = TestBed.get(TrailingDetailsService);
    messageService = TestBed.get(MessageService);
    fixture.detectChanges();
    formGroup = formBuilder.group({});
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('resetTrailerListFields have been called', () => {
    component.resetTrailerListFields();
    expect(component.trailingDetailsModel.totalMembersForScrollValidation).toBe(0);
    expect(component.trailingDetailsModel.isScrollServiceHappend).toBe(false);
    expect(component.trailingDetailsModel.recordFrom).toBe(0);
    expect(component.trailingDetailsModel.recordDefaultSize).toBe(100);
  });
  it('resetAddedTrailerDataTable have been called', () => {
    component.resetAddedTrailerDataTable();
    expect(component.trailingDetailsModel.isAddTemporaryTableVisible).toBe(true);
  });
  it('resetTrailingDetailsView have been called', () => {
    spyOn(component, 'resetTrailingDetailsView');
    spyOn(component, 'setCheckedForTrailingCheckboxes');
    component.onRemoveTrailingEquipmentCancelBtnClicked();
    expect(component.resetTrailingDetailsView).toHaveBeenCalled();
    expect(component.setCheckedForTrailingCheckboxes).toHaveBeenCalledWith(false);
  });
  it('operationalGroupCode have been set', () => {
    component.operationalGroupCode = 'Test';
    expect(component.trailingDetailsModel.storableDataModel).toEqual([]);
    expect(component.trailingDetailsModel.isOperationalGroupChanged).toEqual(undefined);
  });
  it('newOperationalTeamToAdd have been set', () => {
    component.newOperationalTeamToAdd = true;
    expect(component.trailingDetailsModel.isNewOperationalGroup).toBeTruthy();
  });
  it('operationalGroupData have been set', () => {
    const demo = {
      operationalGroupCode: 'string',
      operationalGroupDescription: 'string',
      operationalGroupTypeCode: 'string',
      operationalGroupTypeDescription: 'string',
      operationalGroupSubTypeCode: 'string',
      operationalGroupSubTypeDescription: 'string',
      businessUnit: 'string',
      utilizationStatus: [{
        utilizationStatusCode: 'string',
        utilizationStatusDescription: 'string',
      }],
      lastUpdated: 'string',
      lastUpdatedBy: 'string',
      totalMembers: 5,
      status: 'string',
      profilePic: 'string',
      profilePicture: 'string',
      utilizationStatusDescList: 'string',
      lastUpdatedDateValue: 'string',
      userProfileImg: 'string',
      userImgNameData: 'string',
      financeBusinessUnitCode: 'string',
    };
    component.operationalGroupData = demo;
    expect(component.trailingDetailsModel.operationalGroupData).toBeTruthy();
  });
  it('operationalGroupForm have been set', () => {
    component.operationalGroupForm = formGroup;
    expect(component.trailingDetailsModel.operationalGroupForm).toBeTruthy();
  });
  it('parentTabChangeDetection have been called', () => {
    spyOn(component, 'resetTrailerListFields');
    const event = {
      originalEvent: {
        isTrusted: true,
      },
      index: 3,
      isOperationalGroupChanged: true,
    };
    component.parentTabChangeDetection = event.index;
    component.parentTabChangeDetection = event;
    expect(component.resetTrailerListFields).toHaveBeenCalled();
  });
  it('profileView have been set', () => {
    component.profileView = true;
    expect(component.trailingDetailsModel.isProfileView).toBeTruthy();
  });
  it('showTrucklist throwing Error', () => {
    spyOn(service, 'getTrailingDetails').and.returnValue(throwError({}));
    component.showTrucklist({});
    expect(component.trailingDetailsModel.trailingData).toEqual([]);
    expect(component.trailingDetailsModel.isLoading).toEqual(false);
  });
  it('initActionReqdErrorOnRemove have been set', () => {
    spyOn(messageService, 'clear');
    spyOn(messageService, 'add');
    component.initActionReqdErrorOnRemove();
    expect(messageService.clear).toHaveBeenCalled();
  });
  it('onClearTrailingEquipmentCode have been set', () => {
    component.onClearTrailingEquipmentCode();
    expect(component.trailingDetailsModel.defaultEquipmentType).toEqual('');
  });
  it('getValidationErrorResponse have been called', () => {
    const operationalTeamUtilityService = TestBed.get(OperationalTeamUtilityService);
    const trailingDetailsUtilityService = TestBed.get(TrailingDetailsUtilityService);
    spyOn(operationalTeamUtilityService, 'getMemberValidationResponse');
    spyOn(trailingDetailsUtilityService, 'executeMemberValidation');
    const response = {
      'traceid': 'f6ee1af2826b0936',
      'status': 400,
      'errors': [
        {
          'fieldErrorFlag': false,
          'errorMessage': 'The action cannot be performed. Please refresh the page and try again.',
          'errorType': 'Business Validation Error',
          'fieldName': null,
          'code': 'EX_TYPE_ALREADY_ACTIVATED',
          'errorSeverity': 'ERROR'
        }
      ]
    };
    component.getValidationErrorResponse(response);
    expect(operationalTeamUtilityService.getMemberValidationResponse).toHaveBeenCalled();
    expect(trailingDetailsUtilityService.executeMemberValidation).toHaveBeenCalled();
  });
  it('searchInputListener have been called', () => {
    const trailingDetailsUtilityService = TestBed.get(TrailingDetailsUtilityService);
    spyOn(trailingDetailsUtilityService, 'searchInputListener');
    component.searchInputListener();
    expect(trailingDetailsUtilityService.searchInputListener).toHaveBeenCalled();
  });
  it('onGridLazyLoad have been called', () => {
    const event = {
      filters: {},
      first: 1,
      globalFilter: ' ',
      multiSortMeta: ' ',
      rows: 1,
      sortField: 'string',
      sortOrder: 1
    };
    const trailingDetailsUtilityService = TestBed.get(TrailingDetailsUtilityService);
    spyOn(trailingDetailsUtilityService, 'onGridLazyLoad');
    component.onGridLazyLoad(event);
    expect(trailingDetailsUtilityService.onGridLazyLoad).toHaveBeenCalled();
  });
  it('removeTrailingFromTheTable have been called', () => {
    const res: number[] = [];
    const trailingDetailsUtilityService = TestBed.get(TrailingDetailsUtilityService);
    spyOn(trailingDetailsUtilityService, 'removeEquipmentsFromTable');
    spyOn(component, 'onRemoveTrailingEquipmentCancelBtnClicked');
    component.removeTrailingFromTheTable(res);
    expect(component.onRemoveTrailingEquipmentCancelBtnClicked).toHaveBeenCalled();
    expect(trailingDetailsUtilityService.removeEquipmentsFromTable).toHaveBeenCalled();
  });
  it('onCancelBtnClicked have been called', () => {
    const operationalTeamUtilityService = TestBed.get(OperationalTeamUtilityService);
    spyOn(operationalTeamUtilityService, 'setIsAddMemberClicked');
    spyOn(component, 'getOperationalGroupCode');
    spyOn(component, 'resetAddedTrailerDataTable');
    component.onCancelBtnClicked();
    expect(operationalTeamUtilityService.setIsAddMemberClicked).toHaveBeenCalled();
    expect(component.getOperationalGroupCode).toHaveBeenCalled();
    expect(component.resetAddedTrailerDataTable).toHaveBeenCalled();
  });
  it('onUpdateTrailingDataIntoTable have been called', () => {
    const overRideEquipment = 'abc';
    const trailingDetailsUtilityService = TestBed.get(TrailingDetailsUtilityService);
    spyOn(trailingDetailsUtilityService, 'updateTrailingDataIntoLocalstore');
    component.onUpdateTrailingDataIntoTable(overRideEquipment);
    expect(trailingDetailsUtilityService.updateTrailingDataIntoLocalstore).toHaveBeenCalled();
    expect(component.trailingDetailsModel.overRideTrailingEquipment).toEqual(overRideEquipment);
  });
  it('scrollInfoOnDetails have been set', () => {
    spyOn(component, 'infiniteScrollImplementation');
    const demo = JSON.stringify({ scrollTop: 2, currentTabSelectionIdx: 2, isMemberServiceNeedsToCall: false });
    component.scrollInfoOnDetails = demo;
    expect(component.trailingDetailsModel.teamDetailsScrollInformation).toBeTruthy();
    expect(component.infiniteScrollImplementation).toBeTruthy();
  });
  it('onConfirmYesClicked have been called', () => {
    spyOn(component, 'onUpdateTrailingDataIntoTable');
    component.onConfirmYesClicked();
    expect(component.onUpdateTrailingDataIntoTable).toHaveBeenCalled();
  });
  it('infiniteScrollImplementation have been called - if block executed', () => {
    spyOn(component, 'callTrailingEquipmentListService');
    component.trailingDetailsModel.recordFrom = 0;
    component.trailingDetailsModel.recordDefaultSize = 25;
    component.trailingDetailsModel.totalMembersForScrollValidation = 40;
    component.trailingDetailsModel.teamDetailsScrollInformation = {
      scrollTop: 1, currentTabSelectionIdx: 3, isMemberServiceNeedsToCall: true
    };
    component.trailingDetailsModel.isTrailingEquipmentListPopulated = true;
    component.infiniteScrollImplementation();
    expect(component.trailingDetailsModel.isScrollServiceHappend).toBe(true);
    expect(component.trailingDetailsModel.recordFrom).toBe(25);
    expect(component.callTrailingEquipmentListService).toHaveBeenCalled();
  });
  it('infiniteScrollImplementation have been called - else block executed', () => {
    spyOn(component, 'callTrailingEquipmentListService');
    component.trailingDetailsModel.recordFrom = 0;
    component.trailingDetailsModel.recordDefaultSize = 25;
    component.trailingDetailsModel.totalMembersForScrollValidation = 40;
    component.trailingDetailsModel.teamDetailsScrollInformation = {
      scrollTop: 1, currentTabSelectionIdx: 3, isMemberServiceNeedsToCall: false
    };
    component.trailingDetailsModel.isTrailingEquipmentListPopulated = true;
    component.infiniteScrollImplementation();
    expect(component.trailingDetailsModel.isScrollServiceHappend).toBe(false);
    expect(component.trailingDetailsModel.recordFrom).toEqual(0);
  });
  it('resetTrailingDetailsView have been called', () => {
    component.resetTrailingDetailsView();
    expect(component.trailingDetailsModel.isSaveCancelBtnsVisible).toEqual(false);
    expect(component.trailingDetailsModel.isRemoveCancelBtnsVisible).toEqual(false);
  });
});
