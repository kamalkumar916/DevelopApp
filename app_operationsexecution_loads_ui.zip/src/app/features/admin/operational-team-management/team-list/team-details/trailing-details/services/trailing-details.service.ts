import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { TrailingDetailsQuery } from '../query/trailing-details.query';
import { MemberValidationResponse } from './../../model/team-details.interface';
import { MemberValidationInput } from '../../../../model/operational-team.interface';

@Injectable()
export class TrailingDetailsService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }

  getTrailingDetails(trailingQuery: TrailingDetailsQuery): Observable<any> {
    return this.http.post(this.endpoint.getTeamList, trailingQuery);
  }

  getTrailEquipmentOnTypeahead(typeaheadQuery: any): Observable<any> {
    return this.http.post(this.endpoint.getTruckList, typeaheadQuery);
  }

  getAddTrailerBusinessValidation(operGroupCode: string, groupType: string, memeberId: string): Observable<MemberValidationResponse> {
    return this.http.get<MemberValidationResponse>(`${this.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=trailingequipment&memberIds=${memeberId}&type=${groupType}&action=add`);
  }

  getRemoveTrailerBusinessValidation(operGroupCode: string, groupType: string, memeberId: string): Observable<MemberValidationResponse> {
    return this.http.get<MemberValidationResponse>(`${this.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=trailingequipment&memberIds=${memeberId}&type=${groupType}&action=remove`);
  }
  postMemberBusinessValidation(operGrpCode: string, memberRequest: MemberValidationInput): Observable<any> {
    const encodedGroupCode = encodeURIComponent(operGrpCode);
    return this.http.post<any>(
      `${this.endpoint.postOGMemberAdhocValidations}/trailingequipments/validations?operationalGroupCode=${encodedGroupCode}`,
      memberRequest);
  }
}
