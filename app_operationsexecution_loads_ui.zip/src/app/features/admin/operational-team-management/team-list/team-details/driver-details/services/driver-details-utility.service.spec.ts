import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { configureTestSuite } from 'ng-bullet';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { DriverDetailsUtilityService } from './driver-details-utility.service';
import { DriverSortSearchService } from './driver-sort-search.service';


describe('DriverDetailsUtilityService', () => {
  let service: DriverDetailsUtilityService;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [DriverDetailsUtilityService, AppConfigService, FormBuilder, DriverSortSearchService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(DriverDetailsUtilityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getDriverName should return expected value', () => {
    const returnValue = service.getDriverName('john', 'doe', 'michael');
    expect(returnValue).toBe('john doe');
  });
});
