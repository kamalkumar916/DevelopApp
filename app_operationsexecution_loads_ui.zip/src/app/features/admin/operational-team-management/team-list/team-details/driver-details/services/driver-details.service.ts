import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';

import { AppConfigService } from '../../../../../../../shared/service/app-config.service';

import { ElasticResponseModel } from '../../../../../../model/elastic-response.interface';
import { MemberValidationResponse } from './../../model/team-details.interface';
import { DriverImageResponse } from './../model/driver-details.interface';
import { MemberValidationInput } from '../../../../model/operational-team.interface';


@Injectable()
export class DriverDetailsService {

  endpoint: any;
  employeeProfileIndexEndPoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = this.appConfigService.getApi('admin');
    this.employeeProfileIndexEndPoint = this.appConfigService.getApi('operationalPlan');
  }

  getDriverListDataForOperGroup(query): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getTeamList, query);
  }

  getDriverOnTypeahead(query): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.employeeProfileIndexEndPoint.getDriverDetails, query);
  }

  getDriverImages(userIds: string): Observable<DriverImageResponse[]> {
    return this.http.get<DriverImageResponse[]>(`${this.endpoint.getUserImages}/${userIds}/AD_USERID,THUMBNAIL_PHOTO`);
  }

  getAddDriverBusinessValidation(operGroupCode: string, groupType: string, memeberId: string): Observable<MemberValidationResponse> {
    return this.http.get<MemberValidationResponse>(`${this.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=driver&memberIds=${memeberId}&type=${groupType}&action=add`);
  }

  getRemoveDriverBusinessValidation(operGroupCode: string, groupType: string, memeberId: string): Observable<MemberValidationResponse> {
    return this.http.get<MemberValidationResponse>(`${this.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=driver&memberIds=${memeberId}&type=${groupType}&action=remove`);
  }

  postMemberBusinessValidation(operGrpCode: string, memberRequest: MemberValidationInput): Observable<any> {
    const encodedGroupCode = encodeURIComponent(operGrpCode);
    return this.http.post<any>
      (`${this.endpoint.postOGMemberAdhocValidations}/drivers/validations?operationalGroupCode=${encodedGroupCode}`, memberRequest);
  }

}
