import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DriverSortSearchService } from './driver-sort-search.service';

describe('DriverSortSearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [DriverSortSearchService, AppConfigService]
    });
  });

  it('should be created', inject([DriverSortSearchService], (service: DriverSortSearchService) => {
    expect(service).toBeTruthy();
  }));
});
