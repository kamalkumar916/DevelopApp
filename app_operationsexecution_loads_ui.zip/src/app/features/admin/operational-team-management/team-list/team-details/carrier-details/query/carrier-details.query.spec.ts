import { CarrierDetailsQuery } from './carrier-details.query';

describe('CarrierDetailsQuery', () => {
    it('getCarrierQuery have been called with Search Type Text', () => {
        const result = CarrierDetailsQuery.getCarrierQuery('text');
        expect(result).toBeTruthy();
    });
    it('getCarrierNameQuery have been called with filter variables', () => {
        const result = CarrierDetailsQuery.getCarrierNameQuery({});
        expect(result).toBeTruthy();
    });
    it('getCarrierListElasticQuery have been called', () => {
        const param = {
            memberStartFrom: 25,
            sortableMember: 'name',
            sortableEvent: {},
            searchType: 'string',
            expirationTimestamp: 'string',
            searchTxt: 'string'
        };
        const result = CarrierDetailsQuery.getCarrierListElasticQuery('DCS', 25, 50, param);
        expect(result).toBeTruthy();
    });
    it('getCarrierListElasticQuery have been called with sort order desc', () => {
        const param = {
            memberStartFrom: 25,
            sortableMember: 'name',
            sortableEvent: { sortOrder: -1 },
            searchType: 'string',
            expirationTimestamp: 'string',
            searchTxt: 'string'
        };
        const result = CarrierDetailsQuery.getCarrierListElasticQuery('DCS', 25, 50, param);
        expect(result).toBeTruthy();
    });
    it('getCarrierListSearchQuery have been called with Search Type Text', () => {
        const result = CarrierDetailsQuery.getCarrierListSearchQuery('');
        expect(result).toBeTruthy();
    });
});
