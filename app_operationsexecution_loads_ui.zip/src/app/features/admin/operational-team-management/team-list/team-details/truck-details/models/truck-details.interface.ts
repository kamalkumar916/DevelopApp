export interface TruckDetailsQuery {
    from: number;
    size: number;
}
export interface FilterVariables {
    from: number;
    size: number;
    searchValue: string;
    assetStatus: string;
}
export interface FilterGroupVariables {
    from: number;
    size: number;
    assetStatus: string;
    operationalGroupCode: string;
}

export interface TruckOverViewDetails {
    AssetUnitPrefixAndID: string;
    AssetStatus: string;
    AssetClassificationCode: string;
    AssetID: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
}
export interface OperationalGroupSelectedEquipment {
    AssetUnitPrefixAndID: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    formattedEndDate?: string;
    AssetID: string;

}
export interface OriginalEvent {
    isTrusted: boolean;
}

export interface TabChangeEvent {
    originalEvent: OriginalEvent;
    index: number;
}

export interface TruckDataModel {
    assetUnitId: string;
    assetClassCode: string;
    assetId: string;
}
export interface PageView {
    first: number;
    rows: number;
}
export interface RemoveRequest {
    memberType: string;
    memberIds: number;
    type: string;
}

export interface ErrorToastMessage {
    severity: string;
    summary: string;
    detail: string;
}

export interface RemoveResponse {
    operationalGroupCode: string;
    memberType: string;
    memberIds: number;
    inCurrentOperationalGroup?: string;
    duplicateMemberAssignmentId: number[];
    pairedMemberAssignmentId?: number;
}
export interface TruckList {
    operationalGroupEquipmentAssignmentId: number;
    equipmentId: string;
    assetUnitId: string;
    equimentClassificationCode: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
}
export interface TruckStorableData {
    equipmentID: number;
    equipmentUnitId: string;
    equipmentClassificationCode: string;
}
