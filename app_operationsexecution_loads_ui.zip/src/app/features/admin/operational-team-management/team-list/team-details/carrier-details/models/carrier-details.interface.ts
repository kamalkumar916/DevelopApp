export interface CarierOverViewList {
    CarrierID: string;
    CarrierName: string;
    SCAC: string;
    CarrierCode: string;
    CarrierStatus: string;
}
export interface OperationalGroupSelectedEquipment {
    CarrierID: string;
    CarrierName: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    formattedEndDate?: string;
    CarrierCode: string;
}

export interface CarrierList {
    _index: string;
    _type: string;
    _id: string;
    _score: number;
    _source: CarierOverViewList;
}
export interface FilterGroupVariables {
    from: number;
    size: number;
    operationalGroup: string;
    carrierStatus: string;
}
export interface FilterVariables {
    from: number;
    size: number;
    searchValue?: string;
}

export interface OriginalEvent {
    isTrusted: boolean;
}

export interface TabChangeEvent {
    originalEvent: OriginalEvent;
    index: number;
}
export interface CarrierDataModel {
    carrierName: string;
    carrierCode: string;
    carrierId: string;
}
export interface SetDefaultColumns {
    property: string;
    name: string;
    isVisible: boolean;
}
export interface PageView {
    first: number;
    rows: number;
}
export interface CarrierListData {
    operationalGroupCarrierAssignmentId?: number;
    carrierName: string;
    carrierCode: string;
    carrierId?: number;
    carrierID?: number;
    effectiveTimestamp?: string;
}
