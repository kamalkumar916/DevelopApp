import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Injectable } from '@angular/core';
import * as lodashutils from 'lodash';
import { DateUtils } from '../../../../../../../shared/jbh-app-services/date-utils';
import { OperationalGroupCarrierAssignment, MemberValidationCustomOutput } from './../../../../model/operational-team.interface';
import { CarrierListData } from './../models/carrier-details.interface';
import {
  MemberValidationResponse, DuplicateAndPairedMemberData, LocalStoreDuplicateMemberData
} from './../../model/team-details.interface';

@Injectable()
export class CarrierDetailsUtilityService {

  constructor(private readonly formBuilder: FormBuilder) { }

  getNewlyAddedRecordForCarrierData(carName: string) {
    return { CarrierName: carName };
  }

  getStorableData(parent: any, carrierData: CarrierListData): OperationalGroupCarrierAssignment {
    return {
      'carrierId': Number(carrierData.carrierId),
      'carrierName': carrierData.carrierName.trim(),
      'carrierCode': carrierData.carrierCode.trim()
    };
  }

  getStorableRemovedData(carrierData: CarrierListData): number {
    return Number(carrierData.carrierId);
  }

  getDateTimeFormat(date: string, time: string) {
    return DateUtils.dateTimeFormat(date, time);
  }

  setInCurrentOGToastMsg(parent: any, errorTitle: string, errorMsg: string) {
    parent.messageService.clear();
    parent.messageService.add({ 'severity': 'error', 'summary': errorTitle, 'detail': errorMsg });
  }

  isAddedCarrierDuplicated(parent: any, carrierID: number): LocalStoreDuplicateMemberData {
    const unAssignedCarriers = parent.utilityServices.getLocalStorageData(parent.getOperationalGroupCode(),
      'operationalGroupUnAssignmentCarrierIds');
    const duplicatedMemberData = { isAddedInLocalStore: false, isRemovedInLocalStore: false };
    const duplicatecarrierrArray = lodashutils.filter(parent.carrierDetailsModel.storableDataModel,
      (carrierData: OperationalGroupCarrierAssignment) => (Number(carrierData.carrierId) === carrierID));
    duplicatedMemberData.isRemovedInLocalStore = lodashutils.filter(unAssignedCarriers,
      (unAssignedCarrierId: number) => (Number(carrierID) === Number(unAssignedCarrierId))).length !== 0;
    if (duplicatecarrierrArray && duplicatecarrierrArray.length !== 0) {
      duplicatedMemberData.isAddedInLocalStore = true;
      if (duplicatedMemberData.isRemovedInLocalStore) {
        duplicatedMemberData.isAddedInLocalStore = duplicatecarrierrArray.length > 1;
      }
      if (duplicatedMemberData.isAddedInLocalStore) {
        const selectedCarrier = parent.carrierDetailsModel.carrierSelectedData;
        const carriereTitle = `${selectedCarrier.carrierName.trim()} (${selectedCarrier.carrierCode.trim()})`;
        const operGroupDesc = parent.carrierDetailsModel.operationalGroupForm.controls['operationalGroupName'].value;
        this.setInCurrentOGToastMsg(parent, 'Member already selected',
          `${carriereTitle} has already been added to ${operGroupDesc} (${parent.getOperationalGroupCode()})`);
      }
    }
    return duplicatedMemberData;
  }

  setCarrierCheckBoxFormControl(scope: any) {
    lodashutils.forEach(scope.carrierDetailsModel.carrierData, (CarrierData) => {
      this.pushCheckBoxIntoControlsArray(scope);
    });
  }

  pushCheckBoxIntoControlsArray(scope: any) {
    const tempCarrierCheckBoxControl = scope.carrierDetailsModel.carrierDetailsForm.controls.tempCarrierCheckBoxes;
    if (tempCarrierCheckBoxControl && tempCarrierCheckBoxControl.controls) {
      tempCarrierCheckBoxControl.push(this.getFormGroupForTempCarrier());
    }
    scope.carrierDetailsModel.tempCarrierFormCheckBoxArray = lodashutils.map(tempCarrierCheckBoxControl.controls, 'controls');
  }

  getFormGroupForTempCarrier(): FormGroup {
    return this.formBuilder.group({ 'tempCarrierCheckBox': [false] });
  }

  setRemovedCarrierData(parent: any, isChecked: boolean, rowData: CarrierListData) {
    if (isChecked) {
      parent.carrierDetailsModel.removeListData.push(rowData);
    } else {
      const removedDataIdx = lodashutils.findIndex(parent.carrierDetailsModel.removeListData,
        { 'carrierCode': rowData.carrierCode });
      if (removedDataIdx !== -1) {
        parent.carrierDetailsModel.removeListData.splice(removedDataIdx, 1);
      }
    }
  }

  removeCarrierFromTable(parent: any, removedCarriers: number[]) {
    const carrierData = lodashutils.cloneDeep(parent.carrierDetailsModel.carrierData);
    const checkBoxCtrls = parent.carrierDetailsModel.carrierDetailsForm.controls.tempCarrierCheckBoxes;
    lodashutils.remove(carrierData, (eachCarrier, idx: number) => {
      const isRemovedMember = removedCarriers.filter(carrierId => (eachCarrier.carrierId === carrierId)).length !== 0;
      if (isRemovedMember) {
        checkBoxCtrls.controls.splice(idx, 1);
      }
      return isRemovedMember;
    });
    if (checkBoxCtrls && checkBoxCtrls.controls && checkBoxCtrls.controls.length !== 0) {
      const checkBoxCtrlsLength = checkBoxCtrls.controls.length;
      for (let idx = 0; idx < checkBoxCtrlsLength; idx++) {
        checkBoxCtrls.controls[idx].controls.tempCarrierCheckBox.setValue(false);
      }
    }
    parent.carrierDetailsModel.tempCarrierFormCheckBoxArray = lodashutils.map(checkBoxCtrls.controls, 'controls');
    parent.carrierDetailsModel.carrierData = carrierData;
    this.setRemovedDataInLocalStore(parent);
    parent.onValidateCheckBox();
    parent.changeDetector.detectChanges();
  }

  setRemovedDataInLocalStore(parent: any) {
    const unAssignedCarriers = parent.utilityServices.getLocalStorageData(parent.getOperationalGroupCode(),
      'operationalGroupUnAssignmentCarrierIds');
    lodashutils.forEach(parent.carrierDetailsModel.removeListData, (removedCarrier) => {
      const isCarrierInEs = lodashutils.filter(parent.carrierDetailsModel.storableCarrierListData,
        (carrierDetails: CarrierListData) => (carrierDetails.carrierId === removedCarrier.carrierId)).length !== 0;
      if (isCarrierInEs) {
        unAssignedCarriers.push(Number(removedCarrier.carrierId));
      } else {
        const storableDataIdx =
          lodashutils.findIndex(parent.carrierDetailsModel.storableDataModel, { 'carrierId': removedCarrier.carrierId });
        if (storableDataIdx !== -1) {
          parent.carrierDetailsModel.storableDataModel.splice(storableDataIdx, 1);
        }
      }
    });
    parent.carrierDetailsModel.removeListData = [];
    parent.utilityServices.setLocalStorageData(parent.getOperationalGroupCode(),
      'operationalGroupCarrierAssignments', parent.carrierDetailsModel.storableDataModel);
    parent.utilityServices.setLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupUnAssignmentCarrierIds',
      lodashutils.uniq(unAssignedCarriers));
  }

  resetProfileViewQuery(parent: any) {
    parent.carrierDetailsModel.profileSortAndSearchQuery = lodashutils.cloneDeep({
      memberStartFrom: 0,
      expirationTimestamp: '',
      searchTxt: '',
      sortableMember: 'OperationalGroupCarrierAssignment.EffectiveTimestamp',
      sortableEvent: { sortOrder: -1 }
    });
  }

  setValidationError(parent: any, validationError: any) {
    if (validationError.status === 400) {
      const errorJson = typeof validationError.error === 'string' ? JSON.parse(validationError.error) : validationError.error;
      const errorMsg = parent.utilityServices.getMemberValidationResponse(errorJson);
      this.setToastForCarrierValidation(parent, errorMsg);
    }
  }

  setToastForCarrierValidation(parent: any, errorMsg: MemberValidationCustomOutput) {
    if (!errorMsg.isOverridedValidation) {
      this.setInCurrentOGToastMsg(parent, errorMsg.validationMsgTitle, errorMsg.memberValidationMsgs[0]);
    }
  }

  getSelectedCarrier(parent: any): string {
    const selectedCarrier = parent.carrierDetailsModel.carrierSelectedData;
    return `${selectedCarrier.carrierName.trim()} (${selectedCarrier.carrierCode.trim()})`;
  }

}
