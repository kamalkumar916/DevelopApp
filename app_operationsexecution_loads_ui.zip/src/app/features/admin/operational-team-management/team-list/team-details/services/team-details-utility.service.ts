import { Injectable } from '@angular/core';
import { SelectItem } from 'primeng/api';
import * as lodashutils from 'lodash';
import { DateUtils } from '../../../../../../shared/jbh-app-services/date-utils';
import { PostableOperationalGroup, UtilizationStatus } from '../../../model/operational-team.interface';
import {
  BusinessUnit, FinanceBusinessUnit
} from '../../../../../drivertask/search-driver-task/advance-search/model/advance-search-interface';
import { OperationalTeamManagementData, OperationalGroupField, OperationalGroupSubTypePost } from './../model/team-details.interface';

@Injectable()
export class TeamDetailsUtilityService {

  constructor() { }

  getOperationalTeamListInformation(scope: any, teamDataResponse: OperationalTeamManagementData): OperationalTeamManagementData {
    const teamDetailData = lodashutils.cloneDeep(teamDataResponse);
    teamDetailData.userImgNameData = this.getUpadatedName(teamDetailData);
    teamDetailData.lastUpdatedBy = (teamDetailData.lastUpdatedBy) ?
      teamDetailData.lastUpdatedBy : '';
    const utilizationStatusDescList = lodashutils.map(teamDataResponse.utilizationStatus, 'utilizationStatusDescription');
    teamDetailData.utilizationStatusDescList = utilizationStatusDescList.join(', ');
    teamDetailData.financeBusinessUnitCode = teamDetailData.financeBusinessUnitCode || teamDetailData.businessUnit;
    teamDetailData.lastUpdatedDateValue = (teamDetailData.lastUpdated) ?
      teamDetailData.lastUpdated : null;
    teamDetailData.userProfileImg =
      (teamDetailData.profilePicture) ? `${scope.teamDetailsModel.base64ImageString},${teamDetailData.profilePicture}` : null;
    return teamDetailData;
  }
  getUpadatedName(teamDetailData: OperationalTeamManagementData): string {
    let updatedPersonName = '';
    if (teamDetailData && teamDetailData.lastUpdatedBy) {
      updatedPersonName = teamDetailData.lastUpdatedBy.split('(')[0];
    }
    return updatedPersonName;
  }
  getEmptyOperationalTeamListInformation(): OperationalTeamManagementData {
    return {
      'operationalGroupCode': '', 'operationalGroupTypeCode': '', 'operationalGroupDescription': '',
      'operationalGroupTypeDescription': '', 'operationalGroupSubTypeCode': '', 'operationalGroupSubTypeDescription': '',
      'businessUnit': '', 'lastUpdated': '', 'lastUpdatedBy': '', 'totalMembers': 0, 'status': '',
      'utilizationStatus': [], 'utilizationStatusDescList': '', 'financeBusinessUnitCode': '',
      'lastUpdatedDateValue': '', 'userProfileImg': null, profilePic: null
    };
  }

  getLocalStoragePostableData(scope: any, operationalGroupData: OperationalTeamManagementData): OperationalTeamManagementData {
    return lodashutils.pick(operationalGroupData, scope.teamDetailsModel.pickableDataList);
  }

  setBusinessUnit(parent: any, buData: BusinessUnit) {
    const buArray = lodashutils.map(buData._embedded.serviceOfferingBusinessUnitTransitModeAssociations,
      'financeBusinessUnitServiceOfferingAssociation');
    parent.teamDetailsModel.businessUnitList = lodashutils.map(buArray,
      (businessUnitData: FinanceBusinessUnit): SelectItem => {
        return { label: businessUnitData.financeBusinessUnitCode, value: businessUnitData.financeBusinessUnitCode };
      });
    parent.teamDetailsModel.businessUnitListLocal = parent.teamDetailsModel.businessUnitList;
  }

  getOperationalGroupData(parent: any): PostableOperationalGroup {
    if (parent.teamDetailsModel.isNewOperationalTeamToAdd) {
      return this.getNewDataToPost(parent);
    }
    return this.getExistingDataToPost(parent);
  }
  getOperationalTeamSubType(parent: any): OperationalGroupSubTypePost {
    if (parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupType']['value']) {
      const ogSubTypeField = parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupType']['value'];
      return { operationalGroupSubTypeCode: ogSubTypeField.value, operationalGroupSubTypeDescription: ogSubTypeField.label };
    }
    return { operationalGroupSubTypeCode: null, operationalGroupSubTypeDescription: null };
  }
  getNewDataToPost(parent: any): PostableOperationalGroup {
    return lodashutils.assign(this.getOperationalTeamSubType(parent), {
      utilizationStatus: this.getUtilizationStatus(parent),
      addingSource: 'Manual',
      businessUnit: parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupBU'].value.label,
      operationalGroupCode: parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupIdentifier'].value,
      operationalGroupDescription: parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupName'].value,
      operationalGroupTypeCode: parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupCategory']['value'].value,
      operationalGroupTypeDescription: parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupCategory'].value.label
    });
  }
  getExistingDataToPost(parent: any): PostableOperationalGroup {
    return lodashutils.assign(this.getOperationalTeamSubType(parent), {
      operationalGroupCode: parent.teamDetailsModel.operationalTeamData.operationalGroupCode,
      operationalGroupTypeCode: parent.teamDetailsModel.operationalTeamData.operationalGroupTypeCode,
      operationalGroupTypeDescription: parent.teamDetailsModel.operationalTeamData.operationalGroupTypeCode,
      businessUnit: parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupBU'].value.label,
      operationalGroupDescription: parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupName'].value,
      utilizationStatus: this.getUtilizationStatus(parent),
      addingSource: 'Manual'
    });
  }
  getUtilizationStatus(parent: any): UtilizationStatus[] {
    const utilizationStatus = parent.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupUtilization'].value;
    return lodashutils.map(utilizationStatus, (utilizationStatusArg: string): UtilizationStatus => {
      const utilizeStatus = lodashutils.find(parent.teamDetailsModel.UtilizationStatusList, { value: utilizationStatusArg });
      return { utilizationStatusCode: utilizeStatus.value, utilizationStatusDescription: utilizeStatus.label };
    });
  }
  getOGGroupFieldValues(property: string, ogFieldData: OperationalGroupField): SelectItem[] {
    const inpPropertyString = (property === 'utilizationStatus') ? `${property}es` : `${property}s`;
    const dataList = !(ogFieldData && ogFieldData._embedded && ogFieldData._embedded[inpPropertyString]) ? [] :
      (ogFieldData && ogFieldData._embedded && ogFieldData._embedded[inpPropertyString]);
    return lodashutils.map(dataList, (eachFieldData) => ({
      label: eachFieldData[`${property}Description`], value: eachFieldData[`${property}Code`]
    }));
  }

}
