import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { DriverDetailsService } from './driver-details.service';
import { configureTestSuite } from 'ng-bullet';

describe('DriverDetailsService', () => {
  let service: DriverDetailsService;
  let httpTestingController: HttpTestingController;
  const memeberId = '18783';
  const operGroupCode = 'DCS';
  const groupType = 'Test';

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [DriverDetailsService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(DriverDetailsService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes getDriverListDataForOperGroup expected calls', () => {
    service.getDriverListDataForOperGroup('').subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTeamList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes getDriverOnTypeahead expected calls', () => {
    service.getDriverOnTypeahead('').subscribe();
    const req = httpTestingController.expectOne(service.employeeProfileIndexEndPoint.getDriverDetails);
    expect(req.request.method).toEqual('POST');
  });
  it('makes getDriverImages expected calls', () => {
    const userIds = 'demo';
    service.getDriverImages(userIds).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getUserImages}/${userIds}/AD_USERID,THUMBNAIL_PHOTO`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected getAddDriverBusinessValidation calls', () => {
    service.getAddDriverBusinessValidation(operGroupCode, groupType, memeberId).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=driver&memberIds=${memeberId}&type=${groupType}&action=add`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected getRemoveDriverBusinessValidation calls', () => {
    service.getRemoveDriverBusinessValidation(operGroupCode, groupType, memeberId).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=driver&memberIds=${memeberId}&type=${groupType}&action=remove`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected postMemberBusinessValidation calls', () => {
    const code = 'DCS';
    const memberRequest = {
      memberIds: 'test',
      operationalGroupType: 'test',
      action: 'add',
      memberName: 'test'
    };
    service.postMemberBusinessValidation(code, memberRequest).subscribe();
    const req =
      httpTestingController.expectOne(`${service.endpoint.postOGMemberAdhocValidations}/drivers/validations?operationalGroupCode=${code}`);
    expect(req.request.method).toEqual('POST');
  });
});
