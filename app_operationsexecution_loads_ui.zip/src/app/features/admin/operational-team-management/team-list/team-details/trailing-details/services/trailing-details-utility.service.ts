import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { takeWhile, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import * as lodashUtils from 'lodash';
import { DateUtils } from '../../../../../../../shared/jbh-app-services/date-utils';
import {
  DuplicateAndPairedMemberData, MemberValidationResponse,
  LocalStoreDuplicateMemberData
} from './../../model/team-details.interface';
import { TrailingGridData, TrailerCodeData } from './../models/trailing-details.interface';
import { OperationalGroupTrailingEquipmentAssignment, MemberValidationCustomOutput } from './../../../../model/operational-team.interface';
import { TrailingDetailsQuery } from '../query/trailing-details.query';
import { Utils } from '../../../../../../../shared/jbh-app-services/utils';
import { SortView } from '../../../model/team-list.interface';

@Injectable()
export class TrailingDetailsUtilityService {

  constructor(private readonly formBuilder: FormBuilder) { }

  isValidTrailerType(parent: any): boolean {
    const equipmentTypeValue = parent.trailingDetailsModel.addEquipmentForm.controls['equipmentType'].value;
    if (equipmentTypeValue) {
      return parent.trailingDetailsModel.equiTypes.indexOf(equipmentTypeValue) !== -1;
    }
    return false;
  }

  getEmptyDataForTrailingData(): TrailingGridData {
    return {
      rowEditable: true, EquipmentNumber: '',
      EquipmentClassificationDescription: '', equipmentID: null,
      operationalGroupEquipmentAssignmentID: null, effectiveTimestamp: '',
      expirationTimestamp: ''
    };
  }

  getNewlyAddedRecordForTrailingData(equipmentDescription: string, equipmentNumber: string, equipmentId: string): TrailingGridData {
    return {
      rowEditable: false, EquipmentNumber: equipmentNumber,
      EquipmentClassificationDescription: equipmentDescription,
      equipmentID: Number(equipmentId),
      operationalGroupEquipmentAssignmentID: null, effectiveTimestamp: '',
      expirationTimestamp: ''
    };
  }

  getStorableData(parent: any, equipmentObject: TrailerCodeData): OperationalGroupTrailingEquipmentAssignment {
    return {
      'equipmentId': Number(equipmentObject.equipmentID),
      'equipmentUnitId': equipmentObject.prefixWithEquipmentNumber.trim(),
      'equipmentClassificationCode': equipmentObject.equipmentClassificationCode.trim(),
      'overrideTrailingEquipmentValidations': parent.trailingDetailsModel.overRideTrailingEquipment,
    };
  }

  setInCurrentOGToastMsg(parent: any, errorTitle: string, errorMsgs: string) {
    parent.messageService.clear();
    parent.messageService.add({ 'severity': 'error', 'summary': errorTitle, 'detail': errorMsgs });
    parent.changeDetector.detectChanges();
  }

  setInOGConfirmDialog(parent: any, memberResponse: MemberValidationResponse) {
    parent.trailingDetailsModel.memberValidationResponseMessage = {
      'operationalGroupCode': memberResponse.operationalGroupCode, 'pairedMemberId': memberResponse.pairedMemberId,
      'duplicateMemberAssignmentId': memberResponse.duplicateMemberAssignmentId
    };
    const operGroupType = parent.trailingDetailsModel.operationalGroupForm.controls['operationalGroupCategory'].value.label
      || parent.trailingDetailsModel.operationalGroupData.operationalGroupTypeCode;
    if (operGroupType === 'Fleet') {
      if (!memberResponse.duplicateMemberAssignmentId) {
        parent.onConfirmYesClicked();
      } else {
        parent.trailingDetailsModel.isConfirmDialogVisible = true;
      }
    } else {
      parent.onConfirmYesClicked();
    }
    parent.changeDetector.detectChanges();
  }

  setTrailingEquipmentDataOnTable(parent: any) {
    const equipValue = parent.trailingDetailsModel.addEquipmentForm.controls['equipmentCode'].value;
    const selectedEquipment =
      lodashUtils.find(parent.trailingDetailsModel.equipTypeaheadDataList, { 'prefixWithEquipmentNumber': equipValue });
    const equipmentType = parent.trailingDetailsModel.defaultEquipmentType;
    const trailerData = this.getNewlyAddedRecordForTrailingData(equipmentType, equipValue, selectedEquipment.equipmentID);
    parent.trailingDetailsModel.storableDataModel.push(this.getStorableData(parent, selectedEquipment));
    parent.operationalTeamUtilityService
      .setLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupTrailingEquipmentAssignments',
        parent.trailingDetailsModel.storableDataModel);
    parent.trailingDetailsModel.trailingData.unshift(trailerData);
  }


  getDefaultValidationResponse(operationalGroupCode: string): DuplicateAndPairedMemberData {
    return { 'duplicateMemberAssignmentId': null, 'pairedMemberId': null, 'operationalGroupCode': operationalGroupCode };
  }

  setRemovedTrailingData(parent: any, isChecked: boolean, rowData: TrailingGridData) {
    if (isChecked) {
      parent.trailingDetailsModel.removedTrailingListData.push(rowData);
    } else {
      const removedDataIdx = lodashUtils.findIndex(parent.trailingDetailsModel.removedTrailingListData,
        { 'equipmentID': rowData.equipmentID });
      if (removedDataIdx !== -1) {
        parent.trailingDetailsModel.removedTrailingListData.splice(removedDataIdx, 1);
      }
    }
  }

  setRemovedDataInLocalStore(parent: any) {
    const unAssignedEquipment =
      parent.operationalTeamUtilityService.getLocalStorageData(parent.getOperationalGroupCode(),
        'operationalGroupUnAssignmentTrailingEquipmentIds');
    lodashUtils.forEach(parent.trailingDetailsModel.removedTrailingListData, (removedEquipment: TrailingGridData) => {
      const isEquipmentInEs = lodashUtils.filter(parent.trailingDetailsModel.esEquipmentData,
        (equipmentDetails: TrailingGridData) => (equipmentDetails.equipmentID === Number(removedEquipment.equipmentID))).length !== 0;
      if (isEquipmentInEs) {
        unAssignedEquipment.push(Number(removedEquipment.equipmentID));
      } else {
        const storableDataIdx =
          lodashUtils.findIndex(parent.trailingDetailsModel.storableDataModel, { 'equipmentId': Number(removedEquipment.equipmentID) });
        if (storableDataIdx !== -1) {
          parent.trailingDetailsModel.storableDataModel.splice(storableDataIdx, 1);
        }
      }
    });
    parent.trailingDetailsModel.removedTrailingListData = [];
    parent.operationalTeamUtilityService.setLocalStorageData(parent.getOperationalGroupCode(),
      'operationalGroupTrailingEquipmentAssignments', parent.trailingDetailsModel.storableDataModel);
    parent.operationalTeamUtilityService.setLocalStorageData(parent.getOperationalGroupCode(),
      'operationalGroupUnAssignmentTrailingEquipmentIds',
      lodashUtils.uniq(unAssignedEquipment));
  }
  setTrailingCheckBoxFormControl(scope: any) {
    const trailingCheckBoxControl = scope.trailingDetailsModel.addEquipmentForm.controls.equipmentCheckBoxes;
    lodashUtils.forEach(scope.trailingDetailsModel.trailingData, (EquipmentListsData) => {
      trailingCheckBoxControl.push(this.getFormGroupForEquipment());
    });
    scope.trailingDetailsModel.trailingFormCheckBoxArray = lodashUtils.map(trailingCheckBoxControl.controls, 'controls');
  }
  getFormGroupForEquipment(): FormGroup {
    return this.formBuilder.group({ 'equipmentCheckBox': [false] });
  }
  setAddedTrailingChkBoxControl(scope: any) {
    const trailingCheckBoxControl = scope.trailingDetailsModel.addEquipmentForm.controls.equipmentCheckBoxes;
    if (trailingCheckBoxControl && trailingCheckBoxControl.controls) {
      trailingCheckBoxControl.controls.unshift(this.getFormGroupForEquipment());
      scope.trailingDetailsModel.trailingFormCheckBoxArray = lodashUtils.map(trailingCheckBoxControl.controls, 'controls');
    }
  }
  getPostableTrailingDataToRemove(parent: any, equipmentObject: TrailingGridData) {
    return Number(equipmentObject.equipmentID);
  }

  removeEquipmentsFromTable(parent: any, removedEquipments: number[]) {
    const equipmentsToProcess = lodashUtils.cloneDeep(parent.trailingDetailsModel.trailingData);
    const trailingCheckBoxControl = parent.trailingDetailsModel.addEquipmentForm.controls.equipmentCheckBoxes;
    lodashUtils.remove(equipmentsToProcess, (trailingDatatoProcess: TrailingGridData, idx: number) => {
      const isRemovedMember =
        removedEquipments.filter(equipmentId => (trailingDatatoProcess.equipmentID === equipmentId)).length !== 0;
      if (isRemovedMember) {
        trailingCheckBoxControl.controls.splice(idx, 1);
      }
      return isRemovedMember;
    });
    parent.trailingDetailsModel.trailingData = equipmentsToProcess;
    parent.trailingDetailsModel.trailingFormCheckBoxArray = lodashUtils.map(trailingCheckBoxControl.controls, 'controls');
    this.setRemovedDataInLocalStore(parent);
    parent.changeDetector.detectChanges();
  }
  searchInputListener(scope: any) {
    scope.trailingDetailsModel.addEquipmentForm.controls['trailingEquipmentSearch'].valueChanges.pipe(
      debounceTime(50), distinctUntilChanged(), takeWhile(() => scope.trailingDetailsModel.canSubscribe))
      .subscribe((value) => {
        if (value !== null && scope.trailingDetailsModel.isProfileView) {
          scope.resetTrailerListFields();
          scope.trailingDetailsModel.isTrailerListSorted = true;
          scope.profileSortAndSearch.emit();
          const searchAndSortQuery = lodashUtils.cloneDeep(scope.trailingDetailsModel.profileSortAndSearchQuery);
          searchAndSortQuery.searchTxt = Utils.formattedSearchText(scope.trailingDetailsModel.addEquipmentForm.controls.
            trailingEquipmentSearch.value);
          const trailingSerachQuery =
            TrailingDetailsQuery.getTrailerListElasticQuery(scope.getOperationalGroupCode(),
              scope.trailingDetailsModel.recordFrom, scope.trailingDetailsModel.recordDefaultSize,
              searchAndSortQuery);
          scope.trailingDetailsModel.profileSortAndSearchQuery = lodashUtils.cloneDeep(searchAndSortQuery);
          scope.showTrucklist(trailingSerachQuery);
        }
      });
  }
  onGridLazyLoad(event: SortView, scope: any) {
    if (scope.trailingDetailsModel.isProfileView && event.sortField) {
      scope.resetTrailerListFields();
      scope.trailingDetailsModel.isTrailerListSorted = true;
      scope.profileSortAndSearch.emit();
      const sortableObjectColumn = lodashUtils.find(scope.trailingDetailsModel.defaultColumns, { 'property': event.sortField });
      const searchAndSortQuery = lodashUtils.cloneDeep(scope.trailingDetailsModel.profileSortAndSearchQuery);
      searchAndSortQuery.sortableMember = sortableObjectColumn.sortableDataMember;
      searchAndSortQuery.sortableEvent = { sortOrder: event.sortOrder ? event.sortOrder : 1 };
      scope.trailingDetailsModel.trailingListElasticQuery = TrailingDetailsQuery.getTrailerListElasticQuery
        (scope.getOperationalGroupCode(), scope.trailingDetailsModel.recordFrom, scope.trailingDetailsModel.recordDefaultSize,
          searchAndSortQuery);
      scope.trailingDetailsModel.profileSortAndSearchQuery = lodashUtils.cloneDeep(searchAndSortQuery);
      scope.trailingDetailsModel.isLoading = true;
      scope.showTrucklist(scope.trailingDetailsModel.trailingListElasticQuery);
    }
  }
  resetProfileViewQuery(parent: any) {
    parent.trailingDetailsModel.profileSortAndSearchQuery = lodashUtils.cloneDeep({
      memberStartFrom: 0,
      expirationTimestamp: '',
      searchTxt: '',
      sortableMember: 'OperationalGroupEquipmentAssignment.EffectiveTimestamp',
      sortableEvent: { sortOrder: -1 }
    });
  }
  isAddedEquipmentDuplicated(parent: any, operationalGroupCode: string,
    assetID: number, equipValue: string): LocalStoreDuplicateMemberData {
    const unAssignedEquipments =
      parent.operationalTeamUtilityService.getLocalStorageData(parent.getOperationalGroupCode(),
        'operationalGroupUnAssignmentTrailingEquipmentIds');
    const duplicatedMemberData = { isAddedInLocalStore: false, isRemovedInLocalStore: false };
    const duplicateEquipmentArray =
      lodashUtils.filter(parent.trailingDetailsModel.storableDataModel,
        (equipmentData: OperationalGroupTrailingEquipmentAssignment) =>
          Number(equipmentData.equipmentId) === Number(assetID));

    duplicatedMemberData.isRemovedInLocalStore = lodashUtils.filter(unAssignedEquipments,
      (unAssignEquipmentId: number) => (Number(assetID) === unAssignEquipmentId)).length !== 0;
    if (duplicateEquipmentArray && duplicateEquipmentArray.length !== 0) {
      duplicatedMemberData.isAddedInLocalStore = true;
      if (duplicatedMemberData.isRemovedInLocalStore) {
        duplicatedMemberData.isAddedInLocalStore = duplicateEquipmentArray.length > 1;
      }
      if (duplicatedMemberData.isAddedInLocalStore) {
        const operGroupDesc = parent.trailingDetailsModel.operationalGroupForm.controls['operationalGroupName'].value;
        this.setInCurrentOGToastMsg(parent, 'Member already selected',
          `${equipValue} has already been added to ${operGroupDesc} (${parent.getOperationalGroupCode()})`);
      }
    }
    return duplicatedMemberData;
  }

  executeMemberValidation(parent: any, memberValidation: MemberValidationCustomOutput) {
    if (memberValidation.isOverridedValidation) {
      parent.trailingDetailsModel.overRideTrailingErrorMsgs = memberValidation.memberValidationMsgs;
      parent.trailingDetailsModel.isConfirmDialogVisible = true;
    } else {
      this.setInCurrentOGToastMsg(parent, memberValidation.validationMsgTitle, memberValidation.memberValidationMsgs[0]);
    }
    parent.changeDetector.detectChanges();
  }
  updateTrailingDataIntoLocalstore(parent: any) {
    this.setTrailingEquipmentDataOnTable(parent);
    parent.onCancelBtnClicked();
    parent.changeDetector.detectChanges();
  }
  getExistingEquipmentRemovalInfo(parent: any, equipmentsRemoved: number[]): number[] {
    const removableEquipments = [];
    const localStoredEquipment =
      parent.operationalTeamUtilityService.getLocalStorageData(parent.getOperationalGroupCode(),
        'operationalGroupTrailingEquipmentAssignments');
    equipmentsRemoved.forEach((removedTruckID: number) => {
      const existingTruckIdx = lodashUtils.findIndex(localStoredEquipment, { equipmentId: removedTruckID });
      if (existingTruckIdx === -1) {
        removableEquipments.push(removedTruckID);
      }
    });
    return removableEquipments;
  }
}
