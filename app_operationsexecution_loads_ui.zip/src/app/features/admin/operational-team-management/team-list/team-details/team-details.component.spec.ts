import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { TeamDetailsComponent } from './team-details.component';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { LocalStorageService } from '../../../../../shared/jbh-app-services/local-storage.service';
import { UserService } from '../../../../../shared/jbh-esa/index';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormGroup } from '@angular/forms';
import {
  AutoCompleteModule, MultiSelectModule, TabViewModule, PanelModule,
  CheckboxModule, CalendarModule, DialogModule, TooltipModule
} from 'primeng/primeng';
import { DriverDetailsComponent } from '../team-details/driver-details/driver-details.component';
import { TruckDetailsComponent } from '../team-details/truck-details/truck-details.component';
import { CarrierDetailsComponent } from '../team-details/carrier-details/carrier-details.component';
import { TrailingDetailsComponent } from '../team-details/trailing-details/trailing-details.component';
import { PipesModule } from '../../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from '../../../../../shared/directives/directives.module';
import { TableModule } from 'primeng/table';
import { OperationalTeamUtilityService } from '../../services/operational-team-utility.service';
import { TeamDetailsService } from './services/team-details.service';
import { TeamDetailsUtilityService } from './services/team-details-utility.service';
import { TruckDetailsService } from './truck-details/services/truck-details.service';
import { TruckDetailsUtilityService } from './truck-details/services/truck-details-utility.service';
import { CarrierDetailsService } from './carrier-details/services/carrier-details.service';
import { CarrierDetailsUtilityService } from './carrier-details/services/carrier-details-utility.service';
import { TrailingDetailsService } from './trailing-details/services/trailing-details.service';
import { TrailingDetailsUtilityService } from './trailing-details/services/trailing-details-utility.service';
import { DriverDetailsService } from './driver-details/services/driver-details.service';
import { DriverDetailsUtilityService } from './driver-details/services/driver-details-utility.service';
import { DriverSortSearchService } from './driver-details/services/driver-sort-search.service';
import { throwError } from 'rxjs/internal/observable/throwError';
import { Subscription } from 'rxjs';

describe('TeamDetailsComponent', () => {
  let component: TeamDetailsComponent;
  let fixture: ComponentFixture<TeamDetailsComponent>;
  let service: TeamDetailsService;
  let messageService: MessageService;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [DriverDetailsComponent,
        TeamDetailsComponent, TruckDetailsComponent, CarrierDetailsComponent, TrailingDetailsComponent],
      imports: [RouterTestingModule, PipesModule, TableModule,
        JbhLoaderModule, TooltipModule, DirectivesModule, HttpClientTestingModule,
        DialogModule, CalendarModule, CheckboxModule, NoopAnimationsModule,
        ReactiveFormsModule, FormsModule, AutoCompleteModule, MultiSelectModule, TabViewModule,
        PanelModule],
      providers: [MessageService, TruckDetailsUtilityService,
        TruckDetailsService, AppConfigService, TeamDetailsService,
        CarrierDetailsService, CarrierDetailsUtilityService, TrailingDetailsService,
        OperationalTeamUtilityService, TrailingDetailsUtilityService,
        DriverDetailsService, DriverDetailsUtilityService,
        TeamDetailsUtilityService, LocalStorageService, UserService, DriverSortSearchService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamDetailsComponent);
    component = fixture.componentInstance;
    service = TestBed.get(TeamDetailsService);
    messageService = TestBed.get(MessageService);
    fixture.detectChanges();
    formGroup = formBuilder.group({
      operationalGroupName: [''],
      operationalGroupIdentifier: [''],
      operationalGroupCategory: [''],
      operationalGroupType: [''],
      operationalGroupBU: [''],
      operationalGroupUtilization: ['ABC']
    });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onIdentifierBlurred have been called', () => {
    spyOn(component, 'processLocalStorageService');
    component.onIdentifierBlurred({ target: { value: 'test' } });
    expect(component.processLocalStorageService).toHaveBeenCalled();
  });

  it('getOperationalGroupFormData have been called', () => {
    spyOn(component, 'resetOperationalGroupStaticData');
    component.getOperationalGroupFormData();
    expect(component.resetOperationalGroupStaticData).toHaveBeenCalled();
  });

  it('resetOperationalGroupStaticData to return expected value', () => {
    component.resetOperationalGroupStaticData();
    expect(component.teamDetailsModel.operationalGroupFormData.isValidForm).toBe(false);
  });

  it('checkIsUtilizationExists have been called', () => {
    component.teamDetailsModel.newOperationalGroupForm = null;
    const returnValue = component.checkIsUtilizationExists();
    expect(returnValue).toBe(false);
  });
  it('driverActiveCount have been set', () => {
    component.driverActiveDaysCount = 14;
    expect(component.teamDetailsModel.driverActiveDaysCount).toEqual(14);
  });
  it('newOperationalTeamToAdd have been set', () => {
    component.newOperationalTeamToAdd = true;
    expect(component.teamDetailsModel.isNewOperationalTeamToAdd).toBe(true);
  });
  it('operationalGroupCode have been set', () => {
    component.operationalGroupCode = 'Test';
    expect(component.teamDetailsModel.tabActiveIndex).toEqual(0);
  });
  it('operationalGroupStatus have been set', () => {
    const operationalGroupStatus = {
      status: 'Active'
    };
    spyOn(component, 'setOperationalTeamDetails');
    component.operationalGroupStatus = operationalGroupStatus;
    expect(component.setOperationalTeamDetails).toHaveBeenCalled();
  });
  it('getOperationalGroupType throwing Error', () => {
    component.teamDetailsModel.isNewOperationalTeamToAdd = true;
    spyOn(service, 'getOperationalGroupType').and.returnValue(throwError({}));
    component.loadCategory();
    expect(component.teamDetailsModel.categoryList).toEqual([]);
  });
  it('getOperationalGroupSubType throwing Error', () => {
    spyOn(service, 'getOperationalGroupSubType').and.returnValue(throwError({}));
    component.loadType();
    expect(component.teamDetailsModel.typeList).toEqual([]);
  });
  it('loadBusinessUnit throwing Error', () => {
    spyOn(service, 'getBUForTransferInitiation').and.returnValue(throwError({}));
    component.loadBusinessUnit();
    expect(component.teamDetailsModel.businessUnitList).toEqual([]);
    expect(component.teamDetailsModel.businessUnitListLocal).toEqual([]);
  });
  it('loadUtilizationStatus throwing Error', () => {
    spyOn(service, 'getUtilizationStatus').and.returnValue(throwError({}));
    component.loadUtilizationStatus();
    expect(component.teamDetailsModel.UtilizationStatusList).toEqual([]);
  });
  it('onHandleTabChange calling', () => {
    component.onHandleTabChange('ABC');
    expect(component.teamDetailsModel.tabChangeEvent).toBe('ABC');
  });
  it('loadCategory throwing Error', () => {
    component.teamDetailsModel.isNewOperationalTeamToAdd = true;
    component.teamDetailsModel.loadCategoryPresent = new Subscription();
    spyOn(component.teamDetailsModel.loadCategoryPresent, 'unsubscribe');
    spyOn(service, 'getOperationalGroupType').and.returnValue(throwError({}));
    component.loadCategory();
    expect(component.teamDetailsModel.loadCategoryPresent.unsubscribe).toBeTruthy();
  });
  it('loadType throwing Error', () => {
    component.teamDetailsModel.loadTypePresent = new Subscription();
    spyOn(component.teamDetailsModel.loadTypePresent, 'unsubscribe');
    spyOn(service, 'getOperationalGroupSubType').and.returnValue(throwError({}));
    component.loadType();
    expect(component.teamDetailsModel.loadTypePresent.unsubscribe).toBeTruthy();
  });
  it('loadBusinessUnit throwing Error', () => {
    component.teamDetailsModel.businessUnitPresent = new Subscription();
    spyOn(component.teamDetailsModel.businessUnitPresent, 'unsubscribe');
    spyOn(service, 'getBUForTransferInitiation').and.returnValue(throwError({}));
    component.loadBusinessUnit();
    expect(component.teamDetailsModel.businessUnitPresent.unsubscribe).toBeTruthy();
  });
  it('loadUtilizationStatus throwing Error', () => {
    component.teamDetailsModel.utilizationStatusPresent = new Subscription();
    spyOn(component.teamDetailsModel.utilizationStatusPresent, 'unsubscribe');
    spyOn(service, 'getUtilizationStatus').and.returnValue(throwError({}));
    component.loadUtilizationStatus();
    expect(component.teamDetailsModel.utilizationStatusPresent.unsubscribe).toBeTruthy();
  });
  it('getIsValidUtilizationStatus have been called', () => {
    const result = component.getIsValidUtilizationStatus();
    expect(result).toBe(null);
  });
  it('getIsValidUtilizationStatus have been called', () => {
    component.teamDetailsModel.newOperationalGroupForm = formGroup;
    const result = component.getIsValidUtilizationStatus();
    expect(result).toBe(true);
  });
  it('markAllFieldsTouched have been called', () => {
    component.teamDetailsModel.newOperationalGroupForm = formGroup;
    component.markAllFieldsTouched();
    expect(component.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupUtilization'].touched).toBe(true);
  });
});
