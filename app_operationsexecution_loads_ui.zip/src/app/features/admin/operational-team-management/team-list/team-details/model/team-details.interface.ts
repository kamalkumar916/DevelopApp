import { PostableOperationalGroup } from '../../../model/operational-team.interface';

export interface UtilizationStatus {
    utilizationStatusCode: string;
    utilizationStatusDescription: string;
}

export interface OperationalTeamManagementData {
    operationalGroupCode: string;
    operationalGroupDescription: string;
    operationalGroupTypeCode: string;
    operationalGroupTypeDescription: string;
    operationalGroupSubTypeCode: string;
    operationalGroupSubTypeDescription: string;
    businessUnit: string;
    utilizationStatus: UtilizationStatus[];
    lastUpdated: string;
    lastUpdatedBy: string;
    totalMembers: number;
    status: string;
    profilePic?: string;
    profilePicture?: string;
    utilizationStatusDescList?: string;
    lastUpdatedDateValue?: string;
    userProfileImg?: string;
    userImgNameData?: string;
    financeBusinessUnitCode?: string;
}

export interface MemberValidationResponse {
    operationalGroupCode: string;
    memberType: string;
    memberIds: number;
    inCurrentOperationalGroup?: string;
    duplicateMemberAssignmentId?: number[];
    pairedMemberId?: number[];
}

export interface DuplicateAndPairedMemberData {
    operationalGroupCode: string;
    duplicateMemberAssignmentId?: number[];
    pairedMemberId?: number[];
}

export interface LocalStoreDuplicateMemberData {
    isAddedInLocalStore: boolean;
    isRemovedInLocalStore: boolean;
}

export interface ProfileSortAndSearch {
    memberStartFrom: number;
    sortableMember: string;
    sortableEvent?: any;
    searchType?: string;
    expirationTimestamp?: string;
    searchTxt: string;
}

export interface OperationalGroupFormData {
    operationalGroupData: PostableOperationalGroup;
    isValidForm: boolean;
}

export interface OperationalGroupType {
    operationalGroupTypeDescription: string;
    operationalGroupTypeCode: string;
}

export interface OperationalGroupSubType {
    operationalGroupSubtypeDescription?: string;
    operationalGroupSubtypeCode?: string;
}

export interface OperationalGroupSubTypePost {
    operationalGroupSubTypeDescription?: string;
    operationalGroupSubTypeCode?: string;
}

export interface Embedded {
    operationalGroupTypes?: OperationalGroupType[];
    operationalGroupSubtypes?: OperationalGroupSubType[];
    utilizationStatuses?: UtilizationStatus[];
}

export interface OperationalGroupField {
    _embedded: Embedded;
}
