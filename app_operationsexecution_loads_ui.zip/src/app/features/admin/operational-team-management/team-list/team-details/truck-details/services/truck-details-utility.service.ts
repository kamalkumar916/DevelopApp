import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import * as moment from 'moment';

import * as lodashutils from 'lodash';

import { TruckDataModel, TruckList, TruckStorableData } from '../models/truck-details.interface';
import { DateUtils } from '../../../../../../../shared/jbh-app-services/date-utils';
import {
  DuplicateAndPairedMemberData, MemberValidationResponse, LocalStoreDuplicateMemberData
} from './../../model/team-details.interface';
import { OperationalGroupTruckAssignment, MemberValidationCustomOutput } from './../../../../model/operational-team.interface';

@Injectable()
export class TruckDetailsUtilityService {

  constructor(private readonly formBuilder: FormBuilder) { }

  getNewlyAddedRecordForTruckData(equpNumber: string) {
    return { EquipmentNumber: equpNumber };
  }
  getStorableData(parent: any, equipId: TruckDataModel): OperationalGroupTruckAssignment {
    return {
      equipmentId: Number(equipId.assetId),
      equipmentUnitId: equipId.assetUnitId.trim(),
      equipmentClassificationCode: equipId.assetClassCode,
      overrideTruckValidations: parent.truckDetailsModel.overRideTruck
    };
  }
  getFormattedDateTime(date: string, format: string): string {
    return moment(date).format(format);
  }
  setRemovedTruckData(parent: any, isChecked: boolean, rowData: TruckList) {
    if (isChecked) {
      parent.truckDetailsModel.removedTruckListData.push(rowData);
    } else {
      const removedDataIdx = lodashutils.findIndex(parent.truckDetailsModel.removedTruckListData,
        { 'equipmentId': rowData.equipmentId });
      if (removedDataIdx !== -1) {
        parent.truckDetailsModel.removedTruckListData.splice(removedDataIdx, 1);
      }
    }
  }

  setRemovedDataInLocalStore(parent: any) {
    const unAssignedTrucks = parent.utilityService
      .getLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupUnAssignmentTruckEquipmentIds');
    lodashutils.forEach(parent.truckDetailsModel.removedTruckListData, (removedTruck: TruckList) => {
      const isTruckInEs = lodashutils.filter(parent.truckDetailsModel.storableTruckData,
        (truckDetails) => (Number(truckDetails.equipmentId) === Number(removedTruck.equipmentId))).length !== 0;
      if (isTruckInEs) {
        unAssignedTrucks.push(Number(removedTruck.equipmentId));
      } else {
        lodashutils.remove(parent.truckDetailsModel.storableDataModel, { 'equipmentId': Number(removedTruck.equipmentId) });
        lodashutils.remove(parent.truckDetailsModel.localStorableDataModel, { 'equipmentId': Number(removedTruck.equipmentId) });
      }
    });
    parent.truckDetailsModel.removedTruckListData = [];
    const postDataArray = lodashutils.uniqBy(parent.truckDetailsModel
      .localStorableDataModel.concat(parent.truckDetailsModel.storableDataModel), 'equipmentId');
    parent.utilityService
      .setLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupTruckAssignments', postDataArray);
    parent.utilityService
      .setLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupUnAssignmentTruckEquipmentIds', unAssignedTrucks);
  }

  removeTrucksFromTable(parent: any, removedTrucks: number[]) {
    const trucksToProcess = lodashutils.cloneDeep(parent.truckDetailsModel.truckData);
    const truckCheckBoxControl = parent.truckDetailsModel.truckDeatilsForm.controls.truckCheckBoxes;
    lodashutils.remove(trucksToProcess, (truckDatatoProcess: TruckList, idx: number) => {
      const isRemovedMember = removedTrucks.filter(equipmentId =>
        (truckDatatoProcess.equipmentId.toString() === equipmentId.toString())).length !== 0;
      if (isRemovedMember) {
        truckCheckBoxControl.controls.splice(idx, 1);
      }
      return isRemovedMember;
    });
    parent.truckDetailsModel.truckData = trucksToProcess;
    parent.truckDetailsModel.tempDriverFormCheckBoxArray = lodashutils.map(truckCheckBoxControl.controls, 'controls');
    this.setRemovedDataInLocalStore(parent);
    parent.changeDetector.detectChanges();
  }
  setTruckCheckBoxFormControl(scope: any) {
    const truckCheckBoxControl = scope.truckDetailsModel.truckDeatilsForm.controls.truckCheckBoxes;
    lodashutils.forEach(scope.truckDetailsModel.truckData, (truckListsData) => {
      truckCheckBoxControl.push(this.getFormGroupForTruck());
    });
    scope.truckDetailsModel.truckFormCheckBoxArray = lodashutils.map(truckCheckBoxControl.controls, 'controls');
  }
  getFormGroupForTruck(): FormGroup {
    return this.formBuilder.group({ 'truckCheckBox': [false] });
  }
  setAddedTruckChkBoxControl(scope: any) {
    const truckCheckBoxControl = scope.truckDetailsModel.truckDeatilsForm.controls.truckCheckBoxes;
    if (truckCheckBoxControl && truckCheckBoxControl.controls) {
      truckCheckBoxControl.controls.unshift(this.getFormGroupForTruck());
      scope.truckDetailsModel.truckFormCheckBoxArray = lodashutils.map(truckCheckBoxControl.controls, 'controls');
    }
  }

  executeMemberValidation(parent: any, memberValidation: MemberValidationCustomOutput) {
    if (memberValidation.isOverridedValidation) {
      parent.truckDetailsModel.overRideTruckErrorMsgs = memberValidation.memberValidationMsgs;
      parent.truckDetailsModel.isConfirmDialogVisible = true;
    } else {
      this.setInCurrentOGToastMsg(parent, memberValidation.validationMsgTitle, memberValidation.memberValidationMsgs[0]);
    }
    parent.changeDetector.detectChanges();
  }

  setInCurrentOGToastMsg(parent: any, errorTitle: string, errMsg: string) {
    parent.messageService.clear();
    parent.messageService.add({ 'severity': 'error', 'summary': errorTitle, 'detail': errMsg });
  }

  getDefaultValidationResponse(operationalGroupCode: string): DuplicateAndPairedMemberData {
    return { 'duplicateMemberAssignmentId': null, 'pairedMemberId': null, 'operationalGroupCode': operationalGroupCode };
  }


  isAddedTruckDuplicated(parent: any, selectedEquipment: string, trailerID: string): LocalStoreDuplicateMemberData {
    const unAssignedTrucks = parent.utilityService.getLocalStorageData(parent.getOperationalGroupCode(),
      'operationalGroupUnAssignmentTruckEquipmentIds');
    const duplicatedMemberData = { isAddedInLocalStore: false, isRemovedInLocalStore: false };
    const duplicateTrailerArray =
      lodashutils.filter(parent.truckDetailsModel.storableDataModel.concat(parent.truckDetailsModel.localStorableDataModel),
        (trailerData: OperationalGroupTruckAssignment) => (Number(trailerData.equipmentId) === Number(trailerID)));
    duplicatedMemberData.isRemovedInLocalStore = lodashutils.filter(unAssignedTrucks,
      (unAssignTruckId: number) => (Number(trailerID) === unAssignTruckId)).length !== 0;
    if (duplicateTrailerArray && duplicateTrailerArray.length !== 0) {
      duplicatedMemberData.isAddedInLocalStore = true;
      if (duplicatedMemberData.isRemovedInLocalStore) {
        duplicatedMemberData.isAddedInLocalStore = duplicateTrailerArray.length > 1;
      }
      if (duplicatedMemberData.isAddedInLocalStore) {
        const operGroupDesc = parent.truckDetailsModel.operationalGroupForm.controls['operationalGroupName'].value;
        this.setInCurrentOGToastMsg(parent, 'Member already selected',
          `${selectedEquipment} has already been added to ${operGroupDesc} (${parent.getOperationalGroupCode()})`);
      }
    }
    return duplicatedMemberData;
  }

  resetProfileViewQuery(parent: any) {
    parent.truckDetailsModel.profileSortAndSearchQuery = lodashutils.cloneDeep({
      memberStartFrom: 0,
      expirationTimestamp: '',
      searchTxt: '',
      sortableMember: 'OperationalGroupEquipmentAssignment.EffectiveTimestamp',
      sortableEvent: { sortOrder: -1 }
    });
  }

  onValidateCheckBox(parent: any) {
    const truckDetailsModel = parent.truckDetailsModel;
    const checkedValues = lodashutils.filter(truckDetailsModel.truckFormCheckBoxArray, (eachTruckCheckBox: FormControl): boolean => {
      return eachTruckCheckBox['truckCheckBox']['value'];
    });
    parent.truckDetailsModel.isRemoveCancelBtnsVisible = (checkedValues.length !== 0);
    parent.utilityService.setIsRemoveMemberClicked(truckDetailsModel.isRemoveCancelBtnsVisible, parent.getOperationalGroupCode());
    parent.changeDetector.detectChanges();
  }
  removeTruckFromTheTable(parent: any, removedTrucks: number[]) {
    this.removeTrucksFromTable(parent, removedTrucks);
    parent.onRemoveTruckCancelBtnClicked();
  }
  resetTruckDetailsView(parent: any) {
    parent.truckDetailsModel.truckDeatilsForm.reset();
    parent.truckDetailsModel.isShowSaveLink = false;
    parent.truckDetailsModel.isRemoveCancelBtnsVisible = false;
    parent.truckDetailsModel.isEnableTruck = false;
    parent.changeDetector.detectChanges();
  }

  getExistingTruckRemovalInfo(parent: any, removedTrucks: number[]): number[] {
    const removableTrucks = [];
    const localStoredTrucks =
      parent.utilityService.getLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupTruckAssignments');
    removedTrucks.forEach((removedTruckID: number) => {
      const existingTruckIdx = lodashutils.findIndex(localStoredTrucks, { equipmentId: removedTruckID });
      if (existingTruckIdx === -1) {
        removableTrucks.push(removedTruckID);
      }
    });
    return removableTrucks;
  }

}
