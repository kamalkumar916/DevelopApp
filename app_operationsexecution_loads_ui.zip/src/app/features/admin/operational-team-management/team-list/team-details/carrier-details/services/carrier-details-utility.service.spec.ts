import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from 'ng-bullet';
import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { CarrierDetailsUtilityService } from './carrier-details-utility.service';

describe('CarrierDetailsUtilityService', () => {
  let service: CarrierDetailsUtilityService;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [CarrierDetailsUtilityService, AppConfigService, FormBuilder]
    });
  });
  beforeEach(() => {
    service = TestBed.get(CarrierDetailsUtilityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getNewlyAddedRecordForTruckData should return expected value', () => {
    const returnValue = service.getNewlyAddedRecordForCarrierData('Ford');
    expect(returnValue.CarrierName).toBe('Ford');
  });
});
