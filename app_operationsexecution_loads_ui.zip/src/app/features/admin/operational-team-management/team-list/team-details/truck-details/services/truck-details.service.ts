import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { ElasticResponseModel } from '../../../../../../model/elastic-response.interface';
import { TruckDetailsQuery } from '../query/truck-details.query';
import * as moment from 'moment';
import { MemberValidationResponse } from '../../model/team-details.interface';
import { MemberValidationInput } from '../../../../model/operational-team.interface';

@Injectable()
export class TruckDetailsService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }
  getTruckDetails(truckQuery: TruckDetailsQuery): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getTruckList, truckQuery);
  }
  getTruckViewDetails(truckQuery: TruckDetailsQuery): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getTeamList, truckQuery);
  }
  getAddTruckBusinessValidation(operGroupCode: string, groupType: string, memeberId: string): Observable<MemberValidationResponse> {
    return this.http.get<MemberValidationResponse>(`${this.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=truck&memberIds=${memeberId}&type=${groupType}&action=add`);
  }

  getRemoveTruckBusinessValidation(operGroupCode: string, groupType: string, memeberId: string): Observable<MemberValidationResponse> {
    return this.http.get<MemberValidationResponse>(`${this.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=truck&memberIds=${memeberId}&type=${groupType}&action=remove`);
  }

  postMemberBusinessValidation(operGrpCode: string, memberRequest: MemberValidationInput): Observable<any> {
    const encodedGroupCode = encodeURIComponent(operGrpCode);
    return this.http.post<any>(`${this.endpoint.postOGMemberAdhocValidations}/trucks/validations?operationalGroupCode=${encodedGroupCode}`,
      memberRequest);
  }

}
