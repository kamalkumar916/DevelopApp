import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { TrailingDetailsQuery } from '../query/trailing-details.query';
import { TeamMemberScrollInformation } from './../../../../model/operational-team.interface';
import { DuplicateAndPairedMemberData, OperationalTeamManagementData, ProfileSortAndSearch } from './../../model/team-details.interface';
import {
    DefaultGridColumn, TrailingGridData,
    OperationalGroupVariables, ErrorToastMsg, TrailingStorableData
} from './trailing-details.interface';
import { SecureModel } from '../../../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../../../config/app.config';

export class TrailingDetailsModel {
    isOperationalGroupChanged: boolean;
    defaultColumns: DefaultGridColumn[];
    operationalGroup: string;
    canSubscribe: boolean;
    trailingData: TrailingGridData[];
    isLoading: boolean;
    isAddTemporaryTableVisible: boolean;
    isSaveCancelBtnsVisible: boolean;
    addEquipmentForm: FormGroup;
    typeaheadList: any[];
    equiTypeList: string[];
    equiTypes: string[];
    storableDataModel: any[];
    localStorableDataModel: any[];
    equipTypeaheadDataList: any[];
    filterGroupCodeVariables: OperationalGroupVariables;
    sortField: string;
    sortOrder: string;
    ascendingOrder: string;
    decendingOrder: string;
    searchText: string;
    totalRecords: number;
    isPaginatorReqd: boolean;
    tblScrollHeight: string;
    isProfileView: boolean;
    addEquipError: any;
    isConfirmDialogVisible: boolean;
    selectedEquipCode: string;
    operationalGroupData: OperationalTeamManagementData;
    memberValidationResponseMessage: DuplicateAndPairedMemberData;
    removedTrailingListData: TrailingGridData[];
    isRemoveCancelBtnsVisible: boolean;
    trailingFormCheckBoxArray: FormControl[];
    unableToRemoveEquipment: ErrorToastMsg;
    storableTrailingListData: TrailingStorableData[];
    userInputSearchSubject: Subject<string>;
    profileSortAndSearchQuery: ProfileSortAndSearch;
    trailingListElasticQuery: TrailingDetailsQuery;
    isTrailingExist: boolean;
    isActiveOperationalGroup: boolean;
    isNewOperationalGroup: boolean;
    operationalGroupForm: FormGroup;
    dateTimeFormat: string;
    overRideTrailingEquipment: string;
    overRideTrailingErrorMsgs: string[];
    esEquipmentData: TrailingGridData[];
    teamDetailsScrollInformation: TeamMemberScrollInformation;
    totalMembersForScrollValidation: number;
    isScrollServiceHappend: boolean;
    recordFrom: number;
    recordDefaultSize: number;
    isTrailingEquipmentListPopulated: boolean;
    isTrailerListSorted: boolean;
    defaultEquipmentType: string;
    addEquipmentButton: SecureModel;
    appConfig;


    constructor(private readonly formBuilder: FormBuilder) {
        this.typeaheadList = [];
        this.storableDataModel = [];
        this.isConfirmDialogVisible = false;
        this.isAddTemporaryTableVisible = true;
        this.addEquipmentForm = this.formBuilder.group({
            equipmentCode: ['', Validators.required],
            equipmentCheckBoxes: formBuilder.array([]),
            addTrailingCheckBox: [false],
            trailingEquipmentSearch: ['']
        });
        this.equiTypes = ['Chassis', 'Trailer', 'Container'];
        this.defaultColumns = [
            {
                property: 'Equipment', name: 'Equipment',
                'sortableDataMember': 'OperationalGroupEquipmentAssignment.EquipmentNumber.keyword'
            },
            {
                property: 'Type', name: 'Type',
                'sortableDataMember': 'OperationalGroupEquipmentAssignment.EquipmentClassificationCode.keyword'
            }
        ];

        this.addEquipError = {
            severity: 'error',
            summary: 'Missing Required Information',
            detail: 'Provide the required information in highlighted fields and save again'
        };
        this.unableToRemoveEquipment = {
            severity: 'error',
            summary: 'Unable to Remove Trailing Equipment',
            detail: 'This Equipment is only assigned to this fleet and cannot be unassigned'
        };
        this.canSubscribe = false;
        this.trailingData = [];
        this.filterGroupCodeVariables = {
            from: 0,
            size: 5,
            assetStatus: '',
            operationalGroupCode: ''
        };
        this.ascendingOrder = 'asc';
        this.decendingOrder = 'desc';
        this.searchText = '';
        this.totalRecords = 0;
        this.isPaginatorReqd = false;
        this.isRemoveCancelBtnsVisible = false;
        this.removedTrailingListData = [];
        this.storableTrailingListData = [];
        this.userInputSearchSubject = new Subject<string>();
        this.profileSortAndSearchQuery = {
            memberStartFrom: 0,
            expirationTimestamp: '',
            searchTxt: '',
            sortableMember: 'OperationalGroupEquipmentAssignment.EffectiveTimestamp',
            sortableEvent: { sortOrder: -1 }
        };
        this.trailingListElasticQuery = {};
        this.isTrailingExist = false;
        this.isActiveOperationalGroup = true;
        this.dateTimeFormat = 'YYYY-MM-DD HH:mm:ss.sss Z';
        this.esEquipmentData = [];
        this.overRideTrailingEquipment = 'N';
        this.overRideTrailingErrorMsgs = [];
        this.defaultEquipmentType = '';
        this.appConfig = AppConfig.getConfig();
        this.addEquipmentButton = { url: this.appConfig.api.admin.getOperationalTeamDetails, operation: 'C' };
    }
}

