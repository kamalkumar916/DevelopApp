import {
  Component, OnInit, Input, Output, EventEmitter, ElementRef, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, OnDestroy
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { DateUtils } from '../../../../../../shared/jbh-app-services/date-utils';
import * as lodashutils from 'lodash';
import { Table } from 'primeng/table';
import { MessageService } from 'primeng/components/common/messageservice';
import { Utils } from '../../../../../../shared/jbh-app-services/utils';
import { MemberValidationResponse, OperationalTeamManagementData } from './../model/team-details.interface';
import { OperationalGroupCarrierAssignment, MemberValidationInput } from './../../../model/operational-team.interface';
import { CarrierDetailsModel } from './models/carrier-details.model';
import { CarrierDetailsService } from './services/carrier-details.service';
import { CarrierDetailsUtilityService } from './services/carrier-details-utility.service';
import { CarrierDetailsQuery } from './query/carrier-details.query';
import { OperationalTeamUtilityService } from '../../../services/operational-team-utility.service';
import { CarrierListData, TabChangeEvent, SetDefaultColumns, PageView } from './models/carrier-details.interface';
import { ElasticResponseModel } from '../../../../../model/elastic-response.interface';
import { SortView } from '../../model/team-list.interface';


@Component({
  selector: 'app-carrier-details',
  templateUrl: './carrier-details.component.html',
  styleUrls: ['./carrier-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class CarrierDetailsComponent implements OnInit, OnDestroy {

  @Input() set operationalGroupCode(operationalGroupCodeArg: string) {
    this.carrierDetailsModel.storableDataModel = [];
    this.carrierDetailsModel.isOperationalGroupChanged = true;
    if (operationalGroupCodeArg) {
      this.carrierDetailsModel.filterGroupCodeVariables.operationalGroup = operationalGroupCodeArg;
    }
  }
  @Input()
  set profileView(isProfileViewArg: boolean) {
    this.carrierDetailsModel.isProfileView = isProfileViewArg;
  }
  @Input()
  set scrollInfoOnDetails(scrollInformation: string) {
    if (scrollInformation) {
      this.carrierDetailsModel.teamDetailsScrollInformation = JSON.parse(scrollInformation);
      this.infiniteScrollImplementation();
    }
  }
  @Input()
  set parentTabChangeDetection(parentTabChangeDetectionObject: TabChangeEvent) {
    if (parentTabChangeDetectionObject && parentTabChangeDetectionObject.index === 2) {
      this.resetCarrierListFields();
      this.carrierTable._sortOrder = null;
      this.carrierTable._sortField = null;
      this.carrierDetailsModel.carrierData = [];
      this.carrierDetailsModel.isCarrierListSorted = false;
      this.carrierDetailsModel.carrierDetailsForm['controls']['tempCarrierCheckBoxes']['controls'] = [];
      this.onCancelBtnClicked();
      this.carrierUtility.resetProfileViewQuery(this);
      if (!this.carrierDetailsModel.isNewOperationalGroup) {
        this.callCarrierListService();
      } else {
        this.setLocalStoreDataOnTabNavigation();
        this.carrierUtility.setCarrierCheckBoxFormControl(this);
      }
      this.changeDetector.detectChanges();
    }
  }
  @Input()
  set operationalGroupData(operationalGroupDataArg: OperationalTeamManagementData) {
    this.carrierDetailsModel.operationalGroupData = operationalGroupDataArg;
    this.carrierDetailsModel.isActiveOperationalGroup = !(operationalGroupDataArg && operationalGroupDataArg.status === 'Inactive');
    if (!this.carrierDetailsModel.isActiveOperationalGroup) {
      this.carrierDetailsModel.carrierData = [];
      this.changeDetector.detectChanges();
    }
  }
  @Input()
  set newOperationalTeamToAdd(isNewOperationalTeamToAdd: boolean) {
    this.carrierDetailsModel.isNewOperationalGroup = isNewOperationalTeamToAdd;
  }
  @Input()
  set operationalGroupForm(operationalGroupForm: FormGroup) {
    this.carrierDetailsModel.operationalGroupForm = operationalGroupForm;
  }
  @Output() addMemberClicked = new EventEmitter();
  @Output() profileSortAndSearch = new EventEmitter();
  @ViewChild('opTeamCarrierTable') private readonly carrierTable: Table;
  @ViewChild('opTeamTable') opTeamTable: ElementRef;

  carrierDetailsModel: CarrierDetailsModel;

  constructor(private readonly carrierService: CarrierDetailsService, private readonly formBuilder: FormBuilder,
    private readonly utilityServices: OperationalTeamUtilityService, private readonly changeDetector: ChangeDetectorRef,
    private readonly carrierUtility: CarrierDetailsUtilityService, private readonly messageService: MessageService) {
    this.carrierDetailsModel = new CarrierDetailsModel(this.formBuilder);
  }

  ngOnInit() {
    this.carrierDetailsModel.canSubscribe = true;
    this.resetCarrierListFields();
    this.searchInputListener();
  }

  ngOnDestroy() {
    this.carrierDetailsModel.canSubscribe = false;
    this.carrierDetailsModel.storableDataModel = [];

  }
  hasAccess(actionBtnName: string): boolean {
    return this.utilityServices.hasAccess(actionBtnName);
  }
  getOperationalGroupCode(): string {
    return ((this.carrierDetailsModel.operationalGroupForm &&
      this.carrierDetailsModel.operationalGroupForm.controls['operationalGroupIdentifier'].value) ||
      this.carrierDetailsModel.operationalGroup || this.carrierDetailsModel.filterGroupCodeVariables.operationalGroup);
  }

  addCarrier(event: Event) {
    if (this.carrierDetailsModel.operationalGroupForm.valid) {
      this.utilityServices.setIsAddMemberClicked(true, this.getOperationalGroupCode());
      this.carrierDetailsModel.isEnable = !this.carrierDetailsModel.isEnable;
      this.carrierDetailsModel.isShowSaveLink = true;
      this.carrierDetailsModel.isAddBtnVisible = false;
      this.changeDetector.detectChanges();
    }
    this.addMemberClicked.emit();
  }

  viewCarrierList(carrierQuery: any, callBackFn?: any) {
    this.carrierService.getCarrierDetailsList(carrierQuery).pipe(
      takeWhile(() => this.carrierDetailsModel.canSubscribe),
      finalize(() => {
        this.carrierDetailsModel.isCarrierListPopulated = true;
        if (callBackFn) { callBackFn(); }
        this.carrierDetailsModel.isLoading = false;
        this.changeDetector.detectChanges();
      }))
      .subscribe((data) => {
        if (data && data.hits && data.hits.hits) {
          const carrierListBuckets = data.hits.hits[0];
          if (carrierListBuckets) {
            const carrierViewList = carrierListBuckets['inner_hits'].OperationalGroupCarrierAssignment.hits.hits;
            this.carrierDetailsModel.totalMembersForScrollValidation =
              carrierListBuckets['inner_hits'].OperationalGroupCarrierAssignment.hits.total;
            if (this.carrierDetailsModel.isScrollServiceHappend && this.carrierDetailsModel.carrierData) {
              this.carrierDetailsModel.carrierData =
                this.carrierDetailsModel.carrierData.concat(this.getIteratedCarrierList(carrierViewList));
            } else {
              this.carrierDetailsModel.carrierData = this.getIteratedCarrierList(carrierViewList);
            }
            this.carrierDetailsModel.isScrollServiceHappend = false;
          } else {
            this.carrierDetailsModel.carrierData = [];
          }
          this.setLocalStoreDataOnTabNavigation();
        }
      }, (error: Error) => {
        this.carrierDetailsModel.isLoading = false;
        this.resetCarrierDetailsView();
      });
    this.changeDetector.detectChanges();
  }

  setLocalStoreDataOnTabNavigation() {
    if (this.carrierDetailsModel.operationalGroupData) {
      const updatedLocalStoredcarrier = { localStoreArr: [] };
      const tempCarrierData = this.carrierDetailsModel.carrierData;
      const operGroup = this.carrierDetailsModel.operationalGroupData;
      if (operGroup) {
        const localCarrierDataList =
          this.utilityServices.getLocalStorageData(this.getOperationalGroupCode(), 'operationalGroupCarrierAssignments');
        const localRemovedCarrierList = this.utilityServices.getLocalStorageData(this.getOperationalGroupCode(),
          'operationalGroupUnAssignmentCarrierIds');
        lodashutils.forEach(localRemovedCarrierList, (carrierId: number) => {
          const removedDataIdx = lodashutils.findIndex(tempCarrierData, { 'carrierId': carrierId.toString() });
          if (removedDataIdx !== -1) {
            tempCarrierData.splice(removedDataIdx, 1);
          }
        });
        lodashutils.forEach(localCarrierDataList, (eachCarrierData: OperationalGroupCarrierAssignment) => {
          const isCarrierExistInES = (lodashutils.findIndex(tempCarrierData,
            { 'carrierId': (eachCarrierData.carrierId) }) !== -1);
          if (!isCarrierExistInES) {
            this.getStorageData(eachCarrierData, tempCarrierData);
            updatedLocalStoredcarrier.localStoreArr.push(eachCarrierData);
          }
        });
        this.utilityServices.setLocalStorageData(this.getOperationalGroupCode(),
          'operationalGroupCarrierAssignments', updatedLocalStoredcarrier.localStoreArr);
        this.carrierDetailsModel.carrierData = tempCarrierData;
      }
    }
  }

  getCarrierNameList(event: any) {
    this.carrierDetailsModel.carrierSelectedData = null;
    this.carrierDetailsModel.carrierDetailsForm.controls['carrierDetailsCode'].setErrors(null);
    this.carrierDetailsModel.filterVariables.searchValue = event.query;
    const carrierQuery = CarrierDetailsQuery.getCarrierNameQuery(this.carrierDetailsModel.filterVariables);
    this.carrierService.getCarrierName(carrierQuery).pipe(
      takeWhile(() => this.carrierDetailsModel.canSubscribe),
      finalize(() => {
        this.changeDetector.detectChanges();
      }))
      .subscribe((data: ElasticResponseModel) => {
        if (data && data.hits && data.hits.hits) {
          this.carrierDetailsModel.carrierListData = data.hits.hits.map((assetName) => {
            return {
              'carrierName': assetName._source.CarrierName.trim(),
              'carrierCode': assetName._source.CarrierCode.trim(),
              'carrierId': assetName._source.CarrierID
            };
          });
        }
      }, (error: Error) => {
        this.carrierDetailsModel.carrierListData = [];
      });
  }

  onCancelBtnClicked() {
    this.carrierDetailsModel.isEnable = false;
    this.carrierDetailsModel.isAddBtnVisible = true;
    this.carrierDetailsModel.isShowSaveLink = false;
    this.carrierDetailsModel.isRemoveLinkVisible = false;
    this.carrierDetailsModel.removeListData = [];
    this.carrierDetailsModel.carrierDetailsForm.reset();
    this.utilityServices.setIsRemoveMemberClicked(false, this.getOperationalGroupCode());
    this.utilityServices.setIsAddMemberClicked(false, this.getOperationalGroupCode());
    this.changeDetector.detectChanges();
  }

  onCarrierSelected(event) {
    this.carrierDetailsModel.carrierSelectedData = event;
    this.carrierDetailsModel.carrierDetailsForm.controls['carrierDetailsCode'].setValue(event);
  }

  saveCarrierDataToLocal() {
    this.carrierUtility.pushCheckBoxIntoControlsArray(this);
    const selectedEquipment = this.carrierDetailsModel.carrierSelectedData;
    const storableData = lodashutils.cloneDeep(this.carrierUtility.getStorableData(this, selectedEquipment));
    this.carrierDetailsModel.storableDataModel.push(this.carrierUtility.getStorableData(this, selectedEquipment));
    this.utilityServices.setLocalStorageData(this.getOperationalGroupCode(),
      'operationalGroupCarrierAssignments', this.carrierDetailsModel.storableDataModel);
    this.carrierDetailsModel.carrierData.unshift(lodashutils.assign(storableData, { 'carrierId': storableData.carrierId }));
    this.onCancelBtnClicked();
    this.changeDetector.detectChanges();
  }

  initInlineSaveValidation() {
    const activeMembers = this.carrierDetailsModel.isNewOperationalGroup ? 0 :
      Number(this.carrierDetailsModel.operationalGroupData.totalMembers);
    const membersInOGForValidation =
      this.utilityServices.checkMaxMembersInOperationalGroup(this.getOperationalGroupCode(), activeMembers);
    if (!membersInOGForValidation.isMemberExistsOverLimit) {
      const operGroup = this.carrierDetailsModel.operationalGroupData;
      const selectedEquipment = this.carrierDetailsModel.carrierSelectedData;
      const isAddedCarrierDuplicated = this.carrierUtility.isAddedCarrierDuplicated(this, selectedEquipment.carrierId);
      if (!isAddedCarrierDuplicated.isRemovedInLocalStore && !isAddedCarrierDuplicated.isAddedInLocalStore) {
        this.carrierDetailsModel.isLoading = true;
        const operGroupType = this.carrierDetailsModel.operationalGroupForm.controls['operationalGroupCategory'].value.label
          || operGroup.operationalGroupTypeCode;
        const requestData: MemberValidationInput = {
          memberIds: selectedEquipment.carrierId.toString(), operationalGroupType: operGroupType,
          action: 'add', memberName: this.carrierUtility.getSelectedCarrier(this)
        };
        this.carrierService.postMemberBusinessValidation(this.getOperationalGroupCode(), requestData).pipe(
          takeWhile(() => this.carrierDetailsModel.canSubscribe),
          finalize(() => {
            this.carrierDetailsModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
          .subscribe((response: any) => {
            this.saveCarrierDataToLocal();
            this.carrierDetailsModel.isLoading = false;
            this.changeDetector.detectChanges();
          }, (validationError) => {
            this.carrierUtility.setValidationError(this, validationError);
          });
      } else if (isAddedCarrierDuplicated.isRemovedInLocalStore && !isAddedCarrierDuplicated.isAddedInLocalStore) {
        this.saveCarrierDataToLocal();
      }
    } else {
      this.messageService.clear();
      this.messageService.add(membersInOGForValidation.memberExistsToastMsg);
    }
  }

  saveCarrierData() {
    if (this.carrierDetailsModel.carrierDetailsForm.valid && this.carrierDetailsModel.carrierSelectedData) {
      this.carrierDetailsModel.carrierDetailsForm.controls['carrierDetailsCode'].setErrors(null);
      this.initInlineSaveValidation();
    } else {
      if (!this.carrierDetailsModel.carrierSelectedData) {
        this.carrierDetailsModel.carrierDetailsForm.controls['carrierDetailsCode'].setErrors({ incorrect: true });
      }
      this.messageService.clear();
      this.messageService.add(this.carrierDetailsModel.missingRequiredInfoError);
    }
    this.carrierDetailsModel.carrierDetailsForm.controls['carrierDetailsCode'].markAsTouched();
    this.changeDetector.detectChanges();
  }

  resetCarrierDetailsView() {
    this.carrierDetailsModel.carrierDetailsForm.reset();
    this.carrierDetailsModel.isShowSaveLink = false;
    this.carrierDetailsModel.isEnable = false;
    this.carrierDetailsModel.isAddBtnVisible = true;
    this.carrierDetailsModel.carrierDetailsForm['controls']['tempCarrierCheckBoxes']['controls'] = [];
    this.changeDetector.detectChanges();
  }

  onRemoveCarrierClicked() {
    const removedCarriers = lodashutils.map(this.carrierDetailsModel.removeListData, 'carrierId');
    this.carrierUtility.removeCarrierFromTable(this, removedCarriers);
    this.utilityServices.setIsRemoveMemberClicked(false, this.getOperationalGroupCode());
  }

  onRemoveCarrierCancelClicked() {
    this.carrierDetailsModel.isRemoveLinkVisible = false;
    this.carrierDetailsModel.removeListData = [];
    this.carrierDetailsModel.isAddBtnVisible = true;
    lodashutils.forEach(this.carrierDetailsModel.tempCarrierFormCheckBoxArray, (eachCarrierCheckBox: FormControl) => {
      eachCarrierCheckBox['tempCarrierCheckBox'].setValue(false);
    });
    this.utilityServices.setIsRemoveMemberClicked(false, this.carrierDetailsModel.operationalGroup);
    this.changeDetector.detectChanges();
  }

  tempCarrierNewRowCheckBoxChanged() {
    this.carrierDetailsModel.carrierDetailsForm.controls.newCarrierCheckBox.setValue(false);
    this.setActionRequiredError();
  }

  tempCarrierRowCheckBoxChanged(isChecked: boolean, rowIndex: number, rowData: CarrierListData) {
    if (this.utilityServices.getIsAddMemberClicked()) {
      this.setActionRequiredError();
      this.carrierDetailsModel.tempCarrierFormCheckBoxArray[rowIndex]['tempCarrierCheckBox'].setValue(false);
    } else {
      this.carrierUtility.setRemovedCarrierData(this, isChecked, rowData);
      this.onValidateCheckBox();
    }
    this.changeDetector.detectChanges();
  }

  onValidateCheckBox() {
    const checkBoxArray = this.carrierDetailsModel.tempCarrierFormCheckBoxArray;
    const checkedValues = lodashutils.filter(checkBoxArray, (carrierCheckBox: FormControl): boolean => {
      return carrierCheckBox['tempCarrierCheckBox']['value'];
    });
    this.carrierDetailsModel.isAddBtnVisible = (checkedValues.length === 0);
    this.carrierDetailsModel.isRemoveLinkVisible = (checkedValues.length !== 0);
    this.utilityServices.setIsRemoveMemberClicked(this.carrierDetailsModel.isRemoveLinkVisible, this.getOperationalGroupCode());
  }

  setActionRequiredError() {
    this.messageService.clear();
    this.messageService.add(this.utilityServices.getActionReqdError());
  }

  onSearch() {
    this.carrierDetailsModel.userInputSearchSubject.next(this.carrierDetailsModel.carrierDetailsForm.controls.carrierListSearch.value);
  }

  searchInputListener() {
    this.carrierDetailsModel.userInputSearchSubject.pipe(
      debounceTime(50),
      distinctUntilChanged(),
      takeWhile(() => this.carrierDetailsModel.canSubscribe))
      .subscribe(() => {
        let searchAndSortQuery: any;
        if (this.carrierDetailsModel.isProfileView) {
          this.carrierDetailsModel.isLoading = true;
          this.resetCarrierListFields();
          this.carrierDetailsModel.isCarrierListSorted = true;
          this.profileSortAndSearch.emit();
          searchAndSortQuery = lodashutils.cloneDeep(this.carrierDetailsModel.profileSortAndSearchQuery);
          searchAndSortQuery.searchTxt = Utils.formattedSearchText(
            this.carrierDetailsModel.carrierDetailsForm.controls.carrierListSearch.value
          );
          const carrierserachQuery = CarrierDetailsQuery.getCarrierListElasticQuery(
            this.carrierDetailsModel.filterGroupCodeVariables.operationalGroup, this.carrierDetailsModel.recordFrom,
            this.carrierDetailsModel.recordDefaultSize, searchAndSortQuery);
          this.carrierDetailsModel.profileSortAndSearchQuery = lodashutils.cloneDeep(searchAndSortQuery);
          this.viewCarrierList(carrierserachQuery);
        }
      });
  }

  onSort(event: SortView) {
    if (this.carrierDetailsModel.isProfileView) {
      this.resetCarrierListFields();
      this.carrierDetailsModel.isCarrierListSorted = true;
      this.profileSortAndSearch.emit();
      const searchAndSortQuery = lodashutils.cloneDeep(this.carrierDetailsModel.profileSortAndSearchQuery);
      searchAndSortQuery.sortableMember = 'OperationalGroupCarrierAssignment.CarrierName.keyword';
      searchAndSortQuery.sortableEvent = { sortOrder: event.sortOrder ? event.sortOrder : 1 };
      const carrierserachQuery = CarrierDetailsQuery.getCarrierListElasticQuery(
        this.carrierDetailsModel.filterGroupCodeVariables.operationalGroup, this.carrierDetailsModel.recordFrom,
        this.carrierDetailsModel.recordDefaultSize, searchAndSortQuery
      );
      this.carrierDetailsModel.profileSortAndSearchQuery = lodashutils.cloneDeep(searchAndSortQuery);
      this.carrierDetailsModel.isLoading = true;
      this.viewCarrierList(carrierserachQuery);
    }
  }
  getStorageData(eachCarrierData: OperationalGroupCarrierAssignment, tempCarrierData: CarrierListData[]) {
    tempCarrierData.unshift({
      'carrierName': eachCarrierData.carrierName, 'carrierCode': eachCarrierData.carrierCode, 'carrierId': eachCarrierData.carrierId
    });
  }
  resetCarrierListFields() {
    this.carrierDetailsModel.totalMembersForScrollValidation = 0;
    this.carrierDetailsModel.isScrollServiceHappend = false;
    this.carrierDetailsModel.recordFrom = 0;
    this.carrierDetailsModel.recordDefaultSize = 100;
  }
  infiniteScrollImplementation() {
    const scrollableCount = this.carrierDetailsModel.recordFrom +
      this.carrierDetailsModel.recordDefaultSize;
    if (this.carrierDetailsModel.teamDetailsScrollInformation.isMemberServiceNeedsToCall
      && this.carrierDetailsModel.isCarrierListPopulated
      && this.carrierDetailsModel.teamDetailsScrollInformation.currentTabSelectionIdx === 2 &&
      this.carrierDetailsModel.totalMembersForScrollValidation > scrollableCount) {
      this.carrierDetailsModel.isScrollServiceHappend = true;
      this.carrierDetailsModel.recordFrom = this.carrierDetailsModel.recordFrom +
        this.carrierDetailsModel.recordDefaultSize;
      this.callCarrierListService();
    }
  }
  callCarrierListService() {
    if (this.carrierDetailsModel.isProfileView && this.carrierDetailsModel.isCarrierListSorted) {
      const carrierserachQuery = CarrierDetailsQuery.getCarrierListElasticQuery(
        this.carrierDetailsModel.filterGroupCodeVariables.operationalGroup, this.carrierDetailsModel.recordFrom,
        this.carrierDetailsModel.recordDefaultSize, this.carrierDetailsModel.profileSortAndSearchQuery
      );
      this.viewCarrierList(carrierserachQuery);
    } else {
      this.carrierDetailsModel.isLoading = true;
      const carrierQuery = CarrierDetailsQuery.getOperationalCodeQuery(this.carrierDetailsModel.filterGroupCodeVariables,
        this.carrierDetailsModel.recordFrom,
        this.carrierDetailsModel.recordDefaultSize);
      this.viewCarrierList(carrierQuery, () => {
        this.carrierDetailsModel.storableCarrierListData = lodashutils.cloneDeep(this.carrierDetailsModel.carrierData);
        this.carrierUtility.setCarrierCheckBoxFormControl(this);
        this.carrierDetailsModel.isCarrierListExist = (this.carrierDetailsModel.carrierData.length !== 0);
        this.changeDetector.detectChanges();
      });
    }
  }
  getIteratedCarrierList(carrierViewList) {
    return carrierViewList.map((carrierData): CarrierListData => {
      return {
        'operationalGroupCarrierAssignmentId': carrierData._source.OperationalGroupCarrierAssignmentID,
        'carrierName': carrierData._source.CarrierName,
        'carrierCode': carrierData._source.CarrierCode,
        'carrierId': carrierData._source.CarrierID,
        'effectiveTimestamp': carrierData._source.EffectiveTimestamp
      };
    });
  }
}
