import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { TrailingDetailsService } from './trailing-details.service';
import { configureTestSuite } from 'ng-bullet';

describe('TrailingDetailsService', () => {
  let service: TrailingDetailsService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [TrailingDetailsService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(TrailingDetailsService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes expected getTrailingDetails calls', () => {
    const param = 'L258';
    service.getTrailingDetails(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTeamList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getTrailEquipmentOnTypeahead calls', () => {
    const param = 'L258';
    service.getTrailEquipmentOnTypeahead(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTruckList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getAddTrailerBusinessValidation calls', () => {
    const operGroupCode = 'OG';
    const groupType = 'OG1';
    const memberId = 'L123';
    service.getAddTrailerBusinessValidation(operGroupCode, groupType, memberId).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=trailingequipment&memberIds=${memberId}&type=${groupType}&action=add`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected getRemoveTrailerBusinessValidation calls', () => {
    const operGroupCode = 'OG';
    const groupType = 'OG1';
    const memberId = 'L123';
    service.getRemoveTrailerBusinessValidation(operGroupCode, groupType, memberId).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=trailingequipment&memberIds=${memberId}&type=${groupType}&action=remove`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected postMemberBusinessValidation calls', () => {
    const operGrpCode = 'OG';
    const param = {
      memberIds: 'L123',
      operationalGroupType: 'OG',
      action: 'Update'
    };
    service.postMemberBusinessValidation(operGrpCode, param).subscribe();
    const req =
      httpTestingController.expectOne(
        `${service.endpoint.postOGMemberAdhocValidations}/trailingequipments/validations?operationalGroupCode=${operGrpCode}`);
    expect(req.request.method).toEqual('POST');
  });
});
