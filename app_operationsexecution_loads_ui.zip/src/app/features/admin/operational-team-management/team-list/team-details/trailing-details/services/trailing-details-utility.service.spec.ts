import { TestBed, inject, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { configureTestSuite } from 'ng-bullet';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { TrailingDetailsUtilityService } from './trailing-details-utility.service';
import { TrailingDetailsComponent } from './../trailing-details.component';
import { TableModule } from 'primeng/table';
import { CheckboxModule, PaginatorModule, AutoCompleteModule } from 'primeng/primeng';
import { DialogModule } from 'primeng/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesModule } from 'src/app/shared/pipes/pipes.module';
import { JbhLoaderModule } from 'src/app/shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from 'src/app/shared/directives/directives.module';
import { TrailingDetailsService } from './trailing-details.service';
import { OperationalTeamUtilityService } from '../../../../services/operational-team-utility.service';
import { LocalStorageService } from 'src/app/shared/jbh-app-services/local-storage.service';
import { UserService } from 'src/app/shared/jbh-esa';
import { MessageService } from 'primeng/components/common/messageservice';

describe('TrailingDetailsUtilityService', () => {
  let service: TrailingDetailsUtilityService;
  let component: TrailingDetailsComponent;
  let fixture: ComponentFixture<TrailingDetailsComponent>;
  let messageService: MessageService;
  const formBuilder = new FormBuilder();
  let trailingForm: FormGroup;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [TrailingDetailsComponent],
      imports: [RouterTestingModule, TableModule, FormsModule, ReactiveFormsModule, CheckboxModule, PaginatorModule,
        AutoCompleteModule, DialogModule, HttpClientTestingModule, NoopAnimationsModule, PipesModule,
        JbhLoaderModule, DirectivesModule],
      providers: [TrailingDetailsUtilityService, AppConfigService, FormBuilder, TrailingDetailsService,
        OperationalTeamUtilityService, LocalStorageService, UserService, MessageService]
    })
      .compileComponents();
  });
  beforeEach(() => {
    service = TestBed.get(TrailingDetailsUtilityService);
    fixture = TestBed.createComponent(TrailingDetailsComponent);
    component = fixture.componentInstance;
    messageService = TestBed.get(MessageService);
    trailingForm = formBuilder.group({
      equipmentCode: ['', Validators.required],
      equipmentCheckBoxes: formBuilder.array([]),
      addTrailingCheckBox: [false],
      trailingEquipmentSearch: ['']
    });
    fixture.detectChanges();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getEmptyDataForTrailingData should return expected value', () => {
    const returnValue = service.getEmptyDataForTrailingData();
    expect(returnValue.rowEditable).toBe(true);
  });
  it('getEmptyDataForTrailingData should return expected value', () => {
    const returnValue = service.getEmptyDataForTrailingData();
    expect(returnValue.operationalGroupEquipmentAssignmentID).toBe(null);
  });
  it('getNewlyAddedRecordForTrailingData', () => {
    const data = {
      rowEditable: false, EquipmentNumber: 'JBHZ12345',
      EquipmentClassificationDescription: 'Trailer',
      equipmentID: 12345,
      operationalGroupEquipmentAssignmentID: null, effectiveTimestamp: '',
      expirationTimestamp: ''
    };
    const returnValue = service.getNewlyAddedRecordForTrailingData('Trailer', 'JBHZ12345', '12345');
    expect(returnValue).toEqual(data);
  });
  it('getDefaultValidationResponse have been called with the value', () => {
    const returnValue = service.getDefaultValidationResponse('DCS');
    expect(returnValue.duplicateMemberAssignmentId).toBe(null);
  });
  it('setInCurrentOGToastMsg have been called', () => {
    spyOn(messageService, 'clear');
    spyOn(messageService, 'add');
    service.setInCurrentOGToastMsg(component, 'Error', 'Action cannot be performed');
    expect(messageService.clear).toHaveBeenCalled();
  });
  it('getStorableData have been called with the value', () => {
    component.trailingDetailsModel.overRideTrailingEquipment = 'Y';
    const data = {
      AssetUnitPrefixAndID: 'L12345',
      AssetStatus: 'Available',
      AssetUnitID: '1234',
      OperationalGroup: 'DCS',
      BusinessUnit: 'DCS',
      AssetClassificationCode: 'Container',
      AssetUnitPrefix: 'JBHZ',
      AssetID: 'L12345',
      equipmentID: 12345,
      prefixWithEquipmentNumber: 'JBHZ12345',
      equipmentClassificationCode: 'Container',
    };
    const response = {
      'equipmentId': 12345,
      'equipmentUnitId': 'JBHZ12345',
      'equipmentClassificationCode': 'Container',
      'overrideTrailingEquipmentValidations': 'Y',
    };
    const returnValue = service.getStorableData(component, data);
    expect(returnValue).toEqual(response);
  });
  it('executeMemberValidation have been executing else block', () => {
    const memberValidation = {
      isOverridedValidation: false,
      memberValidationMsgs: ['Action Required'],
      validationMsgType: 'error',
      validationMsgCode: 'error',
      validationMsgTitle: 'Error'
    };
    spyOn(service, 'setInCurrentOGToastMsg');
    service.executeMemberValidation(component, memberValidation);
    expect(service.setInCurrentOGToastMsg).toHaveBeenCalled();
  });
  it('executeMemberValidation have been executing if block', () => {
    const memberValidation = {
      isOverridedValidation: true,
      memberValidationMsgs: ['Action Required'],
      validationMsgType: 'error',
      validationMsgCode: 'error',
      validationMsgTitle: 'Error'
    };
    service.executeMemberValidation(component, memberValidation);
    expect(component.trailingDetailsModel.overRideTrailingErrorMsgs).toEqual(['Action Required']);
    expect(component.trailingDetailsModel.isConfirmDialogVisible).toEqual(true);
  });
  it('getFormGroupForEquipment has to be truthy', () => {
    const returnValue = service.getFormGroupForEquipment();
    expect(returnValue).toBeTruthy();
  });
  it('setRemovedTrailingData have been called', () => {
    const rowData = {
      rowEditable: false,
      EquipmentNumber: '12345',
      EquipmentClassificationDescription: 'Container',
      equipmentID: 12345,
      operationalGroupEquipmentAssignmentID: 12345,
      effectiveTimestamp: 'string',
      expirationTimestamp: 'string'
    };
    service.setRemovedTrailingData(component, true, rowData);
    expect(component.trailingDetailsModel.removedTrailingListData).toEqual([rowData]);
  });
  it('setTrailingCheckBoxFormControl has to be truthy', () => {
    component.trailingDetailsModel.addEquipmentForm = trailingForm;
    service.setTrailingCheckBoxFormControl(component);
    expect(service.setTrailingCheckBoxFormControl).toBeTruthy();
  });
});
