
import * as bodybuilderUtils from 'bodybuilder';
import { ProfileSortAndSearch } from './../../model/team-details.interface';

export class DriverDetailsQuery {
    static readonly operationalGroupDriverAssignmentTypeCode = 'OperationalGroupDriverAssignment.OperationalGroupDriverAssignmentTypeCode';
    static readonly operationalGroup = 'OperationalGroupCode.keyword';
    static readonly expirationTime = 'OperationalGroupDriverAssignment.ExpirationTimestamp';
    static readonly driverAssignmentUserID = 'OperationalGroupDriverAssignment.UserID';
    static readonly driverAssignmentJobGroup = 'OperationalGroupDriverAssignment.JobGroup';
    static getDriverDetailsQuery(operationalGroupCode: string, expirationEndDate: string, recordsFrom: number, defaultSize: number) {
        const tempMatchQuery = {
            'match':
            {
                [this.operationalGroupDriverAssignmentTypeCode]: 'Temporary'
            }
        };
        return {
            '_source': [
                'OperationalGroupCode',
                'OperationalGroupDriverAssignment'
            ],
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                [this.operationalGroup]: operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupDriverAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': defaultSize,
                                    'sort': [{
                                        'OperationalGroupDriverAssignment.EffectiveTimestamp': {
                                            'order': 'desc'
                                        }
                                    }]
                                },
                                'query': {
                                    'bool': {
                                        'should': [
                                            {
                                                'bool': {
                                                    'must': [
                                                        {
                                                            'match': {
                                                                [this.operationalGroupDriverAssignmentTypeCode]: 'Permanent'
                                                            }
                                                        },
                                                        {
                                                            'range': {
                                                                [this.expirationTime]: {
                                                                    'gte': 'now',
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                'bool': {
                                                    'must': [
                                                        {
                                                            'range': {
                                                                [this.expirationTime]: {
                                                                    'gte': 'now',
                                                                    'lte': expirationEndDate,
                                                                    'format': 'MM/dd/YYYY hh:mm a z'
                                                                }
                                                            }
                                                        },
                                                        tempMatchQuery
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };
    }

    static getTemporaryDriverElasticQuery(operationalGroupCode: string, recordsFrom: number,
        noOfRecords: number, sortAndSearchProperty: ProfileSortAndSearch) {
        return {
            '_source': [
                'OperationalGroupCode',
                'OperationalGroupDriverAssignment'
            ],
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                [this.operationalGroup]: operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupDriverAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': noOfRecords,
                                    'sort': this.getSortableQueryArray(sortAndSearchProperty)
                                },
                                'query': {
                                    'bool': {
                                        'must': [
                                            {
                                                'range': {
                                                    [this.expirationTime]: {
                                                        'gte': 'now',
                                                        'lte': sortAndSearchProperty.expirationTimestamp,
                                                        'format': 'MM/dd/YYYY hh:mm a z'
                                                    }
                                                }
                                            },
                                            {
                                                'match': {
                                                    [this.operationalGroupDriverAssignmentTypeCode]: 'Temporary'
                                                }
                                            },
                                            {
                                                'bool': {
                                                    'should': this.getDriverDetailsShouldQuery(
                                                        sortAndSearchProperty.searchTxt, sortAndSearchProperty.searchType
                                                    )
                                                }
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };
    }

    static getPermanentDriverElasticQuery(operationalGroupCode: string, recordsFrom: number,
        noOfRecords: number, sortAndSearchProperty: ProfileSortAndSearch) {
        return {
            '_source': [
                'OperationalGroupCode',
                'OperationalGroupDriverAssignment'
            ],
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                [this.operationalGroup]: operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupDriverAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': noOfRecords,
                                    'sort': this.getSortableQueryArray(sortAndSearchProperty)
                                },
                                'query': {
                                    'bool': {
                                        'must': [
                                            {
                                                'match': {
                                                    [this.operationalGroupDriverAssignmentTypeCode]: 'Permanent'
                                                }
                                            },
                                            {
                                                'bool': {
                                                    'should': this.getDriverDetailsShouldQuery(
                                                        sortAndSearchProperty.searchTxt, sortAndSearchProperty.searchType
                                                    )
                                                }
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };
    }

    static getDriverNameRelatedMustQuery(searchTxt: string) {
        const splittedTxt = searchTxt.split(' ');
        return [
            {
                'bool':
                {
                    'should':
                        [
                            {
                                'multi_match': this.getDriverNameQuery('OperationalGroupDriverAssignment.PreferredName', splittedTxt[0])

                            },
                            {
                                'multi_match': this.getDriverNameQuery('OperationalGroupDriverAssignment.FirstName', splittedTxt[0])
                            }
                        ]
                }
            },
            {
                'multi_match': this.getDriverNameQuery('OperationalGroupDriverAssignment.LastName', splittedTxt[0])
            }
        ];
    }

    static getDriverDetailsShouldQuery(searchTxt: string, searchType: string) {
        const searchTxtValueForSearch = (searchType === 'text') ? searchTxt : '';
        const driverListQuery = [];
        if (searchTxt && searchType === 'text') {
            driverListQuery.push({
                'query_string': {
                    'fields': [
                        'OperationalGroupDriverAssignment.PreferredName',
                        'OperationalGroupDriverAssignment.LastName',
                        'OperationalGroupDriverAssignment.FirstName',
                        this.driverAssignmentUserID,
                        this.driverAssignmentJobGroup,
                        'OperationalGroupDriverAssignment.ExpirationTimestamp.text'
                    ],
                    'query': `*${searchTxtValueForSearch}*`,
                    'default_operator': 'AND'
                }
            });
            if (searchTxt.split(' ').length === 2) {
                driverListQuery.push({
                    'bool': {
                        'must': this.getDriverNameRelatedMustQuery(searchTxt)
                    }
                });
            }
        } else if (searchType === 'date') {
            driverListQuery.push({
                'query_string':
                {
                    'fields': ['OperationalGroupDriverAssignment.ExpirationTimestamp.text'],
                    'query': `*${searchTxt.trim()}*`,
                    'default_operator': 'AND'
                }
            });
        }
        return driverListQuery;
    }

    static getSortableQueryArray(sortAndSearchProperty: ProfileSortAndSearch) {
        const sortableArray = [];
        switch (sortAndSearchProperty.sortableMember) {
            case 'Name':
                sortableArray.push({
                    'OperationalGroupDriverAssignment.PreferredName.keyword': this.sortNameQuery(sortAndSearchProperty)
                });
                sortableArray.push({
                    'OperationalGroupDriverAssignment.FirstName.keyword': this.sortNameQuery(sortAndSearchProperty)
                });
                sortableArray.push({
                    'OperationalGroupDriverAssignment.LastName.keyword': this.sortNameQuery(sortAndSearchProperty)
                });
                break;
            case 'End Date':
                sortableArray.push({
                    [this.expirationTime]:
                        (sortAndSearchProperty.sortableEvent.sortOrder === -1) ? 'desc' : 'asc'
                });
                break;
            default:
                sortableArray.push({
                    [sortAndSearchProperty.sortableMember]:
                        (sortAndSearchProperty.sortableEvent.sortOrder === -1) ? 'desc' : 'asc'
                });
                break;
        }
        return sortableArray;
    }

    static getDriverElasticQuery(elasticSearchTxt: string) {
        return bodybuilderUtils()
            .size(6)
            .sort([{ 'personDTO.prefName.keyword': 'asc' }, { 'personDTO.lastName.keyword': 'asc' }])
            .andQuery('match', 'personDTO.isDriver', 'Y')
            .andQuery('match', 'isActive', true)
            .andQuery('query_string', {
                'fields': ['personDTO.prefName', 'personDTO.lastName',
                    'personDTO.emplId', 'personDTO.userId'],
                'query': `${elasticSearchTxt}*`, 'default_operator': 'AND'
            })
            .build();
    }
    static getDriverNameQuery(driverName: string, splittedTxt: string) {
        return {
            'fields': [
                driverName,
                this.driverAssignmentUserID,
                this.driverAssignmentJobGroup
            ],
            'query': `${splittedTxt}*`,
            'type': 'phrase_prefix'
        };
    }
    static sortNameQuery(sortAndSearchProperty: ProfileSortAndSearch) {
        return (sortAndSearchProperty.sortableEvent.sortOrder === -1) ? 'desc' : 'asc';
    }
}
