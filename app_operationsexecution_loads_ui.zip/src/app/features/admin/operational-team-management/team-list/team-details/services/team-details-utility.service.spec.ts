import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../../shared/service/app-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { TeamDetailsUtilityService } from './team-details-utility.service';
import { configureTestSuite } from 'ng-bullet';

describe('TeamDetailsUtilityService', () => {
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [TeamDetailsUtilityService, AppConfigService]
    });
  });

  it('should be created', inject([TeamDetailsUtilityService], (service: TeamDetailsUtilityService) => {
    expect(service).toBeTruthy();
  }));
});
