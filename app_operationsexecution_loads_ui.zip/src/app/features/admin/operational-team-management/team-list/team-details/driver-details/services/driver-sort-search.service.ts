import { Injectable } from '@angular/core';
import * as lodashutils from 'lodash';
import * as moment from 'moment';
import { Utils } from '../../../../../../../shared/jbh-app-services/utils';
import { SortView } from './../../../model/team-list.interface';
import { DriverDetailsQuery } from './../query/driver-details.query';
import { DriverDetailsElasticQuery, OperationalGroupDriverAssignmentDetail } from './../model/driver-details.interface';

@Injectable()
export class DriverSortSearchService {

  constructor() { }

  getDriverSortQuery(parent: any, driverType: string, sortView: SortView): DriverDetailsElasticQuery {
    let postableQuery: DriverDetailsElasticQuery;
    parent.driverDetailsModel.selectedDriverListType = driverType;
    const operationalGroup = parent.driverDetailsModel.operationalGroupData.operationalGroupCode;
    const postableSearchQuery = lodashutils.cloneDeep(parent.driverDetailsModel[`${driverType}ProfileSortAndSearchQuery`]);
    postableSearchQuery.expirationTimestamp = parent.driverDetailsModel.driverExpirationToDate;
    postableSearchQuery.sortableMember = sortView.sortField;
    postableSearchQuery.sortableEvent = { sortOrder: sortView.sortOrder };
    if (driverType === 'temporary') {
      parent.driverDetailsModel.isTemporaryDriverLoaded = true;
      postableQuery = DriverDetailsQuery.getTemporaryDriverElasticQuery(
        operationalGroup, parent.driverDetailsModel.recordFrom, parent.driverDetailsModel.recordDefaultSize, postableSearchQuery
      );
    } else {
      parent.driverDetailsModel.isPermanentDriverLoaded = true;
      postableQuery = DriverDetailsQuery.getPermanentDriverElasticQuery(
        operationalGroup, parent.driverDetailsModel.recordFrom, parent.driverDetailsModel.recordDefaultSize, postableSearchQuery
      );
    }
    parent.driverDetailsModel[`${driverType}ProfileSortAndSearchQuery`] = lodashutils.cloneDeep(postableSearchQuery);
    return postableQuery;
  }

  getDriverElasticSearchQuery(parent: any, driverType: string, searchValue: string): DriverDetailsElasticQuery {
    let postableQuery: DriverDetailsElasticQuery;
    parent.driverDetailsModel.selectedDriverListType = driverType;
    const operationalGroup = parent.driverDetailsModel.operationalGroupData.operationalGroupCode;
    const postableSearchQuery = lodashutils.cloneDeep(parent.driverDetailsModel[`${driverType}ProfileSortAndSearchQuery`]);
    postableSearchQuery.expirationTimestamp = parent.driverDetailsModel.driverExpirationToDate;
    postableSearchQuery.searchTxt = searchValue || '';
    postableSearchQuery.searchTxt = postableSearchQuery.searchTxt.replace(/[^\w\s/]/gi, '');
    postableSearchQuery.searchType = 'text';
    if (driverType === 'temporary') {
      postableSearchQuery.searchType = (this.isDateValid(postableSearchQuery.searchTxt)) ? 'date' : 'text';
      postableSearchQuery.searchTxt = (postableSearchQuery.searchTxt.trim().length !== 0 && postableSearchQuery.searchType !== 'text') ?
        Utils.formattedSearchText(postableSearchQuery.searchTxt) : postableSearchQuery.searchTxt;
      postableQuery = DriverDetailsQuery.getTemporaryDriverElasticQuery(
        operationalGroup, parent.driverDetailsModel.recordFrom, parent.driverDetailsModel.recordDefaultSize, postableSearchQuery
      );
    } else {
      postableQuery = DriverDetailsQuery.getPermanentDriverElasticQuery(
        operationalGroup, parent.driverDetailsModel.recordFrom, parent.driverDetailsModel.recordDefaultSize, postableSearchQuery
      );
    }
    parent.driverDetailsModel[`${driverType}ProfileSortAndSearchQuery`] = lodashutils.cloneDeep(postableSearchQuery);
    return postableQuery;
  }
  setTemporarayDriverData(parent: any, driversListArray: OperationalGroupDriverAssignmentDetail[]) {
    if (parent.driverDetailsModel.isScrollServiceHappend && parent.driverDetailsModel.temporaryDriverData) {
      parent.driverDetailsModel.temporaryDriverData =
        parent.driverDetailsModel.temporaryDriverData.concat(
          parent.driverDetailsUtilityService.getDriverData(driversListArray, 'Temporary'));
    } else {
      parent.driverDetailsModel.temporaryDriverData = parent.driverDetailsUtilityService.getDriverData(driversListArray, 'Temporary');
    }
  }
  setPermanentDriverData(parent: any, driversListArray: OperationalGroupDriverAssignmentDetail[]) {
    if (parent.driverDetailsModel.isScrollServiceHappend && parent.driverDetailsModel.permanentDriverData) {
      parent.driverDetailsModel.permanentDriverData =
        parent.driverDetailsModel.permanentDriverData.concat(
          parent.driverDetailsUtilityService.getDriverData(driversListArray, 'Permanent'));
    } else {
      parent.driverDetailsModel.permanentDriverData = parent.driverDetailsUtilityService.getDriverData(driversListArray, 'Permanent');
    }
  }
  setDriverListType(parent: any, operationalGroupCode: string, driversListArray: OperationalGroupDriverAssignmentDetail[]) {
    const driverType = parent.driverDetailsModel.selectedDriverListType;
    switch (driverType) {
      case 'temporary':
        this.setTemporarayDriverData(parent, driversListArray);
        parent.driverDetailsModel.storableTemporaryDriverListData = lodashutils.cloneDeep(parent.driverDetailsModel.temporaryDriverData);
        parent.driverDetailsModel.temporaryDriverListData = parent.driverDetailsUtilityService.getTemporaryDriverData(
          parent, operationalGroupCode, parent.driverDetailsModel.temporaryDriverData
        );
        break;
      case 'permanent':
        this.setPermanentDriverData(parent, driversListArray);
        parent.driverDetailsModel.permanentDriverListData = parent.driverDetailsUtilityService.getDriverListFromData(
          operationalGroupCode, parent.driverDetailsModel.permanentDriverData
        );
        break;
      default:
        this.setTemporarayDriverData(parent, driversListArray);
        this.setPermanentDriverData(parent, driversListArray);
        parent.driverDetailsModel.temporaryDriverListData = parent.driverDetailsUtilityService.getTemporaryDriverData(
          parent, operationalGroupCode, parent.driverDetailsModel.temporaryDriverData
        );
        parent.driverDetailsModel.permanentDriverListData = parent.driverDetailsUtilityService.getDriverListFromData(
          operationalGroupCode, parent.driverDetailsModel.permanentDriverData
        );
        parent.driverDetailsModel.isTemporaryDriverListExists = (parent.driverDetailsModel.temporaryDriverListData.length !== 0);
        parent.driverDetailsModel.isPermanentDriverListExists = (parent.driverDetailsModel.permanentDriverListData.length !== 0);
        parent.driverDetailsModel.storableTemporaryDriverListData = lodashutils.cloneDeep(parent.driverDetailsModel.temporaryDriverData);
        break;
    }
    parent.driverDetailsModel.isScrollServiceHappend = false;
  }

  isDateValid(dateValue: string): boolean {
    if (!moment(dateValue).isValid()) {
      return dateValue.split('/').length > 1;
    }
    return moment(dateValue).isValid();
  }

}
