import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';

import { AppConfigService } from '../../../../../../shared/service/app-config.service';
import { BusinessUnit } from '../../../../../drivertask/search-driver-task/advance-search/model/advance-search-interface';
import { OperationalTeamManagementData, OperationalGroupField } from './../model/team-details.interface';

@Injectable()
export class TeamDetailsService {

  endpoint: any;

  constructor(
    private readonly http: HttpClient,
    private readonly appConfigService: AppConfigService
  ) { this.endpoint = appConfigService.getApi('admin'); }

  getOperationalTeamDetails(operationalGroupCode: string): Observable<OperationalTeamManagementData> {
    const encodedGroupCode = encodeURIComponent(operationalGroupCode);
    return this.http.get<OperationalTeamManagementData>
      (`${this.endpoint.getOperationalTeamDetails}?operationalGroupCode=${encodedGroupCode}`);
  }

  getBUForTransferInitiation(): Observable<BusinessUnit> {
    return this.http.get<BusinessUnit>(`${this.endpoint.getBusinessUnit}?size=1000`);
  }

  getOperationalGroupType(): Observable<OperationalGroupField> {
    return this.http.get<OperationalGroupField>(`${this.endpoint.getOperationalGroupTypes}?size=1000`);
  }

  getOperationalGroupSubType(): Observable<OperationalGroupField> {
    return this.http.get<OperationalGroupField>(`${this.endpoint.getOperationalGroupSubtypes}?size=1000`);
  }

  getUtilizationStatus(): Observable<OperationalGroupField> {
    return this.http.get<OperationalGroupField>(`${this.endpoint.getUtilizationStatuses}?size=1000`);
  }

}
