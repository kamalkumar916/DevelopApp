import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { TruckDetailsService } from './truck-details.service';
import { configureTestSuite } from 'ng-bullet';

describe('TruckDetailsService', () => {
  let service: TruckDetailsService;
  let httpTestingController: HttpTestingController;
  const memeberId = '12345';
  const operGroupCode = 'DCS';
  const groupType = 'Test';
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [TruckDetailsService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(TruckDetailsService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes expected getTruckDetails calls', () => {
    service.getTruckDetails({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTruckList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getTruckViewDetails calls', () => {
    service.getTruckViewDetails({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTeamList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getAddTruckBusinessValidation calls', () => {
    service.getAddTruckBusinessValidation(operGroupCode, groupType, memeberId).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=truck&memberIds=${memeberId}&type=${groupType}&action=add`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected getRemoveTruckBusinessValidation calls', () => {
    service.getRemoveTruckBusinessValidation(operGroupCode, groupType, memeberId).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=truck&memberIds=${memeberId}&type=${groupType}&action=remove`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected postMemberBusinessValidation calls', () => {
    const code = 'DCS';
    const memberRequest = {
      memberIds: 'test',
      operationalGroupType: 'test',
      action: 'add',
      memberName: 'test'
    };
    service.postMemberBusinessValidation(code, memberRequest).subscribe();
    const req =
      httpTestingController.expectOne(`${service.endpoint.postOGMemberAdhocValidations}/trucks/validations?operationalGroupCode=${code}`);
    expect(req.request.method).toEqual('POST');
  });
});
