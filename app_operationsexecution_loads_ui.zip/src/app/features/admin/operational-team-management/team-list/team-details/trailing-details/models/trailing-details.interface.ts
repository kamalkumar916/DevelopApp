export interface DefaultGridColumn {
    property: string;
    name: string;
    sortableDataMember: string;
}

export interface TrailingGridData {
    rowEditable: boolean;
    EquipmentNumber: string;
    EquipmentClassificationDescription: string;
    equipmentID: number;
    operationalGroupEquipmentAssignmentID?: number;
    effectiveTimestamp?: string;
    expirationTimestamp?: string;
}

export interface TrailerCodeData {
    AssetUnitPrefixAndID?: string;
    AssetStatus?: string;
    AssetUnitID?: string;
    OperationalGroup: string;
    BusinessUnit: string;
    AssetClassificationCode?: string;
    AssetUnitPrefix?: string;
    AssetID?: string;
    equipmentID?: number;
    prefixWithEquipmentNumber?: string;
    equipmentClassificationCode?: string;
}
export interface OperationalGroupVariables {
    from: number;
    size: number;
    assetStatus: string;
    operationalGroupCode: string;
}
export interface PageView {
    first: number;
    rows: number;
}
export interface ErrorToastMsg {
    severity: string;
    summary: string;
    detail: string;
}
export interface TrailingStorableData {
    operationalGroupEquipmentAssignmentId: number;
    equipmentID: number;
    equipmentUnitId: string;
    equipmentClassificationCode: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
}

