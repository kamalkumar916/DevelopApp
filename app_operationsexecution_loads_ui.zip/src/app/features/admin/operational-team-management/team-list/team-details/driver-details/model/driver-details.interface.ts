export interface OperationalGroupSelectedDriverAssignment {
    operationalGroupDriverAssignmentId: number;
    driverPersonID: number;
    driverFirstName: string;
    driverMiddleName?: any;
    driverLastName: string;
    driverPreferredName: string;
    driverUserId: string;
    driverJobGroup: string;
    operationalGroupDriverAssignmentType: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    profilePic: string;
    profilePicture?: string;
    operationalGroupCode?: string;
    operationalGroupDriverName?: string;
    rowEditable?: boolean;
    userProfileImg?: string;
    formattedEndDate?: string;
    personId?: string;
}

export interface DriverDetails {
    operationalGroupCode: string;
    operationalGroupDriverAssignments: OperationalGroupSelectedDriverAssignment[];
}

export interface ElasticDriverDetails {
    DriverPersonID: number;
    EffectiveTimestamp?: string;
    ExpirationTimestamp: string;
    FirstName: string;
    JobGroup: string;
    LastName: string;
    MiddleName: string;
    OperationalGroupDriverAssignmentID?: number;
    OperationalGroupDriverAssignmentTypeCode: string;
    OperationalGroupDriverAssignmentTypeDescription: string;
    PreferredName: string;
    UserID: string;
    operationalGroupCode?: string;
    operationalGroupDriverName?: string;
    rowEditable?: boolean;
    userProfileImg?: string;
    operationalGroupTitle?: string;
    formattedEndDate?: string;
    profilePicture?: string;
}

export interface DriverListDetails {
    personId: number;
    userId?: string;
    driverUserId: string;
    firstName?: string;
    middleName?: string;
    lastName?: string;
    preferredName?: string;
    jobGroup: string;
    profilePicture?: any;
    operationalGroupDriverName: string;
    userProfileImg?: string;
    operationalGroupDriverToolTip: string;
}

export interface OriginalEvent {
    isTrusted: boolean;
}

export interface TabChangeEvent {
    originalEvent: OriginalEvent;
    index: number;
}

export interface DriverDetailsElasticQuery {
    sort?: any[];
    from?: number;
    query?: any;
    size?: number;
    _source: string[];
}

export interface UtilizationStatus {
    UtilizationStatusCode: string;
    UtilizationStatusDescription: string;
}

export interface OperationalGroupDriverAssignmentDetail {
    DriverPersonID: number;
    EffectiveTimestamp: string;
    ExpirationTimestamp: string;
    FirstName: string;
    JobGroup: string;
    LastName: string;
    MiddleName: string;
    OperationalGroupDriverAssignmentID: number;
    OperationalGroupDriverAssignmentTypeCode: string;
    OperationalGroupDriverAssignmentTypeDescription: string;
    PreferredName: string;
    UserID: string;
}

export interface OperationalGroupData {
    OperationalGroupCode: string;
    OperationalGroupDescription: string;
    OperationalGroupTypeCode: string;
    OperationalGroupTypeDescription: string;
    OperationalGroupSubtypeCode: string;
    OperationalGroupSubtypeDescription: string;
    FinanceBusinessUnitCode: string;
    UtilizationStatus: UtilizationStatus[];
    LastUpdateProgramName: string;
    LastUpdateUserID: string;
    Status: string;
    LastUpdateTimestamp: string;
    OperationalGroupDriverAssignment: OperationalGroupDriverAssignmentDetail[];
}

export interface DriverImageResponse {
    userId: string;
    thumbPhoto: string;
}

export interface EndDateErrorModel {
    endDate: Date;
    isValid: boolean;
    endDateError?: any;
}

export interface DriverValidationMessageInterface {
    isAssignedAndPaired: boolean;
    isOnlyAssigned: boolean;
    isOnlyPaired: boolean;
}
