import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import {
    MemberValidationResponse, OperationalTeamManagementData,
    DuplicateAndPairedMemberData, ProfileSortAndSearch
} from './../../model/team-details.interface';
import { OperationalGroupTruckAssignment, TeamMemberScrollInformation } from './../../../../model/operational-team.interface';

import {
    FilterVariables, FilterGroupVariables, TruckList, TruckStorableData,
    OperationalGroupSelectedEquipment, TruckDataModel, ErrorToastMessage
} from './truck-details.interface';
import { SecureModel } from '../../../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../../../config/app.config';


export class TruckDetailsModel {
    isEnableTruck: boolean;
    truckData: object[];
    truckListData: object[];
    filterVariables: FilterVariables;
    filterGroupCodeVariables: FilterGroupVariables;
    isLoading: boolean;
    isShowSaveLink: boolean;
    canSubscribe: boolean;
    selectedEquipment?: OperationalGroupSelectedEquipment[];
    dateFormat: string;
    storableDataModel: any[];
    localStorableDataModel: any[];
    truckDeatilsForm: FormGroup;
    operationalGroup: string;
    selectedTruckData: TruckDataModel;
    sortField: string;
    sortOrder: string;
    ascendingOrder: string;
    decendingOrder: string;
    searchText: string;
    totalRecords: number;
    isPaginatorReqd: boolean;
    tblScrollHeight: string;
    isProfileView: boolean;
    operationalGroupData: OperationalTeamManagementData;
    isOperationalGroupChanged: boolean;
    isRemoveCancelBtnsVisible: boolean;
    removedTruckListData: TruckList[];
    truckFormCheckBoxArray: FormControl[];
    isTruckLoaded: boolean;
    unableToRemoveTruck: ErrorToastMessage;
    storableTruckListData: OperationalGroupTruckAssignment[];
    duplicateAndPairedMemberData: DuplicateAndPairedMemberData;
    missingRequiredInfoError: any;
    isConfirmDialogVisible: boolean;
    profileSortAndSearchQuery: ProfileSortAndSearch;
    userInputSearchSubject: Subject<string>;
    profileSortQuery: object;
    profileSearchQuery: object;
    isTruckListExist: boolean;
    unableToAddTruckMsg: string;
    pairedDriverTruckMsg: string;
    unableToRemoveTruckMsg: string;
    pairedTruckToDriverMsg: string;
    isActiveOperationalGroup: boolean;
    isNewOperationalGroup: boolean;
    operationalGroupForm: FormGroup;
    dateTimeFormat: string;
    overRideTruck: string;
    overRideTruckErrorMsgs: string[];
    storableTruckData: any[];
    teamDetailsScrollInformation: TeamMemberScrollInformation;
    totalMembersForScrollValidation: number;
    isScrollServiceHappend: boolean;
    recordFrom: number;
    recordDefaultSize: number;
    isTruckListPopulated: boolean;
    isTruckListSorted: boolean;
    addTruckButton: SecureModel;
    appConfig;
    constructor(private readonly formBuilder: FormBuilder) {
        this.dateFormat = 'M/D/YYYY hh:mm a';
        this.isEnableTruck = false;
        this.isOperationalGroupChanged = false;
        this.truckData = [];
        this.truckListData = [];
        this.isConfirmDialogVisible = false;
        this.filterVariables = {
            from: 0,
            size: 5,
            searchValue: '',
            assetStatus: ''
        };
        this.isLoading = false;
        this.isShowSaveLink = false;
        this.filterGroupCodeVariables = {
            from: 0,
            size: 100,
            assetStatus: '',
            operationalGroupCode: ''
        };
        this.canSubscribe = false;
        this.operationalGroup = '';
        this.storableDataModel = [];
        this.storableTruckListData = [];
        this.truckDeatilsForm = formBuilder.group({
            equipmentCode: ['', Validators.required],
            truckCheckBoxes: formBuilder.array([]),
            addTruckCheckBox: [false],
            truckListSearch: ['']
        });
        this.missingRequiredInfoError = {
            'severity': 'error',
            'summary': 'Missing Required Information',
            'detail': 'Provide the required information in highlighted fields and save again'
        };

        this.ascendingOrder = 'asc';
        this.decendingOrder = 'desc';
        this.sortField = 'Name';
        this.searchText = '';
        this.totalRecords = 0;
        this.isPaginatorReqd = false;
        this.removedTruckListData = [];
        this.isRemoveCancelBtnsVisible = false;
        this.unableToRemoveTruck = {
            severity: 'error',
            summary: 'Unable to Remove Truck',
            detail: 'This Truck is only assigned to this fleet and cannot be unassigned'
        };
        this.profileSortAndSearchQuery = {
            memberStartFrom: 0,
            expirationTimestamp: '',
            searchTxt: '',
            sortableMember: 'OperationalGroupEquipmentAssignment.EffectiveTimestamp',
            sortableEvent: { sortOrder: -1 }
        };
        this.userInputSearchSubject = new Subject<string>();
        this.profileSortQuery = {};
        this.profileSearchQuery = {};
        this.isTruckListExist = false;
        this.unableToAddTruckMsg = 'Unable to Add Truck';
        this.unableToRemoveTruckMsg = 'Unable to Remove Truck';
        this.pairedDriverTruckMsg = 'This Truck is paired with a driver and cannot be removed';
        this.pairedTruckToDriverMsg = `This Truck is paired with a driver in an another operational team and cannot be assigned` +
            ` to this team unless it is paired`;
        this.isActiveOperationalGroup = true;
        this.dateTimeFormat = 'YYYY-MM-DD HH:mm:ss.sss Z';
        this.appConfig = AppConfig.getConfig();
        this.addTruckButton = { url: this.appConfig.api.admin.getOperationalTeamDetails, operation: 'C' };
    }
}
