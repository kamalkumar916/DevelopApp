import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { configureTestSuite } from 'ng-bullet';

import { TruckDetailsUtilityService } from './truck-details-utility.service';

describe('TruckDetailsUtilityService', () => {
  let service: TruckDetailsUtilityService;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [TruckDetailsUtilityService, AppConfigService, FormBuilder]
    });
  });

  beforeEach(() => {
    service = TestBed.get(TruckDetailsUtilityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getNewlyAddedRecordForTruckData should return expected value', () => {
    const returnValue = service.getNewlyAddedRecordForTruckData('123');
    expect(returnValue.EquipmentNumber).toBe('123');
  });
});
