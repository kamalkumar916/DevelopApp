import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { DriverDetailsComponent } from './driver-details.component';
import { OperationalTeamManagementModule } from '../../../operational-team-management.module';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfigService } from '../../../../../../shared/service/app-config.service';
import { LocalStorageService } from '../../../../../../shared/jbh-app-services/local-storage.service';
import { UserService } from '../../../../../../shared/jbh-esa/index';
import { TableModule } from 'primeng/table';
import { CheckboxModule, PaginatorModule, AutoCompleteModule, CalendarModule, DialogModule } from 'primeng/primeng';
import { DriverDetailsService } from './services/driver-details.service';
import { OperationalTeamUtilityService } from '../../../services/operational-team-utility.service';
import { DriverDetailsUtilityService } from './services/driver-details-utility.service';
import { PipesModule } from '../../../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from '../../../../../../shared/directives/directives.module';
import { ReactiveFormsModule } from '@angular/forms';
import { DriverSortSearchService } from './services/driver-sort-search.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { TeamDetailsUtilityService } from '../services/team-details-utility.service';

describe('DriverDetailsComponent', () => {
  let component: DriverDetailsComponent;
  let fixture: ComponentFixture<DriverDetailsComponent>;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  let messageService: MessageService;
  let utilityService: OperationalTeamUtilityService;
  let driverDetailsUtilityService: DriverDetailsUtilityService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [DriverDetailsComponent],
      imports: [RouterTestingModule, ReactiveFormsModule, PipesModule, JbhLoaderModule, DirectivesModule,
        TableModule, CheckboxModule, PaginatorModule, AutoCompleteModule,
        CalendarModule, DialogModule, HttpClientTestingModule, NoopAnimationsModule],
      providers: [MessageService, OperationalTeamUtilityService, DriverDetailsService,
        DriverDetailsUtilityService, AppConfigService, LocalStorageService,
        DriverSortSearchService, UserService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverDetailsComponent);
    component = fixture.componentInstance;
    messageService = TestBed.get(MessageService);
    driverDetailsUtilityService = TestBed.get(DriverDetailsUtilityService);
    utilityService = TestBed.get(OperationalTeamUtilityService);
    fixture.detectChanges();
    formGroup = formBuilder.group({});
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('resetDriverListFields have been called', () => {
    component.resetDriverListFields();
    expect(component.driverDetailsModel.totalMembersForScrollValidation).toBe(0);
  });
  it('resetTempDriverListView have been called', () => {
    spyOn(component, 'onRemoveDriverCancelBtnClicked');
    component.resetTempDriverListView();
    expect(component.driverDetailsModel.isSaveCancelBtnsVisible).toBe(false);
    expect(component.onRemoveDriverCancelBtnClicked).toHaveBeenCalled();
  });
  it('setDateLimits have been called', () => {
    spyOn(component, 'setDateLimits');
    component.setAndPopulateDriverList();
    expect(component.setDateLimits).toHaveBeenCalled();
  });
  it('resetPairedDriverValidation have been called', () => {
    spyOn(component, 'resetPairedDriverValidation');
    component.onUpdateDriverPairedValidations();
    expect(component.resetPairedDriverValidation).toHaveBeenCalled();
  });
  it('resetPairedDriverValidation have been called', () => {
    component.resetPairedDriverValidation();
    expect(component.driverDetailsModel.overRideDriver).toBe('N');
  });
  it('onUpdateDriverPairedValidations have been called', () => {
    component.driverDetailsModel.driverDetailsError = {
      'errors': [{
        'code': 'EX_DRIVER_HAVING_PAIRING_TRUCK',
      },
      ]
    };
    component.onUpdateDriverPairedValidations();
    expect(component.driverDetailsModel.overRidePaired).toEqual('Y');
  });
  it('onUpdateDriverPairedValidations have been called', () => {
    component.driverDetailsModel.driverDetailsError = {
      'errors': [{
        'code': 'EX_DRIVER_EXISTS_IN_OTHER_OG',
      },
      ]
    };
    component.onUpdateDriverPairedValidations();
    expect(component.driverDetailsModel.overRideDriver).toEqual('Y');
  });
  it('profileView have been set', () => {
    component.profileView = true;
    expect(component.driverDetailsModel.isProfileView).toBeTruthy();
  });
  it('newOperationalTeamToAdd have been set', () => {
    component.newOperationalTeamToAdd = true;
    expect(component.driverDetailsModel.isNewOperationalGroup).toBeTruthy();
  });
  it('driverActiveDaysCount have been set', () => {
    component.driverActiveDaysCount = 2;
    expect(component.driverDetailsModel.driverActiveDaysCount).toBe(2);
  });
  it('operationalGroupForm have been set', () => {
    component.operationalGroupForm = formGroup;
    expect(component.driverDetailsModel.operationalGroupForm).toBeTruthy();
  });
  it('newOperationalTeamToAdd have been set', () => {
    component.newOperationalTeamToAdd = true;
    expect(component.driverDetailsModel.isNewOperationalGroup).toBeTruthy();
  });
  it('parentTabChangeDetection have been called', () => {
    spyOn(component, 'resetDetailsForProfileView');
    const event = {
      originalEvent: {
        isTrusted: true,
      },
      index: 0,
      isOperationalGroupChanged: true,
    };
    component.parentTabChangeDetection = event;
    expect(component.resetDetailsForProfileView).toHaveBeenCalled();
  });
  it('operationalGroupData have been set', () => {
    spyOn(component, 'setAndPopulateDriverList');
    const demo = {
      operationalGroupCode: 'string',
      operationalGroupDescription: 'string',
      operationalGroupTypeCode: 'string',
      operationalGroupTypeDescription: 'string',
      operationalGroupSubTypeCode: 'string',
      operationalGroupSubTypeDescription: 'string',
      businessUnit: 'string',
      utilizationStatus: [{
        utilizationStatusCode: 'string',
        utilizationStatusDescription: 'string',
      }],
      lastUpdated: 'string',
      lastUpdatedBy: 'string',
      totalMembers: 5,
      status: 'string',
      profilePic: 'string',
      profilePicture: 'string',
      utilizationStatusDescList: 'string',
      lastUpdatedDateValue: 'string',
      userProfileImg: 'string',
      userImgNameData: 'string',
      financeBusinessUnitCode: 'string',
    };
    component.operationalGroupData = demo;
    expect(component.driverDetailsModel.operationalGroupData).toBeTruthy();
    expect(component.setAndPopulateDriverList).toBeTruthy();
  });
  it('scrollInfoOnDetails have been set', () => {
    spyOn(component, 'infiniteScrollImplementation');
    const demo = JSON.stringify({ scrollTop: 2, currentTabSelectionIdx: 2, isMemberServiceNeedsToCall: false });
    component.scrollInfoOnDetails = demo;
    expect(component.driverDetailsModel.teamDetailsScrollInformation).toBeTruthy();
    expect(component.infiniteScrollImplementation).toBeTruthy();
  });
  it('operationalGroupCode have been set', () => {
    spyOn(component, 'resetTempDriverListView');
    spyOn(driverDetailsUtilityService, 'resetAddedDriverChkBoxControl');
    component.operationalGroupCode = 'ogCode';
    expect(component.driverDetailsModel.operationalGroupCode).toBe('ogCode');
    expect(component.driverDetailsModel.isOperationalGroupChanged).toBe(true);
    expect(component.driverDetailsModel.storableDriverListData.length).toBe(0);
    expect(component.driverDetailsModel.removedDriverListData.length).toBe(0);
    expect(component.resetTempDriverListView).toBeTruthy();
    expect(driverDetailsUtilityService.resetAddedDriverChkBoxControl).toBeTruthy();
  });
  it('setAndPopulateDriverList have been called with false of Active OG', () => {
    spyOn(component, 'setDateLimits');
    component.driverDetailsModel.isActiveOperationalGroup = false;
    spyOn(driverDetailsUtilityService, 'resetDriversTableList');
    component.setAndPopulateDriverList();
    expect(component.driverDetailsModel.isOperationalGroupChanged).toBe(true);
    expect(component.setDateLimits).toHaveBeenCalled();
    expect(driverDetailsUtilityService.resetDriversTableList).toHaveBeenCalled();
  });
  it('resetDetailsForProfileView have been called', () => {
    spyOn(driverDetailsUtilityService, 'getDefaultProfileSortAndSearchQuery');
    component.resetDetailsForProfileView();
    expect(driverDetailsUtilityService.getDefaultProfileSortAndSearchQuery).toHaveBeenCalled();
  });
  it('infiniteScrollImplementation have been called - Truth Implementation', () => {
    spyOn(component, 'setDriversDetails');
    component.driverDetailsModel.recordFrom = 0;
    component.driverDetailsModel.recordDefaultSize = 25;
    component.driverDetailsModel.totalMembersForScrollValidation = 40;
    component.driverDetailsModel.teamDetailsScrollInformation = {
      scrollTop: 1, currentTabSelectionIdx: 0, isMemberServiceNeedsToCall: true
    };
    component.driverDetailsModel.isDriverListPopulated = true;
    component.infiniteScrollImplementation();
    expect(component.driverDetailsModel.isScrollServiceHappend).toBe(true);
    expect(component.driverDetailsModel.recordFrom).toBe(25);
    expect(component.setDriversDetails).toHaveBeenCalled();
  });
  it('infiniteScrollImplementation have been called - Falsy Implementation', () => {
    spyOn(component, 'setDriversDetails');
    component.driverDetailsModel.recordFrom = 0;
    component.driverDetailsModel.recordDefaultSize = 25;
    component.driverDetailsModel.totalMembersForScrollValidation = 40;
    component.driverDetailsModel.teamDetailsScrollInformation = {
      scrollTop: 1, currentTabSelectionIdx: 0, isMemberServiceNeedsToCall: false
    };
    component.driverDetailsModel.isDriverListPopulated = true;
    component.infiniteScrollImplementation();
    expect(component.driverDetailsModel.isScrollServiceHappend).toBe(false);
    expect(component.driverDetailsModel.recordFrom).toBe(0);
  });
  it('onAddDriverCancelBtnClicked have been called', () => {
    spyOn(utilityService, 'setIsAddMemberClicked');
    spyOn(component, 'resetTempDriverListView');
    spyOn(driverDetailsUtilityService, 'resetAddedDriverChkBoxControl');
    component.onAddDriverCancelBtnClicked();
    expect(utilityService.setIsAddMemberClicked).toHaveBeenCalled();
    expect(driverDetailsUtilityService.resetAddedDriverChkBoxControl).toHaveBeenCalled();
    expect(component.resetTempDriverListView).toHaveBeenCalled();
  });
  it('onConfirmYesClicked have been called', () => {
    spyOn(component, 'onUpdateDriverPairedValidations');
    spyOn(component, 'onUpdateDriverDataIntoTable');
    component.onConfirmYesClicked();
    expect(component.onUpdateDriverPairedValidations).toHaveBeenCalled();
    expect(component.onUpdateDriverDataIntoTable).toHaveBeenCalled();
  });
  it('onUpdateDriverPairedValidations have been called with pairing', () => {
    component.driverDetailsModel.driverDetailsError = {
      'traceid': '6acf7e516c027e04',
      'errors': [
        {
          'fieldErrorFlag': false,
          'errorMessage': 'The driver paired with a truck has only a permanent assignment to an operational team.',
          'errorType': 'Business Validation Error',
          'fieldName': null,
          'code': 'EX_DRIVER_HAVING_PAIRING_TRUCK',
          'errorSeverity': 'WARNING'
        },
        {
          'fieldErrorFlag': false,
          'errorMessage': 'The temporary assignment of the driver will result in the truck being removed from the previous team.',
          'errorType': 'Business Validation Error',
          'fieldName': null,
          'code': 'EX_DRIVER_HAVING_PAIRING_TRUCK_ADD_ACTION',
          'errorSeverity': 'WARNING'
        }
      ]
    };
    component.onUpdateDriverPairedValidations();
    expect(component.driverDetailsModel.overRidePaired).toEqual('Y');
  });
  it('onUpdateDriverPairedValidations have been called with pairing', () => {
    component.driverDetailsModel.driverDetailsError = {
      'traceid': '6acf7e516c027e04',
      'errors': [
        {
          'fieldErrorFlag': false,
          'errorMessage': 'The driver paired with a truck has only a permanent assignment to an operational team.',
          'errorType': 'Business Validation Error',
          'fieldName': null,
          'code': 'EX_DRIVER_EXISTS_IN_OTHER_OG_WITH_PAIRING_TRUCK',
          'errorSeverity': 'WARNING'
        }
      ]
    };
    component.onUpdateDriverPairedValidations();
    expect(component.driverDetailsModel.overRidePaired).toEqual('Y');
    expect(component.driverDetailsModel.overRideDriver).toEqual('Y');
  });
  it('initActionReqdErrorOnRemove have been set', () => {
    spyOn(messageService, 'clear');
    spyOn(messageService, 'add');
    component.initActionReqdErrorOnRemove();
    expect(messageService.clear).toHaveBeenCalled();
  });
});
