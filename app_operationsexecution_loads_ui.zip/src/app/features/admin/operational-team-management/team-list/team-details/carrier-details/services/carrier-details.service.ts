import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { Observable } from 'rxjs';
import { FilterVariables } from '../models/carrier-details.interface';
import { ElasticResponseModel } from '../../../../../../model/elastic-response.interface';
import { MemberValidationResponse } from './../../model/team-details.interface';
import { MemberValidationInput } from '../../../../model/operational-team.interface';

@Injectable()
export class CarrierDetailsService {
  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('admin');
  }

  getCarrierDetailsList(carrierListQuery: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getCarrierList, carrierListQuery);
  }

  getCarrierName(carrierQuery: FilterVariables): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getCarrierDetail, carrierQuery);
  }

  getAddCarrierBusinessValidation(operGroupCode: string, groupType: string, memeberId: number): Observable<MemberValidationResponse> {
    return this.http.get<MemberValidationResponse>(`${this.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=carrier&memberIds=${memeberId}&type=${groupType}&action=add`);
  }
  postMemberBusinessValidation(operGrpCode: string, memberRequest: MemberValidationInput): Observable<any> {
    const encodedGroupCode = encodeURIComponent(operGrpCode);
    return this.http.post<any>
      (`${this.endpoint.postOGMemberAdhocValidations}/carriers/validations?operationalGroupCode=${encodedGroupCode}`, memberRequest);
  }
}
