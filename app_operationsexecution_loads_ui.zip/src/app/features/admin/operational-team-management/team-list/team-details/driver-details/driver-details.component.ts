import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, Output, OnDestroy, OnInit, ViewChild
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MessageService } from 'primeng/components/common/messageservice';
import * as lodashutils from 'lodash';
import * as moment from 'moment';
import { Table } from 'primeng/table';
import { Utils } from '../../../../../../shared/jbh-app-services/utils';
import { DateUtils } from '../../../../../../shared/jbh-app-services/date-utils';
import { ElasticResponseModel } from '../../../../../model/elastic-response.interface';
import { SortView } from './../../model/team-list.interface';
import { MemberValidationResponse, OperationalTeamManagementData } from './../model/team-details.interface';
import { DriverDetailsModel } from './model/driver-details.model';
import { DriverDetailsQuery } from './query/driver-details.query';
import {
  DriverDetailsElasticQuery, ElasticDriverDetails,
  OperationalGroupSelectedDriverAssignment, DriverImageResponse, TabChangeEvent
} from './model/driver-details.interface';
import { OperationalTeamUtilityService } from '../../../services/operational-team-utility.service';
import { DriverDetailsService } from './services/driver-details.service';
import { DriverDetailsUtilityService } from './services/driver-details-utility.service';

@Component({
  selector: 'app-driver-details',
  templateUrl: './driver-details.component.html',
  styleUrls: ['./driver-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DriverDetailsComponent implements OnInit, OnDestroy {
  driverDetailsModel: DriverDetailsModel;
  @Output() addMemberClicked = new EventEmitter();
  @Output() profileSortAndSearch = new EventEmitter();
  @ViewChild('opTempDriverTable') private readonly temporaryDriverTable: Table;
  @ViewChild('opPermanentDriverTable') private readonly permanentDriverTable: Table;
  @Input()
  set driverActiveDaysCount(daysCount: number) {
    this.driverDetailsModel.driverActiveDaysCount = daysCount;
  }
  @Input()
  set profileView(isProfileViewArg: boolean) {
    this.driverDetailsModel.isProfileView = isProfileViewArg;
  }
  @Input()
  set operationalGroupForm(operationalGroupForm: FormGroup) {
    this.driverDetailsModel.operationalGroupForm = operationalGroupForm;
  }
  @Input()
  set newOperationalTeamToAdd(isNewOperationalTeamToAdd: boolean) {
    this.driverDetailsModel.isNewOperationalGroup = isNewOperationalTeamToAdd;
  }
  @Input()
  set parentTabChangeDetection(parentTabChangeDetectionObject: TabChangeEvent) {
    this.resetTempDriverListView();
    this.resetDriverListFields();
    this.driverDetailsUtilityService.resetAddedDriverChkBoxControl(this);
    if (parentTabChangeDetectionObject && parentTabChangeDetectionObject.index === 0
      && !this.driverDetailsModel.isOperationalGroupChanged) {
      this.resetDetailsForProfileView();
      this.setDriversDetails(this.driverDetailsModel.operationalGroupCode);
    }
  }
  @Input()
  set scrollInfoOnDetails(scrollInformation: string) {
    if (scrollInformation) {
      this.driverDetailsModel.teamDetailsScrollInformation = JSON.parse(scrollInformation);
      this.infiniteScrollImplementation();
    }
  }
  @Input()
  set operationalGroupData(operationalGroupDataArg: OperationalTeamManagementData) {
    this.driverDetailsModel.operationalGroupData = operationalGroupDataArg;
    this.driverDetailsModel.isActiveOperationalGroup = !(operationalGroupDataArg && operationalGroupDataArg.status === 'Inactive');
    this.setAndPopulateDriverList();
  }
  @Input()
  set operationalGroupCode(operationalGroupCodeArg: string) {
    this.driverDetailsModel.tempDriverForm['controls']['tempDriverCheckBoxes']['controls'] = [];
    this.resetTempDriverListView();
    this.driverDetailsUtilityService.resetAddedDriverChkBoxControl(this);
    this.driverDetailsModel.operationalGroupCode = operationalGroupCodeArg;
    this.driverDetailsModel.isOperationalGroupChanged = true;
    this.driverDetailsModel.storableDriverListData = [];
    this.driverDetailsModel.removedDriverListData = [];
  }

  constructor(
    private readonly changeDetector: ChangeDetectorRef, private readonly formBuilder: FormBuilder,
    private readonly messageService: MessageService,
    private readonly utilityService: OperationalTeamUtilityService, private readonly driverDetailsService: DriverDetailsService,
    private readonly driverDetailsUtilityService: DriverDetailsUtilityService
  ) { this.driverDetailsModel = new DriverDetailsModel(this.formBuilder); }

  ngOnInit() {
    this.driverDetailsModel.canSubscribe = true;
    this.resetDriverListFields();
    this.setElasticControlValueChanges('permanent');
    this.setElasticControlValueChanges('temporary');
    this.driverDetailsModel.storableDriverListData = [];
    this.driverDetailsModel.storeDriverImagesForProfileView = [];
  }
  ngOnDestroy() {
    this.driverDetailsModel.canSubscribe = false;
    this.driverDetailsModel.isOperationalGroupChanged = false;
  }
  hasAccess(actionBtnName: string): boolean {
    return this.utilityService.hasAccess(actionBtnName);
  }

  getOperationalGroupCode(): string {
    return ((this.driverDetailsModel.operationalGroupForm &&
      this.driverDetailsModel.operationalGroupForm.controls['operationalGroupIdentifier'].value) ||
      this.driverDetailsModel.operationalGroupCode);
  }
  setAndPopulateDriverList() {
    this.setDateLimits();
    if (this.driverDetailsModel.isOperationalGroupChanged && !this.driverDetailsModel.isNewOperationalGroup) {
      this.setDriversDetails(this.driverDetailsModel.operationalGroupCode);
    }
    if (!this.driverDetailsModel.isActiveOperationalGroup) {
      this.driverDetailsUtilityService.resetDriversTableList(this);
      this.changeDetector.detectChanges();
      this.driverDetailsModel.isOperationalGroupChanged = true;
    }
  }
  setDateLimits() {
    const todayDate = new Date().toISOString();
    const futureDate = new Date(moment(todayDate).add(this.driverDetailsModel.driverActiveDaysCount, 'd').toISOString()).toISOString();
    const expirationDateTimeValue = this.driverDetailsUtilityService.getExpirationDateValue(futureDate).toISOString();
    this.driverDetailsModel.driverExpiratationFromDate =
      DateUtils.getTimeFormatWithZoneAbbr(todayDate, this.driverDetailsModel.dateFormat);
    this.driverDetailsModel.driverExpirationToDate =
      DateUtils.getTimeFormatWithZoneAbbr(expirationDateTimeValue, this.driverDetailsModel.dateFormat);
    this.driverDetailsModel.calanderMinDate = new Date(this.driverDetailsModel.driverExpiratationFromDate);
    this.driverDetailsModel.calenderMaxDate = new Date(this.driverDetailsModel.driverExpirationToDate.split(' ')[0]);
  }
  setDriversDetails(operationalGroupCode: string) {
    if (this.driverDetailsModel.isProfileView && (this.driverDetailsModel.isTemporaryDriverListSorted ||
      this.driverDetailsModel.isPermanentDriverListSorted)) {
      if (this.driverDetailsModel.driverChecking === 'temporary') {
        this.driverDetailsModel.isTemporaryDriverLoaded = true;
        const operationalGroup = this.driverDetailsModel.operationalGroupData.operationalGroupCode;
        const postableQuery = DriverDetailsQuery.getTemporaryDriverElasticQuery(
          operationalGroup, this.driverDetailsModel.recordFrom, this.driverDetailsModel.recordDefaultSize,
          this.driverDetailsModel.temporaryProfileSortAndSearchQuery
        );
        this.setDriverDetailsForOperGroupCode(postableQuery);
      } else {
        this.driverDetailsModel.isPermanentDriverLoaded = true;
        const operationalGroup = this.driverDetailsModel.operationalGroupData.operationalGroupCode;
        const postableQuery = DriverDetailsQuery.getPermanentDriverElasticQuery(
          operationalGroup, this.driverDetailsModel.recordFrom, this.driverDetailsModel.recordDefaultSize,
          this.driverDetailsModel.permanentProfileSortAndSearchQuery
        );
        this.setDriverDetailsForOperGroupCode(postableQuery);
      }
    } else {
      this.driverDetailsUtilityService.resetDriversTableList(this);
      this.driverDetailsUtilityService.resetDriverDetailsView(this);
      this.driverDetailsModel.isTemporaryDriverLoaded = true;
      this.driverDetailsModel.isPermanentDriverLoaded = true;
      this.changeDetector.detectChanges();
      const postableQuery = lodashutils.cloneDeep(DriverDetailsQuery.getDriverDetailsQuery(
        operationalGroupCode, this.driverDetailsModel.driverExpirationToDate, this.driverDetailsModel.recordFrom,
        this.driverDetailsModel.recordDefaultSize));
      this.driverDetailsModel.selectedDriverListType = 'All';
      this.setDriverDetailsForOperGroupCode(postableQuery);
    }
  }
  setDriverDetailsForOperGroupCode(postableQuery: DriverDetailsElasticQuery) {
    const dataToPost = lodashutils.cloneDeep(postableQuery);
    this.driverDetailsService.getDriverListDataForOperGroup(dataToPost).pipe(
      takeWhile(() => this.driverDetailsModel.canSubscribe),
      finalize(() => {
        this.driverDetailsModel.isDriverListPopulated = true;
        this.driverDetailsModel.isTemporaryDriverLoaded = false;
        this.driverDetailsModel.isPermanentDriverLoaded = false;
        this.driverDetailsModel.isOperationalGroupChanged = false;
        this.changeDetector.detectChanges();
      }))
      .subscribe((driverDataList: ElasticResponseModel) => {
        if (driverDataList && driverDataList.hits && driverDataList.hits.hits) {
          this.driverDetailsUtilityService.setDriversList(this, this.driverDetailsModel.operationalGroupCode, driverDataList);
          if (this.driverDetailsModel.isOperationalGroupChanged) {
            this.setDriverImagesForDrivers(this.driverDetailsModel.imageUserIDArray, (driverImagesResponse: DriverImageResponse[]) => {
              const driverResponseArray =
                lodashutils.map(driverImagesResponse, lodashutils.partialRight(lodashutils.pick, ['userId', 'thumbPhoto']));
              this.driverDetailsModel.storeDriverImagesForProfileView = driverResponseArray;
              this.driverDetailsUtilityService.setImageForDrivers(this, this.driverDetailsModel.storeDriverImagesForProfileView);
            });
          } else {
            this.driverDetailsUtilityService.setImageForDrivers(this, this.driverDetailsModel.storeDriverImagesForProfileView);
          }
        } else {
          this.driverDetailsUtilityService.resetDriversTableList(this);
        }
      }, (error) => { this.driverDetailsUtilityService.resetDriversTableList(this); });
  }
  setDriverImagesForDrivers(userIdArray: string[], callBackFn: any) {
    if (userIdArray && userIdArray.length !== 0) {
      this.driverDetailsService.getDriverImages(lodashutils.uniq(userIdArray).toString()).pipe(
        takeWhile(() => this.driverDetailsModel.canSubscribe),
        finalize(() => { this.changeDetector.detectChanges(); }))
        .subscribe((driverImagesResponse: DriverImageResponse[]) => {
          callBackFn(driverImagesResponse);
        }, (error) => { callBackFn([]); });
    }
  }
  setCheckedForDriverCheckboxes(isCheckBoxesChecked: boolean) {
    lodashutils.forEach(this.driverDetailsModel.tempDriverFormCheckBoxArray, (eachDriverCheckBox: FormControl) => {
      eachDriverCheckBox['tempDriverCheckBox'].setValue(isCheckBoxesChecked);
    });
  }
  setElasticControlValueChanges(driverType: string) {
    const permanentDriverElasticControl = this.driverDetailsModel.tempDriverForm.controls[`${driverType}DriverElasticSearchTxtBox`];
    permanentDriverElasticControl.valueChanges.pipe(debounceTime(300), distinctUntilChanged(),
      takeWhile(() => this.driverDetailsModel.canSubscribe))
      .subscribe((value) => {
        if (this.driverDetailsModel.isProfileView && this.driverDetailsModel.operationalGroupData
          && !this.driverDetailsModel.isOperationalGroupChanged) {
          this.resetDriverListFields();
          this.driverDetailsModel.isTemporaryDriverListSorted = (driverType === 'temporary');
          this.driverDetailsModel.isPermanentDriverListSorted = (driverType === 'permanent');
          this.profileSortAndSearch.emit();
          const postableQuery = this.driverDetailsUtilityService.getDriverElasticSearchQuery(this, driverType, value);
          this.setDriverDetailsForOperGroupCode(postableQuery);
          this.changeDetector.detectChanges();
        }
      });
  }

  initActionReqdErrorOnRemove() {
    this.messageService.clear();
    this.messageService.add(this.utilityService.getActionReqdError());
  }
  initInlineSaveBusinessValidation() {
    const activeMembers = this.driverDetailsModel.isNewOperationalGroup ? 0 :
      Number(this.driverDetailsModel.operationalGroupData.totalMembers);
    const membersInOGForValidation =
      this.utilityService.checkMaxMembersInOperationalGroup(this.getOperationalGroupCode(), activeMembers);
    if (!membersInOGForValidation.isMemberExistsOverLimit) {
      const selectedDriver = this.driverDetailsModel.selectedDriver;
      const isAddedDriverDuplicated = this.driverDetailsUtilityService.isAddedDriverDuplicated(this, selectedDriver.personId);
      if (!isAddedDriverDuplicated.isRemovedInLocalStore && !isAddedDriverDuplicated.isAddedInLocalStore) {
        this.resetPairedDriverValidation();
        this.driverDetailsModel.driverDetailsError = null;
        this.driverDetailsModel.overRideDriverErrorMsgs = [];
        const operGroup = this.driverDetailsModel.operationalGroupData;
        const operGroupType = this.driverDetailsModel.operationalGroupForm.controls['operationalGroupCategory'].value.label
          || operGroup.operationalGroupTypeCode;
        const memberValidationRequest = {
          memberIds: selectedDriver.personId, operationalGroupType: operGroupType, action: 'add',
          memberName: this.driverDetailsUtilityService.getDriverNameForValidation(this)
        };
        this.driverDetailsModel.isTemporaryDriverLoaded = true;
        this.driverDetailsService.postMemberBusinessValidation(this.getOperationalGroupCode(), memberValidationRequest)
          .pipe(takeWhile(() => this.driverDetailsModel.canSubscribe), finalize(() => {
            this.driverDetailsModel.isTemporaryDriverLoaded = false;
            this.changeDetector.detectChanges();
          })).subscribe((response) => {
            this.resetPairedDriverValidation();
            this.onUpdateDriverDataIntoTable();
          }, (validationError) => {
            this.setValidationErrForPostCall(validationError);
          });
      } else if (isAddedDriverDuplicated.isRemovedInLocalStore && !isAddedDriverDuplicated.isAddedInLocalStore) {
        this.resetPairedDriverValidation();
        this.onUpdateDriverDataIntoTable();
      }
    } else {
      this.messageService.clear();
      this.messageService.add(membersInOGForValidation.memberExistsToastMsg);
    }
  }
  setValidationErrForPostCall(validationError: any) {
    if (validationError.status === 400) {
      const errorJson = typeof validationError.error === 'string' ? JSON.parse(validationError.error) : validationError.error;
      this.driverDetailsUtilityService.executeMemberValidation(this, this.utilityService.getMemberValidationResponse(errorJson));
      this.driverDetailsModel.driverDetailsError = errorJson;
    }
  }
  resetPairedDriverValidation() {
    this.driverDetailsModel.overRideDriver = 'N';
    this.driverDetailsModel.overRidePaired = 'N';
  }
  onAddTemporaryDriverBtnClicked() {
    if (this.driverDetailsModel.operationalGroupForm.valid) {
      this.driverDetailsModel.isSaveCancelBtnsVisible = true;
      this.driverDetailsModel.isAddTemporaryTableVisible = false;
      this.driverDetailsUtilityService.setAddedDriverChkBoxControl(this);
      this.driverDetailsModel.temporaryDriverListData.unshift(this.driverDetailsUtilityService.getEmptyDriverData());
      this.utilityService.setIsAddMemberClicked(true, this.getOperationalGroupCode());
      this.changeDetector.detectChanges();
    }
    this.addMemberClicked.emit();
  }
  onAddDriverCancelBtnClicked() {
    this.driverDetailsUtilityService.resetAddedDriverChkBoxControl(this);
    this.utilityService.setIsAddMemberClicked(false, this.getOperationalGroupCode());
    this.resetTempDriverListView();
  }
  onDriverSaveBtnClicked() {
    if (this.driverDetailsModel.tempDriverForm.valid && this.driverDetailsModel.selectedDriver) {
      this.driverDetailsModel.tempDriverForm['controls']['tempDriverName'].setErrors(null);
      const endDateValidation = this.driverDetailsUtilityService.getEndDateValidated(this);
      if (endDateValidation.isValid) { this.initInlineSaveBusinessValidation(); } else {
        this.messageService.clear();
        this.messageService.add(endDateValidation.endDateError);
        this.driverDetailsModel.tempDriverForm['controls']['tempDriverExpireDate'].setErrors({ incorrect: true });
      }
    } else {
      if (!this.driverDetailsModel.selectedDriver) {
        this.driverDetailsModel.tempDriverForm['controls']['tempDriverName'].setErrors({ incorrect: true });
      }
      this.messageService.clear();
      this.messageService.add(this.driverDetailsModel.addTempDriverError);
    }
    this.driverDetailsModel.tempDriverForm['controls']['tempDriverName'].markAsTouched();
    this.driverDetailsModel.tempDriverForm['controls']['tempDriverExpireDate'].markAsTouched();
    this.changeDetector.detectChanges();
  }
  onUpdateDriverDataIntoTable() {
    this.driverDetailsUtilityService.updateDriverDataIntoLocalstore(this);
  }
  onConfirmYesClicked() {
    this.onUpdateDriverPairedValidations();
    this.onUpdateDriverDataIntoTable();
  }
  onUpdateDriverPairedValidations() {
    this.resetPairedDriverValidation();
    const errorJSON = this.driverDetailsModel.driverDetailsError;
    if (errorJSON && errorJSON.errors && errorJSON.errors.length > 0) {
      const validationErrorCode = errorJSON.errors[0].code;
      switch (validationErrorCode) {
        case 'EX_DRIVER_HAVING_PAIRING_TRUCK':
          this.driverDetailsModel.overRidePaired = 'Y';
          break;
        case 'EX_DRIVER_EXISTS_IN_OTHER_OG_WITH_PAIRING_TRUCK':
          this.driverDetailsModel.overRideDriver = 'Y';
          this.driverDetailsModel.overRidePaired = 'Y';
          break;
        case 'EX_DRIVER_EXISTS_IN_OTHER_OG':
          this.driverDetailsModel.overRideDriver = 'Y';
          break;
        default:
          break;
      }
    }
  }
  onTempDriverHeaderChanged(isHeaderChecked: boolean) {
    this.driverDetailsModel.removedDriverListData = [];
    if (this.utilityService.getIsAddMemberClicked()) {
      this.initActionReqdErrorOnRemove();
      this.driverDetailsModel.tempDriverForm['controls'].tempDriverHeaderCheckBox.setValue(false);
    } else {
      this.setCheckedForDriverCheckboxes(isHeaderChecked);
      if (isHeaderChecked) {
        this.driverDetailsModel.removedDriverListData = lodashutils.cloneDeep(this.driverDetailsModel.temporaryDriverListData);
      }
      this.onValidateCheckBox();
    }
  }
  onTempDriverChanged(isChecked: boolean, rowIndex: number, rowData: ElasticDriverDetails) {
    if (this.utilityService.getIsAddMemberClicked()) {
      this.initActionReqdErrorOnRemove();
      this.driverDetailsModel.tempDriverFormCheckBoxArray[rowIndex]['tempDriverCheckBox'].setValue(false);
    } else {
      this.driverDetailsUtilityService.setRemovedDriverData(this, isChecked, rowData);
      this.onValidateCheckBox();
    }
  }
  onAutocompleteSearch(event) {
    const searchTxt = Utils.formattedSearchText(event.query);
    this.driverDetailsModel.driverListWidth = (event.originalEvent && event.originalEvent.srcElement) ?
      (event.originalEvent.srcElement.scrollWidth - this.driverDetailsModel.driverListInputPadding) :
      this.driverDetailsModel.driverListDefaultWidth;
    this.driverDetailsModel.selectedDriver = null;
    this.driverDetailsService.getDriverOnTypeahead(DriverDetailsQuery.getDriverElasticQuery(searchTxt)).pipe(
      takeWhile(() => this.driverDetailsModel.canSubscribe),
      finalize(() => { this.changeDetector.detectChanges(); }))
      .subscribe((driverResponse: ElasticResponseModel) => {
        this.driverDetailsModel.typeaheadDriverList = this.driverDetailsUtilityService.getDriverInfoFromTypeahead(driverResponse);
        this.setDriverImagesForDrivers(lodashutils.map(this.driverDetailsModel.typeaheadDriverList, 'userId'),
          (driverImages: DriverImageResponse) => {
            this.driverDetailsModel.typeaheadDriverList = lodashutils.map(this.driverDetailsModel.typeaheadDriverList, (driver) => {
              const thumbPhotoUser = lodashutils.find(driverImages, { userId: driver.userId });
              driver.userProfileImg = (thumbPhotoUser && thumbPhotoUser.thumbPhoto) ?
                `data:image/jpeg;base64,${thumbPhotoUser.thumbPhoto}` : null;
              return driver;
            });
            this.changeDetector.detectChanges();
          });
      }, (error) => { this.driverDetailsModel.typeaheadDriverList = []; });
  }
  onDriverSelected(driverDetails: OperationalGroupSelectedDriverAssignment) {
    this.driverDetailsModel.selectedDriver = driverDetails;
    this.driverDetailsModel.tempDriverForm['controls']['tempDriverName']
      .setValue(`${driverDetails.operationalGroupDriverName} (${driverDetails.driverUserId})`);
  }
  onCalendarInput(calenderInputEvent: any) {
    const keyCode = calenderInputEvent.keyCode;
    if (!(keyCode >= 47 && keyCode <= 57)) { calenderInputEvent.preventDefault(); }
  }
  onDriverRemoveBtnClicked() {
    const removedDrivers = lodashutils.map(this.driverDetailsModel.removedDriverListData, 'DriverPersonID');
    this.removeDriverFromTheTable(removedDrivers);
    this.changeDetector.detectChanges();
  }
  onRemoveDriverCancelBtnClicked() {
    this.driverDetailsUtilityService.resetDriverDetailsView(this);
    this.setCheckedForDriverCheckboxes(false);
    this.driverDetailsModel.removedDriverListData = [];
    this.driverDetailsModel.tempDriverForm['controls'].tempDriverHeaderCheckBox.setValue(false);
    this.utilityService.setIsRemoveMemberClicked(false, this.getOperationalGroupCode());
  }
  onValidateCheckBox() {
    const driverDetailsModel = this.driverDetailsModel;
    const checkedValues = lodashutils.filter(driverDetailsModel.tempDriverFormCheckBoxArray, (driverCheckBox: FormControl): boolean => {
      return driverCheckBox['tempDriverCheckBox']['value'];
    });
    this.driverDetailsModel.isRemoveCancelBtnsVisible = (checkedValues.length !== 0);
    this.driverDetailsModel.isAddTemporaryTableVisible = !this.driverDetailsModel.isRemoveCancelBtnsVisible;
    const isHeaderCheckNeeded = (checkedValues.length === driverDetailsModel.temporaryDriverListData.length);
    this.driverDetailsModel.tempDriverForm['controls'].tempDriverHeaderCheckBox.setValue(isHeaderCheckNeeded);
    this.utilityService.setIsRemoveMemberClicked(driverDetailsModel.isRemoveCancelBtnsVisible, this.getOperationalGroupCode());
    this.changeDetector.detectChanges();
  }
  onGridLazyLoad(sortView: SortView, driverType: string) {
    this.driverDetailsModel.driverChecking = driverType;
    if (this.driverDetailsModel.isProfileView && this.driverDetailsModel.operationalGroupData
      && !this.driverDetailsModel.isOperationalGroupChanged) {
      this.resetDriverListFields();
      this.driverDetailsModel.isTemporaryDriverListSorted = (driverType === 'temporary');
      this.driverDetailsModel.isPermanentDriverListSorted = (driverType === 'permanent');
      this.profileSortAndSearch.emit();
      const postableQuery = this.driverDetailsUtilityService.getDriverSortQuery(this, driverType, sortView);
      this.setDriverDetailsForOperGroupCode(postableQuery);
      this.changeDetector.detectChanges();
    }
  }

  removeDriverFromTheTable(removedDrivers: number[]) {
    this.driverDetailsUtilityService.removeDriversFromTable(this, removedDrivers);
    this.onRemoveDriverCancelBtnClicked();
  }
  resetTempDriverListView() {
    this.driverDetailsModel.tempDriverForm.reset();
    this.driverDetailsModel.isSaveCancelBtnsVisible = false;
    this.driverDetailsModel.isConfirmDialogVisible = false;
    this.driverDetailsModel.isAddTemporaryTableVisible = true;
    this.driverDetailsModel.temporaryDriverListData = this.driverDetailsUtilityService
      .getIterateCancelDriverData(this.driverDetailsModel.temporaryDriverListData);
    this.driverDetailsModel.confirmDialogMsgVisibility = lodashutils.cloneDeep(this.driverDetailsModel.confirmDialogMsgJson);
    this.driverDetailsModel.memberValidationResponseMessage = this.driverDetailsUtilityService
      .getDefaultValidationResponse(this.driverDetailsModel.operationalGroupCode);
    this.onRemoveDriverCancelBtnClicked();
    this.changeDetector.detectChanges();
  }
  resetDetailsForProfileView() {
    this.temporaryDriverTable._sortOrder = null;
    this.permanentDriverTable._sortOrder = null;
    this.permanentDriverTable._sortField = null;
    this.temporaryDriverTable._sortField = null;
    this.driverDetailsModel.tempDriverForm.controls[`temporaryDriverElasticSearchTxtBox`].setValue('');
    this.driverDetailsModel.tempDriverForm.controls[`permanentDriverElasticSearchTxtBox`].setValue('');
    this.driverDetailsModel.temporaryProfileSortAndSearchQuery = this.driverDetailsUtilityService.getDefaultProfileSortAndSearchQuery();
    this.driverDetailsModel.permanentProfileSortAndSearchQuery = this.driverDetailsUtilityService.getDefaultProfileSortAndSearchQuery();
    this.changeDetector.detectChanges();
  }
  resetDriverListFields() {
    this.driverDetailsModel.totalMembersForScrollValidation = 0;
    this.driverDetailsModel.isScrollServiceHappend = false;
    this.driverDetailsModel.recordFrom = 0;
    this.driverDetailsModel.recordDefaultSize = 100;
  }
  infiniteScrollImplementation() {
    const scrollableCount = this.driverDetailsModel.recordFrom +
      this.driverDetailsModel.recordDefaultSize;
    if (this.driverDetailsModel.teamDetailsScrollInformation.isMemberServiceNeedsToCall
      && this.driverDetailsModel.isDriverListPopulated
      && this.driverDetailsModel.teamDetailsScrollInformation.currentTabSelectionIdx === 0 &&
      this.driverDetailsModel.totalMembersForScrollValidation > scrollableCount) {
      this.driverDetailsModel.isScrollServiceHappend = true;
      this.driverDetailsModel.recordFrom = this.driverDetailsModel.recordFrom +
        this.driverDetailsModel.recordDefaultSize;
      this.setDriversDetails(this.driverDetailsModel.operationalGroupCode);
    }
  }
}
