import { TrailingDetailsQuery } from './trailing-details.query';
const operationalGroup = { operationalGroupCode: 'DCS' };
describe('TrailingDetailsQuery', () => {
    it('getTrailingDetails have been called with record size', () => {
        const result = TrailingDetailsQuery.getTrailingDetails(operationalGroup, 0, 25);
        expect(result).toBeTruthy();
    });
    it('getTrailerListElasticQuery have been called with profileSortSearch', () => {
        const profileSortSearch = {
            memberStartFrom: 0,
            sortableMember: 'type',
            sortableEvent: 'desc',
            searchType: 'test',
            expirationTimestamp: 'test',
            searchTxt: 'string'
        };
        const result = TrailingDetailsQuery.getTrailerListElasticQuery('DCS', 0, 25, profileSortSearch);
        expect(result).toBeTruthy();
    });
    it('getTrailerListSearchQuery have been called with search test', () => {
        const result = TrailingDetailsQuery.getTrailerListSearchQuery('test');
        expect(result).toBeTruthy();
    });
});
