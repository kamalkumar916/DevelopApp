import { ProfileSortAndSearch } from './../../model/team-details.interface';

export class CarrierDetailsQuery {
    static getCarrierQuery(searchValue: string) {
        return {
            from: 0,
            size: 3,
            'query': {
                'bool': {
                    'must': [
                        {
                            'match': {
                                'CarrierStatus': 'A'
                            }
                        }
                    ],
                    'should': [
                        {
                            'query_string': {
                                'default_field': 'CarrierName',
                                'query': searchValue
                            }
                        }
                    ]
                }
            },
            '_source': []

        };
    }
    static getCarrierNameQuery(filterVariables: any) {
        return {
            from: 0,
            size: 6,
            'query': {
                'bool': {
                    'should': [
                        {
                            'query_string': {
                                'default_field': 'CarrierName',
                                'query': `${filterVariables.searchValue}*`,
                                'default_operator': 'AND'
                            }
                        }
                    ]
                }
            },
            '_source': [],
            'sort': [
                {
                    'CarrierName.keyword': {
                        'order': 'asc'
                    }
                }
            ]
        };
    }

    static getOperationalCodeQuery(filterGroupCodeVariables: any, recordsFrom: number, defaultSize: number) {
        return {

            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'OperationalGroupCode.keyword': filterGroupCodeVariables.operationalGroup
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupCarrierAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': defaultSize,
                                    'sort': [
                                        {
                                            'OperationalGroupCarrierAssignment.EffectiveTimestamp': {
                                                'order': 'desc'
                                            }
                                        }
                                    ]
                                },
                                'query': {
                                    'bool': {
                                        'must': [
                                            {
                                                'range': {
                                                    'OperationalGroupCarrierAssignment.ExpirationTimestamp': {
                                                        'gte': 'now',
                                                        'lte': '12/31/2199 11:59 PM CST',
                                                        'format': 'MM/dd/YYYY hh:mm a z'
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                }
            }

        };
    }

    static getCarrierListElasticQuery(operationalGroupCode: string, recordsFrom: number,
        noOfRecords: number, sortAndSearchProperty: ProfileSortAndSearch) {
        return {
            '_source': [
                'OperationalGroupCode',
                'OperationalGroupCarrierAssignment'
            ],
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'OperationalGroupCode.keyword': operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupCarrierAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': noOfRecords,
                                    'sort': [
                                        {
                                            [sortAndSearchProperty.sortableMember]:
                                                (sortAndSearchProperty.sortableEvent.sortOrder === -1) ? 'desc' : 'asc'
                                        }
                                    ]
                                },
                                'query': {
                                    'bool': {
                                        'must': this.getCarrierListSearchQuery(sortAndSearchProperty.searchTxt)
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };
    }

    static getCarrierListSearchQuery(searchTxt: string) {
        const carrierMustQuery: any = [{
            'range': {
                'OperationalGroupCarrierAssignment.ExpirationTimestamp': {
                    'gte': 'now',
                    'lte': '12/31/2199 11:59 PM CST',
                    'format': 'MM/dd/YYYY hh:mm a z'
                }
            }
        }];
        if (searchTxt && searchTxt.trim().length !== 0) {
            carrierMustQuery.push({
                'query_string': {
                    'fields': [
                        'OperationalGroupCarrierAssignment.CarrierName',
                        'OperationalGroupCarrierAssignment.CarrierCode'
                    ],
                    'query': `*${searchTxt}*`,
                    'default_operator': 'AND'
                }
            });
        }
        return carrierMustQuery;
    }


}
