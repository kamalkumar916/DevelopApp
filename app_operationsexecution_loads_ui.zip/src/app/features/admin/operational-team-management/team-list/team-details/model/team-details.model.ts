
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/api';
import { OperationalTeamManagementData, OperationalGroupFormData } from './team-details.interface';
import { TeamMemberScrollInformation } from './../../../model/operational-team.interface';
import { SecureModel } from '../../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../../config/app.config';

export class TeamDetailsModel {

    loaderFlag: boolean;
    canSubscribe: boolean;
    tabActiveIndex: number;
    detailLoaderFlag: boolean;
    base64ImageString: string;
    lastUpdatedFormat: string;
    operationalGroupCode: string;
    tabChangeEvent: any;
    utilizationStatusDescList: string[];
    pickableDataList: string[];
    operationalTeamData: OperationalTeamManagementData;
    isNewOperationalTeamToAdd: boolean;
    newOperationalGroupForm: FormGroup;
    categoryList: SelectItem[];
    categoryListLocal: SelectItem[];
    businessUnitList: string[];
    businessUnitListLocal: string[];
    typeList: SelectItem[];
    typeListLocal: SelectItem[];
    UtilizationStatusList: SelectItem[];
    isActiveOperationalGroup: boolean;
    operationalGroupFormData: OperationalGroupFormData;
    driverActiveDaysCount: number;
    teamDetailsScrollInformation: TeamMemberScrollInformation;
    teamDetailsScrollInfoToPost: string;
    editOperationalTeamButton: SecureModel;
    viewOperationalTeamButton: SecureModel;
    loadCategoryPresent: any;
    loadTypePresent: any;
    businessUnitPresent: any;
    utilizationStatusPresent: any;
    appConfig;
    constructor(private readonly formBuilder: FormBuilder) {
        this.detailLoaderFlag = false;
        this.utilizationStatusDescList = [];
        this.lastUpdatedFormat = 'M/D/YYYY hh:mmA';
        this.base64ImageString = 'data:image/jpeg;base64';
        this.pickableDataList = ['operationalGroupCode', 'operationalGroupTypeCode',
            'operationalGroupDescription', 'operationalGroupTypeDescription',
            'operationalGroupSubTypeCode', 'operationalGroupSubTypeDescription',
            'businessUnit', 'utilizationStatus'];
        this.newOperationalGroupForm = formBuilder.group({
            operationalGroupName: ['', Validators.required],
            operationalGroupIdentifier: ['', Validators.required],
            operationalGroupCategory: ['', Validators.required],
            operationalGroupType: [''],
            operationalGroupBU: ['', Validators.required],
            operationalGroupUtilization: ['']
        });
        this.operationalGroupFormData = {
            isValidForm: false, operationalGroupData: null
        };
        this.categoryList = [];
        this.categoryListLocal = [];
        this.typeList = [];
        this.typeListLocal = [];
        this.businessUnitList = [];
        this.businessUnitListLocal = [];
        this.teamDetailsScrollInformation = {
            isMemberServiceNeedsToCall: false, currentTabSelectionIdx: 0,
            scrollTop: 0
        };
        this.appConfig = AppConfig.getConfig();
        this.editOperationalTeamButton = { url: this.appConfig.api.admin.getOperationalTeamDetails, operation: 'C' };
        this.viewOperationalTeamButton = { url: this.appConfig.api.admin.getOperationalTeamDetails, operation: 'R' };
    }
}
