import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../../shared/service/app-config.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { TeamDetailsService } from './team-details.service';
import { configureTestSuite } from 'ng-bullet';

describe('TeamDetailsService', () => {
  let service: TeamDetailsService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [TeamDetailsService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(TeamDetailsService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes expected getoperationalteamdetails calls', () => {
    const groupCode = '3M4';
    service.getOperationalTeamDetails(groupCode).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}?operationalGroupCode=${groupCode}`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected businessunit calls', () => {
    service.getBUForTransferInitiation().subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getBusinessUnit}?size=1000`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected getOperationalGroupTypes calls', () => {
    service.getOperationalGroupType().subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalGroupTypes}?size=1000`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected getOperationalGroupSubType calls', () => {
    service.getOperationalGroupSubType().subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalGroupSubtypes}?size=1000`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected getUtilizationStatus calls', () => {
    service.getUtilizationStatus().subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getUtilizationStatuses}?size=1000`);
    expect(req.request.method).toEqual('GET');
  });
});
