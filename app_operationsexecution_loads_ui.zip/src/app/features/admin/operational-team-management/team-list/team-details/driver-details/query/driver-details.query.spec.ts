import { DriverDetailsQuery } from './driver-details.query';

describe('DriverDetailsQuery', () => {

    it('getTemporaryDriverElasticQuery have been called', () => {
        spyOn(DriverDetailsQuery, 'getSortableQueryArray');
        spyOn(DriverDetailsQuery, 'getDriverDetailsShouldQuery');
        const sortAndSearchData = {
            memberStartFrom: 0, sortableMember: 'az', sortableEvent: {},
            searchType: 'txt', expirationTimestamp: '01/01/2020', searchTxt: ''
        };
        const result = DriverDetailsQuery.getTemporaryDriverElasticQuery('ogCode', 1, 25, sortAndSearchData);
        expect(result).toBeTruthy();
        expect(DriverDetailsQuery.getSortableQueryArray).toHaveBeenCalled();
        expect(DriverDetailsQuery.getDriverDetailsShouldQuery).toHaveBeenCalled();
    });

    it('getPermanentDriverElasticQuery have been called', () => {
        spyOn(DriverDetailsQuery, 'getSortableQueryArray');
        spyOn(DriverDetailsQuery, 'getDriverDetailsShouldQuery');
        const sortAndSearchData = {
            memberStartFrom: 0, sortableMember: 'az', sortableEvent: {},
            searchType: 'txt', expirationTimestamp: '01/01/2020', searchTxt: ''
        };
        const result = DriverDetailsQuery.getPermanentDriverElasticQuery('ogCode', 1, 25, sortAndSearchData);
        expect(result).toBeTruthy();
        expect(DriverDetailsQuery.getSortableQueryArray).toHaveBeenCalled();
        expect(DriverDetailsQuery.getDriverDetailsShouldQuery).toHaveBeenCalled();
    });

    it('getDriverNameRelatedMustQuery have been called', () => {
        spyOn(DriverDetailsQuery, 'getDriverNameQuery');
        const result = DriverDetailsQuery.getDriverNameRelatedMustQuery('ogCode');
        expect(result).toBeTruthy();
        expect(DriverDetailsQuery.getDriverNameQuery).toHaveBeenCalled();
    });

    it('getDriverDetailsShouldQuery have been called with Search Type Text', () => {
        spyOn(DriverDetailsQuery, 'getDriverNameRelatedMustQuery');
        const result = DriverDetailsQuery.getDriverDetailsShouldQuery('ovCode', 'text');
        expect(result).toBeTruthy();
        expect(result[0].query_string).toBeTruthy();
    });

    it('getDriverDetailsShouldQuery have been called with Search Type Text with two Spaces', () => {
        spyOn(DriverDetailsQuery, 'getDriverNameRelatedMustQuery');
        const result = DriverDetailsQuery.getDriverDetailsShouldQuery('ovCode ovG', 'text');
        expect(result).toBeTruthy();
        expect(result[0].query_string).toBeTruthy();
        expect(result[1].bool).toBeTruthy();
    });

    it('getDriverDetailsShouldQuery have been called with Search Type date', () => {
        spyOn(DriverDetailsQuery, 'getDriverNameRelatedMustQuery');
        const result = DriverDetailsQuery.getDriverDetailsShouldQuery('ovCode', 'date');
        expect(result).toBeTruthy();
        expect(result[0].query_string).toBeTruthy();
    });

    it('getSortableQueryArray have been called with Switch Name', () => {
        spyOn(DriverDetailsQuery, 'sortNameQuery');
        const sortAndSearchData = {
            memberStartFrom: 0, sortableMember: 'Name', sortableEvent: {},
            searchType: 'txt', expirationTimestamp: '01/01/2020', searchTxt: ''
        };
        const result = DriverDetailsQuery.getSortableQueryArray(sortAndSearchData);
        expect(result).toBeTruthy();
    });

    it('getSortableQueryArray have been called Switch End Date', () => {
        spyOn(DriverDetailsQuery, 'sortNameQuery');
        const sortAndSearchData = {
            memberStartFrom: 0, sortableMember: 'End Date', sortableEvent: {},
            searchType: 'txt', expirationTimestamp: '01/01/2020', searchTxt: ''
        };
        const result = DriverDetailsQuery.getSortableQueryArray(sortAndSearchData);
        expect(result).toBeTruthy();
    });

    it('getSortableQueryArray have been called Switch Default', () => {
        spyOn(DriverDetailsQuery, 'sortNameQuery');
        const sortAndSearchData = {
            memberStartFrom: 0, sortableMember: 'Any Value', sortableEvent: {},
            searchType: 'txt', expirationTimestamp: '01/01/2020', searchTxt: ''
        };
        const result = DriverDetailsQuery.getSortableQueryArray(sortAndSearchData);
        expect(result).toBeTruthy();
    });

    it('getDriverElasticQuery have been called', () => {
        const result = DriverDetailsQuery.getDriverElasticQuery('elStx');
        expect(result).toBeTruthy();
    });

    it('getDriverNameQuery have been called', () => {
        const result = DriverDetailsQuery.getDriverNameQuery('drvrName', 'splitTxt');
        expect(result).toBeTruthy();
    });

    it('sortNameQuery have been called with desc', () => {
        const sortAndSearchData = {
            memberStartFrom: 0, sortableMember: 'Name', sortableEvent: { sortOrder: -1 },
            searchType: 'txt', expirationTimestamp: '01/01/2020', searchTxt: ''
        };
        const result = DriverDetailsQuery.sortNameQuery(sortAndSearchData);
        expect(result).toBeTruthy();
        expect(result).toBe('desc');
    });

    it('sortNameQuery have been called with asc', () => {
        const sortAndSearchData = {
            memberStartFrom: 0, sortableMember: 'Name', sortableEvent: { sortOrder: 1 },
            searchType: 'txt', expirationTimestamp: '01/01/2020', searchTxt: ''
        };
        const result = DriverDetailsQuery.sortNameQuery(sortAndSearchData);
        expect(result).toBeTruthy();
        expect(result).toBe('asc');
    });

});
