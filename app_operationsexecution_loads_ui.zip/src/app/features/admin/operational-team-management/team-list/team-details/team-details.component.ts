import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter,
  Input, Output, OnDestroy, OnInit, ViewChild
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TabView, TabPanel } from 'primeng/primeng';
import { SelectItem } from 'primeng/api';
import { takeWhile, finalize } from 'rxjs/operators';
import { MessageService } from 'primeng/components/common/messageservice';
import * as lodashUtils from 'lodash';
import { BusinessUnit } from '../../../../drivertask/search-driver-task/advance-search/model/advance-search-interface';
import { TeamDetailsModel } from './model/team-details.model';
import { UpdateGroupStatusResponse } from './../model/team-list.interface';
import { OperationalTeamManagementData, OperationalGroupFormData, OperationalGroupField } from './model/team-details.interface';
import { OperationalTeamUtilityService } from '../../services/operational-team-utility.service';
import { TeamDetailsService } from './services/team-details.service';
import { TeamDetailsUtilityService } from './services/team-details-utility.service';

@Component({
  selector: 'app-team-details',
  templateUrl: './team-details.component.html',
  styleUrls: ['./team-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TeamDetailsComponent implements OnInit, OnDestroy {
  @Input()
  set driverActiveDaysCount(daysCount: number) {
    this.teamDetailsModel.driverActiveDaysCount = daysCount;
  }
  @Input()
  set newOperationalTeamToAdd(isNewOperationalTeam: boolean) {
    this.teamDetailsModel.isNewOperationalTeamToAdd = isNewOperationalTeam;
  }
  @Input()
  set operationalGroupCode(operationalGroupCodeArg: string) {
    this.teamDetailsModel.tabActiveIndex = 0;
    this.onSelectTab(this.teamDetailsModel.tabActiveIndex);
    this.setOperationalTeamDetails(operationalGroupCodeArg);
  }
  @Input()
  set operationalGroupStatus(operationalGroupStatus: UpdateGroupStatusResponse) {
    if (operationalGroupStatus) {
      this.setOperationalTeamDetails(this.teamDetailsModel.operationalGroupCode);
    }
  }

  @Output() provideMaskForSplitView: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() operationalGroupData: EventEmitter<OperationalTeamManagementData> = new EventEmitter<OperationalTeamManagementData>();

  @ViewChild(TabView) tabView: TabView;
  @ViewChild('teamDetail') teamDetailContent: ElementRef;
  teamDetailsModel: TeamDetailsModel;

  constructor(
    private readonly changeDetector: ChangeDetectorRef, private readonly teamDetailsService: TeamDetailsService,
    private readonly utilityService: OperationalTeamUtilityService, private readonly teamDetailsUtilityService: TeamDetailsUtilityService,
    private readonly messageService: MessageService, private readonly formBuilder: FormBuilder
  ) {
    this.teamDetailsModel = new TeamDetailsModel(this.formBuilder);
    this.teamDetailsModel.canSubscribe = true;
  }

  ngOnInit() {
    this.teamDetailsModel.canSubscribe = true;
    this.teamDetailsModel.newOperationalGroupForm.reset();
    if (this.teamDetailsModel.isNewOperationalTeamToAdd) {
      this.loadFieldLevelServices();
    }
  }
  ngOnDestroy() {
    this.teamDetailsModel.canSubscribe = false;
    if (this.teamDetailsModel.loadCategoryPresent) {
      this.teamDetailsModel.loadCategoryPresent.unsubscribe();
    }
    if (this.teamDetailsModel.loadTypePresent) {
      this.teamDetailsModel.loadTypePresent.unsubscribe();
    }
    if (this.teamDetailsModel.businessUnitPresent) {
      this.teamDetailsModel.businessUnitPresent.unsubscribe();
    }
    if (this.teamDetailsModel.utilizationStatusPresent) {
      this.teamDetailsModel.utilizationStatusPresent.unsubscribe();
    }
  }

  hasAccess(operation: string): boolean {
    return this.utilityService.hasESAAccess(operation);
  }

  loadFieldLevelServices() {
    this.loadCategory();
    this.loadType();
    this.loadBusinessUnit();
    this.loadUtilizationStatus();
    this.updateActiveLoadEditableFields();
  }
  loadCategory() {
    if (this.teamDetailsModel.isNewOperationalTeamToAdd) {
      if (this.teamDetailsModel.loadCategoryPresent) {
        this.teamDetailsModel.loadCategoryPresent.unsubscribe();
      }
      this.teamDetailsModel.loadCategoryPresent = this.teamDetailsService.getOperationalGroupType().pipe(
        finalize(() => {
          this.teamDetailsModel.categoryListLocal = this.teamDetailsModel.categoryList;
          this.changeDetector.detectChanges();
        }))
        .subscribe((response: OperationalGroupField) => {
          this.teamDetailsModel.categoryList = this.teamDetailsUtilityService.getOGGroupFieldValues('operationalGroupType', response);
        }, (error) => {
          this.teamDetailsModel.categoryList = [];
        });
    }
  }
  loadType() {
    if (this.teamDetailsModel.loadTypePresent) {
      this.teamDetailsModel.loadTypePresent.unsubscribe();
    }
    this.teamDetailsModel.loadTypePresent = this.teamDetailsService.getOperationalGroupSubType().pipe(
      finalize(() => {
        this.teamDetailsModel.typeListLocal = this.teamDetailsModel.typeList;
        this.changeDetector.detectChanges();
      }))
      .subscribe((response: OperationalGroupField) => {
        this.teamDetailsModel.typeList = this.teamDetailsUtilityService.getOGGroupFieldValues('operationalGroupSubtype', response);
      }, (error) => {
        this.teamDetailsModel.typeList = [];
      });
  }
  loadBusinessUnit() {
    if (this.teamDetailsModel.businessUnitPresent) {
      this.teamDetailsModel.businessUnitPresent.unsubscribe();
    }
    this.teamDetailsModel.businessUnitPresent = this.teamDetailsService.getBUForTransferInitiation().pipe(
      finalize(() => { this.changeDetector.detectChanges(); }))
      .subscribe((response: BusinessUnit) => {
        if (response && response._embedded && response._embedded.serviceOfferingBusinessUnitTransitModeAssociations) {
          this.teamDetailsUtilityService.setBusinessUnit(this, response);
        }
      }, (error) => {
        this.teamDetailsModel.businessUnitList = [];
        this.teamDetailsModel.businessUnitListLocal = [];
      });
  }
  loadUtilizationStatus() {
    if (this.teamDetailsModel.utilizationStatusPresent) {
      this.teamDetailsModel.utilizationStatusPresent.unsubscribe();
    }
    this.teamDetailsModel.utilizationStatusPresent = this.teamDetailsService.getUtilizationStatus().pipe(
      finalize(() => { this.changeDetector.detectChanges(); }))
      .subscribe((response: OperationalGroupField) => {
        this.teamDetailsModel.UtilizationStatusList = this.teamDetailsUtilityService.getOGGroupFieldValues('utilizationStatus', response);
      }, (error) => {
        this.teamDetailsModel.UtilizationStatusList = [];
      });
  }

  updateActiveLoadEditableFields() {
    if (this.teamDetailsModel.isActiveOperationalGroup) {
      const ogData = this.teamDetailsModel.operationalTeamData;
      this.teamDetailContent.nativeElement.scrollTop = 0;
      const utilizationStatusDescList = lodashUtils.map(ogData.utilizationStatus, 'utilizationStatusCode');
      this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupName'].setValue(ogData.operationalGroupDescription);
      this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupUtilization'].patchValue(utilizationStatusDescList);
      this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupIdentifier'].setValue(ogData.operationalGroupCode);
      this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupBU'].setValue({
        'label': ogData.financeBusinessUnitCode, 'value': ogData.financeBusinessUnitCode
      });
      this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupType'].setValue({
        'label': ogData.operationalGroupSubTypeDescription, 'value': ogData.operationalGroupSubTypeCode
      });
      this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupCategory'].setValue({
        'label': ogData.operationalGroupTypeCode, 'value': ogData.operationalGroupTypeCode
      });
    }
  }

  onHandleTabChange(tabChangeEvt) {
    if (!this.utilityService.getIsAddMemberClicked() && !this.utilityService.getIsRemoveMemberClicked()) {
      this.teamDetailsModel.tabChangeEvent = tabChangeEvt;
      this.teamDetailsModel.tabActiveIndex = tabChangeEvt.index;
      this.teamDetailContent.nativeElement.scrollTop = 0;
    } else {
      this.onSelectTab(this.teamDetailsModel.tabActiveIndex);
      this.messageService.clear();
      this.messageService.add(this.utilityService.getActionReqdError());
    }
  }
  onSelectTab(idx: number) {
    if (this.tabView && this.tabView.tabs) {
      for (const tab of this.tabView.tabs) {
        if (tab.selected) {
          tab.selected = false;
        }
      }
      this.tabView.tabs[idx].selected = true;
    }
  }
  onAutoCompleteFields(searchEvent: any, autoCompleteListProperty: string) {
    const autoCompleteList = [];
    for (const autoCompleteData of this.teamDetailsModel[`${autoCompleteListProperty}Local`]) {
      const listValue = autoCompleteData.label || autoCompleteData;
      if (listValue.toLowerCase().indexOf(searchEvent.query.toLowerCase()) === 0) {
        autoCompleteList.push(autoCompleteData);
      }
    }
    this.teamDetailsModel[autoCompleteListProperty] = autoCompleteList;
    this.changeDetector.detectChanges();
  }
  onNameIdentityTyped(event: any): boolean | undefined {
    const regex = new RegExp('^[a-zA-Z0-9\\s]+$');
    const key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) {
      event.preventDefault();
      return false;
    }
  }
  onIdentifierBlurred(event: any) {
    this.resetOperationalTeamDetails();
    this.teamDetailsModel.operationalTeamData.operationalGroupCode = event.target.value;
    this.processLocalStorageService();
  }

  processLocalStorageService() {
    this.utilityService.setOperationalGroupData(
      this.teamDetailsUtilityService.getLocalStoragePostableData(this, this.teamDetailsModel.operationalTeamData)
    );
  }

  setOperationalTeamDetails(operationalGroupCode: string) {
    if (operationalGroupCode) {
      this.teamDetailsModel.loaderFlag = true;
      this.teamDetailsModel.operationalGroupCode = operationalGroupCode;
      this.teamDetailsService.getOperationalTeamDetails(operationalGroupCode).pipe(
        takeWhile(() => this.teamDetailsModel.canSubscribe),
        finalize(() => {
          this.teamDetailsModel.loaderFlag = false;
          this.processLocalStorageService();
          this.provideMaskForSplitView.emit(this.teamDetailsModel.loaderFlag);
          this.setIsActiveOperationalGroup(this.teamDetailsModel.operationalTeamData);
          this.operationalGroupData.emit(this.teamDetailsModel.operationalTeamData);
          if (this.teamDetailsModel.isActiveOperationalGroup) {
            this.loadFieldLevelServices();
          }
          this.changeDetector.detectChanges();
        }))
        .subscribe((response: OperationalTeamManagementData) => {
          if (response) {
            this.teamDetailsModel.operationalTeamData = this.teamDetailsUtilityService.getOperationalTeamListInformation(this, response);
          } else {
            this.resetOperationalTeamDetails();
          }
        }, (error: Error) => {
          this.resetOperationalTeamDetails();
        });
    }
  }
  setIsActiveOperationalGroup(operationalGroupData: OperationalTeamManagementData) {
    this.teamDetailsModel.isActiveOperationalGroup = !(operationalGroupData && operationalGroupData.status === 'Inactive');
  }

  resetOperationalTeamDetails() {
    this.teamDetailsModel.operationalTeamData = this.teamDetailsUtilityService.getEmptyOperationalTeamListInformation();
  }
  resetOperationalGroupStaticData() {
    this.teamDetailsModel.operationalGroupFormData = { isValidForm: false, operationalGroupData: null };
  }

  getOperationalGroupFormData(): OperationalGroupFormData {
    this.resetOperationalGroupStaticData();
    if (this.teamDetailsModel.newOperationalGroupForm.valid) {
      this.teamDetailsModel.operationalGroupFormData.isValidForm = this.teamDetailsModel.newOperationalGroupForm.valid;
      this.teamDetailsModel.operationalGroupFormData.operationalGroupData = this.teamDetailsUtilityService.getOperationalGroupData(this);
    }
    return this.teamDetailsModel.operationalGroupFormData;
  }

  markAllFieldsTouched() {
    this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupBU'].markAsTouched();
    this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupName'].markAsTouched();
    this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupType'].markAsTouched();
    this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupCategory'].markAsTouched();
    this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupIdentifier'].markAsTouched();
    this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupUtilization'].markAsTouched();
    this.changeDetector.detectChanges();
  }

  onOptionalFieldBlurred(event: any, formControlName: string) {
    this.teamDetailsModel.newOperationalGroupForm.controls[formControlName].setValue(null);
  }

  onTeamDetailsScroll(event: any) {
    const scrollableElement = event.target;
    const scrollableElementHeight = scrollableElement.scrollHeight - scrollableElement.clientHeight;
    this.teamDetailsModel.teamDetailsScrollInformation = {
      scrollTop: scrollableElement.scrollTop, currentTabSelectionIdx: this.teamDetailsModel.tabActiveIndex,
      isMemberServiceNeedsToCall: (scrollableElementHeight === scrollableElement.scrollTop)
    };
    this.teamDetailsModel.teamDetailsScrollInfoToPost = JSON.stringify(this.teamDetailsModel.teamDetailsScrollInformation);
    this.changeDetector.detectChanges();
  }

  getIsValidUtilizationStatus(): boolean {
    return (this.teamDetailsModel && this.teamDetailsModel.newOperationalGroupForm &&
      this.teamDetailsModel.newOperationalGroupForm.get('operationalGroupUtilization')
      && this.teamDetailsModel.newOperationalGroupForm.get('operationalGroupUtilization').value &&
      this.teamDetailsModel.newOperationalGroupForm.get('operationalGroupUtilization').value.length !== 0);
  }
  checkIsUtilizationExists(): boolean {
    if (this.teamDetailsModel.newOperationalGroupForm) {
      const utilization = this.teamDetailsModel.newOperationalGroupForm.controls['operationalGroupUtilization'];
      return (utilization && utilization.value && utilization.value.length > 0);
    }
    return false;
  }

}
