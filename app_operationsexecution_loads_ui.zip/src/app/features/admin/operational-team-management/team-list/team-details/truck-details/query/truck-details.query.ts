import { ProfileSortAndSearch } from './../../model/team-details.interface';

export class TruckDetailsQuery {

    static getOperationalCodeQuery(filterGroupCodeVariables: any, recordsFrom: number, defaultSize: number) {
        return {

            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'OperationalGroupCode.keyword': filterGroupCodeVariables.operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupEquipmentAssignment',
                                'query': {
                                    'bool': {
                                        'must': [{
                                            'range': {
                                                'OperationalGroupEquipmentAssignment.ExpirationTimestamp': {
                                                    'gte': 'now',
                                                    'lte': '12/31/2199 11:59 PM CST',
                                                    'format': 'MM/dd/YYYY hh:mm a z'
                                                }
                                            }
                                        }, {
                                            'match': {
                                                'OperationalGroupEquipmentAssignment.EquipmentClassificationCode': 'Tractor'
                                            }
                                        }]
                                    }
                                },
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': defaultSize,
                                    'sort': [
                                        {
                                            'OperationalGroupEquipmentAssignment.EffectiveTimestamp': {
                                                'order': 'desc'
                                            }
                                        }
                                    ]

                                }
                            }

                        }
                    ]
                }

            }
        };
    }

    static getTruckListElasticQuery(operationalGroupCode: string, recordsFrom: number,
        noOfRecords: number, sortAndSearchProperty: ProfileSortAndSearch) {
        return {
            '_source': [
                'OperationalGroupCode',
                'OperationalGroupEquipmentAssignment'
            ],
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'OperationalGroupCode.keyword': operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupEquipmentAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': noOfRecords,
                                    'sort': [
                                        {
                                            [sortAndSearchProperty.sortableMember]:
                                                (sortAndSearchProperty.sortableEvent.sortOrder === -1) ? 'desc' : 'asc'
                                        }
                                    ]
                                },
                                'query': {
                                    'bool': {
                                        'must': this.getTruckListSearchQuery(sortAndSearchProperty.searchTxt)
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };
    }

    static getTruckListSearchQuery(searchTxt: string) {
        const truckMustQuery: any = [{
            'match': {
                'OperationalGroupEquipmentAssignment.EquipmentClassificationCode': 'Tractor'
            }
        }, {
            'range': {
                'OperationalGroupEquipmentAssignment.ExpirationTimestamp': {
                    'gte': 'now',
                    'lte': '12/31/2199 11:59 PM CST',
                    'format': 'MM/dd/YYYY hh:mm a z'
                }
            }
        }];
        truckMustQuery.push({
            'query_string': {
                'fields': [
                    'OperationalGroupEquipmentAssignment.EquipmentNumber'
                ],
                'query': `*${searchTxt}*`,
                'default_operator': 'AND'
            }
        });
        return truckMustQuery;
    }

}

