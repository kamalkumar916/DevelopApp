import { TruckDetailsQuery } from './truck-details.query';

describe('TruckDetailsQuery', () => {
    it('getTruckListSearchQuery have been called with Search Type Text', () => {
        const result = TruckDetailsQuery.getTruckListSearchQuery('text');
        expect(result).toBeTruthy();
    });
    it('getOperationalCodeQuery have been called with filter variables', () => {
        const result = TruckDetailsQuery.getOperationalCodeQuery({}, 0, 25);
        expect(result).toBeTruthy();
    });
    it('getTruckListElasticQuery have been called with empty param', () => {
        const param = {
            memberStartFrom: 25,
            sortableMember: 'name',
            sortableEvent: {},
            searchType: 'string',
            expirationTimestamp: 'string',
            searchTxt: 'string'
        };
        const result = TruckDetailsQuery.getTruckListElasticQuery('DCS', 25, 50, param);
        expect(result).toBeTruthy();
    });
    it('getTruckListElasticQuery have been called with paramValue', () => {
        const param = {
            memberStartFrom: 25,
            sortableMember: 'name',
            sortableEvent: { sortOrder: -1 },
            searchType: 'string',
            expirationTimestamp: 'string',
            searchTxt: 'string'
        };
        const result = TruckDetailsQuery.getTruckListElasticQuery('DCS', 25, 50, param);
        expect(result).toBeTruthy();
    });
});
