import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { CarrierDetailsComponent } from './carrier-details.component';
import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfigService } from '../../../../../../shared/service/app-config.service';
import { LocalStorageService } from '../../../../../../shared/jbh-app-services/local-storage.service';
import { UserService } from '../../../../../../shared/jbh-esa/index';
import { TableModule } from 'primeng/table';
import { CheckboxModule, PaginatorModule, AutoCompleteModule } from 'primeng/primeng';
import { ReactiveFormsModule, Validators } from '@angular/forms';
import { CarrierDetailsService } from './services/carrier-details.service';
import { OperationalTeamUtilityService } from '../../../services/operational-team-utility.service';
import { CarrierDetailsUtilityService } from './services/carrier-details-utility.service';
import { PipesModule } from '../../../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from '../../../../../../shared/directives/directives.module';
import { FormBuilder, FormGroup } from '@angular/forms';
import { cloneDeep } from 'lodash';
describe('CarrierDetailsComponent', () => {
  let component: CarrierDetailsComponent;
  let fixture: ComponentFixture<CarrierDetailsComponent>;
  const formBuilder = new FormBuilder();
  let formGroup: FormGroup;
  let carrierForm: FormGroup;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [CarrierDetailsComponent],
      imports: [RouterTestingModule,
        TableModule, CheckboxModule, PaginatorModule,
        AutoCompleteModule, ReactiveFormsModule, HttpClientTestingModule,
        NoopAnimationsModule, PipesModule, JbhLoaderModule, DirectivesModule],
      providers: [MessageService,
        CarrierDetailsService, OperationalTeamUtilityService,
        CarrierDetailsUtilityService, AppConfigService,
        LocalStorageService, UserService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarrierDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    formGroup = formBuilder.group({
      operationalGroupBU: [{}, Validators.required],
      operationalGroupCategory: [{}, Validators.required],
      operationalGroupIdentifier: ['', Validators.required],
      operationalGroupName: ['', Validators.required],
      operationalGroupType: [[], Validators.required]
    });
    carrierForm = formBuilder.group({
      carrierDetailsCode: ['', Validators.required],
      newCarrierCheckBox: [false],
      tempCarrierCheckBoxes: formBuilder.array([]),
      carrierListSearch: ['']
    });

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('onCancelBtnClicked have been called', () => {
    component.onCancelBtnClicked();
    expect(component.carrierDetailsModel.isAddBtnVisible).toBe(true);
  });
  it('onRemoveCarrierCancelClicked have been called', () => {
    component.onRemoveCarrierCancelClicked();
    expect(component.carrierDetailsModel.isRemoveLinkVisible).toBe(false);
  });
  it('resetCarrierListFields have been called', () => {
    component.resetCarrierListFields();
    expect(component.carrierDetailsModel.totalMembersForScrollValidation).toBe(0);
  });
  it('profileView have been set', () => {
    component.profileView = true;
    expect(component.carrierDetailsModel.isProfileView).toBe(true);
  });
  it('operationalGroupCode have been set', () => {
    component.operationalGroupCode = 'Test';
    expect(component.carrierDetailsModel.storableDataModel).toEqual([]);
    expect(component.carrierDetailsModel.isOperationalGroupChanged).toEqual(true);
  });
  it('isProfileView have been set', () => {
    component.profileView = true;
    expect(component.carrierDetailsModel.isProfileView).toBeTruthy();
  });
  it('newOperationalTeamToAdd have been set', () => {
    component.newOperationalTeamToAdd = true;
    expect(component.carrierDetailsModel.isNewOperationalGroup).toBeTruthy();
  });
  it('operationalGroupForm have been set', () => {
    component.operationalGroupForm = formGroup;
    expect(component.carrierDetailsModel.operationalGroupForm).toBeTruthy();
  });
  it('parentTabChangeDetection have been called', () => {
    spyOn(component, 'resetCarrierListFields');
    spyOn(component, 'onCancelBtnClicked');
    const event = {
      originalEvent: {
        isTrusted: true,
      },
      index: 2,
      isOperationalGroupChanged: true,
    };
    component.parentTabChangeDetection = event;
    expect(component.resetCarrierListFields).toHaveBeenCalled();
    expect(component.onCancelBtnClicked).toHaveBeenCalled();
  });
  it('operationalGroupData have been set', () => {
    const demo = {
      operationalGroupCode: 'string',
      operationalGroupDescription: 'string',
      operationalGroupTypeCode: 'string',
      operationalGroupTypeDescription: 'string',
      operationalGroupSubTypeCode: 'string',
      operationalGroupSubTypeDescription: 'string',
      businessUnit: 'string',
      utilizationStatus: [{
        utilizationStatusCode: 'string',
        utilizationStatusDescription: 'string',
      }],
      lastUpdated: 'string',
      lastUpdatedBy: 'string',
      totalMembers: 5,
      status: 'string',
      profilePic: 'string',
      profilePicture: 'string',
      utilizationStatusDescList: 'string',
      lastUpdatedDateValue: 'string',
      userProfileImg: 'string',
      userImgNameData: 'string',
      financeBusinessUnitCode: 'string',
    };
    component.operationalGroupData = demo;
    expect(component.carrierDetailsModel.operationalGroupData).toBeTruthy();
  });
  it('getOperationalGroupCode have been called', () => {
    component.carrierDetailsModel.operationalGroupForm = formGroup;
    component.carrierDetailsModel.filterGroupCodeVariables.operationalGroup = 'DCS 99CO01';
    component.getOperationalGroupCode();
    expect(component.getOperationalGroupCode).toBeTruthy();
  });
  it('tempCarrierNewRowCheckBoxChanged have been called', () => {
    component.carrierDetailsModel.carrierDetailsForm = carrierForm;
    component.carrierDetailsModel.carrierDetailsForm.controls.newCarrierCheckBox.setValue(false);
    spyOn(component, 'setActionRequiredError');
    component.tempCarrierNewRowCheckBoxChanged();
    expect(component.setActionRequiredError).toHaveBeenCalled();
  });
  it('infiniteScrollImplementation have been executed', () => {
    component.carrierDetailsModel.recordFrom = 0;
    component.carrierDetailsModel.recordDefaultSize = 100;
    component.carrierDetailsModel.teamDetailsScrollInformation = {
      scrollTop: 13,
      currentTabSelectionIdx: 2,
      isMemberServiceNeedsToCall: true
    };
    component.carrierDetailsModel.isCarrierListPopulated = true;
    component.carrierDetailsModel.totalMembersForScrollValidation = 102;
    spyOn(component, 'callCarrierListService');
    component.infiniteScrollImplementation();
    expect(component.callCarrierListService).toHaveBeenCalled();
  });
  it('tempCarrierNewRowCheckBoxChanged have been called with new carrier add', () => {
    component.carrierDetailsModel.carrierDetailsForm = carrierForm;
    component.carrierDetailsModel.carrierDetailsForm.controls.newCarrierCheckBox.setValue(false);
    spyOn(component, 'setActionRequiredError');
    component.tempCarrierNewRowCheckBoxChanged();
    expect(component.setActionRequiredError).toHaveBeenCalled();
  });
  it('tempCarrierRowCheckBoxChanged have been called', () => {
    const index = 1;
    const checked = true;
    const rowData = {
      operationalGroupCarrierAssignmentId: 12,
      carrierName: 'string',
      carrierCode: 'string',
      carrierId: 1,
      carrierID: 21,
      effectiveTimestamp: 'string'
    };
    component.tempCarrierRowCheckBoxChanged(checked, index, rowData);
    expect(component.tempCarrierRowCheckBoxChanged).toBeTruthy();
  });

  it('on setActionRequiredError block implemented', () => {
    component.setActionRequiredError();
    expect(component.setActionRequiredError).toBeTruthy();
  });

  it('onSearch method have been called', () => {
    component.carrierDetailsModel.carrierDetailsForm = carrierForm;
    component.onSearch();
    expect(component.onSearch).toBeTruthy();
  });
  it('calling callCarrierListService with if block', () => {
    component.carrierDetailsModel.isProfileView = true;
    component.carrierDetailsModel.isCarrierListSorted = true;
    spyOn(component, 'viewCarrierList');
    component.callCarrierListService();
    expect(component.viewCarrierList).toHaveBeenCalled();
  });

  it('calling callCarrierListService with else block', () => {
    component.carrierDetailsModel.isProfileView = false;
    component.carrierDetailsModel.isCarrierListSorted = false;
    component.carrierDetailsModel.isLoading = true;
    component.carrierDetailsModel.storableCarrierListData = cloneDeep(component.carrierDetailsModel.carrierData);
    spyOn(component, 'viewCarrierList');
    component.callCarrierListService();
    expect(component.viewCarrierList).toHaveBeenCalled();
  });
  it('setLocalStoreDataOnTabNavigation have been executed', () => {
    component.carrierDetailsModel.operationalGroupData = {
      businessUnit: 'DCS',
      financeBusinessUnitCode: 'DCS',
      lastUpdated: '10/18/2019 08:27 AM CDT',
      lastUpdatedBy: 'PadmaRekha SarvothamaRao (JCNT555)',
      lastUpdatedDateValue: '10/18/2019 08:27 AM CDT',
      operationalGroupCode: 'DCS AAFA58',
      operationalGroupDescription: 'AARON RENTS -FAIGA ',
      operationalGroupSubTypeCode: 'Dedicated',
      operationalGroupSubTypeDescription: 'Dedicated',
      operationalGroupTypeCode: 'Fleet',
      operationalGroupTypeDescription: 'Fleet',
      profilePicture: '',
      status: 'Active',
      totalMembers: 23,
      userImgNameData: 'PadmaRekha SarvothamaRao ',
      userProfileImg: null,
      utilizationStatus: [{
        utilizationStatusCode: 'Bobtail',
        utilizationStatusDescription: 'Bobtail'
      }],
      utilizationStatusDescList: 'Bobtail, From/To, Intermodal, Local, Over The Road, Pickup, Regional'
    };
    component.setLocalStoreDataOnTabNavigation();
    expect(component.setLocalStoreDataOnTabNavigation).toBeTruthy();
  });
  it('onSort have been called', () => {
    const event: any = {
      'filters': {}, 'first': 0, 'globalFilter': null, 'multiSortMeta': [{
        field: 'onPage',
        order: 1
      }], 'rows': 25, 'sortField': undefined,
      'sortOrder': 1
    };
    component.carrierDetailsModel.isProfileView = true;
    spyOn(component, 'resetCarrierListFields');
    component.onSort(event);
    expect(component.resetCarrierListFields).toHaveBeenCalled();
  });
  it('scrollInfoOnDetails have been set', () => {
    spyOn(component, 'infiniteScrollImplementation');
    const demo = JSON.stringify({ scrollTop: 2, currentTabSelectionIdx: 2, isMemberServiceNeedsToCall: false });
    component.scrollInfoOnDetails = demo;
    expect(component.carrierDetailsModel.teamDetailsScrollInformation).toBeTruthy();
    expect(component.infiniteScrollImplementation).toBeTruthy();
  });
  it('onRemoveCarrierClicked have been called', () => {
    component.onRemoveCarrierClicked();
    expect(component.onRemoveCarrierClicked).toBeTruthy();
  });
});
