import {
  ChangeDetectorRef, ChangeDetectionStrategy, Component, Input, Output, EventEmitter, OnInit, OnDestroy, ViewChild
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { takeWhile, finalize } from 'rxjs/operators';
import * as lodashUtils from 'lodash';
import { Table } from 'primeng/table';
import { MessageService } from 'primeng/components/common/messageservice';
import { SortView } from '../../model/team-list.interface';
import { ElasticResponseModel, HitsModel } from '../../../../../model/elastic-response.interface';
import { MemberValidationResponse, OperationalTeamManagementData } from './../model/team-details.interface';
import { TrailingGridData, PageView } from './models/trailing-details.interface';
import { TrailingDetailsModel } from './models/trailing-details.model';
import { TrailingDetailsQuery } from './query/trailing-details.query';
import { TrailingDetailsService } from './services/trailing-details.service';
import { TrailingDetailsUtilityService } from './services/trailing-details-utility.service';
import { OperationalTeamUtilityService } from '../../../services/operational-team-utility.service';
import { OperationalGroupTrailingEquipmentAssignment, MemberValidationInput } from '../../../model/operational-team.interface';
import { DateUtils } from '../../../../../../shared/jbh-app-services/date-utils';
import { AssetDetailQuery } from '../../../../../query/asset-detail.query';

@Component({
  selector: 'app-trailing-details',
  templateUrl: './trailing-details.component.html',
  styleUrls: ['./trailing-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrailingDetailsComponent implements OnInit, OnDestroy {
  @Input() set operationalGroupCode(operationalGroupCodeArg: string) {
    this.trailingDetailsModel.storableDataModel = [];
    this.trailingDetailsModel.removedTrailingListData = [];
    this.trailingDetailsModel.addEquipmentForm['controls']['equipmentCheckBoxes']['controls'] = [];
    if (operationalGroupCodeArg) {
      this.trailingDetailsModel.filterGroupCodeVariables.operationalGroupCode = operationalGroupCodeArg;
    }
  }
  @Input()
  set newOperationalTeamToAdd(isNewOperationalTeamToAdd: boolean) {
    this.trailingDetailsModel.isNewOperationalGroup = isNewOperationalTeamToAdd;
  }
  @Input()
  set operationalGroupData(operationalGroupDataArg: OperationalTeamManagementData) {
    this.trailingDetailsModel.isOperationalGroupChanged = true;
    this.trailingDetailsModel.operationalGroupData = operationalGroupDataArg;
    this.trailingDetailsModel.isActiveOperationalGroup = !(operationalGroupDataArg && operationalGroupDataArg.status === 'Inactive');
    if (!this.trailingDetailsModel.isActiveOperationalGroup) {
      this.trailingDetailsModel.trailingData = [];
      this.changeDetector.detectChanges();
    }
  }
  @Input()
  set scrollInfoOnDetails(scrollInformation: string) {
    if (scrollInformation) {
      this.trailingDetailsModel.teamDetailsScrollInformation = JSON.parse(scrollInformation);
      this.infiniteScrollImplementation();
    }
  }
  @Input()
  set operationalGroupForm(operationalGroupForm: FormGroup) {
    this.trailingDetailsModel.operationalGroupForm = operationalGroupForm;
  }
  @Input()
  set profileView(isProfileViewArg: boolean) {
    this.trailingDetailsModel.isProfileView = isProfileViewArg;
  }
  @Input()
  set parentTabChangeDetection(parentTabChangeDetectionObject: any) {
    if (parentTabChangeDetectionObject && parentTabChangeDetectionObject.index === 3) {
      this.resetTrailerListFields();
      this.trailingTable._sortOrder = null;
      this.trailingTable._sortField = null;
      this.trailingDetailsModel.trailingData = [];
      this.trailingDetailsModel.storableDataModel = this.operationalTeamUtilityService
        .getLocalStorageData(this.getOperationalGroupCode(), 'operationalGroupTrailingEquipmentAssignments');
      this.onCancelBtnClicked();
      this.trailingDetailsUtilityService.resetProfileViewQuery(this);
      if (!this.trailingDetailsModel.isNewOperationalGroup) {
        this.callTrailingEquipmentListService();
      } else {
        this.setLocalStoreDataOnTabNavigation();
        this.trailingDetailsUtilityService.setTrailingCheckBoxFormControl(this);
      }
      this.trailingDetailsModel.addEquipmentForm.controls['trailingEquipmentSearch'].setValue('');
      this.resetAddedTrailerDataTable();
    }
  }
  @Output() addMemberClicked = new EventEmitter();
  @Output() profileSortAndSearch = new EventEmitter();
  @ViewChild('opTrailingTable') private readonly trailingTable: Table;
  trailingDetailsModel: TrailingDetailsModel;

  constructor(
    private readonly trailingDetailsService: TrailingDetailsService,
    private readonly trailingDetailsUtilityService: TrailingDetailsUtilityService, private readonly formBuilder: FormBuilder,
    private readonly operationalTeamUtilityService: OperationalTeamUtilityService, private readonly messageService: MessageService,
    private readonly changeDetector: ChangeDetectorRef
  ) {
    this.trailingDetailsModel = new TrailingDetailsModel(this.formBuilder);
  }
  ngOnInit() {
    this.resetTrailerListFields();
    this.searchInputListener();
    this.trailingDetailsModel.canSubscribe = true;
    this.trailingDetailsModel.storableDataModel = [];
  }
  ngOnDestroy() {
    this.trailingDetailsModel.storableDataModel = [];
    this.trailingDetailsModel.canSubscribe = false;
  }
  hasAccess(actionBtnName: string): boolean {
    return this.operationalTeamUtilityService.hasAccess(actionBtnName);
  }
  showTrucklist(truckQuery: any, callBackFn?: any) {
    this.trailingDetailsModel.isLoading = true;
    this.trailingDetailsService.getTrailingDetails(truckQuery).pipe(
      takeWhile(() => this.trailingDetailsModel.canSubscribe),
      finalize(() => {
        this.trailingDetailsModel.isTrailingEquipmentListPopulated = true;
        this.trailingDetailsModel.isLoading = false;
        this.changeDetector.detectChanges();
        if (callBackFn) { callBackFn(); }
      }))
      .subscribe((data: ElasticResponseModel) => {
        this.trailingDetailsModel.isLoading = false;
        if (data && data.hits && data.hits.hits) {
          const trailListData = lodashUtils.map(data.hits.hits, 'inner_hits');
          if (trailListData && trailListData.length > 0) {
            this.trailingDetailsModel.totalMembersForScrollValidation =
              trailListData[0]['OperationalGroupEquipmentAssignment']['hits']['total'];
          }
          const eachTrailListData = lodashUtils.map(trailListData, 'OperationalGroupEquipmentAssignment.hits.hits');
          const trailListArray = lodashUtils.map(eachTrailListData[0], '_source');
          if (this.trailingDetailsModel.isScrollServiceHappend && this.trailingDetailsModel.trailingData) {
            this.trailingDetailsModel.trailingData =
              this.trailingDetailsModel.trailingData.concat(this.getIteratedTrailerList(trailListArray));
          } else {
            this.trailingDetailsModel.trailingData = this.getIteratedTrailerList(trailListArray);
          }
          this.trailingDetailsModel.isScrollServiceHappend = false;
        } else {
          this.trailingDetailsModel.trailingData = [];
          this.resetAddedTrailerDataTable();
        }
        this.trailingDetailsUtilityService.setTrailingCheckBoxFormControl(this);
      }, (error: Error) => {
        this.trailingDetailsModel.trailingData = [];
        this.trailingDetailsModel.isLoading = false;
      });
    this.changeDetector.detectChanges();
  }
  getOperationalGroupCode(): string {
    return ((this.trailingDetailsModel.operationalGroupForm &&
      this.trailingDetailsModel.operationalGroupForm.controls['operationalGroupIdentifier'].value) ||
      this.trailingDetailsModel.filterGroupCodeVariables.operationalGroupCode);
  }
  addTrailerEquipment() {
    if (this.trailingDetailsModel.operationalGroupForm.valid) {
      this.operationalTeamUtilityService.setIsAddMemberClicked(true, this.getOperationalGroupCode());
      this.trailingDetailsUtilityService.setAddedTrailingChkBoxControl(this);
      this.trailingDetailsModel.isAddTemporaryTableVisible = false;
      this.trailingDetailsModel.isSaveCancelBtnsVisible = true;
      this.trailingDetailsModel.trailingData.unshift(this.trailingDetailsUtilityService.getEmptyDataForTrailingData());
      this.changeDetector.detectChanges();
    }
    this.addMemberClicked.emit();
  }

  initInlineSaveValidations() {
    const activeMembers = this.trailingDetailsModel.isNewOperationalGroup ? 0 :
      Number(this.trailingDetailsModel.operationalGroupData.totalMembers);
    const membersInOGForValidation =
      this.operationalTeamUtilityService.checkMaxMembersInOperationalGroup(this.getOperationalGroupCode(), activeMembers);
    if (!membersInOGForValidation.isMemberExistsOverLimit) {
      const operGroupData = this.trailingDetailsModel.operationalGroupData;
      const equipValue = this.trailingDetailsModel.addEquipmentForm.controls['equipmentCode'].value;
      const selectedEquipment =
        lodashUtils.find(this.trailingDetailsModel.equipTypeaheadDataList, { 'prefixWithEquipmentNumber': equipValue });
      const isAddedEquipmentDuplicated = this.trailingDetailsUtilityService.isAddedEquipmentDuplicated(
        this, this.getOperationalGroupCode(), selectedEquipment.equipmentID, equipValue
      );
      const operGroupType = this.trailingDetailsModel.operationalGroupForm.controls['operationalGroupCategory'].value.label
        || operGroupData.operationalGroupTypeCode;
      const requestData: MemberValidationInput = {
        memberIds: selectedEquipment.equipmentID, memberName: equipValue.trim(),
        operationalGroupType: operGroupType, action: 'add'
      };
      if (!isAddedEquipmentDuplicated.isRemovedInLocalStore && !isAddedEquipmentDuplicated.isAddedInLocalStore) {
        this.trailingDetailsModel.isLoading = true;
        this.trailingDetailsService
          .postMemberBusinessValidation(this.getOperationalGroupCode(), requestData).pipe(
            takeWhile(() => this.trailingDetailsModel.canSubscribe),
            finalize(() => {
              this.trailingDetailsModel.isLoading = false;
              this.changeDetector.detectChanges();
            }))
          .subscribe((memberResponse: any) => {
            this.onUpdateTrailingDataIntoTable('N');
          }, (validationError) => {
            this.getValidationErrorResponse(validationError);
          });
      } else if (isAddedEquipmentDuplicated.isRemovedInLocalStore && !isAddedEquipmentDuplicated.isAddedInLocalStore) {
        this.trailingDetailsModel.isLoading = false;
        this.onUpdateTrailingDataIntoTable('N');
      }
    } else {
      this.messageService.clear();
      this.messageService.add(membersInOGForValidation.memberExistsToastMsg);
    }
  }
  setLocalStoreDataOnTabNavigation() {
    if (this.trailingDetailsModel.operationalGroupData) {
      const updatedLocalStoredEquipment = { localStoreArr: [] };
      const tempTrailingData = this.trailingDetailsModel.trailingData;
      const localTrailingDataList =
        this.operationalTeamUtilityService.getLocalStorageData(this.getOperationalGroupCode(),
          'operationalGroupTrailingEquipmentAssignments');
      const localRemovedTrailingList =
        this.operationalTeamUtilityService.getLocalStorageData(this.getOperationalGroupCode(),
          'operationalGroupUnAssignmentTrailingEquipmentIds');
      lodashUtils.forEach(localRemovedTrailingList, (equipmentId: number) => {
        const tempTrailingRemoveIdx = lodashUtils.findIndex(tempTrailingData, { 'equipmentID': equipmentId });
        if (tempTrailingRemoveIdx !== -1) {
          tempTrailingData.splice(tempTrailingRemoveIdx, 1);
        }
      });
      lodashUtils.forEach(localTrailingDataList, (eachTrailingData: OperationalGroupTrailingEquipmentAssignment) => {
        const isEquipmentExistInES = (lodashUtils.findIndex(tempTrailingData,
          { 'equipmentID': (eachTrailingData.equipmentId) }) !== -1);
        if (!isEquipmentExistInES) {
          tempTrailingData.unshift({
            'rowEditable': false, 'EquipmentNumber': eachTrailingData.equipmentUnitId.toString(),
            'EquipmentClassificationDescription': eachTrailingData.equipmentClassificationCode,
            'equipmentID': eachTrailingData.equipmentId
          });
          updatedLocalStoredEquipment.localStoreArr.push(eachTrailingData);
        }
      });
      this.operationalTeamUtilityService.setLocalStorageData(this.getOperationalGroupCode(),
        'operationalGroupTrailingEquipmentAssignments', updatedLocalStoredEquipment.localStoreArr);
      this.trailingDetailsModel.trailingData = tempTrailingData;
    }
  }
  onUpdateTrailingDataIntoTable(overRideEquipment: string) {
    this.trailingDetailsModel.overRideTrailingEquipment = overRideEquipment;
    this.trailingDetailsUtilityService.updateTrailingDataIntoLocalstore(this);
  }
  onConfirmYesClicked() {
    this.onUpdateTrailingDataIntoTable('Y');
  }
  onSaveBtnClicked() {
    if (this.trailingDetailsModel.addEquipmentForm.valid
      && this.trailingDetailsModel.selectedEquipCode) {
      this.initInlineSaveValidations();
    } else {
      if (!this.trailingDetailsModel.selectedEquipCode) {
        this.setEquipmentValidationError('equipmentCode');
      }
    }
    this.trailingDetailsModel.addEquipmentForm['controls']['equipmentCode'].markAsTouched();
    this.changeDetector.detectChanges();
  }
  onCancelBtnClicked() {
    this.operationalTeamUtilityService.setIsAddMemberClicked(false, this.getOperationalGroupCode());
    this.resetAddedTrailerDataTable();
  }
  onTrailingSelected(trailingEquipmentName: string) {
    this.trailingDetailsModel.selectedEquipCode = trailingEquipmentName;
    const equipTypeArray = lodashUtils.filter(this.trailingDetailsModel.equipTypeaheadDataList,
      { 'prefixWithEquipmentNumber': trailingEquipmentName });
    this.trailingDetailsModel.defaultEquipmentType = equipTypeArray[0].equipmentClassificationCode;
    this.trailingDetailsModel.addEquipmentForm.controls['equipmentCode'].setValue(trailingEquipmentName);
  }
  onTrailingTypeSelected(trailingType: string) {
    this.trailingDetailsModel.addEquipmentForm.controls['equipmentCode'].setValue('');
    this.trailingDetailsModel.addEquipmentForm.controls['equipmentCode'].markAsUntouched();
  }
  onTrailingAutocompleteSearch(TrailingAutocompleteEvent) {
    this.trailingDetailsModel.selectedEquipCode = null;
    this.trailingDetailsModel.addEquipmentForm['controls']['equipmentCode'].markAsUntouched();
    this.trailingDetailsModel.addEquipmentForm['controls']['equipmentCode'].setErrors(null);
    const txtBoxValue = TrailingAutocompleteEvent.query;
    if (txtBoxValue.length > 0) {
      const trailQuery = AssetDetailQuery.getAssetByEquipmentQuery(txtBoxValue);
      this.trailingDetailsService.getTrailEquipmentOnTypeahead(trailQuery).pipe(
        takeWhile(() => this.trailingDetailsModel.canSubscribe),
        finalize(() => { this.changeDetector.detectChanges(); }))
        .subscribe((response: ElasticResponseModel) => {
          if (response && response.hits && response.hits.hits) {
            this.trailingDetailsModel.equipTypeaheadDataList = lodashUtils.map(response.hits.hits, '_source');
            this.trailingDetailsModel.typeaheadList =
              lodashUtils.map(this.trailingDetailsModel.equipTypeaheadDataList, 'prefixWithEquipmentNumber');
          }
        }, (error) => { this.trailingDetailsModel.typeaheadList = []; });
    }
  }
  filterTrailingEquipment(TrailingNameEvent) {
    this.trailingDetailsModel.equiTypeList = [];
    for (const equipTypes of this.trailingDetailsModel.equiTypes) {
      if (equipTypes.toLowerCase().indexOf(TrailingNameEvent.toLowerCase()) === 0) {
        this.trailingDetailsModel.equiTypeList.push(equipTypes);
      }
    }
    this.changeDetector.detectChanges();
  }
  setEquipmentValidationError(formControlMember: string) {
    this.trailingDetailsModel.addEquipmentForm['controls'][formControlMember].setErrors({ incorrect: true });
    this.messageService.clear();
    this.messageService.add(this.trailingDetailsModel.addEquipError);
  }
  getIterateCancelData(listDetails): TrailingGridData[] {
    return lodashUtils.filter(listDetails, { 'rowEditable': false });
  }
  resetAddedTrailerDataTable() {
    this.trailingDetailsModel.isAddTemporaryTableVisible = true;
    this.trailingDetailsModel.isSaveCancelBtnsVisible = false;
    this.trailingDetailsModel.isConfirmDialogVisible = false;
    this.trailingDetailsModel.isRemoveCancelBtnsVisible = false;
    this.trailingDetailsModel.defaultEquipmentType = '';
    this.trailingDetailsModel.trailingData = this.getIterateCancelData(this.trailingDetailsModel.trailingData);
    this.trailingDetailsModel.addEquipmentForm.reset();
    this.changeDetector.detectChanges();
  }
  resetTrailingDetailsView() {
    this.trailingDetailsModel.addEquipmentForm.reset();
    this.trailingDetailsModel.isSaveCancelBtnsVisible = false;
    this.trailingDetailsModel.trailingData = this.getIterateCancelData(this.trailingDetailsModel.trailingData);
    this.trailingDetailsModel.isRemoveCancelBtnsVisible = false;
    this.changeDetector.detectChanges();
  }
  onRemoveTrailingEquipmentCancelBtnClicked() {
    this.resetTrailingDetailsView();
    this.setCheckedForTrailingCheckboxes(false);
    this.trailingDetailsModel.removedTrailingListData = [];
    this.operationalTeamUtilityService.setIsRemoveMemberClicked(false, this.getOperationalGroupCode());
  }
  onTrailingAddChanged(isHeaderChecked: boolean) {
    this.initActionReqdErrorOnRemove();
    this.trailingDetailsModel.addEquipmentForm.controls['addTrailingCheckBox'].setValue(false);
  }
  setCheckedForTrailingCheckboxes(isCheckBoxesChecked: boolean) {
    lodashUtils.forEach(this.trailingDetailsModel.trailingFormCheckBoxArray, (eachEquipmentCheckBox: FormControl) => {
      eachEquipmentCheckBox['equipmentCheckBox'].setValue(isCheckBoxesChecked);
    });
  }
  initActionReqdErrorOnRemove() {
    this.messageService.clear();
    this.messageService.add(this.operationalTeamUtilityService.getActionReqdError());
  }
  onEquipmentStateChanged(isChecked: boolean, rowIndex: number, rowData: TrailingGridData) {
    if (this.operationalTeamUtilityService.getIsAddMemberClicked()) {
      this.initActionReqdErrorOnRemove();
      this.trailingDetailsModel.trailingFormCheckBoxArray[rowIndex]['equipmentCheckBox'].setValue(false);
    } else {
      this.trailingDetailsUtilityService.setRemovedTrailingData(this, isChecked, rowData);
      this.onValidateCheckBox();
    }
  }
  onValidateCheckBox() {
    const trailingDetailsModel = this.trailingDetailsModel;
    const checkedValues =
      lodashUtils.filter(trailingDetailsModel.trailingFormCheckBoxArray, (eachEquipmentCheckBox: FormControl): boolean => {
        return eachEquipmentCheckBox['equipmentCheckBox']['value'];
      });
    this.trailingDetailsModel.isRemoveCancelBtnsVisible = (checkedValues.length !== 0);
    this.operationalTeamUtilityService
      .setIsRemoveMemberClicked(trailingDetailsModel.isRemoveCancelBtnsVisible, this.getOperationalGroupCode());
    this.changeDetector.detectChanges();
  }
  removeTrailingFromTheTable(removedEquipments: number[]) {
    this.trailingDetailsUtilityService.removeEquipmentsFromTable(this, removedEquipments);
    this.onRemoveTrailingEquipmentCancelBtnClicked();
  }
  onTrailingRemoveBtnClicked() {
    const operGroup = this.trailingDetailsModel.operationalGroupData;
    const removedEquipments = lodashUtils.map(this.trailingDetailsModel.removedTrailingListData, 'equipmentID');
    const existingEquipmentToRemove = this.trailingDetailsUtilityService.getExistingEquipmentRemovalInfo(this, removedEquipments);
    if (existingEquipmentToRemove && existingEquipmentToRemove.length !== 0) {
      this.trailingDetailsModel.isLoading = true;
      const operGroupType = this.trailingDetailsModel.operationalGroupForm.controls['operationalGroupCategory'].value.label
        || operGroup.operationalGroupTypeCode;
      const requestData: MemberValidationInput = {
        memberIds: existingEquipmentToRemove.toString(),
        operationalGroupType: operGroupType,
        action: 'remove'
      };
      this.trailingDetailsService
        .postMemberBusinessValidation(this.getOperationalGroupCode(), requestData).pipe(
          takeWhile(() => this.trailingDetailsModel.canSubscribe),
          finalize(() => {
            this.trailingDetailsModel.isLoading = false;
            this.changeDetector.detectChanges();
          })).subscribe((validationResponse) => {
            this.removeTrailingFromTheTable(removedEquipments);
          }, (validationError) => {
            this.getValidationErrorResponse(validationError);
          });
    } else {
      this.removeTrailingFromTheTable(removedEquipments);
    }
  }
  onGridLazyLoad(event: SortView) {
    this.trailingDetailsUtilityService.onGridLazyLoad(event, this);
  }
  searchInputListener() {
    this.trailingDetailsUtilityService.searchInputListener(this);
  }
  getValidationErrorResponse(validationError: any) {
    if (validationError.status === 400) {
      const errorJson = typeof validationError.error === 'string' ? JSON.parse(validationError.error) : validationError.error;
      this.trailingDetailsUtilityService.executeMemberValidation(this,
        this.operationalTeamUtilityService.getMemberValidationResponse(errorJson));
    }
  }
  resetTrailerListFields() {
    this.trailingDetailsModel.totalMembersForScrollValidation = 0;
    this.trailingDetailsModel.isScrollServiceHappend = false;
    this.trailingDetailsModel.recordFrom = 0;
    this.trailingDetailsModel.recordDefaultSize = 100;
  }
  infiniteScrollImplementation() {
    const scrollableCount = this.trailingDetailsModel.recordFrom +
      this.trailingDetailsModel.recordDefaultSize;
    if (this.trailingDetailsModel.teamDetailsScrollInformation.isMemberServiceNeedsToCall
      && this.trailingDetailsModel.isTrailingEquipmentListPopulated
      && this.trailingDetailsModel.teamDetailsScrollInformation.currentTabSelectionIdx === 3 &&
      this.trailingDetailsModel.totalMembersForScrollValidation > scrollableCount) {
      this.trailingDetailsModel.isScrollServiceHappend = true;
      this.trailingDetailsModel.recordFrom = this.trailingDetailsModel.recordFrom +
        this.trailingDetailsModel.recordDefaultSize;
      this.callTrailingEquipmentListService();
    }
  }
  callTrailingEquipmentListService() {
    if (this.trailingDetailsModel.isProfileView && this.trailingDetailsModel.isTrailerListSorted) {
      const trailingSerachQuery =
        TrailingDetailsQuery.getTrailerListElasticQuery(this.getOperationalGroupCode(),
          this.trailingDetailsModel.recordFrom, this.trailingDetailsModel.recordDefaultSize,
          this.trailingDetailsModel.profileSortAndSearchQuery);
      this.showTrucklist(trailingSerachQuery);
    } else {
      const truckQuery = TrailingDetailsQuery.getTrailingDetails(this.trailingDetailsModel.filterGroupCodeVariables,
        this.trailingDetailsModel.recordFrom,
        this.trailingDetailsModel.recordDefaultSize);
      this.showTrucklist(truckQuery, () => {
        this.trailingDetailsModel.isTrailingExist = (this.trailingDetailsModel.trailingData.length !== 0);
        this.trailingDetailsModel.esEquipmentData = lodashUtils.cloneDeep(this.trailingDetailsModel.trailingData);
        this.setLocalStoreDataOnTabNavigation();
        this.changeDetector.detectChanges();
      });
    }
  }
  getIteratedTrailerList(trailListArray) {
    return lodashUtils.map(trailListArray, (truckUnitId) => {
      return {
        'rowEditable': false, 'EquipmentNumber': truckUnitId.EquipmentNumber,
        'EquipmentClassificationDescription': truckUnitId.EquipmentClassificationDescription,
        'equipmentID': Number(truckUnitId.EquipmentID),
        'operationalGroupEquipmentAssignmentID': truckUnitId.OperationalGroupEquipmentAssignmentID,
        'effectiveTimestamp': truckUnitId.EffectiveTimestamp, 'expirationTimestamp': truckUnitId.ExpirationTimestamp
      };
    });
  }
  onClearTrailingEquipmentCode() {
    this.trailingDetailsModel.defaultEquipmentType = '';
  }
}
