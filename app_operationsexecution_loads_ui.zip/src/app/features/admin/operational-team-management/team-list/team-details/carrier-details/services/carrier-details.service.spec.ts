import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../../../shared/service/app-config.service';
import { CarrierDetailsService } from './carrier-details.service';
import { configureTestSuite } from 'ng-bullet';

describe('CarrierDetailsService', () => {
  let service: CarrierDetailsService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [CarrierDetailsService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(CarrierDetailsService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes expected getCarrierDetailsList calls', () => {
    const param = 'L258';
    service.getCarrierDetailsList(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getCarrierList);
    expect(req.request.method).toEqual('POST');
  });

  it('makes expected getCarrierName calls', () => {
    const param = {
      from: 0,
      size: 25
    };
    service.getCarrierName(param).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getCarrierDetail);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getAddCarrierBusinessValidation calls', () => {
    const operGroupCode = 'OG';
    const groupType = 'OG1';
    const memeberId = 123;
    service.getAddCarrierBusinessValidation(operGroupCode, groupType, memeberId).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}/${operGroupCode}/members?` +
      `memberType=carrier&memberIds=${memeberId}&type=${groupType}&action=add`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected postMemberBusinessValidation calls', () => {
    const operationalGroupCode = 'OG123';
    const param = {
      memberIds: 'L123',
      operationalGroupType: 'OG',
      action: 'Update'
    };
    service.postMemberBusinessValidation(operationalGroupCode, param).subscribe();
    const req =
      httpTestingController.expectOne(
        `${service.endpoint.postOGMemberAdhocValidations}/carriers/validations?operationalGroupCode=${operationalGroupCode}`);
    expect(req.request.method).toEqual('POST');
  });
});
