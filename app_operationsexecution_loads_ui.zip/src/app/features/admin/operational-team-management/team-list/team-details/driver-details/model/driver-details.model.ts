import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as lodashutils from 'lodash';
import { OperationalGroupDriverAssignment, TeamMemberScrollInformation } from './../../../../model/operational-team.interface';
import { DuplicateAndPairedMemberData, OperationalTeamManagementData, ProfileSortAndSearch } from './../../model/team-details.interface';
import {
    DriverDetails, DriverListDetails, DriverValidationMessageInterface, DriverImageResponse,
    ElasticDriverDetails, OperationalGroupData, OperationalGroupSelectedDriverAssignment
} from './driver-details.interface';
import { SecureModel } from '../../../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../../../config/app.config';

export class DriverDetailsModel {

    dateFormat: string;
    driverActiveDaysCount: number;
    isProfileView: boolean;
    canSubscribe: boolean;
    tempDriverForm: FormGroup;
    operationalGroupCode: string;
    driverExpirationToDate: string;
    driverExpiratationFromDate: string;
    isTemporaryDriverLoaded: boolean;
    isPermanentDriverLoaded: boolean;
    temporaryDriverData: ElasticDriverDetails[];
    permanentDriverData: ElasticDriverDetails[];
    isSaveCancelBtnsVisible: boolean;
    isRemoveCancelBtnsVisible: boolean;
    isAddTemporaryTableVisible: boolean;
    typeaheadDriverList: DriverListDetails[];
    addTempDriverError: any;
    removeFleetDriverError: any;
    tempDriverstableColumns: any[];
    permanentDriversTableColumns: any[];
    operationalGroupData: OperationalTeamManagementData;
    selectedDriver?: OperationalGroupSelectedDriverAssignment;
    removedDriverListData: ElasticDriverDetails[];
    temporaryDriverListData: ElasticDriverDetails[];
    permanentDriverListData: ElasticDriverDetails[];
    storableTemporaryDriverListData: ElasticDriverDetails[];
    storableDriverListData: OperationalGroupDriverAssignment[];
    calanderMinDate: Date;
    calenderMaxDate: Date;
    defaultDriverCount: number;
    isOperationalGroupChanged: boolean;
    isConfirmDialogVisible: boolean;
    selectedDriverListType: string;

    endDateFutureValueError: any;
    endDatePastValueError: any;
    imageUserIDArray: string[];
    tempDriverFormCheckBoxArray: FormControl[];

    confirmDialogMsgJson: DriverValidationMessageInterface;
    confirmDialogMsgVisibility: DriverValidationMessageInterface;
    memberValidationResponseMessage: DuplicateAndPairedMemberData;
    temporaryProfileSortAndSearchQuery: ProfileSortAndSearch;
    permanentProfileSortAndSearchQuery: ProfileSortAndSearch;
    profileViewDefaultSortColumn: string;
    profileViewDefaultSortOrder: number;
    storeDriverImagesForProfileView: DriverImageResponse[];

    isTemporaryDriverListExists: boolean;
    isPermanentDriverListExists: boolean;
    isActiveOperationalGroup: boolean;
    isNewOperationalGroup: boolean;
    driverListWidth: number;
    driverListDefaultWidth: number;
    driverListInputPadding: number;
    dateTimeFormat: string;
    operationalGroupForm: FormGroup;
    overRideDriver: string;
    overRideDriverErrorMsgs: string[];
    teamDetailsScrollInformation: TeamMemberScrollInformation;
    totalMembersForScrollValidation: number;
    isScrollServiceHappend: boolean;
    recordFrom: number;
    recordDefaultSize: number;
    isDriverListPopulated: boolean;
    isTemporaryDriverListSorted: boolean;
    isPermanentDriverListSorted: boolean;
    driverChecking: string;
    addDriverButton: SecureModel;
    overRidePaired: string;
    driverDetailsError: any;
    appConfig;
    constructor(formBuilder: FormBuilder) {
        this.storeDriverImagesForProfileView = [];
        this.isConfirmDialogVisible = false;
        this.defaultDriverCount = 100;
        this.dateFormat = 'M/D/YYYY hh:mm a';
        this.imageUserIDArray = [];
        this.removedDriverListData = [];
        this.selectedDriverListType = 'All';
        this.tempDriverForm = formBuilder.group({
            tempDriverName: ['', Validators.required],
            tempDriverExpireDate: ['', Validators.required],
            tempDriverCheckBoxes: formBuilder.array([]),
            tempDriverHeaderCheckBox: [true],
            temporaryDriverElasticSearchTxtBox: [''],
            permanentDriverElasticSearchTxtBox: ['']
        });

        this.temporaryProfileSortAndSearchQuery = {
            memberStartFrom: 0,
            expirationTimestamp: '',
            searchTxt: '',
            searchType: 'text',
            sortableMember: 'OperationalGroupDriverAssignment.EffectiveTimestamp',
            sortableEvent: { sortOrder: -1 }
        };

        this.permanentProfileSortAndSearchQuery = lodashutils.cloneDeep(this.temporaryProfileSortAndSearchQuery);

        this.profileViewDefaultSortOrder = -1;
        this.profileViewDefaultSortColumn = 'End Date';

        this.confirmDialogMsgJson = { isAssignedAndPaired: false, isOnlyAssigned: false, isOnlyPaired: false };

        this.removeFleetDriverError = {
            'severity': 'error',
            'summary': 'Unable to Remove Driver',
            'detail': 'This Driver is only assigned to this fleet and cannot be unassigned'
        };

        this.addTempDriverError = {
            'severity': 'error',
            'summary': 'Missing Required Information',
            'detail': 'Provide the required information in highlighted fields and save again'
        };

        this.endDateFutureValueError = {
            'severity': 'error',
            'summary': 'End Date Error',
            'detail': 'End date cannot be more than 14 days from the current date'
        };

        this.endDatePastValueError = {
            'severity': 'error',
            'summary': 'End Date Error',
            'detail': 'End date cannot be a past date'
        };

        this.tempDriverstableColumns = [
            {
                'label': 'Name', 'key': 'operationalGroupDriverName',
                'styleClass': 'width53'
            },
            {
                'label': 'End Date', 'key': 'formattedEndDate',
                'styleClass': ''
            }
        ];

        this.permanentDriversTableColumns = [
            { 'label': 'Name', 'key': 'operationalGroupDriverName' }
        ];
        this.isTemporaryDriverListExists = false;
        this.isPermanentDriverListExists = false;
        this.driverListWidth = 0;
        this.driverListDefaultWidth = 300;
        this.driverListInputPadding = 20;
        this.isActiveOperationalGroup = true;
        this.dateTimeFormat = 'YYYY-MM-DD';
        this.temporaryDriverListData = [];
        this.permanentDriverListData = [];
        this.appConfig = AppConfig.getConfig();
        this.addDriverButton = { url: this.appConfig.api.admin.getOperationalTeamDetails, operation: 'C' };
    }

}
