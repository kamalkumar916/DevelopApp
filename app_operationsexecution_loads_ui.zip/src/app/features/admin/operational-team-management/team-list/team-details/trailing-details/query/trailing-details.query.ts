import { ProfileSortAndSearch } from './../../model/team-details.interface';

export class TrailingDetailsQuery {
    static readonly equipmentClassificationCode = 'OperationalGroupEquipmentAssignment.EquipmentClassificationCode';
    static getTrailingDetails(operationalGroup: any, recordsFrom: number, defaultSize: number) {

        return {
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'OperationalGroupCode.keyword': operationalGroup.operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupEquipmentAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': defaultSize,
                                    'sort': [
                                        {
                                            'OperationalGroupEquipmentAssignment.EffectiveTimestamp': {
                                                'order': 'desc'
                                            }
                                        }
                                    ]
                                },
                                'query': {
                                    'bool': {
                                        'must': [
                                            {
                                                'range': {
                                                    'OperationalGroupEquipmentAssignment.ExpirationTimestamp': {
                                                        'gte': 'now',
                                                        'lte': '12/31/2199 11:59 PM CST',
                                                        'format': 'MM/dd/YYYY hh:mm a z'
                                                    }
                                                }
                                            },
                                            {
                                                'bool': {
                                                    'must_not': [
                                                        {
                                                            'match': {
                                                                [this.equipmentClassificationCode]: 'Tractor'
                                                            }
                                                        }
                                                    ]
                                                }
                                            }]
                                    }
                                }
                            }
                        }
                    ]
                }

            }
        };
    }



    static getTrailerListElasticQuery(operationalGroupCode: string, recordsFrom: number,
        noOfRecords: number, sortAndSearchProperty: ProfileSortAndSearch) {
        return {
            '_source': [
                'OperationalGroupCode',
                'OperationalGroupEquipmentAssignment'
            ],
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'OperationalGroupCode.keyword': operationalGroupCode
                            }
                        },
                        {
                            'nested': {
                                'path': 'OperationalGroupEquipmentAssignment',
                                'inner_hits': {
                                    'from': recordsFrom,
                                    'size': noOfRecords,
                                    'sort': [
                                        {
                                            [sortAndSearchProperty.sortableMember]:
                                                (sortAndSearchProperty.sortableEvent.sortOrder === -1) ? 'desc' : 'asc'
                                        }
                                    ]
                                },
                                'query': {
                                    'bool': {
                                        'must': this.getTrailerListSearchQuery(sortAndSearchProperty.searchTxt)
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };
    }

    static getTrailerListSearchQuery(searchTxt: string) {
        const trailerMustQuery: any = [{
            'range': {
                'OperationalGroupEquipmentAssignment.ExpirationTimestamp': {
                    'gte': 'now',
                    'lte': '12/31/2199 11:59 PM CST',
                    'format': 'MM/dd/YYYY hh:mm a z'
                }
            }
        }, {
            'bool': {
                'must_not': [
                    {
                        'match': {
                            [this.equipmentClassificationCode]: 'Tractor'
                        }
                    }
                ]
            }
        }];
        trailerMustQuery.push({
            'query_string': {
                'fields': [
                    this.equipmentClassificationCode,
                    'OperationalGroupEquipmentAssignment.EquipmentNumber'
                ],
                'query': `*${searchTxt}*`,
                'default_operator': 'AND'
            }
        });
        return trailerMustQuery;
    }


}
