import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import {
    MemberValidationResponse, OperationalTeamManagementData,
    DuplicateAndPairedMemberData, ProfileSortAndSearch
} from './../../model/team-details.interface';
import { Subject } from 'rxjs';
import {
    CarrierListData,
    FilterVariables, FilterGroupVariables,
    OperationalGroupSelectedEquipment, CarrierDataModel
} from './carrier-details.interface';
import { TeamMemberScrollInformation } from './../../../../model/operational-team.interface';
import { SecureModel } from '../../../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../../../config/app.config';
export class CarrierDetailsModel {
    isEnable: boolean;
    carrierData: CarrierListData[];
    carrierListData: object[];
    filterVariables: FilterVariables;
    isShowSaveLink: boolean;
    filterGroupCodeVariables: FilterGroupVariables;
    canSubscribe: boolean;
    isLoading: boolean;
    selectedEquipment?: OperationalGroupSelectedEquipment[];
    dateFormat: string;
    storableDataModel: any[];
    carrierDetailsForm: FormGroup;
    operationalGroup: string;
    operationalGroupCodeArgData: string;
    carrierSelectedData: CarrierListData;
    sortField: string;
    sortOrder: string;
    ascendingOrder: string;
    decendingOrder: string;
    searchText: string;
    totalRecords: number;
    isPaginatorReqd: boolean;
    tblScrollHeight: string;
    isProfileView: boolean;
    operationalGroupData: OperationalTeamManagementData;
    duplicateAndPairedMemberData: DuplicateAndPairedMemberData;
    missingRequiredInfoError: any;
    isOperationalGroupChanged: boolean;
    tempCarrierFormCheckBoxArray: FormControl[];
    isRemoveLinkVisible: boolean;
    isAddBtnVisible: boolean;
    removeListData: CarrierListData[];
    profileSortAndSearchQuery: ProfileSortAndSearch;
    userInputSearchSubject: Subject<string>;
    profileSortQuery: object;
    profileSearchQuery: object;
    isCarrierListExist: boolean;
    isActiveOperationalGroup: boolean;
    isNewOperationalGroup: boolean;
    operationalGroupForm: FormGroup;
    dateTimeFormat: string;
    removableDataModel: number[];
    storableCarrierListData: CarrierListData[];
    teamDetailsScrollInformation: TeamMemberScrollInformation;
    totalMembersForScrollValidation: number;
    isScrollServiceHappend: boolean;
    recordFrom: number;
    recordDefaultSize: number;
    isCarrierListPopulated: boolean;
    isCarrierListSorted: boolean;
    addCarrierButton: SecureModel;
    appConfig;
    constructor(private readonly formBuilder: FormBuilder) {
        this.dateFormat = 'M/D/YYYY hh:mm a';
        this.isEnable = false;
        this.carrierData = [];
        this.carrierListData = [];
        this.filterVariables = {
            from: 0,
            size: 1000,
            searchValue: ''
        };
        this.ascendingOrder = 'asc';
        this.decendingOrder = 'desc';
        this.isLoading = false;
        this.isShowSaveLink = false;
        this.filterGroupCodeVariables = {
            from: 0,
            size: 100,
            operationalGroup: '',
            carrierStatus: ''
        };
        this.isAddBtnVisible = true;
        this.isRemoveLinkVisible = false;
        this.removeListData = [];
        this.tempCarrierFormCheckBoxArray = [];
        this.canSubscribe = true;
        this.operationalGroup = '';
        this.storableDataModel = [];
        this.carrierDetailsForm = formBuilder.group({
            carrierDetailsCode: ['', Validators.required],
            newCarrierCheckBox: [false],
            tempCarrierCheckBoxes: formBuilder.array([]),
            carrierListSearch: ['']
        });
        this.missingRequiredInfoError = {
            'severity': 'error',
            'summary': 'Missing Required Information',
            'detail': 'Provide the required information in highlighted fields and save again'
        };
        this.sortField = 'Name';
        this.searchText = '';
        this.totalRecords = 0;
        this.isPaginatorReqd = false;
        this.profileSortAndSearchQuery = {
            memberStartFrom: 0,
            expirationTimestamp: '',
            searchTxt: '',
            sortableMember: 'OperationalGroupCarrierAssignment.EffectiveTimestamp',
            sortableEvent: { sortOrder: -1 }
        };
        this.userInputSearchSubject = new Subject<string>();
        this.profileSortQuery = {};
        this.profileSearchQuery = {};
        this.isCarrierListExist = false;
        this.isActiveOperationalGroup = true;
        this.dateTimeFormat = 'YYYY-MM-DD HH:mm:ss.sss Z';
        this.removableDataModel = [];
        this.storableCarrierListData = [];
        this.appConfig = AppConfig.getConfig();
        this.addCarrierButton = { url: this.appConfig.api.admin.getOperationalTeamDetails, operation: 'C' };
    }
}
