import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Injectable } from '@angular/core';
import * as moment from 'moment';
import * as lodashutils from 'lodash';
import { DateUtils } from '../../../../../../../shared/jbh-app-services/date-utils';
import { ElasticResponseModel } from '../../../../../../model/elastic-response.interface';
import { SortView } from './../../../model/team-list.interface';
import { OperationalGroupDriverAssignment, MemberValidationCustomOutput } from './../../../../model/operational-team.interface';
import {
  DuplicateAndPairedMemberData, MemberValidationResponse, ProfileSortAndSearch, LocalStoreDuplicateMemberData
} from './../../model/team-details.interface';
import {
  DriverDetailsElasticQuery, DriverImageResponse, DriverListDetails, ElasticDriverDetails,
  EndDateErrorModel, OperationalGroupData, OperationalGroupDriverAssignmentDetail
} from './../model/driver-details.interface';
import { DriverSortSearchService } from './driver-sort-search.service';

@Injectable()
export class DriverDetailsUtilityService {

  constructor(private readonly formBuilder: FormBuilder, private readonly driverSortSearchService: DriverSortSearchService) { }

  getDriverData(driverDataList: OperationalGroupDriverAssignmentDetail[], filterString: string): OperationalGroupDriverAssignmentDetail[] {
    const driverListArray = [];
    lodashutils.forEach(driverDataList, (eachDriverData: OperationalGroupDriverAssignmentDetail) => {
      if (eachDriverData.OperationalGroupDriverAssignmentTypeDescription === filterString) {
        driverListArray.push(eachDriverData);
      }
    });
    return driverListArray;
  }
  getDriverName(PreferredName: string, LastName: string, FirstName: string): string {
    const driverFirstName = PreferredName || FirstName;
    return `${driverFirstName} ${LastName}`;
  }
  getDriverListFromData(operationalGroupCode: string, driverResponseData: ElasticDriverDetails[]): Array<ElasticDriverDetails> {
    if (driverResponseData) {
      return lodashutils.map(driverResponseData,
        (driverData: ElasticDriverDetails): ElasticDriverDetails => {
          const eachDriverData = lodashutils.cloneDeep(driverData);
          eachDriverData.operationalGroupCode = operationalGroupCode;
          eachDriverData.operationalGroupDriverName = this.getDriverName(driverData.PreferredName,
            driverData.LastName, driverData.FirstName);
          eachDriverData.operationalGroupTitle = `${eachDriverData.operationalGroupDriverName} (${eachDriverData.UserID})`;
          eachDriverData.operationalGroupTitle += ` ${eachDriverData.JobGroup}`;
          eachDriverData.userProfileImg = null;
          eachDriverData.formattedEndDate =
            (driverData.ExpirationTimestamp) ? moment(driverData.ExpirationTimestamp).format('MM/DD/YYYY') : null;
          eachDriverData.rowEditable = false;
          return eachDriverData;
        });
    }
    return driverResponseData;
  }
  getTemporaryDriverData(scope: any, operationalGroupCode: string, driverResponse: ElasticDriverDetails[]): Array<ElasticDriverDetails> {
    const updatedLocalStoredDriver = { localStoreArr: [] };
    const tempDriverArray = this.getDriverListFromData(operationalGroupCode, driverResponse);
    const localdriverDataList = scope.utilityService
      .getLocalStorageData(scope.getOperationalGroupCode(), 'operationalGroupDriverAssignments');
    const unAssignedDrivers = scope.utilityService.getLocalStorageData(scope.getOperationalGroupCode(),
      'operationalGroupUnAssignmentPersonIds');
    lodashutils.forEach(unAssignedDrivers, (driverId: number) => {
      const removedDataIdx = lodashutils.findIndex(tempDriverArray, { 'DriverPersonID': driverId });
      if (removedDataIdx !== -1) {
        tempDriverArray.splice(removedDataIdx, 1);
      }
    });
    lodashutils.forEach(localdriverDataList, (eachDriverData: OperationalGroupDriverAssignment) => {
      const isDriverExistInES = (lodashutils.findIndex(tempDriverArray,
        { 'DriverPersonID': Number(eachDriverData.driverPersonID) }) !== -1);
      if (!isDriverExistInES) {
        const addedDriver = lodashutils.cloneDeep(this.getAddedDriverDataObject(operationalGroupCode, eachDriverData));
        const profileImg = lodashutils.find(scope.driverDetailsModel.storeDriverImagesForProfileView, { userId: addedDriver.UserID });
        addedDriver.userProfileImg = (profileImg && profileImg.thumbPhoto) ? `data:image/jpeg;base64,${profileImg.thumbPhoto}` : null;
        tempDriverArray.unshift(addedDriver);
        updatedLocalStoredDriver.localStoreArr.push(eachDriverData);
      }
    });
    scope.utilityService.setLocalStorageData(scope.getOperationalGroupCode(),
      'operationalGroupDriverAssignments', updatedLocalStoredDriver.localStoreArr);
    return tempDriverArray;
  }
  getEmptyDriverData(): ElasticDriverDetails {
    return {
      'OperationalGroupDriverAssignmentID': 0, 'DriverPersonID': 0, 'FirstName': '', 'MiddleName': null,
      'LastName': '', 'PreferredName': '', 'UserID': '', 'JobGroup': '', 'OperationalGroupDriverAssignmentTypeCode': '',
      'EffectiveTimestamp': '', 'operationalGroupTitle': '', 'ExpirationTimestamp': '', 'operationalGroupCode': '',
      'operationalGroupDriverName': '', 'userProfileImg': null, 'formattedEndDate': '', 'rowEditable': true,
      'OperationalGroupDriverAssignmentTypeDescription': ''
    };
  }
  getIterateCancelDriverData(driverListDetails: ElasticDriverDetails[]): ElasticDriverDetails[] {
    return lodashutils.filter(driverListDetails, { 'rowEditable': false });
  }
  getPostableDriverDataToAdd(scope: any): OperationalGroupDriverAssignment {
    const driverData = scope.driverDetailsModel.selectedDriver;
    const expiryDate = this.getExpirationDateValue(scope.driverDetailsModel.tempDriverForm['controls']['tempDriverExpireDate'].value);
    return {
      'driverUserId': driverData.userId, 'driverPositionDescription': driverData.jobGroup,
      'driverPersonID': driverData.personId, 'driverLastName': driverData.lastName,
      'driverFirstName': driverData.firstName, 'driverMiddleName': driverData.middleName,
      'driverPreferredName': driverData.preferredName, 'operationalGroupDriverAssignmentTypeCode': 'Temporary',
      'overrideDriverValidations': scope.driverDetailsModel.overRideDriver,
      'overridePairedValidations': scope.driverDetailsModel.overRidePaired,
      'expirationTimestamp': moment(expiryDate.toISOString()).format(scope.driverDetailsModel.dateTimeFormat)
    };
  }
  getExpirationDateValue(expirationDate: string): Date {
    const expiryDate = new Date(expirationDate);
    expiryDate.setHours(23);
    expiryDate.setMinutes(59);
    expiryDate.setSeconds(59);
    return expiryDate;
  }
  getAddedDriverDataObject(operationalGroupCode: string, addedDriverData: OperationalGroupDriverAssignment): ElasticDriverDetails {
    const driverName = this.getDriverName(addedDriverData.driverPreferredName,
      addedDriverData.driverLastName, addedDriverData.driverFirstName);
    const driverTitle = `${driverName} (${addedDriverData.driverUserId}) ${addedDriverData.driverPositionDescription}`;
    return {
      'DriverPersonID': addedDriverData.driverPersonID, 'FirstName': addedDriverData.driverFirstName,
      'MiddleName': addedDriverData.driverMiddleName, 'LastName': addedDriverData.driverLastName,
      'PreferredName': addedDriverData.driverPreferredName, 'UserID': addedDriverData.driverUserId,
      'JobGroup': addedDriverData.driverPositionDescription,
      'OperationalGroupDriverAssignmentTypeCode': addedDriverData.operationalGroupDriverAssignmentTypeCode,
      'OperationalGroupDriverAssignmentTypeDescription': addedDriverData.operationalGroupDriverAssignmentTypeCode,
      'ExpirationTimestamp': addedDriverData.expirationTimestamp, 'operationalGroupCode': operationalGroupCode,
      'operationalGroupDriverName': driverName, 'operationalGroupTitle': driverTitle, 'userProfileImg': null,
      'rowEditable': false, 'formattedEndDate': moment(addedDriverData.expirationTimestamp).format('MM/DD/YYYY')
    };
  }
  getDriverInfoFromTypeahead(driverListDetails: ElasticResponseModel): DriverListDetails[] {
    return lodashutils.map(driverListDetails.hits.hits, (driverData) => {
      const eachDriverData = driverData._source;
      const driverToolTip = `${eachDriverData.personDTO.prefName} ${eachDriverData.personDTO.lastName} ` +
        `(${eachDriverData.personDTO.userId}) ${eachDriverData.personDTO.jobTitle}`;
      return {
        driverUserId: eachDriverData.personDTO.userId,
        operationalGroupDriverToolTip: driverToolTip, userId: eachDriverData.personDTO.userId,
        jobGroup: eachDriverData.personDTO.jobTitle, preferredName: eachDriverData.personDTO.prefName,
        firstName: eachDriverData.personDTO.firstName,
        lastName: eachDriverData.personDTO.lastName, personId: eachDriverData.emplid, userProfileImg: null,
        operationalGroupDriverName: `${eachDriverData.personDTO.prefName} ${eachDriverData.personDTO.lastName}`,
      };
    });
  }
  getBase64ImageForDrivers(driverDataArray: ElasticDriverDetails[], driverResponse: DriverImageResponse[]) {
    return lodashutils.map(driverDataArray, (driverData) => {
      const imageResponseData = lodashutils.find(driverResponse, { 'userId': driverData.UserID });
      if (imageResponseData) {
        driverData.userProfileImg = (imageResponseData.thumbPhoto) ? `data:image/jpeg;base64,${imageResponseData.thumbPhoto}` : null;
      }
      return driverData;
    });
  }
  getEndDateValidated(scope: any): EndDateErrorModel {
    const driverModel = scope.driverDetailsModel;
    const endDateVal = scope.driverDetailsModel.tempDriverForm['controls']['tempDriverExpireDate'].value;
    const endDateValidatedJSON = { 'endDate': endDateVal, endDateError: {}, isValid: (endDateVal && endDateVal.length !== 0) };
    if (endDateValidatedJSON.isValid) {
      const selectedDate = moment(this.getExpirationDateValue(endDateVal));
      const startDate = moment(scope.driverDetailsModel.driverExpiratationFromDate);
      const diffDays = selectedDate.diff(startDate, 'd');
      const duration = moment.duration(selectedDate.diff(startDate))['_data'];
      endDateValidatedJSON.isValid = (duration.years === 0 && duration.days >= 0 && diffDays <= driverModel.driverActiveDaysCount);
      if (!endDateValidatedJSON.isValid) {
        endDateValidatedJSON.endDateError = (duration.days < 0) ? driverModel.endDatePastValueError : driverModel.endDateFutureValueError;
      }
      return endDateValidatedJSON;
    }
    return endDateValidatedJSON;
  }
  getFormGroupForTempDriver(): FormGroup {
    return this.formBuilder.group({ 'tempDriverCheckBox': [false] });
  }
  getDefaultValidationResponse(operationalGroupCode: string): DuplicateAndPairedMemberData {
    return { 'duplicateMemberAssignmentId': null, 'pairedMemberId': null, 'operationalGroupCode': operationalGroupCode };
  }

  setDriversList(scope: any, operationalGroupCode: string, driverDataList: ElasticResponseModel) {
    const driverListData = lodashutils.map(driverDataList.hits.hits, 'inner_hits');
    if (driverListData && driverListData.length > 0) {
      scope.driverDetailsModel.totalMembersForScrollValidation =
        driverDataList.hits.hits[0]['inner_hits'].OperationalGroupDriverAssignment.hits.total;
    }
    const eachDriverListData = lodashutils.map(driverListData, 'OperationalGroupDriverAssignment.hits.hits');
    const driversListArray = lodashutils.map(eachDriverListData[0], '_source');
    this.driverSortSearchService.setDriverListType(scope, operationalGroupCode, driversListArray);
    const tempDriverUserIdArray = lodashutils.map(scope.driverDetailsModel.temporaryDriverListData, 'UserID');
    const permanentDriverUserIdArray = lodashutils.map(scope.driverDetailsModel.permanentDriverListData, 'UserID');
    scope.driverDetailsModel.imageUserIDArray = tempDriverUserIdArray.concat(permanentDriverUserIdArray);
    this.setDriverCheckBoxFormControl(scope);
  }
  setImageForDrivers(scope: any, driverResponse: DriverImageResponse[]) {
    const tempDrivers = scope.driverDetailsModel.temporaryDriverListData;
    const permananetDrivers = scope.driverDetailsModel.permanentDriverListData;
    scope.driverDetailsModel.temporaryDriverListData = this.getBase64ImageForDrivers(tempDrivers, driverResponse);
    scope.driverDetailsModel.permanentDriverListData = this.getBase64ImageForDrivers(permananetDrivers, driverResponse);
  }
  setAddedDriverInLocalStore(scope: any, operationalGroupCode: string) {
    const driverData = scope.driverDetailsModel.selectedDriver;
    scope.driverDetailsModel.tempDriverForm['controls']['tempDriverExpireDate'].setErrors(null);
    const storableDriverData = this.getPostableDriverDataToAdd(scope);
    const tempDriverListData = this.getAddedDriverDataObject(operationalGroupCode, storableDriverData);
    tempDriverListData['userProfileImg'] = (driverData.profilePicture) ? `data:image/jpeg;base64,${driverData.profilePicture}` : null;
    scope.driverDetailsModel.storableDriverListData.push(storableDriverData);
    scope.driverDetailsModel.temporaryDriverListData.unshift(tempDriverListData);
    scope.utilityService.setLocalStorageData(scope.getOperationalGroupCode(), 'operationalGroupDriverAssignments',
      scope.driverDetailsModel.storableDriverListData);
    scope.driverDetailsModel.storeDriverImagesForProfileView.push({
      userId: driverData.driverUserId, thumbPhoto: driverData.profilePicture
    });
  }
  setDriverCheckBoxFormControl(scope: any) {
    const tempDriverCheckBoxControl = scope.driverDetailsModel.tempDriverForm.controls.tempDriverCheckBoxes;
    if (tempDriverCheckBoxControl && tempDriverCheckBoxControl.controls) {
      lodashutils.forEach(scope.driverDetailsModel.temporaryDriverListData, (driverData) => {
        tempDriverCheckBoxControl.push(this.getFormGroupForTempDriver());
      });
      scope.driverDetailsModel.tempDriverForm['controls'].tempDriverHeaderCheckBox.setValue(false);
      scope.driverDetailsModel.tempDriverFormCheckBoxArray = lodashutils.map(tempDriverCheckBoxControl.controls, 'controls');
    }
  }
  setAddedDriverChkBoxControl(scope: any) {
    const tempDriverCheckBoxControl = scope.driverDetailsModel.tempDriverForm.controls.tempDriverCheckBoxes;
    if (tempDriverCheckBoxControl && tempDriverCheckBoxControl.controls) {
      tempDriverCheckBoxControl.controls.unshift(this.getFormGroupForTempDriver());
      scope.driverDetailsModel.tempDriverFormCheckBoxArray = lodashutils.map(tempDriverCheckBoxControl.controls, 'controls');
    }
  }
  setInCurrentOGToastMsg(parent: any, errTitle: string, errMsg: string) {
    parent.messageService.clear();
    parent.messageService.add({ 'severity': 'error', 'summary': errTitle, 'detail': errMsg || '' });
  }
  setRemovedDriverData(parent: any, isChecked: boolean, rowData: ElasticDriverDetails) {
    if (isChecked) {
      parent.driverDetailsModel.removedDriverListData.push(rowData);
    } else {
      const removedDataIdx = lodashutils.findIndex(parent.driverDetailsModel.removedDriverListData,
        { 'DriverPersonID': rowData.DriverPersonID });
      if (removedDataIdx !== -1) {
        parent.driverDetailsModel.removedDriverListData.splice(removedDataIdx, 1);
      }
    }
  }

  updateDriverDataIntoLocalstore(parent: any) {
    this.setAddedDriverInLocalStore(parent, parent.driverDetailsModel.operationalGroupCode);
    parent.utilityService.setIsAddMemberClicked(false, parent.getOperationalGroupCode());
    parent.resetTempDriverListView();
    parent.changeDetector.detectChanges();
  }

  executeMemberValidation(parent: any, memberValidation: MemberValidationCustomOutput) {
    if (memberValidation.isOverridedValidation) {
      parent.driverDetailsModel.overRideDriverErrorMsgs = memberValidation.memberValidationMsgs;
      parent.driverDetailsModel.isConfirmDialogVisible = true;
    } else {
      this.setInCurrentOGToastMsg(parent, memberValidation.validationMsgTitle, memberValidation.memberValidationMsgs[0]);
    }
    parent.changeDetector.detectChanges();
  }

  resetAddedDriverData(parent: any) {
    parent.driverDetailsModel.isTemporaryDriverLoaded = false;
    parent.driverDetailsModel.memberValidationResponseMessage =
      this.getDefaultValidationResponse(parent.driverDetailsModel.operationalGroupCode);
    parent.onConfirmYesClicked();
  }
  resetAddedDriverChkBoxControl(parent: any) {
    const editableRows = lodashutils.filter(parent.driverDetailsModel.temporaryDriverListData, { 'rowEditable': true });
    const tempDriverCheckBoxControl = parent.driverDetailsModel.tempDriverForm.controls.tempDriverCheckBoxes;
    if (tempDriverCheckBoxControl && tempDriverCheckBoxControl.controls) {
      if (editableRows.length > 0) {
        tempDriverCheckBoxControl.controls.splice(0, 1);
      }
      parent.driverDetailsModel.tempDriverFormCheckBoxArray = lodashutils.map(tempDriverCheckBoxControl.controls, 'controls');
    }
  }
  removeDriversFromTable(parent: any, removedDrivers: number[]) {
    const temporaryDrivers = lodashutils.cloneDeep(parent.driverDetailsModel.temporaryDriverListData);
    const tempDriverCheckBoxControl = parent.driverDetailsModel.tempDriverForm.controls.tempDriverCheckBoxes;
    lodashutils.remove(temporaryDrivers, (tempDriverData: ElasticDriverDetails, idx: number) => {
      const isRemovedMember = removedDrivers.filter(driverId => (tempDriverData.DriverPersonID === driverId)).length !== 0;
      if (isRemovedMember) {
        tempDriverCheckBoxControl.controls.splice(idx, 1);
      }
      return isRemovedMember;
    });
    parent.driverDetailsModel.temporaryDriverListData = temporaryDrivers;
    parent.driverDetailsModel.tempDriverFormCheckBoxArray = lodashutils.map(tempDriverCheckBoxControl.controls, 'controls');
    this.setRemovedDataInLocalStore(parent);
    parent.changeDetector.detectChanges();
  }

  setRemovedDataInLocalStore(parent: any) {
    const unAssignedDrivers = parent.utilityService
      .getLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupUnAssignmentPersonIds');
    lodashutils.forEach(parent.driverDetailsModel.removedDriverListData, (removedDriver: ElasticDriverDetails) => {
      const isDriverInEs = lodashutils.filter(parent.driverDetailsModel.storableTemporaryDriverListData,
        (driverDetails: ElasticDriverDetails) => (driverDetails.DriverPersonID === removedDriver.DriverPersonID)).length !== 0;
      if (isDriverInEs) {
        unAssignedDrivers.push(removedDriver.DriverPersonID);
      } else {
        const storableDataIdx =
          lodashutils.findIndex(parent.driverDetailsModel.storableDriverListData, { 'driverPersonID': removedDriver.DriverPersonID });
        if (storableDataIdx !== -1) {
          parent.driverDetailsModel.storableDriverListData.splice(storableDataIdx, 1);
        }
      }
    });
    parent.driverDetailsModel.removedDriverListData = [];
    parent.utilityService.setLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupDriverAssignments',
      parent.driverDetailsModel.storableDriverListData);
    parent.utilityService.setLocalStorageData(parent.getOperationalGroupCode(), 'operationalGroupUnAssignmentPersonIds',
      lodashutils.uniq(unAssignedDrivers));
  }
  isAddedDriverDuplicated(parent: any, driverID: string): LocalStoreDuplicateMemberData {
    const unAssignedDrivers = parent.utilityService.getLocalStorageData(parent.getOperationalGroupCode(),
      'operationalGroupUnAssignmentPersonIds');
    const duplicatedMemberData = { isAddedInLocalStore: false, isRemovedInLocalStore: false };
    const duplicateDriverArray = lodashutils.filter(parent.driverDetailsModel.storableDriverListData,
      (driverData: OperationalGroupDriverAssignment) =>
        (!DateUtils.isFutureDate(driverData.expirationTimestamp) && driverData.driverPersonID.toString() === driverID.toString()));
    duplicatedMemberData.isRemovedInLocalStore = lodashutils.filter(unAssignedDrivers,
      (unAssignDriverId: number) => (Number(driverID) === unAssignDriverId)).length !== 0;
    if (duplicateDriverArray && duplicateDriverArray.length !== 0) {
      duplicatedMemberData.isAddedInLocalStore = true;
      if (duplicatedMemberData.isRemovedInLocalStore) {
        duplicatedMemberData.isAddedInLocalStore = (duplicateDriverArray.length > 1);
      }
      if (duplicatedMemberData.isAddedInLocalStore) {
        const addedDriverData = parent.driverDetailsModel.selectedDriver;
        const driverName = this.getDriverName(addedDriverData.preferredName,
          addedDriverData.lastName, addedDriverData.firstName);
        const driverTitle = `${driverName} (${addedDriverData.driverUserId})`;
        const operGroupDesc = parent.driverDetailsModel.operationalGroupForm.controls['operationalGroupName'].value;
        this.setInCurrentOGToastMsg(parent, 'Member already selected',
          `${driverTitle} has already been added to ${operGroupDesc} (${parent.getOperationalGroupCode()})`);
      }
    }
    return duplicatedMemberData;
  }
  getDefaultProfileSortAndSearchQuery(): ProfileSortAndSearch {
    return {
      memberStartFrom: 0, expirationTimestamp: '', sortableEvent: { sortOrder: -1 }, searchType: 'text',
      searchTxt: '', sortableMember: 'OperationalGroupDriverAssignment.EffectiveTimestamp'
    };
  }
  getDriverElasticSearchQuery(parent: any, driverType: string, searchValue: string): DriverDetailsElasticQuery {
    return this.driverSortSearchService.getDriverElasticSearchQuery(parent, driverType, searchValue);
  }
  getDriverSortQuery(parent: any, driverType: string, sortView: SortView): DriverDetailsElasticQuery {
    return this.driverSortSearchService.getDriverSortQuery(parent, driverType, sortView);
  }
  getDriverNameForValidation(parent: any): string {
    const addedDriverData = parent.driverDetailsModel.selectedDriver;
    const driverName = this.getDriverName(addedDriverData.preferredName,
      addedDriverData.lastName, addedDriverData.firstName);
    return `${driverName} (${addedDriverData.driverUserId})`;
  }

  resetDriverDetailsView(parent: any) {
    parent.driverDetailsModel.tempDriverForm.reset();
    parent.driverDetailsModel.isSaveCancelBtnsVisible = false;
    parent.driverDetailsModel.isRemoveCancelBtnsVisible = false;
    parent.driverDetailsModel.isAddTemporaryTableVisible = true;
    parent.changeDetector.detectChanges();
  }
  resetDriversTableList(parent: any) {
    parent.driverDetailsModel.temporaryDriverListData = [];
    parent.driverDetailsModel.permanentDriverListData = [];
    parent.driverDetailsModel.isTemporaryDriverLoaded = false;
    parent.driverDetailsModel.isPermanentDriverLoaded = false;
    parent.driverDetailsModel.tempDriverForm['controls']['tempDriverCheckBoxes']['controls'] = [];
  }
}
