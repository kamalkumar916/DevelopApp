import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from '../../../../../shared/service/app-config.service';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import {
  OperationalPlanParameter, OperationalTeamListModel,
  UpdateGroupStatus, UpdateGroupStatusResponse
} from '../model/team-list.interface';
import { PostableOperationalGroup } from '../../model/operational-team.interface';



@Injectable()
export class TeamListService {

  endpoint: any;

  constructor(
    private readonly http: HttpClient,
    private readonly appConfigService: AppConfigService
  ) {
    this.endpoint = appConfigService.getApi('admin');
  }
  getOperationalTeamList(query: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getTeamList, query);
  }
  saveOperationalTeamData(query: PostableOperationalGroup, operationalGroupCode: string): Observable<boolean> {
    return this.http.patch<boolean>(`${this.endpoint.getOperationalTeamDetails}`, query);
  }
  addOperationalTeamData(query: PostableOperationalGroup): Observable<boolean> {
    return this.http.post<boolean>(this.endpoint.getOperationalTeamDetails, query);
  }
  downloadExcel(requestParam: any, headers?: HttpHeaders | null): Observable<Blob> {
    return this.http.post(this.endpoint.excelDownloadOperationalTeam, requestParam, { headers, responseType: 'blob' });
  }
  activateInactivateOperationalTeam(operationalGroupCode: string, groupStatus: UpdateGroupStatus): Observable<string> {
    const encodedGroupCode = encodeURIComponent(operationalGroupCode);
    const excessUrl = `/activateoperationalgroup?operationalGroupCode=${encodedGroupCode}&action=${groupStatus.action}`;
    return this.http.patch<string>(
      `${this.endpoint.getOperationalTeamDetails}${excessUrl}`, {});
  }
  getOWOSearchDateRangeDaysCount(dbParamName: string): Observable<OperationalPlanParameter> {
    return this.http.get<OperationalPlanParameter>(`${this.endpoint.getOWOSearchDateRangeDaysCount}?parameterName=${dbParamName}`);
  }
}
