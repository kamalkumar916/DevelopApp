import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { TeamListUtilityService } from './team-list-utility.service';
import { configureTestSuite } from 'ng-bullet';
const dataToPost = {
  operationalGroupCode: 'DCS',
  operationalGroupDescription: 'DCS',
  operationalGroupTypeCode: 'DCS',
  operationalGroupTypeDescription: 'DCS',
  operationalGroupSubTypeCode: 'DCS',
  operationalGroupSubTypeDescription: 'DCS',
  businessUnit: 'DCS',
  addingSource: 'Manual',
  isAddMemberClicked: false,
  isRemoveMemberClicked: false,
  financeBusinessUnitCode: 'DCS',
  utilizationStatus: [],
  operationalGroupDriverAssignments: [],
  operationalGroupUnAssignmentPersonIds: [],
  operationalGroupTruckAssignments: [],
  operationalGroupUnAssignmentTruckEquipmentIds: [],
  operationalGroupTrailingEquipmentAssignments: [],
  operationalGroupUnAssignmentTrailingEquipmentIds: [],
  operationalGroupCarrierAssignments: [],
  operationalGroupUnAssignmentCarrierIds: []
};

describe('TeamListUtilityService', () => {
  let utilityService: TeamListUtilityService;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [TeamListUtilityService, AppConfigService]
    });
  });
  beforeEach(() => {
    utilityService = TestBed.get(TeamListUtilityService);
  });
  it('should be created', () => {
    expect(utilityService).toBeTruthy();
  });
  it('excelHeaders have been called', () => {
    const resultData = [
      'operationalGroupDescription',
      'operationalGroupCode',
      'operationalGroupTypeDescription',
      'operationalGroupSubtypeDescription',
      'financeBusinessUnitCode',
      'utilizationStatus',
      'lastUpdateTimestamp',
      'lastUpdateProgramName',
      'status'
    ];
    const response = utilityService.excelHeaders();
    expect(response).toEqual(resultData);
  });
  it('getIsValidDataToPost have been called', () => {
    const returnValue = utilityService.getIsValidDataToPost(dataToPost);
    expect(returnValue).toBe(false);
  });
  it('getIsValidDataToPost have been called with null value', () => {
    const returnValue = utilityService.getIsValidDataToPost(null);
    expect(returnValue).toBe(false);
  });
  it('getSaveSuccessToastMsg have been called with value', () => {
    const returnValue = utilityService.getSaveSuccessToastMsg(dataToPost);
    expect(returnValue.severity).toEqual('success');
  });
  it('getPostableDataWithFinanceBU have been called with null value', () => {
    const returnValue = utilityService.getPostableDataWithFinanceBU(dataToPost);
    expect(returnValue).toBeTruthy();
  });
});
