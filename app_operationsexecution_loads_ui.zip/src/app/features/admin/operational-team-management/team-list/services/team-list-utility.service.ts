import { Injectable, EventEmitter } from '@angular/core';
import * as lodashutils from 'lodash';

import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import { PostableOperationalGroup } from '../../model/operational-team.interface';
import { OperationalTeamListModel, SortView } from '../model/team-list.interface';
import { TeamListModel } from './../model/team-list.model';

@Injectable()
export class TeamListUtilityService {

  emitActiveDays: EventEmitter<number> = new EventEmitter<number>();
  constructor() { }

  processDataForTeamList(teamDataList: ElasticResponseModel): Array<OperationalTeamListModel> {
    let groupList = [];
    if (teamDataList && teamDataList.hits && teamDataList.hits.hits) {
      const teamList = teamDataList.hits.hits;
      if (teamList && teamList.length > 0) {
        groupList = teamList.map((teamDataArg: HitsModel): OperationalTeamListModel => {
          const teamData = teamDataArg._source;
          const utilizationStatus = teamData.UtilizationStatus;
          return {
            'status': teamData.Status,
            'utilizationStatus': utilizationStatus,
            'lastUpdateUserID': teamData.LastUpdateUserID,
            'lastUpdateTimestamp': teamData.LastUpdateTimestamp,
            'operationalGroupCode': teamData.OperationalGroupCode,
            'financeBusinessUnitCode': teamData.FinanceBusinessUnitCode,
            'operationalGroupTypeCode': teamData.OperationalGroupTypeCode,
            'operationalGroupSubtypeCode': teamData.OperationalGroupSubtypeCode,
            'operationalGroupDescription': teamData.OperationalGroupDescription,
            'operationalGroupTypeDescription': teamData.OperationalGroupTypeDescription,
            'operationalGroupSubtypeDescription': (teamData.OperationalGroupSubtypeDescription) ?
              (teamData.OperationalGroupSubtypeDescription) : '- - -',
            'lastUpdateProgramName': `${teamData.LastUpdateProgramName}`,
            'UtilizationStatusDescription': this.getUtilizationStatus(utilizationStatus)
          };
        });
      }
    }
    return groupList;
  }

  getIsValidDataToPost(dataToPost: PostableOperationalGroup): boolean {
    if (dataToPost) {
      const driverCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupDriverAssignments');
      const equipCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupTruckAssignments');
      const carrierCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupCarrierAssignments');
      const trailCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupTrailingEquipmentAssignments');
      const driverUnAssignCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupUnAssignmentPersonIds');
      const equipUnAssignCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupUnAssignmentTruckEquipmentIds');
      const trailUnAssignCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupUnAssignmentTrailingEquipmentIds');
      const carrierUnAssignCount = this.getCountOfOGMembers(dataToPost, 'operationalGroupUnAssignmentCarrierIds');
      return (driverCount !== 0 || equipCount !== 0 || carrierCount !== 0 || trailCount !== 0 || driverUnAssignCount !== 0
        || equipUnAssignCount !== 0 || carrierUnAssignCount !== 0 || trailUnAssignCount !== 0);
    }
    return false;
  }

  getCountOfOGMembers(dataToPost: PostableOperationalGroup, dataMember: string): number {
    return (dataToPost[dataMember]) ? dataToPost[dataMember].length : 0;
  }

  isFormDataDuplicated(parent: any, dataToPost: PostableOperationalGroup, formLevelData: PostableOperationalGroup): boolean {
    const localStoredData = lodashutils.omit(dataToPost, parent.teamListModel.assignUnassignDataMembers);
    return !lodashutils.isEqual(localStoredData, formLevelData);
  }

  getUpdateSuccessToastMsg(teamListModel: TeamListModel) {
    const successToastMsg = lodashutils.cloneDeep(teamListModel.updateSuccessToastMsg);
    successToastMsg.detail = `${teamListModel.operationalGroupName} (${teamListModel.operationalGroupCode}) ` +
      `${teamListModel.updateSuccessToastMsg.detail}`;
    return successToastMsg;
  }

  getSaveSuccessToastMsg(operationalGroupData: PostableOperationalGroup) {
    const successToastMsg = { 'severity': 'success', 'summary': 'Success', 'detail': 'Operational Team has been added successfully' };
    successToastMsg.detail = `${operationalGroupData.operationalGroupDescription} ` +
      `(${operationalGroupData.operationalGroupCode}) ${successToastMsg.detail}`;
    return successToastMsg;
  }

  excelHeaders(): string[] {
    return [
      'operationalGroupDescription',
      'operationalGroupCode',
      'operationalGroupTypeDescription',
      'operationalGroupSubtypeDescription',
      'financeBusinessUnitCode',
      'utilizationStatus',
      'lastUpdateTimestamp',
      'lastUpdateProgramName',
      'status'
    ];
  }

  getUtilizationStatus(utilizationStatus): string[] {
    let utilizationStatusList = lodashutils.map(utilizationStatus, 'UtilizationStatusDescription');
    utilizationStatusList = (utilizationStatusList.every(lodashutils.isNull)) ? ['- - -'] : utilizationStatusList;
    return utilizationStatusList;
  }

  filterContent(parent: any) {
    parent.teamListModel.filterParam = {};
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['selectedCategory'])) {
      parent.teamListModel.filterParam['selectedCategory'] = parent.teamListModel.filterValues['selectedCategory'];
      parent.teamListModel.filterParam['selectedCategoryEmpty'] = '';
    } else {
      parent.teamListModel.filterParam['selectedCategory'] = [];
      parent.teamListModel.filterParam['selectedCategoryEmpty'] = '*';
    }
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['selectedType'])) {
      parent.teamListModel.filterParam['selectedType'] = parent.teamListModel.filterValues['selectedType'];
      parent.teamListModel.filterParam['selectedTypeEmpty'] = '';
    } else {
      parent.teamListModel.filterParam['selectedType'] = [];
      parent.teamListModel.filterParam['selectedTypeEmpty'] = '*';
    }
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['selectedBU'])) {
      parent.teamListModel.filterParam['selectedBU'] = parent.teamListModel.filterValues['selectedBU'];
      parent.teamListModel.filterParam['selectedBUEmpty'] = '';
    } else {
      parent.teamListModel.filterParam['selectedBU'] = [];
      parent.teamListModel.filterParam['selectedBUEmpty'] = '*';
    }
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['selectedUtilizationStatus'])) {
      parent.teamListModel.filterParam['selectedUtilizationStatus'] = parent.teamListModel.filterValues['selectedUtilizationStatus'];
      parent.teamListModel.filterParam['selectedUtilizationStatusEmpty'] = '';
    } else {
      parent.teamListModel.filterParam['selectedUtilizationStatus'] = [];
      parent.teamListModel.filterParam['selectedUtilizationStatusEmpty'] = '*';
    }
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['selectedStatus'])) {
      parent.teamListModel.filterParam['selectedStatus'] = parent.teamListModel.filterValues['selectedStatus'];
      parent.teamListModel.filterParam['selectedStatusEmpty'] = '';
    } else {
      parent.teamListModel.filterParam['selectedStatus'] = [];
      parent.teamListModel.filterParam['selectedStatusEmpty'] = '*';
    }
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['lastUpdated'])) {
      parent.teamListModel.filterParam['lastUpdated'] = parent.teamListModel.filterValues['lastUpdated'];
    }
    this.setlastUpdatedTimeValues(parent);
  }
  setlastUpdatedTimeValues(parent: any) {
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['selectedLastUpdatedBy'])) {
      parent.teamListModel.filterParam['selectedLastUpdatedBy'] = parent.teamListModel.filterValues['selectedLastUpdatedBy'];
      parent.teamListModel.filterParam['selectedLastUpdatedByEmpty'] = '';
    } else {
      parent.teamListModel.filterParam['selectedLastUpdatedBy'] = [];
      parent.teamListModel.filterParam['selectedLastUpdatedByEmpty'] = '*';
    }
    if (!lodashutils.isEmpty(parent.teamListModel.filterValues['selectedLastUpdatedByUserId'])) {
      parent.teamListModel.filterParam['selectedLastUpdatedByUserId'] = parent.teamListModel.filterValues['selectedLastUpdatedByUserId'];
      parent.teamListModel.filterParam['selectedLastUpdatedByUserIdEmpty'] = '';
    } else {
      parent.teamListModel.filterParam['selectedLastUpdatedByUserId'] = [];
      parent.teamListModel.filterParam['selectedLastUpdatedByUserIdEmpty'] = '*';
    }
  }
  setDefaultScrollPosition(parent: any) {
    const scrollableElement = parent.opTeamTable['el'].nativeElement.querySelector('.ui-table-scrollable-body');
    if (scrollableElement) {
      scrollableElement.scrollTop = 0;
    }
  }
  setSuccessToastMsgForStatus(parent: any) {
    const operationalGroupDetail = `${parent.teamListModel.opertaionalTeamDetails.operationalGroupDescription} ` +
      `(${parent.teamListModel.opertaionalTeamDetails.operationalGroupCode})`;
    parent.messageService.clear();
    parent.messageService.add({
      'severity': 'success', 'summary': 'Success',
      'detail': `${operationalGroupDetail} has been ${parent.teamListModel.operationalGroupStatusLabel}d successfully`
    });
  }
  setErrorforValidation(parent: any, validationError: any) {
    const errorJson = typeof validationError.error === 'string' ? JSON.parse(validationError.error) : validationError.error;
    const errMsgJson = parent.utilityService.getMemberValidationResponse(errorJson);
    if (!errMsgJson.isOverridedValidation) {
      parent.messageService.clear();
      parent.messageService.add(
        { 'severity': 'error', 'summary': 'Action Cannot be Perfomed', 'detail': errMsgJson.memberValidationMsgs[0] });
    }
  }
  setParallelEditError(parent: any) {
    parent.messageService.clear();
    parent.messageService.add({
      'severity': 'error', 'summary': 'Error',
      'detail': 'This Operational Team has been deactivated. Please refresh.'
    });
  }
  setErrorForInactiveOperatationalGroup(parent: any, errorCode: string) {
    parent.messageService.clear();
    const errorMsg = lodashutils.cloneDeep(parent.teamListModel.operationalGroupStatusToast);
    switch (errorCode) {
      case '01':
        parent.teamListModel.isMaskNeeded = false;
        errorMsg.detail = parent.teamListModel.activeMemberErrorMsg;
        parent.messageService.add(errorMsg);
        break;
      case '02':
        parent.teamListModel.isMaskNeeded = false;
        errorMsg.detail = parent.teamListModel.activeLoadErrorMsg;
        parent.messageService.add(errorMsg);
        break;
      default:
        this.setSuccessToastMsgForStatus(parent);
        parent.teamListModel.operationalGroupInactivateStatus = { status: errorCode };
        break;
    }
  }
  getPostableDataWithFinanceBU(postableData: PostableOperationalGroup): PostableOperationalGroup {
    postableData.financeBusinessUnitCode = postableData.businessUnit;
    return lodashutils.omit(postableData, 'businessUnit');
  }
  getIsEditFieldUpdated(parent: any): boolean {
    if (parent.teamDetailsComponent) {
      const operationalTeamData = parent.teamDetailsComponent.getOperationalGroupFormData();
      const dataToPost = lodashutils.omit(
        lodashutils.cloneDeep(parent.utilityService.getLocalStorageDataToPost()), ['isAddMemberClicked', 'isRemoveMemberClicked']
      );
      return this.getIsValidDataToPost(dataToPost)
        || this.isFormDataDuplicated(parent, dataToPost, operationalTeamData.operationalGroupData);
    }
    return false;
  }
  viewOperationalGroupProfile(parent: any) {
    if (!parent.utilityService.getIsAddMemberClicked() && !parent.utilityService.getIsRemoveMemberClicked()) {
      parent.teamListModel.isOperationalGroupUpdated = (parent.teamListModel.opertaionalTeamDetails.status === 'Active'
        && this.getIsEditFieldUpdated(parent));
      if (!parent.teamListModel.isOperationalGroupUpdated) {
        this.navigateToOperationalGroupPage(parent);
      }
    } else {
      parent.onDisplayActionReqdError();
    }
    parent.changeDetector.detectChanges();
  }
  navigateToOperationalGroupPage(parent: any) {
    parent.teamListModel.isProfileView = true;
    const encodedGroupCode = encodeURIComponent(parent.teamListModel.operationalGroupCode);
    parent.utilityService.router.navigate
      ([`/admin/operationalteammanagement/viewprofile/${encodedGroupCode}?${parent.teamListModel.isProfileView}`])
      .then(() => this.emitActiveDays.emit(parent.teamListModel.driverActiveDaysCount));
  }
  getAddFormDirty(parent: any) {
    if (parent.teamDetailsComponent && parent.teamDetailsComponent.teamDetailsModel.newOperationalGroupForm) {
      return parent.teamDetailsComponent.teamDetailsModel.newOperationalGroupForm.dirty;
    }
    return false;
  }
  onOGRowSelect(parent: any, selectedRow: OperationalTeamListModel) {
    if (parent.teamListModel.isNewOperationalTeamToAdd && parent.teamListModel.splitView) {
      if (this.getAddFormDirty(parent)) {
        this.showRowBasedConfirmation(parent);
      } else {
        this.showSelectedRowDataOnGrid(parent, selectedRow);
      }
    } else if (!parent.teamListModel.splitView) {
      this.showSelectedRowDataOnGrid(parent, selectedRow);
    } else if ((parent.teamListModel.opertaionalTeamDetails.status === 'Active') && (this.getIsEditFieldUpdated(parent) ||
      parent.utilityService.getIsAddMemberClicked() || parent.utilityService.getIsRemoveMemberClicked())
      && !parent.teamListModel.isLostOGChangesDialogVisible) {
      this.showRowBasedConfirmation(parent);
    } else {
      this.showSelectedRowDataOnGrid(parent, selectedRow);
    }
    parent.teamListModel.addOperationalTeamStaticRecord.selectedRow = selectedRow;
    parent.changeDetector.detectChanges();
  }
  showRowBasedConfirmation(parent: any) {
    parent.teamListModel.operationalTeamSelectedList = [];
    parent.teamListModel.isLostOGChangesDialogVisible = true;
    parent.teamListModel.addOperationalTeamStaticRecord.outOfNewOPTeamMember = 'SelectedRow';
  }
  showSelectedRowDataOnGrid(parent: any, selectedRow: OperationalTeamListModel) {
    parent.teamListModel.splitView = true;
    parent.teamListModel.iconFlag = false;
    parent.teamListModel.isNewOperationalTeamToAdd = false;
    parent.teamListModel.filterView = false;
    parent.teamListModel.isMaskNeeded = (parent.teamListModel.operationalGroupCode !== selectedRow.operationalGroupCode);
    parent.teamListModel.operationalTeamSelectedList = [selectedRow];
    parent.teamListModel.operationalGroupCode = selectedRow.operationalGroupCode;
    parent.teamListModel.operationalGroupName = selectedRow.operationalGroupDescription;
  }
  onOGTeamGridLazyLoad(parent: any, event: SortView) {
    if (parent.teamListModel.isNewOperationalTeamToAdd && parent.teamListModel.splitView) {
      this.showGridLazyLoadBasedConfirmation(parent);
    } else if (parent.teamListModel.splitView && (parent.teamListModel.opertaionalTeamDetails.status === 'Active')
      && (this.getIsEditFieldUpdated(parent) || parent.utilityService.getIsAddMemberClicked() ||
        parent.utilityService.getIsRemoveMemberClicked()) && !parent.teamListModel.isLostOGChangesDialogVisible) {
      this.showGridLazyLoadBasedConfirmation(parent);
    } else if (!parent.teamListModel.isGridLazyLoadTriggeredPartial) {
      parent.onOPTeamTableEditLazyLoad(event);
    }
    parent.teamListModel.isGridLazyLoadTriggeredPartial = false;
  }
  showGridLazyLoadBasedConfirmation(parent: any) {
    parent.teamListModel.isLostOGChangesDialogVisible = true;
    parent.teamListModel.addOperationalTeamStaticRecord.outOfNewOPTeamMember = 'GridLazyLoad';
    parent.opTeamTable._sortField = parent.teamListModel.addOperationalTeamStaticRecord.selectedLazyLoadData.sortField;
    parent.opTeamTable._sortOrder = parent.teamListModel.addOperationalTeamStaticRecord.selectedLazyLoadData.sortOrder;
    parent.changeDetector.detectChanges();
  }
  onAddUpdateSuccess(parent: any, toastMessage: any) {
    parent.teamListModel.isAddOrUpdateOperGroup = true;
    parent.onClose();
    parent.messageService.clear();
    parent.utilityService.clearAllLocalStorageData();
    parent.messageService.add(toastMessage);
    parent.onUpdateGridRecord();
  }
}
