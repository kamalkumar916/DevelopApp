import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { TeamListService } from './team-list.service';
import { configureTestSuite } from 'ng-bullet';

describe('TeamListService', () => {
  let service: TeamListService;
  let httpTestingController: HttpTestingController;
  const requestParam = {
    operationalGroupCode: 'DCS',
    operationalGroupDescription: 'DCS',
    operationalGroupTypeCode: 'test',
    operationalGroupTypeDescription: 'test',
    operationalGroupSubTypeCode: 'test',
    operationalGroupSubTypeDescription: 'test',
    businessUnit: 'DCS',
    utilizationStatus: [],
    operationalGroupDriverAssignments: [],
    operationalGroupUnAssignmentPersonIds: [],
    operationalGroupTruckAssignments: [],
    operationalGroupUnAssignmentTruckEquipmentIds: [],
    operationalGroupTrailingEquipmentAssignments: [],
    operationalGroupUnAssignmentTrailingEquipmentIds: [],
    operationalGroupCarrierAssignments: [],
    operationalGroupUnAssignmentCarrierIds: []
  };
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [TeamListService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(TeamListService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('makes expected operationalGroup calls', () => {
    service.getOperationalTeamList({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTeamList);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected getOWOSearchDateRangeDaysCount calls', () => {
    const dbParam = 'OGMaxMemberCount';
    service.getOWOSearchDateRangeDaysCount(dbParam).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOWOSearchDateRangeDaysCount}?parameterName=${dbParam}`);
    expect(req.request.method).toEqual('GET');
  });
  it('makes expected downloadExcel calls', () => {
    service.downloadExcel({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.excelDownloadOperationalTeam);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected activateInactivateOperationalTeam calls', () => {
    const encodedGroupCode = 'ABC';
    const groupStatus = {
      action: 'Inactivate'
    };
    const excessUrl = `/activateoperationalgroup?operationalGroupCode=${encodedGroupCode}&action=${groupStatus.action}`;
    service.activateInactivateOperationalTeam(encodedGroupCode, groupStatus).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOperationalTeamDetails}${excessUrl}`);
    expect(req.request.method).toEqual('PATCH');
  });
  it('makes expected addOperationalTeamData calls', () => {
    service.addOperationalTeamData(requestParam).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalTeamDetails);
    expect(req.request.method).toEqual('POST');
  });
  it('makes expected saveOperationalTeamData calls', () => {
    service.saveOperationalTeamData(requestParam, 'DCS').subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalTeamDetails);
    expect(req.request.method).toEqual('PATCH');
  });
});
