import { FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';
import {
    AddOperationalTeamStaticRecord, FilterPanel, OperationalTeamListModel, UpdateGroupStatusResponse,
    TableColumnModel, TeamListElasticSortableQuery, TeamListElasticQuery
} from './team-list.interface';
import { OperationalTeamManagementData } from '../team-details/model/team-details.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class TeamListModel {
    iconFlag: boolean;
    sortField: string;
    searchText: string;
    splitView: boolean;
    filterView: boolean;
    totalRecords: number;
    pageStart: number;
    listSize: number;
    isLoading: boolean;
    isInitialLoading: boolean;
    menuItems: MenuItem[];
    userInputSearchSubject: Subject<string>;
    queryString: string;
    canSubscribe: boolean;
    isPaginatorReqd: boolean;
    operationalGroupCode: string;
    operationalGroupName: string;
    tableColumns: TableColumnModel[];
    teamListElasticQuery: TeamListElasticQuery;
    gridSortQuery: TeamListElasticSortableQuery;
    operationalTeamList: OperationalTeamListModel[];
    operationalTeamSelectedList: OperationalTeamListModel[];
    breadcrumbOperationalGroups: MenuItem[];
    filterValues: any;
    filterParam: any;
    tblScrollHeight: string;
    updateSuccessToastMsg: any;
    infoToastMsg: any;
    filterPanel: FilterPanel;
    teamListForm: FormGroup;
    isEmptyPage: boolean;
    isProfileView: boolean;
    isMaskNeeded: boolean;
    isActiveOperationalGroup: boolean;
    opertaionalTeamDetails: OperationalTeamManagementData;
    displayDialog: boolean;
    activeLoadErrorMsg: string;
    activeMemberErrorMsg: string;
    operationalGroupStatusToast: any;
    operationalGroupInactivateStatus: UpdateGroupStatusResponse;
    isLazyLoadTriggered: boolean;
    isNewOperationalTeamToAdd: boolean;
    addOperationalTeamStaticRecord: AddOperationalTeamStaticRecord;
    isLostOGChangesDialogVisible: boolean;
    isProfileDialogVisible: boolean;
    isSplitChangesDialogVisible: boolean;
    operationalGroupStatusLabel: string;
    duplicateIdentityToastMsg: any;
    elasticIntervalTimer: number;
    isOperationalGroupUpdated: boolean;
    isGridLazyLoadTriggeredPartial: boolean;
    driverActiveDaysCount: number;
    isOGStatusChanged: boolean;
    isAddOrUpdateOperGroup: boolean;
    defautDriverActiveDaysCount: number;
    gridPaginatorExistSize: number;
    styleClass: string;
    styleClassAdded: string;
    assignUnassignDataMembers: string[];
    maxOGMemberCount: number;
    isOverflowReqd: boolean;
    isProfileViewConfirmation: boolean;
    emptyResponse: string;
    addOperationalTeamButton: SecureModel;
    profileRedirectionIcon: SecureModel;
    appConfig;
    constructor() {
        this.menuItems = [];
        this.operationalGroupCode = '';
        this.searchText = '';
        this.totalRecords = 0;
        this.splitView = false;
        this.sortField = 'Name';
        this.filterView = false;
        this.filterValues = { 'selectedStatus': ['Active'] };
        this.operationalTeamList = [];
        this.isPaginatorReqd = false;
        this.isMaskNeeded = false;
        this.queryString = '';
        this.userInputSearchSubject = new Subject<string>();
        this.operationalTeamSelectedList = [];
        this.infoToastMsg = {
            'severity': 'info',
            'summary': 'No Changes Found',
            'detail': 'There are no changes detected in the current action'
        };
        this.updateSuccessToastMsg = {
            'severity': 'success',
            'summary': 'Success',
            'detail': 'Operational Team has been updated successfully'
        };
        this.operationalGroupStatusToast = {
            'severity': 'error',
            'summary': 'Operational Team in Use',
            'detail': ''
        };
        this.activeLoadErrorMsg = 'Team cannot be inactivated while associated with an active load';
        this.activeMemberErrorMsg = 'Team cannot be inactivated while associated with an active member';
        this.breadcrumbOperationalGroups = [
            { label: 'Administration', routerLink: ['/dashboard'] },
            {
                label: 'Operational Team Management',
                routerLink: ['/admin/operatioanlteammanagement']
            }
        ];
        this.styleClass = 'team-list-std-style team-list-category-bu-style';
        this.styleClassAdded = 'team-list-std-style';
        this.tableColumns = [
            {
                'label': 'Name',
                'key': 'operationalGroupDescription', 'styleClass': 'team-list-std-style team-list-desc-style',
                'sortableDataMember': 'OperationalGroupDescription.keyword'
            },
            {
                'label': 'Identifier',
                'key': 'operationalGroupCode', 'styleClass': this.styleClassAdded,
                'sortableDataMember': 'OperationalGroupCode.keyword'
            },
            {
                'label': 'Category',
                'key': 'operationalGroupTypeDescription', 'styleClass': this.styleClass,
                'sortableDataMember': 'OperationalGroupTypeDescription.keyword'
            },
            {
                'label': 'Type',
                'key': 'operationalGroupSubtypeDescription', 'styleClass': this.styleClassAdded,
                'sortableDataMember': 'OperationalGroupSubtypeDescription.keyword'
            },
            {
                'label': 'Business Unit',
                'key': 'financeBusinessUnitCode', 'styleClass': this.styleClass,
                'sortableDataMember': 'FinanceBusinessUnitCode.keyword'
            },
            {
                'label': 'Utilization Status',
                'key': 'UtilizationStatusDescription', 'styleClass': this.styleClassAdded,
                'sortableDataMember': 'UtilizationStatus.UtilizationStatusDescription.keyword'
            },
            {
                'label': 'Last Updated',
                'key': 'lastUpdateTimestamp', 'styleClass': 'team-list-std-style team-list-timeStamp-style',
                'sortableDataMember': 'LastUpdateTimestamp'
            },
            {
                'label': 'Last Updated By',
                'key': 'lastUpdateProgramName', 'styleClass': 'team-list-std-style team-list-updated-style',
                'sortableDataMember': 'LastUpdateProgramName.keyword'
            },
            {
                'label': 'Status',
                'key': 'status', 'styleClass': this.styleClass,
                'sortableDataMember': 'Status.keyword'
            }
        ];
        this.filterPanel = {
            lastUpdated: true,
            isOpen: false
        };
        this.isEmptyPage = true;
        this.isProfileView = false;
        this.addOperationalTeamStaticRecord = {
            selectedLazyLoadData: null, selectedPaginatorData: null,
            selectedRow: null, outOfNewOPTeamMember: null
        };
        this.duplicateIdentityToastMsg = {
            'severity': 'error', 'summary': 'Reference Data Duplication',
            'detail': 'There is already a Operational Team of this type with the Identifier. Please designate a different code'
        };
        this.defautDriverActiveDaysCount = 14;
        this.elasticIntervalTimer = 1000;
        this.assignUnassignDataMembers = ['operationalGroupDriverAssignments', 'operationalGroupTruckAssignments',
            'operationalGroupCarrierAssignments', 'operationalGroupTrailingEquipmentAssignments',
            'operationalGroupUnAssignmentPersonIds', 'operationalGroupUnAssignmentTruckEquipmentIds',
            'operationalGroupUnAssignmentTrailingEquipmentIds', 'operationalGroupUnAssignmentCarrierIds'];
        this.driverActiveDaysCount = this.defautDriverActiveDaysCount;
        this.maxOGMemberCount = 200;
        this.isOverflowReqd = false;
        this.isProfileViewConfirmation = false;
        this.emptyResponse = '- - -';
        this.appConfig = AppConfig.getConfig();
        this.addOperationalTeamButton = { url: this.appConfig.api.admin.getOperationalTeamDetails, operation: 'C' };
        this.profileRedirectionIcon = { url: this.appConfig.api.uiAccessList.operationalTeamProfileRedirection, operation: 'R' };
    }
}
