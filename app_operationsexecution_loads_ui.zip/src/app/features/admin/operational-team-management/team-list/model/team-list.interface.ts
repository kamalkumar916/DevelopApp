export interface TableColumnModel {
    label: string;
    key: string;
    styleClass: string;
    sortableDataMember: string;
}

export interface OperationalTeamListModel {
    operationalGroupCode: string;
    operationalGroupDescription: string;
    operationalGroupTypeCode: string;
    operationalGroupTypeDescription: string;
    operationalGroupSubtypeCode: string;
    operationalGroupSubtypeDescription: string;
    financeBusinessUnitCode: string;
    utilizationStatus: UtilizationStatus[];
    UtilizationStatusDescription: string[];
    lastUpdateProgramName: string;
    lastUpdateUserID: string;
    status: string;
    lastUpdateTimestamp: string;
}

export interface UtilizationStatus {
    UtilizationStatusCode: string;
    UtilizationStatusDescription: string;
}

export interface SortView {
    filters: object;
    first: number;
    globalFilter: any;
    multiSortMeta: any;
    rows: number;
    sortField: string;
    sortOrder: number;
}

export interface Bool {
    must?: any[];
}

export interface Query {
    bool?: Bool;
}

export interface TeamListElasticQuery {
    from: number;
    size: number;
    sort?: any[];
    query?: Query;
    _source: string[];
}

export interface TeamListElasticSortableQuery {
    sort: any[];
}
export interface FilterPanel {
    lastUpdated: boolean;
    isOpen: boolean;
}

export interface UpdateGroupStatus {
    action: string;
}

export interface UpdateGroupStatusResponse {
    status: string;
}

export interface AddOperationalTeamStaticRecord {
    selectedPaginatorData?: any;
    outOfNewOPTeamMember?: string;
    selectedLazyLoadData?: SortView;
    selectedRow?: OperationalTeamListModel;
}

export interface OperationalPlanParameter {
    operationalPlanParameterId: number;
    parameterName: string;
    parameterValue: string;
    parameterDescription: string;
    effectiveTimestamp: Date;
    expirationTimestamp: Date;
    lastUpdateTimestampString: Date;
    _links: any;
}
