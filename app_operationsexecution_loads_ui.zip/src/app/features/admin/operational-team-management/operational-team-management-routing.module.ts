import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TeamListComponent } from './team-list/team-list.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { ViewAuditComponent } from './view-profile/view-audit/view-audit/view-audit.component';
import { UnsavedChangesGuard } from '../../../shared/unsaved-changes.guard';

const routes: Routes = [
  { path: '', component: TeamListComponent, canDeactivate: [UnsavedChangesGuard]},
  { path: 'viewprofile/:id', component: ViewProfileComponent },
  { path: 'viewaudit/:id', component: ViewAuditComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [UnsavedChangesGuard]
})
export class OperationalTeamManagementRoutingModule { }
