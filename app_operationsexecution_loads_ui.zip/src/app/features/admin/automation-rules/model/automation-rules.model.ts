import { MenuItem } from 'primeng/api';
import { HitsModel } from './../../../model/elastic-response.interface';
import { Breadcrumb, FilterVariables, DropDownValue, RuleTypeData, ColumnSorting } from './automation-rules.interface';
import { ListItem } from '../../../model/listitem.interface';
import { SecureModel } from '../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../config/app.config';

export class AutomationRulesModel {

    breadcrumb: Breadcrumb[];
    subscribeFlag: boolean;
    automationRulesList: HitsModel[];
    totalRecords: number;
    from: number;
    first: number;
    size: number;
    searchValue: string;
    searchInputValue: string;
    objectParam: object;
    items: MenuItem[];
    listEmptyFlag: boolean;
    filterFlag: boolean;
    ruleNameFilter: string[];
    filterLastUpdatedBy: ListItem[];
    associationLevel: DropDownValue[];
    filterVariables: FilterVariables;
    selectedTimeRange: Date[];
    startTime: string;
    startDate: string;
    endTime: string;
    endDate: string;
    invalidRuleName: boolean;
    loadingFlag: boolean;
    associationLevelField: string[];
    associationTypeField: string[];
    showFilter: boolean;
    selectedStatus: string;
    selectedStartDate: string;
    selectedEndDate: string;
    invalidUpdatedByName: boolean;
    clearFiltersFlag: boolean;
    filterLastUpdatedByField: string;
    associationType: RuleTypeData[];
    sortField: string;
    sortOrder: string;
    ascendingOrder: string;
    descendingOrder: string;
    tableColumnHeaders: ColumnSorting[];
    configureNewButton: SecureModel;
    appConfig;
    constructor() {
        this.breadcrumb = [
            { label: 'Administration', routerLink: [''] },
            {
                label: 'Automation Rules',
                routerLink: ['/admin/automationrules']
            }];
        this.subscribeFlag = true;
        this.from = 0;
        this.first = 0;
        this.size = 25;
        this.searchValue = '';
        this.searchInputValue = '';
        this.objectParam = {};
        this.automationRulesList = [];
        this.filterVariables = {
            from: 0,
            size: 25,
            searchValue: '',
            ruleNameSelected: [],
            associationLevelSelected: [],
            ruleCategorySelected: [],
            lastUpdatedValueSelected: null,
            lastUpdatedBySelected: [],
            statusSelected: ['Active'],
            lastUpdatedFromTimeStamp: null,
            lastUpdatedToTimeStamp: null
        };
        this.loadingFlag = false;
        this.associationLevelField = [];
        this.associationTypeField = [];
        this.ruleNameFilter = [];
        this.showFilter = false;
        this.selectedStatus = '';
        this.selectedStartDate = '';
        this.selectedEndDate = '';
        this.invalidUpdatedByName = false;
        this.clearFiltersFlag = true;
        this.filterLastUpdatedByField = '';
        this.ascendingOrder = 'asc';
        this.descendingOrder = 'desc';
        this.appConfig = AppConfig.getConfig();
        this.configureNewButton = { url: this.appConfig.api.uiAccessList.configureNewRule, operation: 'C' };
        this.tableColumnHeaders = [{
            'name': 'Rule Name',
            'queryKey': 'RuleName.keyword'
        }, {
            'name': 'Association Level',
            'queryKey': 'RuleTypeDescription.keyword'
        },
        {
            'name': 'Rule Category',
            'queryKey': 'RuleCategoryDescription.keyword'
        }, {
            'name': 'Status',
            'queryKey': 'Status.keyword'
        },
        {
            'name': 'Last Updated',
            'queryKey': 'LastUpdateTimestamp.date'
        },
        {
            'name': 'Last Updated By',
            'queryKey': 'LastUpdateProgramName.keyword'
        }];
    }
}
