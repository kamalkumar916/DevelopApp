import { ListItem } from '../../../model/listitem.interface';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';

export interface Breadcrumb {
  label: string;
  routerLink: Array<string>;
}
export interface AutomationRuleQuery {
  from: number;
  size: number;
  sort: Array<SortRule>;
}

export interface SortRule {
  'RuleName.keyword': Order;
}

export interface Order {
  order: string;
}
export interface RuleCriteriaDetails {
  RuleLogicalOperatorDescription: null;
  RuleLogicalOperatorCode: null;
  RuleCriteriaCode: null;
  RuleCriteriaLogicalOperatorAssociationID: null;
  RuleCriteriaValue: RuleCriteriaValue;
  RuleCriteriaDescription: null;
}
export interface RuleCriteriaValue {
  RuleCriteriaValue: null;
  RuleCriteriaDetailID: null;
}

export interface FilterVariables {
  from: number;
  size: number;
  searchValue: string;
  ruleNameSelected: Array<string>;
  associationLevelSelected: Array<string>;
  ruleCategorySelected: Array<string>;
  lastUpdatedValueSelected: Date;
  lastUpdatedBySelected: Array<string>;
  statusSelected: Array<string>;
  lastUpdatedFromTimeStamp: Date | string;
  lastUpdatedToTimeStamp: Date | string;
}
export interface DropDownValue {
  label: string;
  value: string;
}
export interface RuleType {
  _embedded: RuleTypeEmbeddedInterface;
  _links: any;
  page: PageContentInterface;
}
export interface PageContentInterface {
  size: number;
  totalElements: number;
  totalPages: number;
  number: number;
}
export interface RuleTypeEmbeddedInterface {
  ruleTypes: Array<any>;
}
export interface RuleCategory {
  _embedded: RuleTypeEmbeddedInterface;
  _links: any;
  page: PageContentInterface;
}
export interface RuleCategoryEmbeddedInterface {
  ruleCategories: Array<any>;
}

export interface FilterConfigFields {
  title: string;
  url?: string;
  query?: any;
  callback?: ListItem[];
  data?: ListItem[];
}

export interface FilterConfig {
  ruleName: FilterConfigFields;
  associationLevel: FilterConfigFields;
  ruleCategory: FilterConfigFields;
  lastUpdatedOn: FilterConfigFields;
  lastUpdatedBy: FilterConfigFields;
  status: FilterConfigFields;
}
export interface RuleTypeData {
  createTimestamp: string;
  createProgramName: string;
  lastUpdateProgramName: string;
  createUserId: string;
  lastUpdateUserId: string;
  ruleTypeCode: string;
  ruleTypeDescription: string;
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateTimestampString: string;
  _links: Links;
}

export interface Links {
  self: Self;
  ruleType: Self;
}

export interface Self {
  href: string;
  templated?: boolean;
}
export interface FilterData {
  filterQuery: FilterVariables;
}
export interface AttributeType {
  label: string;
  value: ValueType;
}
export interface ValueType {
  code: string;
  description: string;
}
export interface ColumnSorting {
  name: string;
  queryKey: string;
}
export interface OperationalPlanTypeObject {
  _embedded: OperationalPlanTypeEmbedded;
  _links: PlanTypeLinks;
  page: Page;
}
export interface OperationalPlanTypeEmbedded {
  operationalPlanTypes: OperationalPlanTypesItem[];
}
export interface OperationalPlanTypesItem {
  operationalPlanTypeCode: string;
  operationalPlanTypeDescription: string;
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateTimestampString: string;
  _links: PlanTypeLinks;
}
export interface PlanTypeLinks {
  self: Self;
  operationalPlanType: OperationalPlanType;
  profile?: Profile;
}
export interface OperationalPlanType {
  href: string;
}
export interface Profile {
  href: string;
}
export interface Page {
  size: number;
  totalElements: number;
  totalPages: number;
  number: number;
}
export interface OperationalPlanSubtypeObject {
  _embedded: OperationalPlanSubtypeEmbedded;
  _links: PlanSubTypeLinks;
  page: Page;
}
export interface OperationalPlanSubtypeEmbedded {
  operationalPlanSubtypes: OperationalPlanSubtypesItem[];
}
export interface OperationalPlanSubtypesItem {
  operationalPlanSubtypeCode: string;
  operationalPlanTypeCode: string;
  operationalPlanSubtypeDescription: string;
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateTimestampString: string;
  _links: PlanSubTypeLinks;
}
export interface PlanSubTypeLinks {
  self: Self;
  operationalPlanSubtype: OperationalPlanSubtype;
  profile?: Profile;
}
export interface OperationalPlanSubtype {
  href: string;
}
export interface StopReasonObject {
  _embedded: StopReasonEmbedded;
  _links: StopReasonLinks;
  page: Page;
}
export interface StopReasonEmbedded {
  stopReasons: StopReasonsItem[];
}
export interface StopReasonsItem {
  createTimestamp: string;
  createProgramName: string;
  lastUpdateProgramName: string;
  createUserId: string;
  lastUpdateUserId: string;
  stopReasonCode: string;
  stopReasonDescription: string;
  effectiveTimestamp: string;
  expirationTimestamp: string;
  lastUpdateTimestampString: string;
  _links: StopReasonLinks;
}
export interface StopReasonLinks {
  self: Self;
  stopReason: StopReason;
  profile?: Profile;
  search?: Search;
}
export interface StopReason {
  href: string;
}
export interface Search {
  href: string;
}
export interface EquipmentClassificationObject {
  _embedded: EquipmentClassificationEmbedded;
  _links: EquipmentClassificationLinks;
}
export interface EquipmentClassificationEmbedded {
  equipmentClassifications: EquipmentClassificationsItem[];
}
export interface EquipmentClassificationsItem {
  '@id': number;
  createTimestamp: string;
  equipmentClassificationCode: string;
  effectiveTimestamp: string;
  equipmentClassificationDescription: string;
  expirationTimestamp: string;
  equipmentFunctionalGroupCode: string;
  _links: EquipmentClassificationLinks;
}
export interface EquipmentClassificationLinks {
  self: Self;
  equipmentClassification?: EquipmentClassification;
  equipmentClassificationTypeAssociations?: EquipmentClassificationTypeAssociations;
  equipments?: Equipments;
  profile?: Profile;
  search?: Search;
}
export interface EquipmentClassification {
  href: string;
}
export interface EquipmentClassificationTypeAssociations {
  href: string;
}
export interface Equipments {
  href: string;
}
export interface EquipmentSubClass {
  _embedded: EquipmentSubClassEmbedded;
  _links: EquipmentSubClassLinks;
}
export interface EquipmentSubClassEmbedded {
  equipmentTypes: EquipmentTypesItem[];
}
export interface EquipmentTypesItem {
  '@id': number;
  createTimestamp: string;
  equipmentTypeCode: string;
  effectiveTimestamp: string;
  equipmentTypeDescription: string;
  expirationTimestamp: string;
  _links: EquipmentSubClassLinks;
}
export interface EquipmentSubClassLinks {
  self: Self;
  equipmentType?: EquipmentType;
  equipments?: Equipments;
  equipmentClassificationTypeAssociations?: EquipmentClassificationTypeAssociations;
}
export interface EquipmentType {
  href: string;
}

export interface ClassificationType {
  operationalPlanClassificationDescription: string;
}


