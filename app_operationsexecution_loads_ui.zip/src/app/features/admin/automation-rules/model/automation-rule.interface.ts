
export interface RuleCriteriaDetails {
    ruleCriteriaCode: string;
    ruleCriteriaDescription: string;
    ruleLogicalOperatorCode: string;
    ruleLogicalOperatorDescription: string;
    ruleCriteriaValues: Array<RuleCriteriaValue>;
    editable: boolean;
    hasNoResult: boolean;
    ruleCriteriaId: number;
    compType: string;
    attributeItems: AttributeType[];
    isCheck: boolean;
}
export interface RuleAttribute {
    ruleDetailId: number;
    ruleCriteriaSetID: number;
    ruleStatus: string;
    ruleSupersedeTypeCode: string;
    ruleCriteriaDetails: Array<RuleCriteriaDetails>;
    ruleParameters: Array<RuleParameters>;
}
export interface RuleParameters {
    ruleParameterId: number;
    ruleParameterCriteriaCode: string;
    ruleParameterTypeDescription?: string;
    ruleParameterTypeName: string;
    ruleParameterTypeCode: string;
    ruleParameterValueTypeCode: string;
    ruleLogicalOperatorCode: string;
    ruleLogicalOperatorDescription: string;
    parameterNumberValue: number;
    parameterCharValue: string;
    parameterDateValue: string;
}
export interface RuleOverviewDetails {
    _index: string;
    _type: string;
    _id: string;
    _version: number;
    found: boolean;
    _source: SourceDetails;
}
export interface SourceDetails {
    RuleDescription: string;
    LastUpdateUserID: string;
    RuleBusinessProcessCode: string;
    RuleBusinessProcessDescription: string;
    RuleCategoryDescription: string;
    RuleTypeCode: string;
    RuleCategoryCode: string;
    RuleCategoryTypeAssociationID: number;
    RuleSupersedeTypeCode: string;
    RuleDetailID: number;
    RuleTypeDescription: string;
    RuleCriteriaSetID: number;
    RuleCode: string;
    RuleName: string;
    LastUpdateProgramName: string;
    ruleCriteriaDetails: Array<RuleCriteriaDetails>;
    RuleParameter: Array<RuleParameters>;
    EffectiveTimestamp: string;
    Status: string;
    ExpirationTimestamp: string;
    LastUpdateTimestamp: string;
}
export interface RuleCriteriaValue {
    ruleCriteriaValue: string;
    ruleCriteriaDetailId: number;
    ruleCriteriaValueDescription: string;
}
export interface AttributeType {
    label: string;
    value: string;
}
export interface ValueType {
    code: string;
    description: string;
}
export interface RuleOperators {
    RuleLogicalOperator: RuleOperatorDetail;
    RuleCriteriaCode: string;
    RuleCriteriaDescription: string;
}
export interface RuleOperatorDetail {
    RuleLogicalOperatorDescription: string;
    RuleLogicalOperatorCode: string;
}
export interface ExistingRule {
    found: boolean;
    _id: number;
    _index: string;
    _type: string;
    _version: number;
    _source: ConfiguredRuleDetails;
}
export interface ConfiguredRuleDetails {
    CreateProgramName: string;
    CreateTimestamp: string;
    CreateUserID: string;
    EffectiveTimestamp: string;
    ExpirationTimestamp: string;
    LastUpdateProgramName: string;
    LastUpdateTimestamp: string;
    LastUpdateUserID: string;
    RuleBusinessProcessCode: string;
    RuleBusinessProcessDescription: string;
    RuleCategoryCode: string;
    RuleCategoryDescription: string;
    RuleCategoryTypeAssociationID: number;
    RuleCode: string;
    RuleComment: string;
    RuleCriteria: Array<RuleOperators>;
    RuleDescription: string;
    RuleDetailID: string;
    RuleInclusionExclusionTypeCode: string;
    RuleName: string;
    RuleParameter: Array<RuleParamArray>;
    RuleSequenceNumber: string;
    RuleTypeCode: string;
    RuleTypeDescription: string;
    SendCustomerNotificationIndicator: string;
}
export interface RuleParamArray {
    ParameterDefaultCharValue: string;
    ParameterDefaultNumberValue: number;
    RuleParameterCriteriaCode: string;
    RuleParameterTypeCode: string;
    RuleParameterTypeDescription: string;
    RuleParameterValueTypeCode: string;
}
export interface BusinessUnit {
    financeBusinessUnitCode: string;
}
export interface OperationalGroup {
    operationalGroupDescription: string;
}
export interface ServiceOfferingFilter {
    serviceOfferingCode: string;
}
export interface Links {
    operationalWorkOrderSubtype?: HrefTemplate;
    oprationalWorkOrderType?: HrefTemplate;
    serviceOfferingBusinessUnitTransitModeAssociation?: HrefTemplate;
    self: Self;
}
export interface HrefTemplate {
    href: string;
    templated?: string;
}
export interface BusinessUnitService {
    serviceOfferingBusinessUnitTransitModeAssociations: Array<ServiceOfferingBusinessUnit>;
}
export interface Self {
    self: Href;
}
export interface Href {
    href: string;
}
export interface TeamsData {
    id?: number;
    createProgramName: string;
    createTimestamp: string;
    createUserId: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateProgramName: string;
    lastUpdateTimestampString: string;
    lastUpdateUserId: string;
    teamID: number;
    teamLeaderPersonID: string;
    teamName: string;
    _links: Self;
}
export interface FinanceBusinessUnit {
    effectiveTimestamp: string;
    expirationTimestamp: string;
    financeBusinessUnitCode: string;
    financeBusinessUnitServiceOfferingAssociationID: string;
    lastUpdateTimestampString: string;
    serviceOfferingCode: string;
}
export interface ServiceOfferingBusinessUnit {
    financeBusinessUnitServiceOfferingAssociation: FinanceBusinessUnit;
    freightShippingType: string;
    lastUpdateTimestampString: string;
    transitMode: string;
    utilizationClassification: string;
    _links: Links;
}
export interface LobResponse {
    aggregations: AggregationData;
}
export interface AggregationData {
    unique: UniqueData;
}
export interface UniqueData {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: Array<LobResponseData>;
}
export interface LobResponseData {
    key: string;
    doc_count: number;
    Level: LevelData;
}
export interface LevelData {
    total: number;
    max_score: number;
    hits: HitsData;
}
export interface HitsData {
    total: number;
    max_score: number;
    hits: Array<OrganizationName>;
}
export interface OrganizationName {
    _index: string;
    _type: string;
    _id: number;
    _score: number;
    _source: SourceData;
}
export interface SourceData {
    OrganizationName: string;
    Level: string;
    OrganizationID: number;
}

export interface RuleCriteriaDetailsItem {
    ruleCriteriaDetailId: string;
    ruleCriteriaCode: string;
    ruleCriteriaDescription: string;
    ruleLogicalOperatorCode: string;
    ruleLogicalOperatorDescription: string;
    ruleCriteriaValue: string;
}

export interface ActiveInactivate {
    ruleCriteriaSetID: number;
    startDate: string;
    endDate: string;
    ruleStatus: string;
}
export interface RuleParameter {
    RuleParameterValueTypeCode: string;
    RuleLogicalOperatorDescription: string;
    RuleParameterTypeCode: string;
    RuleParameterID: number;
    ParameterNumberValue: number;
    ParameterDateValue: string;
    RuleParameterCriteriaCode: string;
    ParameterCharValue: string;
    RuleLogicalOperatorCode: string;
    RuleParameterTypeDescription: string;
}

