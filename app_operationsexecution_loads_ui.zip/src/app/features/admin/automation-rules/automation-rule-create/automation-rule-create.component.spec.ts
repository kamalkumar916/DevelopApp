import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { FormArray } from '@angular/forms';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { AutomationRuleCreateService } from './services/automation-rule-create.service';

import { AutomationRuleCreateComponent } from './automation-rule-create.component';

import { configureTestSuite } from 'ng-bullet';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MultiSelectModule } from 'primeng/multiselect';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { RuleOverviewComponent } from '../rule-overview/rule-overview.component';
import { DirectivesModule } from '../../../../shared/directives/directives.module';
import { AttributeType, ValueType } from '../model/automation-rules.interface';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { AttributeValuePair } from './model/automation-rule-create.interface';
import { AutomationRuleCreateUtils } from './services/automation-rule-create-utils';

const equpiClassData = {
  _embedded: {
    equipmentClassifications: [{
      equipmentClassificationDescription: '',
      equipmentClassificationCode: ''
    }]
  }
};
const stopReasonData = {
  _embedded: {
    stopReasons: [{
      stopReasonDescription: '',
      stopReasonCode: ''
    }]
  }
};
const configuredRuleDetails = {
  CreateProgramName: '',
  CreateTimestamp: '',
  CreateUserID: '',
  EffectiveTimestamp: '',
  ExpirationTimestamp: '',
  LastUpdateProgramName: '',
  LastUpdateTimestamp: '',
  LastUpdateUserID: '',
  RuleBusinessProcessCode: '',
  RuleBusinessProcessDescription: '',
  RuleCategoryCode: '',
  RuleCategoryDescription: '',
  RuleCategoryTypeAssociationID: 1,
  RuleCode: '',
  RuleComment: '',
  RuleCriteria: [{
    RuleCriteriaCode: '',
    RuleCriteriaDescription: '',
    RuleLogicalOperator: {
      RuleLogicalOperatorDescription: '',
      RuleLogicalOperatorCode: ''
    }
  }],
  RuleDescription: '',
  RuleDetailID: '',
  RuleInclusionExclusionTypeCode: '',
  RuleName: '',
  RuleParameter: [{
    ParameterDefaultCharValue: '',
    ParameterDefaultNumberValue: 1,
    RuleParameterCriteriaCode: '',
    RuleParameterTypeCode: '',
    RuleParameterTypeDescription: '',
    RuleParameterValueTypeCode: ''
  }],
  RuleSequenceNumber: '',
  RuleTypeCode: '',
  RuleTypeDescription: '',
  SendCustomerNotificationIndicator: ''
};
const existingRule = {
  found: true,
  _id: null,
  _index: '',
  _type: '',
  _version: 1,
  _source: configuredRuleDetails
};
const equipSubClassData = {
  _embedded: {
    equipmentTypes: [{
      equipmentTypeDescription: '',
      equipmentTypeCode: ''
    }]
  }
};
const populateClassificationTypeValuesData = {
  _embedded: {
    operationalPlanClassificationCodes: [{
      operationalPlanClassificationDescription: '',
      operationalPlanClassificationCode: ''
    }]
  }
};
const ruleCriteriaDetails = [{
  ruleCriteriaDetailId: '',
  ruleCriteriaCode: '',
  ruleCriteriaDescription: '',
  ruleLogicalOperatorCode: '',
  ruleLogicalOperatorDescription: '',
  ruleCriteriaValue: ''
}];
const businessUnit = {
  _embedded: {
    serviceOfferingBusinessUnitTransitModeAssociations: [{
      financeBusinessUnitServiceOfferingAssociation: {
        financeBusinessUnitCode: ''
      }
    }]
  }
};
const operationalGroup = {
  _embedded: {
    operationalGroups: [{
      operationalGroupCode: ''
    }]
  }
};
const elasticModel = {
  timed_out: true,
  took: 1,
  aggregations: '',
  hits: {
    max_score: null,
    total: null,
    hits: [{
      sort: [''],
      _id: '',
      _index: '',
      _score: 1,
      _source: '',
      _type: '',
    }]
  },
  _shards: {
    total: 1,
    successful: 1,
    skipped: 1,
    failed: 1
  }
};
const onsaveinlinedata = [{
  attribute: {
    code: 'a'
  },
  operator: {
    code: 'a'
  },
  value: ['a', 'b'],
  nonEditable: true,
  noResultFlag: true,
  checkFlag: true,
  code: ['jbh']
}];
const saveReqObj = {
  ruleDetailId: 1,
  ruleCriteriaSetID: '',
  orderRuleSupersedeTypeCode: '',
  ruleCriteriaDetails: [{
    ruleCriteriaDetailId: '',
    ruleCriteriaCode: '',
    ruleCriteriaDescription: '',
    ruleLogicalOperatorCode: '',
    ruleLogicalOperatorDescription: '',
    ruleCriteriaValue: ''
  }],
  ruleParameters: [{
    ruleParameterId: '',
    ruleParameterCriteriaCode: '',
    ruleParameterTypeName: '',
    ruleParameterTypeCode: '',
    ruleParameterValueTypeCode: '',
    ruleLogicalOperatorCode: '',
    ruleLogicalOperatorDescription: '',
    parameterNumberValue: 1,
    parameterCharValue: '',
    parameterDateValue: ''
  }]
};
class MockAutomationRuleCreateService {
  constructor() { }
  getRuleOverviewDetails(ruleDetailId) {
    return of(existingRule);
  }
  getEquipmentClassification() {
    return of(equpiClassData);
  }
  getStopReason() {
    return of(stopReasonData);
  }
  getEquipmentSubClass() {
    return of(equipSubClassData);
  }
  getClassificationPlan() {
    return of(populateClassificationTypeValuesData);
  }
  getBusinessUnit() {
    return of(businessUnit);
  }
  getOperationalGroupValues() {
    return of(operationalGroup);
  }
  getCorporateAccountData(ueryParamValue: object) {
    return of(elasticModel);
  }
  getOWOSubtypeData() {
    return throwError(null);
  }
  getOperationalPlanType() {
    return throwError(null);
  }
  getOperationalPlanSubtype() {
    return throwError(null);
  }
  getLineOfBusinessData() {
    return throwError(null);
  }
  getBillToAccountData() {
    return throwError(null);
  }
  getLocationData() {
    return throwError(null);
  }
  getTeamData() {
    return throwError(null);
  }
  getSCACData() {
    return throwError(null);
  }
  getOperationalGroupData() {
    return throwError(null);
  }
  getDriverData() {
    return throwError(null);
  }
  getTruckData() {
    return throwError(null);
  }
  createNewRule() {
    return throwError(null);
  }
}
describe('AutomationRuleCreateComponent', () => {
  let component: AutomationRuleCreateComponent;
  let fixture: ComponentFixture<AutomationRuleCreateComponent>;
  let attrData: AttributeType[];
  let valueType: ValueType;
  let automationRuleCreateService: AutomationRuleCreateService;
  let attributeValueArray: AttributeValuePair[];

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, BreadcrumbModule, CheckboxModule, AutoCompleteModule, DropdownModule, MultiSelectModule, FormsModule,
        ReactiveFormsModule, TableModule, ConfirmDialogModule, DirectivesModule],
      providers: [UserService, AppConfigService, MessageService, ConfirmationService,
        { provide: AutomationRuleCreateService, useClass: MockAutomationRuleCreateService }],
      declarations: [AutomationRuleCreateComponent, RuleOverviewComponent]
    })
      .compileComponents();
  });


  beforeEach(() => {
    fixture = TestBed.createComponent(AutomationRuleCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onInlineRemove non editable mode to be true', () => {
    component.automationRuleCreateModel.nonEditableMode = true;
    component.onInlineRemove();
    expect(component.automationRuleCreateModel.addAttribute).toBe(true);
  });

  it('onInlineRemove non editable mode to be false', () => {
    component.automationRuleCreateModel.nonEditableMode = false;
    component.onInlineRemove();
    expect(component.automationRuleCreateModel.addAttribute).toBe(false);
  });

  it('getResultSettingList have been called', () => {
    const form = new FormArray([]);
    const formArray = component.getResultSettingList(form);
    expect(formArray).toBeDefined([]);
  });

  it('getResultSettingList else case have been called', () => {
    const formArray = component.getResultSettingList(null);
    expect(formArray).toEqual([]);
  });

  it('removeAddedAttribute have been called', () => {
    attrData = [{
      label: 'check label',
      value: {
        code: 'check code',
        description: 'check description'
      }
    }];
    component.removeAddedAttribute(attrData);
    expect(component.automationRuleCreateModel.filterAttributeItems).toBe(attrData);
  });

  it('removeAddedAttribute with attributeValueArray value been called', () => {
    attributeValueArray = [{
      attribute: {
        code: 'check code',
        description: ''
      },
      operator: '',
      value: [''],
      nonEditable: true,
      noResultFlag: true,
      checkFlag: true,
      code: ['']
    }];
    component.automationRuleCreateModel.attributeValueArray = attributeValueArray;
    attrData = [{
      label: 'check label',
      value: {
        code: 'check code',
        description: 'check description'
      }
    }];
    component.removeAddedAttribute(attrData);
    expect(component.automationRuleCreateModel.filterAttributeItems.length).toEqual(0);
  });

  it('setEquipmentClassification have been called', () => {
    automationRuleCreateService = TestBed.get(AutomationRuleCreateService);
    spyOn(automationRuleCreateService, 'getEquipmentClassification').and.returnValue(of(equpiClassData));
    valueType = {
      code: 'check code',
      description: 'check description'
    };
    component.setEquipmentClassification(valueType);
    expect(component.automationRuleCreateModel.selectedAttribute).toBe(valueType);
  });

  it('checkForEquipmentType have been called', () => {
    attributeValueArray = [{
      attribute: {
        code: 'check code',
        description: 'Trailing Equipment Type'
      },
      operator: '',
      value: [''],
      nonEditable: true,
      noResultFlag: true,
      checkFlag: true,
      code: ['code']
    }];
    component.automationRuleCreateModel.attributeValueArray = attributeValueArray;
    valueType = {
      code: 'check code',
      description: 'check description'
    };
    component.checkForEquipmentType(valueType);
    expect(component.automationRuleCreateModel.equipmentClassificationCode).toEqual([['code']]);
  });

  it('setStopReason have been called', () => {
    valueType = {
      code: 'check code',
      description: 'check description'
    };
    component.setStopReason(valueType);
    expect(component.automationRuleCreateModel.selectedAttribute).toEqual(valueType);
  });

  it('getEquipmentSubClass have been called', () => {
    valueType = {
      code: 'check code',
      description: 'check description'
    };
    component.getEquipmentSubClass(valueType);
    expect(component.automationRuleCreateModel.selectedAttribute).toEqual(valueType);
  });

  it('getClassificationCode have been called', () => {
    valueType = {
      code: 'check code',
      description: 'check description'
    };
    component.getClassificationCode(valueType);
    expect(component.automationRuleCreateModel.selectedAttribute).toEqual(valueType);
  });

  it('setAttributeValues case Corporate Account have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Corporate Account' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateCorporateAccountValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateCorporateAccountValues).toHaveBeenCalled();
  });

  it('setAttributeValues case Line of Business have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Line of Business' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateLineOfBusinessValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateLineOfBusinessValues).toHaveBeenCalled();
  });

  it('setAttributeValues case Bill To have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Bill To' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateBillToAccountValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateBillToAccountValues).toHaveBeenCalled();
  });

  it('setAttributeValues case Team have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Team' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateTeamValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateTeamValues).toHaveBeenCalled();
  });

  it('setAttributeValues case Destination Location been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Destination Location' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateLocationValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateLocationValues).toHaveBeenCalled();
  });

  it('setAttributeValues case SCAC Code have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'SCAC Code' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateSCACCodeValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateSCACCodeValues).toHaveBeenCalled();
  });

  it('setAttributeValues case Operational Group of Driver/Truck have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Operational Group of Driver/Truck' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateOperationalGroupValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateOperationalGroupValues).toHaveBeenCalled();
  });

  it('setAttributeValues case Driver have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Driver' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateDriverValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateDriverValues).toHaveBeenCalled();
  });

  it('setAttributeValues case Truck have been calledd', () => {
    const configuredata = [{
      attribute: { description: 'Truck' },
      operator: '',
      value: ''
    }];
    spyOn(component, 'populateTruckValues');
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.setAttributeValues('jbh', 0);
    expect(component.populateTruckValues).toHaveBeenCalled();
  });

  it('onSelectBUField have been called', () => {
    const configuredata = [{
      attribute: { description: 'Driver', code: '' },
      operator: { description: 'Driver', code: '' },
      value: ''
    }];
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.automationRuleCreateModel.ruleCriteriaDetails = ruleCriteriaDetails;
    component.onSelectBUField({}, [''], 'a', 0);
    expect(component.automationRuleCreateModel.attributeValueArray[0].value).toEqual(['']);
  });

  it('onSelectValueField have been called', () => {
    spyOn(AutomationRuleCreateUtils, 'checkIfPresent').and.returnValue(true);
    const configuredata = [{
      attribute: { description: 'Driver', code: '' },
      operator: { description: 'Driver', code: '' },
      value: ''
    }];
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.automationRuleCreateModel.ruleCriteriaDetails = ruleCriteriaDetails;
    component.onSelectValueField({ label: 'a', value: 'a' }, 0);
    expect(component.automationRuleCreateModel.attributeValueArray[0].value).toEqual(['a']);
  });

  it('onRemoveValues have been called', () => {
    component.automationRuleCreateModel.attributeValueArray = [{
      attribute: '',
      operator: '',
      value: [''],
      nonEditable: true,
      noResultFlag: true,
      checkFlag: true,
      code: ['jbh']
    }];
    component.automationRuleCreateModel.ruleCriteriaDetails = ruleCriteriaDetails;
    component.onRemoveValues({ label: 1, value: '' }, 0);
    expect(component.automationRuleCreateModel.attributeValueArray).toBeDefined();
  });

  it('getBusinessUnit have been called', () => {
    component.getBusinessUnit();
    expect(component.automationRuleCreateModel.ruleValues).toBeDefined();
  });

  it('getOperationalGroup have been called', () => {
    component.getOperationalGroup();
    expect(component.automationRuleCreateModel.ruleValues).toBeDefined();
  });

  it('populateCorporateAccountValues have been called', () => {
    spyOn(component, 'setAccountRecordsPopulatedValues');
    component.populateCorporateAccountValues('', 0);
    expect(component.setAccountRecordsPopulatedValues).toHaveBeenCalled();
  });

  it('setAccountRecordsPopulatedValues have been called', () => {
    spyOn(component, 'setPopulatedValues');
    component.setAccountRecordsPopulatedValues(elasticModel, 0);
    expect(component.setPopulatedValues).toHaveBeenCalled();
  });

  it('onSaveInlineData have been called', () => {
    spyOn(component, 'generateRequestObj');
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSaveInlineData();
    expect(component.automationRuleCreateModel.nonEditableMode).toBeTruthy();
  });

  it('onSaveInlineData else case have been called', () => {
    const data = onsaveinlinedata;
    data[0].value = [];
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSaveInlineData();
    expect(component.automationRuleCreateModel.nonEditableMode).toBeFalsy();
  });

  it('generateRequestObj have been called', () => {
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.generateRequestObj();
    expect(component.automationRuleCreateModel.resultObj.length).toEqual(1);
  });

  it('generateRequestObj else case have been called', () => {
    const data = onsaveinlinedata;
    data[0].code = null;
    component.automationRuleCreateModel.attributeValueArray = data;
    component.generateRequestObj();
    expect(component.automationRuleCreateModel.resultObj.length).toEqual(1);
  });

  it('onCreateNewRule else case have been called', () => {
    spyOn(AutomationRuleCreateUtils, 'showMissingInformation');
    component.automationRuleCreateModel.saveRequestObj = saveReqObj;
    component.onCreateNewRule();
    expect(AutomationRuleCreateUtils.showMissingInformation).toHaveBeenCalled();
  });

  it('onCreateNewRule if case have been called', () => {
    spyOn(AutomationRuleCreateUtils, 'showMissingInformation');
    const configuredata = [{
      attribute: { description: 'Destination Location', code: '' },
      operator: { code: '', description: '' },
      value: 'abc'
    }];
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.automationRuleCreateModel.saveRequestObj = saveReqObj;
    component.onCreateNewRule();
    expect(AutomationRuleCreateUtils.showMissingInformation).toHaveBeenCalled();
  });

  it('getBooleanResultSet have been called', () => {
    const data = [{
      ParameterTypeName: null,
      RuleParameterCriteriaCode: null
    }];
    component.getBooleanResultSet(data);
    expect(component.automationRuleCreateModel.booleanData).toEqual(data);
  });

  it('onSelectAttribute case Business Unit  of Driver/Truck have been called', () => {
    spyOn(component, 'getBusinessUnit');
    const data = {
      code: '',
      description: 'Business Unit  of Driver/Truck'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.automationRuleCreateModel.attributeValueArray[0].nonEditable = false;
    component.onSelectAttribute(data, 0);
    expect(component.getBusinessUnit).toHaveBeenCalled();
  });

  it('onSelectAttribute case Equipment Maintenance Status have been called', () => {
    const data = {
      code: '',
      description: 'Equipment Maintenance Status'
    };
    component.automationRuleCreateModel.attributeValueType = '';
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.automationRuleCreateModel.compType).toEqual('');
  });

  it('onSelectAttribute case SCAC Code have been called', () => {
    const data = {
      code: '',
      description: 'SCAC Code'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.automationRuleCreateModel.compType).toEqual('autocomplete');
  });

  it('onSelectAttribute case Operational Group have been called', () => {
    spyOn(component, 'setAttributeValues');
    const data = {
      code: '',
      description: 'Operational Group'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.automationRuleCreateModel.compType).toEqual('autocomplete');
  });

  it('onSelectAttribute case Operational Work Order Sub-Type have been called', () => {
    spyOn(component, 'setAttributeValueSubType');
    const data = {
      code: '',
      description: 'Operational Work Order Sub-Type'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.setAttributeValueSubType).toHaveBeenCalled();
  });

  it('onSelectAttribute case Operational Plan Type have been called', () => {
    spyOn(component, 'setOperationalPlanType');
    const data = {
      code: '',
      description: 'Operational Plan Type'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.setOperationalPlanType).toHaveBeenCalled();
  });

  it('onSelectAttribute case Operational Plan Subtype have been called', () => {
    spyOn(component, 'setOperationalPlanSubType');
    const data = {
      code: '',
      description: 'Operational Plan Subtype'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.setOperationalPlanSubType).toHaveBeenCalled();
  });

  it('onSelectAttribute case Stop Reason have been called', () => {
    spyOn(component, 'setStopReason');
    const data = {
      code: '',
      description: 'Stop Reason'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.setStopReason).toHaveBeenCalled();
  });

  it('onSelectAttribute case Trailing Equipment Type have been called', () => {
    spyOn(component, 'setEquipmentClassification');
    const data = {
      code: '',
      description: 'Trailing Equipment Type'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.setEquipmentClassification).toHaveBeenCalled();
  });

  it('onSelectAttribute case Trailing Equipment Sub Class have been called', () => {
    spyOn(component, 'getEquipmentSubClass');
    const data = {
      code: '',
      description: 'Trailing Equipment Sub Class'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.getEquipmentSubClass).toHaveBeenCalled();
  });

  it('onSelectAttribute case Operational Plan Classification have been called', () => {
    spyOn(component, 'getClassificationCode');
    const data = {
      code: '',
      description: 'Operational Plan Classification'
    };
    component.automationRuleCreateModel.attributeValueArray = onsaveinlinedata;
    component.onSelectAttribute(data, 0);
    expect(component.getClassificationCode).toHaveBeenCalled();
  });

  it('onSelectOperator have been called', () => {
    const data = {
      code: '',
      description: 'Trailing Equipment Sub Class'
    };
    component.onSelectOperator(data, 0);
    expect(component.automationRuleCreateModel.attributeValueArray[0].operator).toEqual(data);
  });

  it('onClickInlineCancel have been called', () => {
    spyOn(component, 'resetFormControl');
    const inlinedata = [{
      attribute: {
        code: 'check code',
        description: ''
      },
      operator: '',
      value: [''],
      nonEditable: false,
      noResultFlag: true,
      checkFlag: true,
      code: ['']
    }];
    const configuredata = [{
      attribute: { description: 'Destination Location', code: '' },
      operator: { code: '', description: '' },
      value: 'abc'
    }];
    component.automationRuleCreateModel.attributeValueArray = inlinedata;
    component.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'].setValue(configuredata);
    component.automationRuleCreateModel.selectedRows = [];
    component.onClickInlineCancel([], inlinedata);
    expect(component.automationRuleCreateModel.removedIndices.length).toEqual(0);
  });
});
