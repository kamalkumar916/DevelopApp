import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormArray, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';
import { takeWhile, finalize } from 'rxjs/operators';

import * as lodashUtils from 'lodash';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { AutomationRuleCreateModel } from './model/automation-rule-create.model';
import {
  AttributeValuePair, RuleCriteriaDetails,
  CreateResponse, RemoveValue, SelectedValue, CreateRequest
} from './model/automation-rule-create.interface';
import { LobResponse, TeamsData, ExistingRule } from '../model/automation-rule.interface';
import { AttributeType, ValueType } from '../model/automation-rules.interface';
import { AutomationRuleCreateService } from './services/automation-rule-create.service';
import { AutomationRuleCreateUtils } from './services/automation-rule-create-utils';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';
import { AutomationRulesUtility } from '../services/automation-rules.utility';
import {
  ScacCodeQuery, EmployeeprofileQuery, OperationalGroupQuery,
  AccountHierarchyQuery, AccountservicesQuery, LocationDetailsQuery, AssetdetailQuery
} from '../../../query/elastic-search.query';
import { ErrorUtils } from '../../../../shared/jbh-app-services/error-utils';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-configure-newrule',
  templateUrl: './automation-rule-create.component.html',
  styleUrls: ['./automation-rule-create.component.scss']
})
export class AutomationRuleCreateComponent implements OnInit, OnDestroy {
  automationRuleCreateModel: AutomationRuleCreateModel;
  resultControl: FormArray;
  constructor(private readonly activatedRoute: ActivatedRoute,
    private readonly automationRuleCreateService: AutomationRuleCreateService,
    private readonly toastMessage: MessageService,
    private readonly fb: FormBuilder, private readonly router: Router,
    private readonly confirmationService: ConfirmationService, private readonly changeDetector: ChangeDetectorRef) {
    this.automationRuleCreateModel = new AutomationRuleCreateModel;
  }
  ngOnInit() {
    this.iterateFormArray();
    this.automationRuleCreateModel.configureNewForm = this.fb.group({
      resultSetting: [''],
      configureRuleArray: this.fb.array([this.initializeFormGroup()]),
    });
    this.getRuleOverview(this.activatedRoute.queryParams['_value'].ruledetailid);
  }
  ngOnDestroy() {
    this.automationRuleCreateModel.subscribeFlag = false;
  }
  initializeFormGroup() {
    return this.fb.group({
      'attribute': ['', Validators.required],
      'operator': ['', Validators.required],
      'value': ['', Validators.required]
    });
  }
  initializeResultSetting(): FormGroup {
    return this.fb.group({
      'resultValue': ['', Validators.required]
    });
  }
  get configureRuleArrayElements() {
    return this.automationRuleCreateModel.configureNewForm.get('configureRuleArray')['controls'];
  }
  checkIsArray(index: number) {
    return lodashUtils.isArray(this.automationRuleCreateModel.attributeValueArray[index].code);
  }
  onRowUnCheck(event) {
    const index = event.attribute.code;
    const removeItem = lodashUtils.indexOf(this.automationRuleCreateModel.removedIndices, index);
    this.automationRuleCreateModel.removedIndices.splice(removeItem, 1);
    this.automationRuleCreateModel.selectedRowLength = this.automationRuleCreateModel.selectedRows.length;
    AutomationRuleCreateUtils.setButtonFlags(false, this.automationRuleCreateModel);
  }
  onRowCheck(rowData) {
    this.automationRuleCreateModel.selectedRowLength = this.automationRuleCreateModel.selectedRows.length;
    AutomationRuleCreateUtils.setButtonFlags(true, this.automationRuleCreateModel);
    const index = rowData.attribute.code;
    let rowChecked = false;
    if (lodashUtils.indexOf(this.automationRuleCreateModel.removedIndices, index) === -1) {
      this.automationRuleCreateModel.removedIndices.push(index);
      rowChecked = true;
    } else {
      this.automationRuleCreateModel.removedIndices.splice(index, 1);
    }
    if (!this.automationRuleCreateModel.nonEditableMode) {
      const indexPos = lodashUtils.findIndex(this.automationRuleCreateModel.attributeValueArray, ['attribute', 'Select Attribute']);
      this.automationRuleCreateModel.attributeValueArray.splice(indexPos, 1);
    }
    this.automationRuleCreateModel.enableRemoveBtn = rowChecked;
    this.automationRuleCreateModel.nonEditableMode = true;
    if (rowChecked) {
      this.automationRuleCreateModel.enableCancelBtn = true;
    } else {
      if (this.automationRuleCreateModel.removedIndices.length > 0) {
        this.automationRuleCreateModel.enableCancelBtn = true;
      } else {
        this.automationRuleCreateModel.enableCancelBtn = false;
      }
    }
  }
  onHeaderCheckboxToggle(event: boolean) {
    this.automationRuleCreateModel.selectedRowLength = this.automationRuleCreateModel.selectedRows.length;
    this.automationRuleCreateModel.headerChekbox = (event);
    AutomationRuleCreateUtils.setButtonFlags(event, this.automationRuleCreateModel);
    const tempArray = this.automationRuleCreateModel.attributeValueArray;
    if (event) {
      for (const item of tempArray) {
        if (lodashUtils.indexOf(this.automationRuleCreateModel.removedIndices, item) === -1) {
          this.automationRuleCreateModel.removedIndices.push(item.attribute.code);
          this.automationRuleCreateModel.enableRemoveBtn = true;
          this.automationRuleCreateModel.nonEditableMode = true;
        }
      }
    } else {
      this.automationRuleCreateModel.removedIndices = [];
      this.automationRuleCreateModel.enableCancelBtn = false;
    }
  }
  getRuleOverview(ruleDetailId: number) {
    this.automationRuleCreateModel.tableLoading = true;
    this.automationRuleCreateService.getRuleOverviewDetails(ruleDetailId).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag),
      finalize(() => {
        this.changeDetector.detectChanges();
      })).subscribe((data: ExistingRule) => {
        if (data) {
          if (data._source && data._source.RuleParameter) {
            this.validateRuleParameterList(data._source.RuleParameter);
          } else {
            this.automationRuleCreateModel.configureNewForm.controls['resultSetting'].clearValidators();
            this.automationRuleCreateModel.configureNewForm.controls['resultSetting'].updateValueAndValidity();
          }
          this.automationRuleCreateModel.ruleOverViewDetails = data._source;
          AutomationRuleCreateUtils.getOverViewDetails(this.automationRuleCreateModel, data);
          this.automationRuleCreateModel.paramItems = this.removeDuplicateOperator(this.automationRuleCreateModel.paramItems, 'label');
          this.changeDetector.detectChanges();
        }
      }, (error) => {
        this.automationRuleCreateModel.ruleOverViewDetails = null;
      });
  }
  validateRuleParameterList(ruleParamData) {
    const ruleParameter = lodashUtils.cloneDeep(ruleParamData);
    const booleanParameter = lodashUtils.filter(ruleParameter, { 'RuleParameterTypeCode': 'Boolean' });
    if (booleanParameter && booleanParameter.length > 0) {
      this.getBooleanResultSet(booleanParameter);
      this.automationRuleCreateModel.isBooleanCriteria = true;
    }
    const sourceData = lodashUtils.cloneDeep(ruleParamData);
    this.automationRuleCreateModel.ruleParamDetails = sourceData.filter(function (element) {
      return element.RuleParameterTypeCode !== null;
    });

    this.automationRuleCreateModel.textResultValue = this.automationRuleCreateModel.ruleParamDetails.filter(function (element) {
      return element.RuleParameterTypeCode.toLowerCase() !== 'boolean';
    });
    if (this.automationRuleCreateModel.textResultValue &&
      this.automationRuleCreateModel.textResultValue.length > 0) {
      this.automationRuleCreateModel.isTextCriteria = true;
      const control = [];
      this.automationRuleCreateModel.textResultValue.forEach((value) => {
        control.push(this.initializeResultSetting());
      });
      this.automationRuleCreateModel.configureNewForm.addControl('txtResultSetting', this.fb.array(control));
      this.resultControl = this.automationRuleCreateModel.configureNewForm.get('txtResultSetting')['controls'];
    }
    if (this.automationRuleCreateModel.ruleParamDetails.length > 0) {
      this.automationRuleCreateModel.showResultSetting = true;
    }
    if (this.automationRuleCreateModel.isBooleanCriteria) {
      this.automationRuleCreateModel.configureNewForm.controls['resultSetting'].setValidators([Validators.required]);
      this.automationRuleCreateModel.configureNewForm.controls['resultSetting'].updateValueAndValidity();
    }
  }
  getResultSettingList(form: FormArray) {
    if (form) {
      return form;
    }
    return [];
  }
  getResultSettingLabel(index: number) {
    return this.automationRuleCreateModel.textResultValue[index].RuleParameterTypeDescription;
  }
  removeDuplicateOperator(params: Array<AttributeType>, property: string): Array<AttributeType> {
    return params.filter((obj, value, arr) => {
      if (obj.label) {
        return arr.map(mapObj => mapObj[property]).indexOf(obj[property]) === value;
      }
    });
  }
  addNewRow(arrayIndex: number) {
    this.automationRuleCreateModel.valueItems = [];
    this.iterateFormArray();
    this.automationRuleCreateModel.save = true;
    this.automationRuleCreateModel.cancel = true;
    this.automationRuleCreateModel.addAttribute = false;
    this.automationRuleCreateModel.nonEditableMode = false;
    this.automationRuleCreateModel.enableCancelBtn = true;
    this.automationRuleCreateModel.removeTable = false;
    const control: FormArray = this.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'] as FormArray;
    control.insert(0, this.initializeFormGroup());
    const actualData = AutomationRuleCreateUtils.populateAttributes(this.automationRuleCreateModel.dataInfo);
    this.removeAddedAttribute(actualData);
  }
  resetFormControl(index) {
    const control = this.configureRuleArrayElements[index];
    control.controls.attribute.reset();
    control.controls.operator.reset();
    control.controls.value.reset();
  }
  removeAddedAttribute(actualData: AttributeType[]) {
    for (const item of this.automationRuleCreateModel.attributeValueArray) {
      actualData.forEach((data, i) => {
        const filterAttributeItems = data;
        if (filterAttributeItems && filterAttributeItems.value.code && item.attribute &&
          filterAttributeItems.value.code === item.attribute.code) {
          actualData.splice(i, 1);
          this.automationRuleCreateModel.filterAttributeItems = actualData;
          this.changeDetector.detectChanges();
        }
      });
    }
    if (this.automationRuleCreateModel.attributeValueArray.length <= 1) {
      this.automationRuleCreateModel.filterAttributeItems = actualData;
    }
  }
  onClickInlineCancel(requestObj: Array<RuleCriteriaDetails>, inlineData: Array<AttributeValuePair>) {
    this.automationRuleCreateModel.valueItems = [];
    const controls = this.automationRuleCreateModel.configureNewForm.controls['configureRuleArray'] as FormArray;
    if (lodashUtils.isEmpty(this.automationRuleCreateModel.selectedRows)) {
      this.automationRuleCreateModel.cancel = true;
      this.automationRuleCreateModel.addAttribute = false;
      this.checkInitialArrayValue(inlineData);
    } else {
      this.automationRuleCreateModel.cancel = false;
      this.automationRuleCreateModel.save = false;
      this.automationRuleCreateModel.remove = false;
      this.automationRuleCreateModel.addAttribute = true;
    }
    this.automationRuleCreateModel.selectedRows = [];
    if (this.automationRuleCreateModel.headerChekbox && !this.automationRuleCreateModel.headerChekbox) {
      this.automationRuleCreateModel.selectedRows = [];
      AutomationRuleCreateUtils.enableInlineCancel(this.automationRuleCreateModel);
    }
    if (inlineData.length === 1 && requestObj.length === 0) {
      AutomationRuleCreateUtils.enableInlineCancel(this.automationRuleCreateModel);
      this.resetFormControl(inlineData.length - 1);
      controls.removeAt(0);
      lodashUtils.pullAt(this.automationRuleCreateModel.attributeValueArray, 0);
      this.automationRuleCreateModel.removeTable = true;
      this.automationRuleCreateModel.attributeValueArray = [];
      this.automationRuleCreateModel.enableCancelBtn = false;
      this.automationRuleCreateModel.nonEditableMode = true;
    }
    if (this.automationRuleCreateModel.attributeValueArray[0] &&
      this.automationRuleCreateModel.attributeValueArray[0].nonEditable === false) {
      this.resetFormControl(0);
      controls.removeAt(0);
      lodashUtils.pullAt(this.automationRuleCreateModel.attributeValueArray, 0);
      this.automationRuleCreateModel.cancel = false;
      this.automationRuleCreateModel.save = false;
      this.automationRuleCreateModel.remove = false;
      this.automationRuleCreateModel.addAttribute = true;
    }
    this.automationRuleCreateModel.removedIndices = [];
  }
  checkInitialArrayValue(inlineData) {
    if (inlineData.length === 1) {
      this.automationRuleCreateModel.removeTable = true;
    }
  }
  iterateFormArray() {
    this.automationRuleCreateModel.attributeValueArray.unshift({
      attribute: { description: 'Select Attribute', code: '' },
      operator: { description: 'Select Operator', code: '' },
      value: [],
      nonEditable: false,
      noResultFlag: false,
      checkFlag: false,
      code: []
    });
  }
  onSelectAttribute(selectedAttribute: ValueType, index: number) {
    this.automationRuleCreateModel.selectedAttributeValue = selectedAttribute;
    this.automationRuleCreateModel.attributeValueArray[index].attribute = selectedAttribute;
    if (this.automationRuleCreateModel.attributeValueArray[index].nonEditable === false) {
      this.automationRuleCreateModel.attributeValueArray[index].code = [];
      this.automationRuleCreateModel.attributeValueArray[index].value = [];
    }
    const controls = this.configureRuleArrayElements[index];
    controls.controls.operator.reset();
    controls.controls.value.reset();
    switch (selectedAttribute.description) {
      case 'Business Unit  of Driver/Truck':
      case 'Business Unit':
      case 'Business Unit of Load':
        this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
        this.getBusinessUnit();
        break;
      case 'Equipment Maintenance Status':
        this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
        this.automationRuleCreateModel.ruleValues = this.automationRuleCreateModel.equipmentStatusRuleValue;
        break;
      case 'SCAC Code':
      case 'Team':
      case 'Bill To':
      case 'Line of Business':
      case 'Origin Location':
      case 'Destination Location':
      case 'Stop Location':
      case 'Location':
      case 'Corporate Account':
        this.automationRuleCreateModel.compType = 'autocomplete';
        break;
      case 'Operational Group':
      case 'Operational Group of Driver/Truck':
      case 'Truck':
      case 'Driver':
        this.automationRuleCreateModel.compType = 'autocomplete';
        this.setAttributeValues(this.automationRuleCreateModel.typedText, this.automationRuleCreateModel.rowIndex);
        break;
      case 'Operational Work Order Sub-Type':
        this.setAttributeValueSubType(selectedAttribute);
        break;
      case 'Operational Plan Type':
        this.setOperationalPlanType(selectedAttribute);
        break;
      case 'Operational Plan Subtype':
        this.setOperationalPlanSubType(selectedAttribute);
        break;
      case 'Stop Reason':
        this.setStopReason(selectedAttribute);
        break;
      case 'Trailing Equipment Type':
        this.setEquipmentClassification(selectedAttribute);
        break;
      case 'Trailing Equipment Sub Class':
        this.getEquipmentSubClass(selectedAttribute);
        break;
      case 'Operational Plan Classification':
        this.getClassificationCode(selectedAttribute);
        break;
    }
  }
  onSelectOperator(selectedOperator: ValueType, rowIndex: number) {
    this.automationRuleCreateModel.attributeValueArray[rowIndex].operator = selectedOperator;
  }
  setAttributeValueSubType(selectedAttribute: ValueType) {
    this.automationRuleCreateModel.selectedAttribute = selectedAttribute;
    this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
    this.automationRuleCreateService.getOWOSubtypeData().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: any) => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRulesUtility.populateSubTypeValues(data);
        }
      });
  }
  setOperationalPlanType(selectedAttribute: ValueType) {
    this.automationRuleCreateModel.selectedAttribute = selectedAttribute;
    this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
    this.automationRuleCreateService.getOperationalPlanType().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: any) => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRulesUtility.getOperationalPlanType(data);
        }
      });
  }
  setOperationalPlanSubType(selectedAttribute: ValueType) {
    this.automationRuleCreateModel.selectedAttribute = selectedAttribute;
    this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
    this.automationRuleCreateService.getOperationalPlanSubtype().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: any) => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRulesUtility.getOperationalPlanSubType(data);
        }
      });
  }
  setEquipmentClassification(selectedAttribute: ValueType) {
    this.automationRuleCreateModel.selectedAttribute = selectedAttribute;
    this.automationRuleCreateModel.compType = 'singleselect';
    this.automationRuleCreateService.getEquipmentClassification().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: any) => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRulesUtility.getEquipmentClassification(data);
        }
      });
  }
  checkForEquipmentType(selectedAttribute: ValueType) {
    let attributeItem = this.automationRuleCreateModel.attributeValueArray.map((attributeArray) => {
      if (attributeArray.attribute.description === 'Trailing Equipment Type') {
        return attributeArray.code;
      }
    });
    attributeItem = lodashUtils.remove(attributeItem, undefined);
    this.automationRuleCreateModel.equipmentClassificationCode = attributeItem ? attributeItem : '';
  }
  setStopReason(selectedAttribute: ValueType) {
    this.automationRuleCreateModel.selectedAttribute = selectedAttribute;
    this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
    this.automationRuleCreateService.getStopReason().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: any) => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRulesUtility.getStopReason(data);
        }
      });
  }
  getEquipmentSubClass(selectedAttribute: ValueType) {
    this.automationRuleCreateModel.selectedAttribute = selectedAttribute;
    this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
    this.automationRuleCreateService.getEquipmentSubClass().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: any) => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRulesUtility.getEquipmentSubClass(data);
        }
      });
  }
  getClassificationCode(selectedAttribute: ValueType) {
    this.automationRuleCreateModel.selectedAttribute = selectedAttribute;
    this.automationRuleCreateModel.compType = this.automationRuleCreateModel.attributeValueType;
    this.automationRuleCreateService.getClassificationPlan().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: any) => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRulesUtility.populateClassificationTypeValues(data);
        }
      });
  }
  setAttributeValues(typedText: string, rowIndex: number) {
    const typeaheadInputText = `${typedText.replace(/[,!?^~=\/{}&&||<>()+*-]/g, ' ')}${'*'}`;
    const attribute = this.configureRuleArrayElements[rowIndex].controls.attribute.value;
    if (typeaheadInputText.length > 1) {
      switch (attribute.description) {
        case 'Corporate Account':
          this.populateCorporateAccountValues(typeaheadInputText, rowIndex);
          break;
        case 'Line of Business':
          this.populateLineOfBusinessValues(typeaheadInputText, rowIndex);
          break;
        case 'Bill To':
          this.populateBillToAccountValues(typeaheadInputText, rowIndex);
          break;
        case 'Team':
          this.populateTeamValues(typeaheadInputText, rowIndex);
          break;
        case 'Destination Location':
        case 'Stop Location':
        case 'Origin Location':
        case 'Location':
          this.populateLocationValues(typeaheadInputText, rowIndex);
          break;
        case 'SCAC Code':
          this.populateSCACCodeValues(typeaheadInputText, rowIndex);
          break;
        case 'Operational Group of Driver/Truck':
        case 'Operational Group':
          this.populateOperationalGroupValues(typeaheadInputText, rowIndex);
          break;
        case 'Driver':
          this.populateDriverValues(typeaheadInputText, rowIndex);
          break;
        case 'Truck':
          this.populateTruckValues(typeaheadInputText, rowIndex);
          break;
      }
    }
  }
  onSelectBUField(event, selectedBuValue: Array<string>, itemValue: string, rowIndex: number) {
    let ifPush = true;
    const controls = this.configureRuleArrayElements[rowIndex].controls;
    this.automationRuleCreateModel.attributeValueArray[rowIndex].value = [];
    this.automationRuleCreateModel.attributeValueArray[rowIndex].code = [];
    this.automationRuleCreateModel.attributeValueArray[rowIndex].value = (selectedBuValue);
    this.automationRuleCreateModel.attributeValueArray[rowIndex].code = (selectedBuValue);
    if (this.automationRuleCreateModel.ruleCriteriaDetails.length > 0) {
      ifPush = AutomationRuleCreateUtils.checkIfPresent(this.automationRuleCreateModel.ruleCriteriaDetails, itemValue);
    }
    if (selectedBuValue && ifPush) {
      this.automationRuleCreateModel.ruleCriteriaDetails.push({
        'ruleCriteriaDetailId': null,
        'ruleCriteriaCode': controls.attribute.value.code,
        'ruleCriteriaDescription': controls.attribute.value.description,
        'ruleLogicalOperatorCode': controls.operator.value.code,
        'ruleLogicalOperatorDescription': controls.operator.value.description,
        'ruleCriteriaValue': itemValue
      });
    }
  }
  onSelectValueField(selectedValue: SelectedValue, rowIndex: number) {
    let ifPush = true;
    const controls = this.configureRuleArrayElements[rowIndex].controls;
    if (this.automationRuleCreateModel.ruleCriteriaDetails.length > 0) {
      ifPush = AutomationRuleCreateUtils.checkIfPresent(this.automationRuleCreateModel.ruleCriteriaDetails, selectedValue.value);
    }
    if (ifPush) {
      this.automationRuleCreateModel.attributeValueArray[rowIndex].value.push(selectedValue.label);
      this.automationRuleCreateModel.attributeValueArray[rowIndex].code.push(selectedValue.value);
      this.automationRuleCreateModel.ruleCriteriaDetails.push({
        'ruleCriteriaDetailId': null,
        'ruleCriteriaCode': controls.attribute.value.code,
        'ruleCriteriaDescription': controls.attribute.value.description,
        'ruleLogicalOperatorCode': controls.operator.value.code,
        'ruleLogicalOperatorDescription': controls.operator.value.description,
        'ruleCriteriaValue': selectedValue.value
      });
    }
  }
  onRemoveValues(removedValue: RemoveValue, index: number) {
    const indexNum = lodashUtils.indexOf(this.automationRuleCreateModel.attributeValueArray[index].code, removedValue.value);
    this.automationRuleCreateModel.attributeValueArray[index].code.splice(indexNum, 1);
    this.automationRuleCreateModel.attributeValueArray[index].value.splice(indexNum, 1);
    this.automationRuleCreateModel.ruleCriteriaDetails.forEach((ruleCriteriaDetails, i) => {
      if (ruleCriteriaDetails.ruleCriteriaValue === removedValue.value) {
        this.automationRuleCreateModel.ruleCriteriaDetails.splice(i, 1);
      }
    });
  }
  getBusinessUnit() {
    this.automationRuleCreateService.getBusinessUnit().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe(data => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRuleCreateUtils.populateValues(data);
        }
      });
  }
  getOperationalGroup() {
    this.automationRuleCreateService.getOperationalGroupValues().pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe(data => {
        if (data) {
          this.automationRuleCreateModel.ruleValues = AutomationRuleCreateUtils.populateOPGroupValues(data);
        }
      });
  }
  populateCorporateAccountValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getCorporateAccountData(AccountHierarchyQuery.getCorporateAccountQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: ElasticResponseModel) =>
        this.setAccountRecordsPopulatedValues(data, rowIndex));
  }
  setAccountRecordsPopulatedValues(data: ElasticResponseModel, rowIndex: number) {
    if (data) {
      this.setPopulatedValues(AutomationRulesUtility.getCorporateAccountRecords(data), rowIndex);
    }
  }
  populateLineOfBusinessValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getLineOfBusinessData(AccountHierarchyQuery.getLineofBusinessQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: LobResponse) => {
        if (data && data.aggregations.unique.buckets) {
          this.setPopulatedValues(data.aggregations.unique.buckets.map((item) => {
            return AutomationRulesUtility.getLobRecords(item.Level.hits.hits);
          }), rowIndex);
        }
      });
  }
  populateBillToAccountValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getBillToAccountData(AccountservicesQuery.getBilToAccountQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: ElasticResponseModel) =>
        this.setPopulatedValues(AutomationRulesUtility.getBillToData(data), rowIndex));
  }
  populateLocationValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getLocationData(LocationDetailsQuery.getOriginDestinationQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getLocationRecords(data), rowIndex);
        }
      });
  }
  populateTeamValues(typeaheadInputText: string, rowIndex: number) {
    const typeaheadInput = `${typeaheadInputText.replace(/[,!?^~=\/{}&&||<>()+*-]/g, ' ')}`;
    this.automationRuleCreateService.getTeamData(typeaheadInput).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: TeamsData) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getTeamRecords(data), rowIndex);
        }
      });
  }
  populateSCACCodeValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getSCACData(ScacCodeQuery.getSCACCodeQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getScacRecords(data), rowIndex);
        }
      });
  }

  populateOperationalGroupValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getOperationalGroupData(OperationalGroupQuery.getOperationalGroupQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRuleCreateUtils.getOperationalGroupRecords(data), rowIndex);
        }
      });
  }

  populateDriverValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getDriverData(EmployeeprofileQuery.getDriverQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getDriverRecords(data), rowIndex);
        }
      });
  }

  populateTruckValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleCreateService.getTruckData(AssetdetailQuery.getTruckQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getTruckRecords(data), rowIndex);
        }
      });
  }

  setPopulatedValues(valueItems: Array<AttributeType>, rowIndex: number) {
    this.automationRuleCreateModel.valueItemsComplete = valueItems;
    this.automationRuleCreateModel.attributeValueArray[rowIndex].noResultFlag =
      this.automationRuleCreateModel.valueItemsComplete.length === 0;
  }

  onSaveInlineData() {
    this.automationRuleCreateModel.addAttribute = true;
    for (const item of this.automationRuleCreateModel.attributeValueArray) {
      if (!lodashUtils.isEmpty(item.attribute.code) &&
        !lodashUtils.isEmpty(item.operator.code) &&
        item.value.length > 0) {
        this.automationRuleCreateModel.nonEditableMode = true;
        item.nonEditable = true;
        this.automationRuleCreateModel.removedIndices = [];
        item.noResultFlag = false;
        this.automationRuleCreateModel.save = false;
        this.automationRuleCreateModel.cancel = false;
        this.generateRequestObj();
        this.automationRuleCreateModel.configureNewForm.controls.configureRuleArray.setErrors(null);
      } else {
        FormValidationUtils.validateAllFormFields(this.automationRuleCreateModel.configureNewForm);
        AutomationRuleCreateUtils.showMissingInformation(this.toastMessage);
        this.automationRuleCreateModel.nonEditableMode = false;
        this.automationRuleCreateModel.save = true;
        this.automationRuleCreateModel.cancel = true;
        this.automationRuleCreateModel.addAttribute = false;
        break;
      }
    }
  }
  generateRequestObj() {
    this.automationRuleCreateModel.resultObj = [];
    for (const item of this.automationRuleCreateModel.attributeValueArray) {
      if (item.code && lodashUtils.isArray(item.code)) {
        for (const itemCode of item.code) {
          this.automationRuleCreateModel.resultObj.push(this.frameResultObject(item, itemCode));
        }
      } else {
        this.automationRuleCreateModel.resultObj.push(this.frameResultObject(item));
      }
    }
  }
  frameResultObject(item, itemCode?) {
    return {
      'ruleCriteriaDetailId': null,
      'ruleCriteriaCode': item.attribute.code,
      'ruleCriteriaDescription': item.attribute.description,
      'ruleLogicalOperatorCode': item.operator.code,
      'ruleLogicalOperatorDescription': item.operator.description,
      'ruleCriteriaValue': itemCode ? itemCode : item.code
    };
  }
  onInlineRemove() {
    if (this.automationRuleCreateModel.nonEditableMode) {
      this.automationRuleCreateModel.addAttribute = true;
    } else {
      this.automationRuleCreateModel.addAttribute = false;
    }
    AutomationRuleCreateUtils.inlineRemove(this.automationRuleCreateModel);
    this.automationRuleCreateModel.removedIndices = [];
  }
  onCancelConfigure() {
    this.router.navigate(['/admin/automationrules']);
  }
  onCreateNewRule() {
    const requestObj = this.automationRuleCreateModel.saveRequestObj;
    FormValidationUtils.validateAllFormFields(this.automationRuleCreateModel.configureNewForm);
    if (this.automationRuleCreateModel.configureNewForm.valid) {
      AutomationRuleCreateUtils.validateResultSetting(this.automationRuleCreateModel, requestObj);
      requestObj.ruleDetailId = parseInt(this.activatedRoute.queryParams['_value'].ruledetailid, 10);
      requestObj.ruleCriteriaSetID = null;
      requestObj.orderRuleSupersedeTypeCode = null;
      requestObj.ruleCriteriaDetails = this.automationRuleCreateModel.resultObj;
      if (this.automationRuleCreateModel.resultObj.length === 0) {
        AutomationRuleCreateUtils.showMissingInformation(this.toastMessage);
      } else {
        this.createSuccess(requestObj);
      }
    } else {
      AutomationRuleCreateUtils.showMissingInformation(this.toastMessage);
    }
  }
  createSuccess(requestObj: CreateRequest) {
    const severityMessage = 'error';
    this.automationRuleCreateService.createNewRule(requestObj).pipe(
      takeWhile(() => this.automationRuleCreateModel.subscribeFlag)).subscribe((data: CreateResponse) => {
        if (data) {
          this.router.navigate(['/admin/automationrules/viewconfigurerule'],
            {
              queryParams: {
                ruleCriteriaSetId: data.ruleCriteriaSetId,
                ruleDetailId: this.activatedRoute.queryParams['_value'].ruledetailid
              }
            });
        }
      }, (error) => {
        if (error && error['status'] === 409) {
          if (error.error['inactiveRuleCriteriaSetId']) {
            this.confirmationService.confirm({
              message: 'An Inactive duplicate rule exists with the matching configuration. Do you wish to view the Inactive rule',
              header: 'Confirmation',
              key: 'DuplicateRule',
              accept: (): void => {
                this.router.navigate(['/admin/automationrules/viewconfigurerule'],
                  {
                    queryParams: {
                      ruleCriteriaSetId: error.error['inactiveRuleCriteriaSetId'],
                    }
                  });
              },
              reject: (): void => {
                AutomationRuleCreateUtils.showDuplicateMessage(this.toastMessage, severityMessage);
              }
            });
          } else {
            AutomationRuleCreateUtils.showDuplicateMessage(this.toastMessage, severityMessage);
          }
        } else if (error && error['status'] === 500) {
          this.toastMessage.add({
            severity: 'error',
            summary: 'Server Error',
            detail: ErrorUtils.getErrorMessage(error['status'])
          });
        }
      });
  }
  getBooleanResultSet(booleanParameter: any) {
    if (booleanParameter) {
      this.automationRuleCreateModel.booleanData = booleanParameter;
      this.automationRuleCreateModel.booleanResultSets = booleanParameter.map((criteriaSets: any) => {
        return {
          label: criteriaSets.ParameterTypeName,
          value: criteriaSets.RuleParameterCriteriaCode
        };
      });
    }
  }
  getresultSettingControls() {
    return this.automationRuleCreateModel.configureNewForm.controls['txtResultSetting'];
  }
}
