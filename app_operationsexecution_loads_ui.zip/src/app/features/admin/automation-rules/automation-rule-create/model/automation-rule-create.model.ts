import { FormGroup } from '@angular/forms';

import {
    AttributeValuePair, CreateRequest, LocationDetails, RuleCriteriaDetails, RuleParam
} from './automation-rule-create.interface';
import { ExistingRule, ConfiguredRuleDetails, RuleParamArray } from '../../model/automation-rule.interface';
import { Breadcrumb } from '../../../../model/breadcrumb.interface';
import { AttributeType, ValueType } from '../../model/automation-rules.interface';
import { SelectItem } from 'primeng/api';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class AutomationRuleCreateModel {
    breadcrumb: Breadcrumb[];
    dataInfo: ExistingRule;
    attributeItems: AttributeType[];
    attributeArrayValues: AttributeType[];
    filterAttributeItems: AttributeType[];
    paramItems: AttributeType[];
    valueItems: AttributeType[];
    valueItemsComplete: AttributeType[];
    selectedAttributeValue: ValueType;
    enableRemoveBtn: boolean;
    subscribeFlag: boolean;
    configureNewForm: FormGroup;
    attributeValueArray: AttributeValuePair[];
    nonEditableMode: boolean;
    selectedAttribute: ValueType;
    selectedOperator: string;
    selectedValue: string;
    compType: string;
    typedText: string;
    rowIndex: number;
    locationDetails: LocationDetails[];
    ruleCriteriaDetails: RuleCriteriaDetails[];
    resultObj: RuleCriteriaDetails[];
    resultSetting: string;
    removeTable: boolean;
    saveRequestObj: CreateRequest;
    ruleParameterCriteriaCode: string;
    ruleparams: RuleParam;
    removedIndices: string[];
    noResultFlag: boolean;
    paramReq: RuleParam;
    inlineData: string[];
    ruleOverViewDetails: ConfiguredRuleDetails;
    ruleStatusFlag: boolean;
    businessFlag: boolean;
    ruleValues: SelectItem[];
    logicalOperatorCode: string;
    logicalOperatorDescription: string;
    tableLoading: boolean;
    enableCancelBtn: boolean;
    headerChekbox: boolean;
    save: boolean;
    cancel: boolean;
    remove: boolean;
    addAttribute: boolean;
    selectedRows: AttributeValuePair[];
    selectedRowLength: number;
    showResultSetting: boolean;
    ruleParamDetails: RuleParamArray[];
    inputNumberPatternRegEx: RegExp;
    attributeValueType: string;
    equipmentStatusRuleValue: SelectItem[];
    equipmentClassificationCode: any;
    isBooleanCriteria: boolean;
    isTextCriteria: boolean;
    textResultValue: any;
    booleanResultSets: SelectItem[];
    ruleArray: any;
    booleanData: any;
    appConfig;
    createButton: SecureModel;
    constructor() {
        this.breadcrumb = [
            { label: 'Administration', routerLink: [''] },
            { label: 'Automation Rules', routerLink: ['/admin/automationrules'] },
            { label: 'Configure New Rule' }];
        this.attributeValueArray = [];
        this.attributeItems = [];
        this.paramItems = [];
        this.valueItems = [];
        this.enableRemoveBtn = false;
        this.subscribeFlag = true;
        this.nonEditableMode = false;
        this.compType = 'multiselect';
        this.ruleCriteriaDetails = [];
        this.removeTable = false;
        this.saveRequestObj = {
            ruleDetailId: null,
            ruleCriteriaSetID: null,
            orderRuleSupersedeTypeCode: '',
            ruleCriteriaDetails: [],
            ruleParameters: []
        };
        this.removedIndices = [];
        this.noResultFlag = false;
        this.inlineData = [];
        this.ruleStatusFlag = false;
        this.businessFlag = false;
        this.logicalOperatorCode = 'Equal';
        this.logicalOperatorDescription = 'Equals';
        this.tableLoading = false;
        this.enableCancelBtn = true;
        this.valueItemsComplete = [];
        this.headerChekbox = true;
        this.addAttribute = false;
        this.save = true;
        this.cancel = true;
        this.remove = false;
        this.resultObj = [];
        this.showResultSetting = false;
        this.inputNumberPatternRegEx = /^[0-9.]*$/;
        this.attributeValueType = 'multiselect';
        this.equipmentStatusRuleValue = [{
            label: 'Operational',
            value: 'Operational'
        }];
        this.isBooleanCriteria = false;
        this.isTextCriteria = false;
        this.appConfig = AppConfig.getConfig();
        this.createButton = { url: this.appConfig.api.automationRules.createRule, operation: 'C' };
    }
}
