import { ValueType } from '../../model/automation-rule.interface';

export interface AttributeValuePair {
    attribute: any;
    operator: any;
    value: Array<string>;
    nonEditable: boolean;
    noResultFlag: boolean;
    checkFlag: boolean;
    code: Array<string>;
}
export interface LocationDetails {
    locationName: string;
    locationCode: string;
    locationID: number;
    address: string;
}
export interface CreateRequest {
    ruleDetailId: number;
    ruleCriteriaSetID: string;
    orderRuleSupersedeTypeCode: string;
    ruleCriteriaDetails: Array<RuleCriteriaDetails>;
    ruleParameters: Array<RuleParam>;
}
export interface RuleCriteriaDetails {
    ruleCriteriaDetailId: string;
    ruleCriteriaCode: string;
    ruleCriteriaDescription: string;
    ruleLogicalOperatorCode: string;
    ruleLogicalOperatorDescription: string;
    ruleCriteriaValue: any;
}
export interface RuleParam {
    ruleParameterId: string;
    ruleParameterCriteriaCode: string;
    ruleParameterTypeName: string;
    ruleParameterTypeCode: string;
    ruleParameterValueTypeCode: string;
    ruleLogicalOperatorCode: string;
    ruleLogicalOperatorDescription: string;
    parameterNumberValue: number;
    parameterCharValue: string;
    parameterDateValue: string;
}
export interface CreateResponse {
    ruleDetailId: string;
    ruleCriteriaSetId: number;
    ruleStatus: string;
    ruleSupersedeTypeCode: string;
    ruleCriteriaDetails: string;
    ruleParameters: string;
}
export interface RemoveValue {
    label: number;
    value: string;
}
export interface SelectedValue {
    value: string;
    label: string;
}
export interface BooleanResultSet {
    RuleParameterCriteriaCode: string;
    RuleParameterCriteriaDescription?: string;
}
