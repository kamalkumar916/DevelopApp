import { FormArray, FormControl } from '@angular/forms';
import * as lodashUtils from 'lodash';
import { SelectItem } from 'primeng/api';

import { CreateRequest, RuleParam } from '../model/automation-rule-create.interface';
import { AutomationRuleCreateModel } from '../model/automation-rule-create.model';
import { ExistingRule, RuleOperators } from '../../model/automation-rule.interface';
import { AttributeType } from '../../model/automation-rules.interface';

export class AutomationRuleCreateUtils {
    static populateAttributes(dataSource: ExistingRule): Array<AttributeType> {
        return dataSource._source.RuleCriteria.map((Items: RuleOperators) => {
            return {
                label: Items.RuleCriteriaDescription,
                value: { code: Items.RuleCriteriaCode, description: Items.RuleCriteriaDescription },
            };
        });
    }
    static populateParameters(dataSource): Array<AttributeType> {
        return dataSource._source.RuleCriteria.map((Items: RuleOperators) => {
            return {
                label: Items.RuleLogicalOperator.RuleLogicalOperatorDescription,
                value: {
                    code: Items.RuleLogicalOperator.RuleLogicalOperatorCode,
                    description: Items.RuleLogicalOperator.RuleLogicalOperatorDescription
                }
            };
        });
    }
    static populateValues(dataSource): Array<AttributeType> {
        return dataSource._embedded.serviceOfferingBusinessUnitTransitModeAssociations.map((Items) => {
            return {
                'label': Items.financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode,
                'value': Items.financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode
            };
        });
    }
    static populateOPGroupValues(dataSource): Array<AttributeType> {
        return dataSource._embedded.operationalGroups.map((Items) => {
            return {
                'label': Items.operationalGroupCode,
                'value': Items.operationalGroupCode
            };
        });
    }
    static getRuleParamDetails(dataSource): any {
        let textRuleValue;
        let resultSetValue;
        let paramDetails = [];
        if (dataSource.isTextCriteria) {
            textRuleValue = dataSource.configureNewForm.controls.txtResultSetting.controls;
        }
        if (dataSource.isBooleanCriteria) {
            resultSetValue = dataSource.configureNewForm.controls.resultSetting.value;
        }
        if (resultSetValue && Array.isArray(resultSetValue)) {
            paramDetails = dataSource.configureNewForm.controls.resultSetting.value.map((paramValue) => {
                const ruleIndex = lodashUtils.findIndex(dataSource.ruleParamDetails, { 'RuleParameterCriteriaCode': paramValue });
                return this.getRuleDetails(dataSource, ruleIndex, 'Y');
            });
        }
        if (textRuleValue && textRuleValue.length > 0) {
            let i = 0;
            textRuleValue.forEach((ruleValue) => {
                const value = ruleValue.controls.resultValue.value;
                const ruleIndex = lodashUtils.findIndex(dataSource.ruleParamDetails, dataSource.textResultValue[i]);
                paramDetails.push(this.getRuleDetails(dataSource, ruleIndex, value));
                i++;
            });
        }
        return paramDetails;
    }
    static getRuleDetails(dataSource, index, paramValue) {
        return {
            ruleParameterId: null,
            ruleParameterCriteriaCode: dataSource.ruleParamDetails[index].RuleParameterCriteriaCode,
            ruleParameterTypeName: null,
            ruleParameterTypeCode: dataSource.ruleParamDetails[index].RuleParameterTypeCode,
            ruleParameterValueTypeCode: dataSource.ruleParamDetails[index].RuleParameterValueTypeCode,
            ruleLogicalOperatorCode: dataSource.logicalOperatorCode,
            ruleLogicalOperatorDescription: dataSource.logicalOperatorDescription,
            parameterNumberValue: dataSource.ruleParamDetails[index].RuleParameterValueTypeCode.toLowerCase() === 'number' ?
                paramValue : null,
            parameterCharValue: dataSource.ruleParamDetails[index].RuleParameterValueTypeCode.toLowerCase() === 'char' ?
                paramValue : null,
            parameterDateValue: dataSource.ruleParamDetails[index].RuleParameterValueTypeCode.toLowerCase() === 'date' ?
                paramValue : null
        };
    }

    static generateFormControl(createModel, newRowIndex: number) {
        createModel.configureNewForm.addControl(`${newRowIndex}_attribute`, new FormControl(''));
        createModel.configureNewForm.addControl(`${newRowIndex}_operator`, new FormControl(''));
        createModel.configureNewForm.addControl(`${newRowIndex}_value`, new FormControl(''));
    }

    static checkIfPresent(array, item: string): boolean {
        let element = {};
        let value = true;
        for (element of array) {
            if (element['ruleCriteriaValue'] === item) {
                value = false;
                break;
            }
        }
        return value;
    }
    static setButtonFlags(event, createModel) {
        if (event) {
            createModel.addAttribute = false;
            createModel.remove = true;
            createModel.cancel = true;
            createModel.save = false;
        } else {
            const hasNonEditable = lodashUtils.filter(createModel.attributeValueArray, ['nonEditable', false]);
            if (hasNonEditable && hasNonEditable.length > 0) {
                createModel.addAttribute = false;
                createModel.cancel = true;
                createModel.save = true;
                createModel.remove = false;
            } else if (createModel.selectedRows && createModel.selectedRows.length > 0) {
                createModel.cancel = true;
                createModel.save = false;
                createModel.remove = true;
                createModel.addAttribute = false;
            } else {
                createModel.cancel = false;
                createModel.save = false;
                createModel.remove = false;
                createModel.addAttribute = true;
            }
        }
    }
    static getOverViewDetails(createModel, data) {
        createModel.dataInfo = data;
        createModel.ruleOverViewDetails = data._source;
        if (createModel.ruleOverViewDetails.RuleTypeDescription.toLowerCase() === 'company') {
            createModel.ruleStatusFlag = false;
        }
        createModel.resultSetting = data._source.RuleParameter[0].RuleParameterTypeDescription;
        createModel.ruleParameterCriteriaCode = data._source.RuleParameter[0].RuleParameterCriteriaCode;
        createModel.attributeItems = this.populateAttributes(data);
        createModel.filterAttributeItems = this.populateAttributes(data);
        createModel.paramItems = this.populateParameters(data);
        createModel.tableLoading = false;
    }
    static enableInlineCancel(automationRuleCreateModel) {
        automationRuleCreateModel.addAttribute = true;
        automationRuleCreateModel.remove = false;
        automationRuleCreateModel.save = false;
        automationRuleCreateModel.cancel = false;
    }
    static showMissingInformation(toastMessage) {
        toastMessage.clear();
        toastMessage.add({
            severity: 'error',
            summary: 'Missing Required Information',
            detail: 'Provide the required information in the highlighted fields and submit the form again'
        });
    }
    static showDuplicateMessage(toastMessage, severityMessage) {
        toastMessage.clear();
        toastMessage.add({
            severity: severityMessage,
            summary: 'Duplicate Rule',
            detail: 'An automation rule has already been set for this combination of configurable attributes'
        });
    }
    static inlineRemove(automationRuleCreateModel) {
        automationRuleCreateModel.selectedRows = [];
        automationRuleCreateModel.remove = false;
        automationRuleCreateModel.cancel = false;
        const newRowIndex = automationRuleCreateModel.attributeValueArray.length;
        let removedElement = [];
        for (const removedItems of automationRuleCreateModel.removedIndices) {
            for (let i = 0; i < newRowIndex; i++) {
                this.resetFormArray(automationRuleCreateModel, 0);
                if (automationRuleCreateModel.attributeValueArray[i].attribute.code === removedItems) {
                    lodashUtils.pullAt(automationRuleCreateModel.attributeValueArray, i);
                    automationRuleCreateModel.attributeValueArray = automationRuleCreateModel.attributeValueArray.filter((obj) => obj);
                    break;
                }
            }
        }
        for (const removedItems of automationRuleCreateModel.removedIndices) {
            automationRuleCreateModel.resultObj.forEach((element, index) => {
                this.resetFormArray(automationRuleCreateModel, 0);
                if (element.ruleCriteriaCode === removedItems) {
                    automationRuleCreateModel.resultObj.splice(index, 1);
                }
            });
        }
        this.resetFormArray(automationRuleCreateModel, newRowIndex - 1);
        automationRuleCreateModel.enableRemoveBtn = false;
        if (automationRuleCreateModel.attributeValueArray.length === 0) {
            automationRuleCreateModel.removeTable = true;
            automationRuleCreateModel.attributeValueArray = [];
            automationRuleCreateModel.configureNewForm.reset();
        }
        lodashUtils.forEach(automationRuleCreateModel.ruleCriteriaDetails, (element) => {
            removedElement = lodashUtils.filter(automationRuleCreateModel.ruleCriteriaDetails,
                ['ruleCriteriaCode', element.ruleCriteriaCode]);
        });
        automationRuleCreateModel.ruleCriteriaDetails = removedElement;
    }
    static resetFormArray(automationRuleCreateModel, index) {
        const control: FormArray = automationRuleCreateModel.configureNewForm.controls['configureRuleArray'] as FormArray;
        control.removeAt(index);
    }
    static validateResultSetting(createModel: AutomationRuleCreateModel, requestObj: CreateRequest) {
        if (createModel.showResultSetting) {
            requestObj.ruleParameters = [];
            const ruleparams: RuleParam = this.getRuleParamDetails(createModel);
            requestObj.ruleParameters = requestObj.ruleParameters.concat(ruleparams);
        } else {
            requestObj.ruleParameters = null;
        }
    }
    static getOperationalGroupRecords(dataSource): Array<AttributeType> {
        return dataSource.hits.hits.map((Items => {
            return {
                label: `${Items._source.OperationalGroupDescription}(${Items._source.OperationalGroupCode})`,
                value: Items._source.OperationalGroupCode,
            };
        }));
    }
}
