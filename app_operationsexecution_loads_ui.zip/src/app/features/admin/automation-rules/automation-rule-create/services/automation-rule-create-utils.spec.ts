import { AutomationRuleCreateUtils } from './automation-rule-create-utils';
import { FormBuilder } from '@angular/forms';

const ruleparamarray = [{
    ParameterDefaultCharValue: '',
    ParameterDefaultNumberValue: 1,
    RuleParameterCriteriaCode: '',
    RuleParameterTypeCode: '',
    RuleParameterTypeDescription: '',
    RuleParameterValueTypeCode: ''
}];
const configuredRuleDetails = {
    CreateProgramName: '',
    CreateTimestamp: '',
    CreateUserID: '',
    EffectiveTimestamp: '',
    ExpirationTimestamp: '',
    LastUpdateProgramName: '',
    LastUpdateTimestamp: '',
    LastUpdateUserID: '',
    RuleBusinessProcessCode: '',
    RuleBusinessProcessDescription: '',
    RuleCategoryCode: '',
    RuleCategoryDescription: '',
    RuleCategoryTypeAssociationID: 1,
    RuleCode: '',
    RuleComment: '',
    RuleCriteria: [{
        RuleCriteriaCode: '',
        RuleCriteriaDescription: '',
        RuleLogicalOperator: {
            RuleLogicalOperatorDescription: '',
            RuleLogicalOperatorCode: ''
        }
    }],
    RuleDescription: '',
    RuleDetailID: '',
    RuleInclusionExclusionTypeCode: '',
    RuleName: '',
    RuleParameter: [{
        ParameterDefaultCharValue: '',
        ParameterDefaultNumberValue: 1,
        RuleParameterCriteriaCode: '',
        RuleParameterTypeCode: '',
        RuleParameterTypeDescription: '',
        RuleParameterValueTypeCode: ''
    }],
    RuleSequenceNumber: '',
    RuleTypeCode: '',
    RuleTypeDescription: 'company',
    SendCustomerNotificationIndicator: ''
};
const overviewData = {
    found: true,
    _id: null,
    _index: '',
    _type: '',
    _version: 1,
    _source: configuredRuleDetails
};
const populateValuesData = {
    _embedded: {
        serviceOfferingBusinessUnitTransitModeAssociations: [{
            financeBusinessUnitServiceOfferingAssociation: {
                financeBusinessUnitCode: {
                    code: '',
                    description: ''
                }
            }
        }]
    }
};
const operationalGroup = {
    _embedded: {
        operationalGroups: [{
            operationalGroupCode: {
                code: '',
                description: ''
            }
        }]
    }
};
describe('AutomationRuleCreateUtils', () => {
    const formBuilder: FormBuilder = new FormBuilder();

    it('getRuleParamDetails have been called', () => {
        spyOn(AutomationRuleCreateUtils, 'getRuleDetails').and.returnValue({});
        const dataSource = {
            isTextCriteria: false,
            isBooleanCriteria: true,
            ruleParamDetails: ruleparamarray,
            configureNewForm: formBuilder.group({
                txtResultSetting: formBuilder.array([]),
                resultSetting: formBuilder.array(['']),
            })
        };
        const rtnval = AutomationRuleCreateUtils.getRuleParamDetails(dataSource);
        expect(rtnval.length).toEqual(1);
    });

    it('getRuleParamDetails with textRuleValue  have been called', () => {
        spyOn(AutomationRuleCreateUtils, 'getRuleDetails').and.returnValue({});
        const dataSource = {
            isTextCriteria: true,
            isBooleanCriteria: false,
            ruleParamDetails: ruleparamarray,
            textResultValue: ruleparamarray,
            configureNewForm: formBuilder.group({
                txtResultSetting: formBuilder.array([formBuilder.group({
                    'resultValue': ['']
                })]),
                resultSetting: ['']
            })
        };
        const rtnval = AutomationRuleCreateUtils.getRuleParamDetails(dataSource);
        expect(rtnval.length).toEqual(1);
    });

    it('getRuleDetails have been called', () => {
        const dataSource = {
            isTextCriteria: false,
            isBooleanCriteria: true,
            ruleParamDetails: ruleparamarray,
            logicalOperatorCode: '',
            logicalOperatorDescription: ''
        };
        const rtnval = AutomationRuleCreateUtils.getRuleDetails(dataSource, 0, null);
        expect(rtnval.ruleParameterId).toBeNull();
    });

    it('generateFormControl have been called', () => {
        const createModel = {
            configureNewForm: formBuilder.group({})
        };
        AutomationRuleCreateUtils.generateFormControl(createModel, 0);
        expect(createModel.configureNewForm.controls['0_attribute'].value).toEqual('');
    });

    it('checkIfPresent have been called', () => {
        const array = [{
            ruleCriteriaValue: ''
        }];
        expect(AutomationRuleCreateUtils.checkIfPresent(array, '')).toBeFalsy();
    });

    it('checkIfPresent with value have been called', () => {
        const array = [{
            ruleCriteriaValue: 'a'
        }];
        expect(AutomationRuleCreateUtils.checkIfPresent(array, '')).toBeTruthy();
    });

    it('setButtonFlags else case have been called', () => {
        const createModel = {
            attributeValueArray: [{
                attribute: {
                    code: 'check code',
                    description: ''
                },
                operator: '',
                value: [''],
                nonEditable: false,
                noResultFlag: true,
                checkFlag: true,
                code: [''],
            }],
            addAttribute: true,
            remove: false,
            save: false
        };
        AutomationRuleCreateUtils.setButtonFlags(null, createModel);
        expect(createModel.addAttribute).toBeFalsy();
    });

    it('setButtonFlags else case 1 have been called', () => {
        const createModel = {
            attributeValueArray: [{
                attribute: {
                    code: 'check code',
                    description: ''
                },
                operator: '',
                value: [''],
                nonEditable: true,
                noResultFlag: true,
                checkFlag: true,
                code: [''],
            }],
            addAttribute: true,
            selectedRows: [{}, {}],
            cancel: false,
            remove: false,
            save: false
        };
        AutomationRuleCreateUtils.setButtonFlags(null, createModel);
        expect(createModel.cancel).toBeTruthy();
    });

    it('setButtonFlags else case 2 have been called', () => {
        const createModel = {
            attributeValueArray: [{
                attribute: {
                    code: 'check code',
                    description: ''
                },
                operator: '',
                value: [''],
                nonEditable: true,
                noResultFlag: true,
                checkFlag: true,
                code: [''],
            }],
            addAttribute: true,
            selectedRows: [],
            cancel: true,
            remove: false,
            save: false
        };
        AutomationRuleCreateUtils.setButtonFlags(null, createModel);
        expect(createModel.cancel).toBeFalsy();
    });

    it('setButtonFlags else case 3 have been called', () => {
        const createModel = {
            addAttribute: true,
            selectedRows: [],
            cancel: true,
            save: false,
            remove: false
        };
        AutomationRuleCreateUtils.setButtonFlags({}, createModel);
        expect(createModel.addAttribute).toBeFalsy();
    });

    it('getOverViewDetails have been called', () => {
        spyOn(AutomationRuleCreateUtils, 'populateAttributes');
        const createModel = {
            addAttribute: true,
            selectedRows: [],
            cancel: true,
            remove: false,
            save: false,
            ruleStatusFlag: true,
            tableLoading: true
        };
        AutomationRuleCreateUtils.getOverViewDetails(createModel, overviewData);
        expect(createModel.tableLoading).toBeFalsy();
    });

    it('enableInlineCancel have been called', () => {
        const automationRuleCreateModel = {
            addAttribute: false,
            cancel: true,
            remove: false,
            save: false
        };
        AutomationRuleCreateUtils.enableInlineCancel(automationRuleCreateModel);
        expect(automationRuleCreateModel.addAttribute).toBeTruthy();
    });

    it('inlineRemove have been called', () => {
        spyOn(AutomationRuleCreateUtils, 'resetFormArray');
        const automationRuleCreateModel = {
            configureNewForm: formBuilder.group({}),
            addAttribute: false,
            cancel: true,
            remove: true,
            save: false,
            selectedRows: [{}, {}],
            attributeValueArray: [{
                attribute: {
                    code: 'check code',
                    description: ''
                },
                operator: '',
                value: [''],
                nonEditable: true,
                noResultFlag: true,
                checkFlag: true,
                code: [''],
            }],
            removedIndices: ['check code'],
            resultObj: [{
                ruleCriteriaDetailId: '',
                ruleCriteriaCode: 'check code',
                ruleCriteriaDescription: '',
                ruleLogicalOperatorCode: '',
                ruleLogicalOperatorDescription: '',
                ruleCriteriaValue: ''
            }],
            ruleCriteriaDetails: [{
                ruleCriteriaCode: 'check code'
            }]
        };
        AutomationRuleCreateUtils.inlineRemove(automationRuleCreateModel);
        expect(automationRuleCreateModel.remove).toBeFalsy();
    });

    it('resetFormArray have been called', () => {
        const automationRuleCreateModel = {
            configureNewForm: formBuilder.group({
                configureRuleArray: formBuilder.array([formBuilder.group({
                    attribute: [''],
                    operator: [''],
                    value: ['']
                })])
            })
        };
        AutomationRuleCreateUtils.resetFormArray(automationRuleCreateModel, 0);
        expect(automationRuleCreateModel.configureNewForm.controls.configureRuleArray.value.length).toEqual(0);
    });

    it('getOperationalGroupRecords have been called', () => {
        const dataSource = {
            hits: {
                hits: [{
                    _source: {
                        OperationalGroupDescription: 'description',
                        OperationalGroupCode: {
                            code: 'code',
                            description: 'desc'
                        }
                    }
                }]
            }
        };
        const rtnval = AutomationRuleCreateUtils.getOperationalGroupRecords(dataSource);
        expect(rtnval[0].value.code).toEqual('code');
    });

    it('populateAttributes have been called', () => {
        const rtnval = AutomationRuleCreateUtils.populateAttributes(overviewData);
        expect(rtnval[0].value.code).toEqual('');
    });

    it('populateValues have been called', () => {
        const rtnval = AutomationRuleCreateUtils.populateValues(populateValuesData);
        expect(rtnval[0].value.code).toEqual('');
    });

    it('populateOPGroupValues have been called', () => {
        const rtnval = AutomationRuleCreateUtils.populateOPGroupValues(operationalGroup);
        expect(rtnval[0].value.code).toEqual('');
    });
});
