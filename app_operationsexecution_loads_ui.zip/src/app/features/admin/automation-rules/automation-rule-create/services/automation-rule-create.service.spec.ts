import { inject, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AutomationRuleCreateService } from './automation-rule-create.service';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { configureTestSuite } from 'ng-bullet';

describe('AutomationRuleCreateService', () => {
  let service: AutomationRuleCreateService;
  let httpTestingController: HttpTestingController;

  const requestObj = {
    ruleDetailId: 1,
    ruleCriteriaSetID: '',
    orderRuleSupersedeTypeCode: '',
    ruleCriteriaDetails: [{
      ruleCriteriaDetailId: '',
      ruleCriteriaCode: '',
      ruleCriteriaDescription: '',
      ruleLogicalOperatorCode: '',
      ruleLogicalOperatorDescription: '',
      ruleCriteriaValue: null
    }],
    ruleParameters: [{
      ruleParameterId: '',
      ruleParameterCriteriaCode: '',
      ruleParameterTypeName: '',
      ruleParameterTypeCode: '',
      ruleParameterValueTypeCode: '',
      ruleLogicalOperatorCode: '',
      ruleLogicalOperatorDescription: '',
      parameterNumberValue: 1,
      parameterCharValue: '',
      parameterDateValue: '',
    }]
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AutomationRuleCreateService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(AutomationRuleCreateService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('getRuleOverviewDetails have been created', () => {
    const ruleDetailId = 1;
    service.getRuleOverviewDetails(ruleDetailId).subscribe();
    const url = `${service.endpoint.configureNewPredefined}/${ruleDetailId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getBusinessUnit have been created', () => {
    service.getBusinessUnit().subscribe();
    const url = service.baseURL.getBusinessUnit + `?size=1000`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getOperationalGroupValues have been created', () => {
    service.getOperationalGroupValues().subscribe();
    const url = service.baseURL.getOperationalGroup + `?size=1000`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getOperationalGroupData have been created', () => {
    const queryParamValue = '';
    service.getOperationalGroupData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalGroup);
    expect(req.request.method).toEqual('POST');
  });

  it('getDriverData have been created', () => {
    const queryParamValue = '';
    service.getDriverData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getDrivers);
    expect(req.request.method).toEqual('POST');
  });

  it('getTruckData have been created', () => {
    const queryParamValue = '';
    service.getTruckData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTrucks);
    expect(req.request.method).toEqual('POST');
  });

  it('getOWOSubtypeData have been created', () => {
    service.getOWOSubtypeData().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.owoSubTypes);
    expect(req.request.method).toEqual('GET');
  });

  it('getCorporateAccountData have been created', () => {
    const queryParamValue = {};
    service.getCorporateAccountData(queryParamValue).subscribe();
    const url = `${service.endpoint.corporateAccountData}?size=5`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('POST');
  });

  it('getLineOfBusinessData have been created', () => {
    const queryParamValue = {};
    service.getLineOfBusinessData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.lineOfBusinessData);
    expect(req.request.method).toEqual('POST');
  });

  it('getBillToAccountData have been created', () => {
    const queryParamValue = {};
    service.getBillToAccountData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.billToAccountData);
    expect(req.request.method).toEqual('POST');
  });

  it('getLocationData have been created', () => {
    const queryParamValue = {};
    service.getLocationData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.locationData);
    expect(req.request.method).toEqual('POST');
  });

  it('getTeamData have been called', () => {
    spyOn(service, 'generateTimeStamp').and.returnValue('');
    const queryParamValue = '';
    service.getTeamData(queryParamValue).subscribe();
    const url = service.endpoint.teamData;
    const param = `${url}?teamName=${queryParamValue}&expirationTimestamp=${queryParamValue}`;
    const req = httpTestingController.expectOne(param);
    expect(req.request.method).toEqual('GET');
  });

  it('getSCACData have been created', () => {
    const queryParamValue = {};
    service.getSCACData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.scacData);
    expect(req.request.method).toEqual('POST');
  });

  it('createNewRule have been created', () => {
    service.createNewRule(requestObj).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.createRule);
    expect(req.request.method).toEqual('POST');
  });

  it('generateTimeStamp have been called', () => {
    const result = new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60 * 1000).toISOString().substr(0, 19);
    const rtnval = service.generateTimeStamp();
    expect(rtnval).toEqual(result);
  });

  it('getOperationalPlanType have been created', () => {
    service.getOperationalPlanType().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalPlanTypes);
    expect(req.request.method).toEqual('GET');
  });

  it('getOperationalPlanSubtype have been created', () => {
    service.getOperationalPlanSubtype().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalPlanSubtype);
    expect(req.request.method).toEqual('GET');
  });

  it('getStopReason have been created', () => {
    service.getStopReason().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getStopReason);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentClassification have been created', () => {
    service.getEquipmentClassification().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentClassification);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentSubClass have been created', () => {
    service.getEquipmentSubClass().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentSubClass);
    expect(req.request.method).toEqual('GET');
  });

  it('getClassificationPlan have been created', () => {
    service.getClassificationPlan().subscribe();
    const url = `${service.endpoint.getClassificationPlanType}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });
});



