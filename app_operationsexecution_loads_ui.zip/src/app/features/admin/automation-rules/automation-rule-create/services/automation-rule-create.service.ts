import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import { CreateResponse, CreateRequest } from '../model/automation-rule-create.interface';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { TeamsData, BusinessUnit, LobResponse, OperationalGroup } from '../../model/automation-rule.interface';
import { OperationalPlanSubtypeObject, OperationalPlanTypeObject, StopReasonObject,
  EquipmentClassificationObject, EquipmentSubClass, ClassificationType} from '../../model/automation-rules.interface';

@Injectable()
export class AutomationRuleCreateService {

  endpoint: any;
  baseURL: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('automationRules');
    this.baseURL = appConfigService.getApi('operationalPlan');
  }
  getRuleOverviewDetails(ruleDetailId: number): Observable<object> {
    return this.http.get(`${this.endpoint.configureNewPredefined}/${ruleDetailId}`);
  }
  getBusinessUnit(): Observable<BusinessUnit> {
    return this.http.get<BusinessUnit>(this.baseURL.getBusinessUnit + `?size=1000`);
  }
  getOperationalGroupValues(): Observable<OperationalGroup> {
    return this.http.get<OperationalGroup>(this.baseURL.getOperationalGroup + `?size=1000`);
  }
  getOperationalGroupData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getOperationalGroup, queryParamValue);
  }
  getDriverData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getDrivers, queryParamValue);
  }
  getTruckData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getTrucks, queryParamValue);
  }
  getOWOSubtypeData(): Observable<any> {
    return this.http.get(this.endpoint.owoSubTypes);
  }
  getCorporateAccountData(queryParamValue: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(`${this.endpoint.corporateAccountData}?size=5`, queryParamValue);
  }
  getLineOfBusinessData(queryParamValue: object): Observable<LobResponse> {
    return this.http.post<LobResponse>(this.endpoint.lineOfBusinessData, queryParamValue);
  }
  getBillToAccountData(queryParamValue: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.billToAccountData, queryParamValue);
  }
  getLocationData(queryParamValue: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.locationData, queryParamValue);
  }
  getTeamData(queryParamValue: string): Observable<TeamsData> {
    const url = this.endpoint.teamData;
    const param = `${url}?teamName=${queryParamValue}&expirationTimestamp=${this.generateTimeStamp()}`;
    return this.http.get<TeamsData>(param);
  }
  getSCACData(queryParamValue: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.scacData, queryParamValue);
  }
  createNewRule(requestObj: CreateRequest): Observable<CreateResponse> {
    return this.http.post<CreateResponse>(this.endpoint.createRule, requestObj);
  }
  generateTimeStamp() {
    return new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60 * 1000).toISOString().substr(0, 19);
  }
  getOperationalPlanType(): Observable<OperationalPlanTypeObject> {
    return this.http.get<OperationalPlanTypeObject>(this.endpoint.getOperationalPlanTypes);
  }
  getOperationalPlanSubtype(): Observable<OperationalPlanSubtypeObject> {
    return this.http.get<OperationalPlanSubtypeObject>(this.endpoint.getOperationalPlanSubtype);
  }
  getStopReason(): Observable<StopReasonObject> {
    return this.http.get<StopReasonObject>(this.endpoint.getStopReason);
  }
  getEquipmentClassification(): Observable<EquipmentClassificationObject> {
    return this.http.get<EquipmentClassificationObject>(this.endpoint.getEquipmentClassification);
  }
  getEquipmentSubClass(): Observable<EquipmentSubClass> {
    return this.http.get<EquipmentSubClass>(this.endpoint.getEquipmentSubClass);
  }
  getClassificationPlan(): Observable<ClassificationType> {
    return this.http.get<ClassificationType>(`${this.endpoint.getClassificationPlanType}`);
  }
}
