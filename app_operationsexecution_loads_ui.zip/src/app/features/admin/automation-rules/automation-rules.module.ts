import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MultiSelectModule } from 'primeng/multiselect';
import { CalendarModule } from 'primeng/calendar';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { PanelModule } from 'primeng/panel';
import { RadioButtonModule } from 'primeng/radiobutton';
import { PaginatorModule } from 'primeng/paginator';
import { TooltipModule } from 'primeng/tooltip';
import { DialogModule } from 'primeng/dialog';

import { DirectivesModule } from '../../../shared/directives/directives.module';
import { JbhFiltersModule } from '../../../shared/jbh-filters/jbh-filters.module';

import { AutomationRulesComponent } from './automation-rules.component';
import { AutomationRulesRoutingModule } from './automation-rules-routing.module';
import { AutomationRulesService } from './services/automation-rules.service';
import { PredefinedRulesComponent } from './predefined-rules/predefined-rules.component';
import { PredefinedRulesService } from './predefined-rules/services/predefined-rules.service';
import { AutomationRuleViewComponent } from './automation-rule-view/automation-rule-view.component';
import { RuleOverviewComponent } from './rule-overview/rule-overview.component';
import { AutomationRuleViewService } from './automation-rule-view/services/automation-rule-view.service';
import { AutomationRuleCreateComponent } from './automation-rule-create/automation-rule-create.component';
import { PredefinedRulesFilterComponent } from './predefined-rules/predefined-rules-filter/predefined-rules-filter.component';
import { PredefinedRulesFilterService } from './predefined-rules/predefined-rules-filter/services/predefined-rules-filter.service';
import { AutomationRuleFilterComponent } from './automation-rule-filter/automation-rule-filter.component';
import { AutomationRuleCreateService } from './automation-rule-create/services/automation-rule-create.service';
import { AutomationRuleEditComponent } from './automation-rule-edit/automation-rule-edit.component';
import { AutomationRuleEditService } from './automation-rule-edit/services/automation-rule-edit.service';

@NgModule({
  imports: [
    CommonModule,
    BreadcrumbModule,
    ButtonModule,
    MenuModule,
    TableModule,
    InputTextModule,
    ScrollPanelModule,
    FormsModule,
    ReactiveFormsModule,
    CheckboxModule,
    DropdownModule,
    AutoCompleteModule,
    MultiSelectModule,
    AutomationRulesRoutingModule,
    ConfirmDialogModule,
    PanelModule,
    AutoCompleteModule,
    CheckboxModule,
    PanelModule,
    CalendarModule,
    DirectivesModule,
    RadioButtonModule,
    PaginatorModule,
    JbhFiltersModule,
    TooltipModule,
    DialogModule
  ],
  declarations: [AutomationRulesComponent, PredefinedRulesComponent,
    AutomationRuleViewComponent, RuleOverviewComponent, AutomationRuleCreateComponent,
    AutomationRuleEditComponent, PredefinedRulesFilterComponent, AutomationRuleFilterComponent],
  providers: [AutomationRulesService, PredefinedRulesService, ConfirmationService, AutomationRuleViewService,
    PredefinedRulesFilterService, AutomationRuleCreateService, AutomationRuleEditService]
})
export class AutomationRulesModule { }
