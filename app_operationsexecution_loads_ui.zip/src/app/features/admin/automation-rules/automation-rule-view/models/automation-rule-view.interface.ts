export interface RuleAttribute {
    ruleDetailId: number;
    ruleCriteriaSetID: number;
    ruleStatus: string;
    ruleSupersedeTypeCode: null;
    ruleCriteriaDetails: Array<RuleCriteriaDetails>;
    ruleParameters: Array<RuleParameters>;
}
export interface RuleCriteriaDetails {
    ruleCriteriaCode: string;
    ruleCriteriaDescription: string;
    ruleLogicalOperatorCode: string;
    ruleLogicalOperatorDescription: string;
    ruleCriteriaValues: Array<RuleCriteriaValues>;
}
export interface RuleCriteriaValues {
    ruleCriteriaDetailId: number;
    ruleCriteriaValue: string;
}
export interface RuleParameters {
    ruleParameterId: number;
    ruleParameterCriteriaCode: string;
    ruleParameterTypeDescription: string;
    ruleParameterValueTypeCode: string;
    ruleLogicalOperatorCode: string;
    ruleLogicalOperatorDescription: string;
    parameterNumberValue: number;
    parameterCharValue: null;
    parameterDateValue: null;
}
export interface ActiveInactivate {
    ruleCriteriaSetID: number;
    startDate: string;
    endDate: string;
    ruleStatus: string;
}
export interface BooleanData {
    ruleHeader: string;
    ruleValue: string;
}
