import { RuleCriteriaDetails, BooleanData } from './automation-rule-view.interface';
import { SourceDetails } from '../../model/automation-rule.interface';
import { Breadcrumb } from '../../../../model/breadcrumb.interface';
import { AppConfig } from '../../../../../../config/app.config';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
export class AutomationRuleViewModel {
  breadcrumb: Breadcrumb[];
  subscribeFlag: boolean;
  ruleAttributes: RuleCriteriaDetails[];
  ruleOverViewDetails: SourceDetails;
  resultSettingHours: any;
  noattributeFlag: boolean;
  ruleStatusFlag: boolean;
  businessFlag: boolean;
  resuluCriteriaId: number;
  resultSettingValue: boolean;
  loadingFlag: boolean;
  ruleOverviewStatus: string;
  ruleCriteriaSetId: string;
  textResultValue: any;
  booleanData: BooleanData[];
  isTextResultExists: boolean;
  booleanResult: any;
  appConfig;
  copyEditButton: SecureModel;
  activateInactivateButton: SecureModel;
  constructor() {
    this.breadcrumb = [
      { label: 'Administration', routerLink: [''] },
      { label: 'Automation Rules', routerLink: ['/admin/automationrules'] },
      { label: 'View Rule' }];
    this.subscribeFlag = true;
    this.ruleAttributes = [];
    this.noattributeFlag = false;
    this.ruleStatusFlag = false;
    this.businessFlag = false;
    this.loadingFlag = false;
    this.isTextResultExists = false;
    this.resultSettingValue = false;
    this.appConfig = AppConfig.getConfig();
    this.copyEditButton = { url: this.appConfig.api.uiAccessList.editCopyRule, operation: 'C' };
    this.activateInactivateButton = { url:  this.appConfig.api.automationRules.activeInactiveRule, operation: 'C' };
  }
}
