import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ActiveInactivate, RuleAttribute } from './../models/automation-rule-view.interface';
import { RuleOverviewDetails } from '../../model/automation-rule.interface';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

@Injectable()
export class AutomationRuleViewService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('automationRules');
  }
  getRuleOverview(ruleCriteriaSetId: number): Observable<RuleOverviewDetails> {
    return this.http.get<RuleOverviewDetails>(`${this.endpoint.ruleOverview}/${ruleCriteriaSetId}`);
  }
  getRuleOverviewDetails(ruleDetailId: number): Observable<object> {
    const url = this.endpoint.configureNewPredefined;

    return this.http.get(`${url}/${ruleDetailId}`);
  }
  getRuleAttributes(ruleCriteriaSetId: number): Observable<RuleAttribute> {
    return this.http.get<RuleAttribute>(`${this.endpoint.ruleAttributes}/${ruleCriteriaSetId}`);
  }
  getActiveInactiveRule(ruleCriteriaSetId: number, ruleStatus: boolean): Observable<ActiveInactivate> {
    return this.http.patch<ActiveInactivate>(`${this.
      endpoint.activeInactiveRule}/${ruleCriteriaSetId}?status=${ruleStatus}`, `${ruleStatus}`);
  }
}
