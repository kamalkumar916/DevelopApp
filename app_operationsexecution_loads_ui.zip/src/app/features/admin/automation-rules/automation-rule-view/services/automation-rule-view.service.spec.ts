import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AutomationRuleViewService } from './automation-rule-view.service';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { configureTestSuite } from 'ng-bullet';

describe('AutomationRuleViewService', () => {
  let service: AutomationRuleViewService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AutomationRuleViewService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(AutomationRuleViewService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('getRuleOverview have been created', () => {
    const ruleCriteriaSetId = 1;
    service.getRuleOverview(ruleCriteriaSetId).subscribe();
    const url = `${service.endpoint.ruleOverview}/${ruleCriteriaSetId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getRuleOverviewDetails have been created', () => {
    const ruleDetailId = 1;
    service.getRuleOverviewDetails(ruleDetailId).subscribe();
    const url = `${service.endpoint.configureNewPredefined}/${ruleDetailId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getRuleAttributes have been created', () => {
    const ruleCriteriaSetId = 1;
    service.getRuleAttributes(ruleCriteriaSetId).subscribe();
    const url = `${service.endpoint.ruleAttributes}/${ruleCriteriaSetId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getActiveInactiveRule have been created', () => {
    const ruleCriteriaSetId = 1;
    const ruleStatus = true;
    service.getActiveInactiveRule(ruleCriteriaSetId, ruleStatus).subscribe();
    const url = `${service.endpoint.activeInactiveRule}/${ruleCriteriaSetId}?status=${ruleStatus}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PATCH');
  });
});
