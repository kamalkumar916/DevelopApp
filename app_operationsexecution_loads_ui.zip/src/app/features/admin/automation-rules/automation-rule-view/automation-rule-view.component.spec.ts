import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { SpinnerService } from '../../../../shared/spinner/index';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { AutomationRuleViewService } from './services/automation-rule-view.service';
import { ConfirmationService } from 'primeng/api';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TableModule } from 'primeng/table';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DirectivesModule } from '../../../../shared/directives/directives.module';

import { RuleOverviewComponent } from '../rule-overview/rule-overview.component';

import { AutomationRuleViewComponent } from './automation-rule-view.component';

import { configureTestSuite } from 'ng-bullet';
import { Router } from '@angular/router';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';

const ruleOverViewData = {
  _type: 'doc',
  _version: 6,
  found: true,
  _id: '31',
  _index: 'operationsexecution-automationrules-ruledetail',
  _source: {
    CreateProgramName: '',
    CreateTimestamp: '',
    CreateUserID: '',
    EffectiveTimestamp: '',
    ExpirationTimestamp: '',
    LastUpdateProgramName: 'SSIS',
    LastUpdateTimestamp: '',
    LastUpdateUserID: '',
    RuleBusinessProcessCode: 'Execution',
    RuleBusinessProcessDescription: 'Execution',
    RuleCategoryCode: 'AutoSwtch',
    RuleCategoryDescription: 'Automated Switch',
    RuleCategoryTypeAssociationID: 31,
    RuleCode: '',
    RuleComment: 'Check the configurable distance between the location of the truck and Switch location',
    RuleDescription: 'Check the configurable distance between the location of the truck and Switch location',
    RuleDetailID: 31,
    RuleInclusionExclusionTypeCode: 'Inclusion',
    RuleName: 'Allowed Switch Distance',
    RuleSequenceNumber: 0,
    RuleTypeCode: 'BusUnit',
    RuleTypeDescription: 'Business Unit',
    SendCustomerNotificationIndicator: 'N',
    RuleParameter: [{
      ParameterDefaultCharValue: 'NULL',
      ParameterDefaultDateValue: null,
      ParameterDefaultNumberValue: 100,
      ParameterTypeName: 'Allowed Switch Distance',
      RuleParameterCriteriaCode: 'AllSwtchDs',
      RuleParameterID: null,
      RuleParameterTypeCode: 'Miles',
      RuleParameterTypeDescription: 'Miles',
      RuleParameterValueTypeCode: 'Number'
    }],
    RuleCriteria: [{
      RuleCriteriaCode: 'BusUnit',
      RuleCriteriaDescription: 'Business Unit',
      RuleCriteriaDetailID: 31,
      RuleCriteriaLogicalOperatorAssociationID: 2,
      RuleLogicalOperator: [{
        RuleLogicalOperatorCode: 'Equal',
        RuleLogicalOperatorDescription: 'Equals'
      }]
    }]
  }
};
const getRuleAttributesData = {
  inactiveRuleCriteriaSetId: null,
  ruleCriteriaSetId: 28,
  ruleDetailId: 31,
  ruleStatus: 'Active',
  ruleSupersedeTypeCode: null,
  ruleCriteriaDetails: [{
    ruleCriteriaCode: 'BusUnit',
    ruleCriteriaDescription: 'Business Unit',
    ruleLogicalOperatorCode: 'Equal',
    ruleLogicalOperatorDescription: 'Equals',
    ruleCriteriaValues: [{
      ruleCriteriaDetailId: 18,
      ruleCriteriaValue: 'JBT',
      ruleCriteriaValueDescription: 'JBT'
    }]
  }],
  ruleParameters: [{
    parameterCharValue: 'NULL',
    parameterDateValue: null,
    parameterNumberValue: 100,
    parameterTypeName: 'Allowed Switch Distance',
    ruleLogicalOperatorCode: 'Equal',
    ruleLogicalOperatorDescription: 'Equals',
    ruleParameterCriteriaCode: 'AllSwtchDs',
    ruleParameterId: 54,
    ruleParameterTypeDescription: 'boolean',
    ruleParameterValueTypeCode: 'Number'
  }]
};
class MockAutomationRuleViewService {
  constructor() { }
  getRuleOverviewDetails(ruleDetailedId) {
    return of(ruleOverViewData);
  }
  getRuleAttributes() {
    return of(getRuleAttributesData);
  }
}

describe('AutomationRuleViewComponent', () => {
  let component: AutomationRuleViewComponent;
  let fixture: ComponentFixture<AutomationRuleViewComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, BreadcrumbModule, TableModule, ConfirmDialogModule, DirectivesModule],
      providers: [SpinnerService, UserService, AppConfigService, MessageService,
        { provide: AutomationRuleViewService, useClass: MockAutomationRuleViewService }, ConfirmationService],
      declarations: [AutomationRuleViewComponent, RuleOverviewComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutomationRuleViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('resultSetting have been called', () => {
    component.resultSetting([]);
    expect(component.automationRuleViewModel.resultSettingHours).toBeDefined([]);
  });

  it('resultSetting Param value will be Array', () => {
    const data = [{
      ruleParameterValueTypeCode: 'char',
      parameterTypeName: 'value'
    }, {
      ruleParameterValueTypeCode: 'number',
      parameterNumberValue: 1
    }, {
      ruleParameterValueTypeCode: 'date',
      parameterDateValue: 1
    }];
    component.resultSetting(data);
    expect(component.automationRuleViewModel.resultSettingHours.length).toEqual(3);
  });

  it('getNonBooleanData have been called', () => {
    const arr = ['check description'];
    component.getNonBooleanData('', arr);
    expect(component.automationRuleViewModel.isTextResultExists).toBe(true);
  });

  it('onClickCopyRule should call the navigate spy', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.automationRuleViewModel.ruleCriteriaSetId = '';
    component.onClickCopyRule();
    expect(router.navigate).toHaveBeenCalledWith(['/admin/automationrules/editconfigurerule'], {
      queryParams: {
        ruleCriteriaSetId: '',
        copyRule: true
      }
    });
  });

  it('onEdit should call the navigate spy', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.automationRuleViewModel.ruleCriteriaSetId = '';
    component.onEdit();
    expect(router.navigate).toHaveBeenCalledWith(['/admin/automationrules/editconfigurerule'], {
      queryParams: {
        ruleCriteriaSetId: ''
      }
    });
  });

  it('onInactivate should call the spy activeInactivate', () => {
    spyOn(component, 'activeInactivate');
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.accept();
    });
    component.onInactivate(true);
    expect(component.activeInactivate).toHaveBeenCalled();
  });

  it('onActivate', () => {
    spyOn(component, 'activeInactivate');
    component.onActivate(true);
    expect(component.activeInactivate).toHaveBeenCalledWith(true);
  });

  it('ruleOverview should set the ruleStatusFlag to be true', () => {
    component.automationRuleViewModel.ruleOverviewStatus = 'active';
    component.ruleOverview(31);
    expect(component.automationRuleViewModel.ruleStatusFlag).toBeTruthy();
  });

  it('ruleOverview should set the ruleStatusFlag to be false', () => {
    component.automationRuleViewModel.ruleOverviewStatus = 'active';
    ruleOverViewData._source.RuleTypeDescription = 'company';
    component.ruleOverview(31);
    expect(component.automationRuleViewModel.ruleStatusFlag).toBeFalsy();
  });

  it('ruleOverview should set the ruleOverViewDetails value to be null', () => {
    const automationRuleViewService = TestBed.get(AutomationRuleViewService);
    spyOn(automationRuleViewService, 'getRuleOverviewDetails').and.returnValue(throwError(null));
    component.ruleOverview(31);
    expect(component.automationRuleViewModel.ruleOverViewDetails).toBeNull();
  });

  it('viewAttributes should set the resultSettingValue value to false', () => {
    const automationRuleViewService = TestBed.get(AutomationRuleViewService);
    spyOn(automationRuleViewService, 'getRuleAttributes').and.returnValue(throwError(null));
    component.viewAttributes(1);
    expect(component.automationRuleViewModel.resultSettingValue).toBeFalsy();
  });
});
