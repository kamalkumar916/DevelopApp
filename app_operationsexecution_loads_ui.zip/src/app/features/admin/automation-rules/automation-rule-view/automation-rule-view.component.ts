import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { Observable, timer } from 'rxjs';
import { finalize, takeWhile } from 'rxjs/operators';
import * as lodashUtils from 'lodash';

import { SpinnerService } from '../../../../../app/shared/spinner/index';

import { AutomationRuleViewModel } from './models/automation-rule-view.model';
import { AutomationRuleViewService } from './services/automation-rule-view.service';
import { ActiveInactivate, RuleAttribute } from './models/automation-rule-view.interface';
import { RuleOverviewDetails } from '../model/automation-rule.interface';

@Component({
  selector: 'app-automation-rule-view',
  templateUrl: './automation-rule-view.component.html',
  styleUrls: ['./automation-rule-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AutomationRuleViewComponent implements OnInit, OnDestroy {
  @ViewChild('viewPage') viewButton: ElementRef;
  automationRuleViewModel: AutomationRuleViewModel;
  constructor(private readonly automationRuleViewService: AutomationRuleViewService,
    private readonly activatedRoute: ActivatedRoute, private readonly changeDetector: ChangeDetectorRef,
    private readonly router: Router, private readonly confirmationService: ConfirmationService,
              private readonly spinnerService: SpinnerService) {
    this.automationRuleViewModel = new AutomationRuleViewModel();
  }

  ngOnInit() {
    this.spinnerService.hide();
    this.automationRuleViewModel.ruleCriteriaSetId = this.activatedRoute.queryParams['value']['ruleCriteriaSetId'];
    this.viewAttributes(this.activatedRoute.queryParams['value']['ruleCriteriaSetId']);
  }
  ngOnDestroy() {
    this.automationRuleViewModel.subscribeFlag = false;
  }
  viewButtonFocus() {
    this.viewButton.nativeElement.querySelector('button').focus();
  }

  ruleOverview(ruleDetailedId: number) {
    this.automationRuleViewService.getRuleOverviewDetails(ruleDetailedId)
      .pipe(
        takeWhile(() => this.automationRuleViewModel.subscribeFlag),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((data: RuleOverviewDetails) => {
        if (data && data._source) {
          this.automationRuleViewModel.ruleOverViewDetails = data._source;
          if (this.automationRuleViewModel.ruleOverViewDetails.RuleTypeDescription.toLowerCase() === 'company') {
            this.automationRuleViewModel.ruleStatusFlag = false;
          } else {
            this.automationRuleViewModel.ruleStatusFlag = true;
            this.automationRuleViewModel.businessFlag =
              (this.automationRuleViewModel.ruleOverviewStatus.toLowerCase() === 'active');
          }
        }
      }, (error) => {
        this.automationRuleViewModel.ruleOverViewDetails = null;
      });
  }
  viewAttributes(ruleCriteriaSetId: number) {
    this.automationRuleViewModel.loadingFlag = true;
    this.automationRuleViewService.getRuleAttributes(ruleCriteriaSetId)
      .pipe(
        takeWhile(() => this.automationRuleViewModel.subscribeFlag),
        finalize(() => {
          this.automationRuleViewModel.loadingFlag = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe((data: RuleAttribute) => {
        const ruleDetailId = data.ruleDetailId;
        this.ruleOverview(ruleDetailId);
        this.automationRuleViewModel.loadingFlag = false;
        this.automationRuleViewModel.ruleAttributes = (data.ruleCriteriaDetails) ? data.ruleCriteriaDetails : [];
        this.automationRuleViewModel.ruleOverviewStatus = data.ruleStatus;
        this.automationRuleViewModel.businessFlag =
          (this.automationRuleViewModel.ruleOverviewStatus.toLowerCase() === 'active');
        this.automationRuleViewModel.noattributeFlag = (data.ruleCriteriaDetails.length === 0);
        const nonBooleanData = lodashUtils.cloneDeep(data.ruleParameters);
        this.automationRuleViewModel.textResultValue = nonBooleanData.filter(function (element) {
          return element.ruleParameterTypeDescription.toLowerCase() !== 'boolean';
        });
        this.getNonBooleanData(data, this.automationRuleViewModel.textResultValue);
        this.automationRuleViewModel.booleanResult = nonBooleanData.filter(function (element) {
          return element.ruleParameterTypeDescription.toLowerCase() === 'boolean';
        });
        if (this.automationRuleViewModel.booleanResult && this.automationRuleViewModel.booleanResult.length > 0) {
          this.automationRuleViewModel.resultSettingValue = true;
          this.resultSetting(this.automationRuleViewModel.booleanResult);
        }
      }, (error) => {
        this.automationRuleViewModel.resultSettingValue = false;
        this.automationRuleViewModel.ruleAttributes = [];
      });
  }
  getNonBooleanData(data, resultValue) {
    if (resultValue && resultValue.length > 0) {
      this.automationRuleViewModel.isTextResultExists = true;
      this.automationRuleViewModel.booleanData = resultValue.map((value) => {
        return {
          ruleHeader: value.ruleParameterTypeDescription,
          ruleValue: (value.parameterNumberValue || value.parameterCharValue || value.parameterDateValue)
        };
      });
    }
  }
  resultSetting(data) {
    this.automationRuleViewModel.resultSettingHours = [];
    if (data && data.length > 0) {
      data.forEach((paramDetails) => {
        if (paramDetails.ruleParameterValueTypeCode.toLowerCase() === 'char') {
          this.automationRuleViewModel.resultSettingHours.push(paramDetails.parameterTypeName);
        } else if (paramDetails.ruleParameterValueTypeCode.toLowerCase() === 'number') {
          this.automationRuleViewModel.resultSettingHours.push(paramDetails.parameterNumberValue);
        } else {
          this.automationRuleViewModel.resultSettingHours.push(paramDetails.parameterDateValue);
        }
      });
    }
  }
  onActivate(status: boolean) {
    this.activeInactivate(status);
  }
  onInactivate(status: boolean): void {
    this.confirmationService.confirm({
      message: 'Are you sure you want to inactivate the rule ?',
      header: 'Inactivate Rule',
      key: 'Inactivate',
      accept: (): void => {
        this.activeInactivate(status);
      }
    });
  }
  activeInactivate(status: boolean) {
    this.automationRuleViewService.getActiveInactiveRule(this.activatedRoute.queryParams['value']['ruleCriteriaSetId'], status)
      .pipe(
        takeWhile(() => this.automationRuleViewModel.subscribeFlag)
      )
      .subscribe((data: ActiveInactivate) => {
        if (data) {
          this.spinnerService.show();
          timer(2000).subscribe((_: any) => {
            this.router.navigate(['/admin/automationrules']);
          });
        }
        this.changeDetector.detectChanges();
      });
  }
  onEdit() {
    this.router.navigate(['/admin/automationrules/editconfigurerule'],
      { queryParams: { ruleCriteriaSetId: this.automationRuleViewModel.ruleCriteriaSetId } });
  }
  onClickCopyRule() {
    this.router.navigate(['/admin/automationrules/editconfigurerule'],
      {
        queryParams: {
          ruleCriteriaSetId: this.automationRuleViewModel.ruleCriteriaSetId,
          copyRule: true
        }
      });
  }
}
