import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component,
  OnInit, ViewChild, Output, EventEmitter, ViewChildren
} from '@angular/core';
import * as utils from 'lodash';

import { AutomationRulesService } from '../services/automation-rules.service';

import { AttributeType, RuleType, RuleCategory, FilterConfig, DropDownValue, FilterData } from '../model/automation-rules.interface';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { AutocompleteFilterComponent } from '../../../../shared/jbh-filters/autocomplete-filter/autocomplete-filter.component';
import { AutomationRulesModel } from '../model/automation-rules.model';
import { AssociationLevelModel } from '../predefined-rules/predefined-rules-filter/model/predefined-rules-filter.interface';

@Component({
  selector: 'app-automation-rule-filter',
  templateUrl: './automation-rule-filter.component.html',
  styleUrls: ['./automation-rule-filter.component.scss'],
  providers: [AutomationRulesService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AutomationRuleFilterComponent implements OnInit {

  @ViewChild(AutocompleteFilterComponent) autoCompleteFilter: AutocompleteFilterComponent;
  @Output() pageReset: EventEmitter<FilterData> = new EventEmitter<FilterData>();
  @ViewChildren('filtercomp') filterComponents;
  filterConfig: FilterConfig;
  automationRuleModel: AutomationRulesModel;
  constructor(private readonly automationRulesService: AutomationRulesService,
    private readonly changeDetector: ChangeDetectorRef) {
    this.filterConfig = automationRulesService.getFilterConfig(this);
    this.automationRuleModel = new AutomationRulesModel();
  }

  ngOnInit() {
  }

  translateValues(value: string) {
    return value;
  }
  getRuleName(data: ElasticResponseModel) {
    let rule = [];
    if (data && data.hits && data.hits.hits) {
      const ruleNameData = data.hits.hits.map((value) => {
        return value._source.RuleName;
      });
      const uniqRule = utils.uniq(ruleNameData);
      rule = uniqRule.map((ruleName) => {
        return {
          'label': ruleName,
          'value': ruleName
        };
      });
    }
    return rule;
  }
  associationLevelList(data: AssociationLevelModel) {
    let associationLevel = [];
    if (data && data._embedded && data._embedded.ruleTypes) {
      associationLevel = data._embedded.ruleTypes.map((value) => {
        return {
          'label': value.ruleTypeDescription,
          'value': value.ruleTypeDescription
        };
      });
    }
    return associationLevel;
  }
  ruleCategoryList(data) {
    let ruleCategory = [];
    if (data && data._embedded && data._embedded.ruleCategories) {
      ruleCategory = data._embedded.ruleCategories.map((value) => {
        return {
          'label': value.ruleCategoryDescription,
          'value': value.ruleCategoryDescription
        };
      });
    }
    return ruleCategory;
  }
  setSelectedValue(event, filterField) {
    this.automationRuleModel.filterVariables.from = 0;
    this.automationRuleModel.filterVariables[filterField] = event.map((data) => {
      return data.value;
    });
    this.getFilteredGridResults();
  }
  onRuleNameSelected(event: DropDownValue[]) {
    this.automationRuleModel.filterVariables.from = 0;
    this.automationRuleModel.filterVariables.ruleNameSelected = [];
    event.forEach(element => {
      this.automationRuleModel.filterVariables.ruleNameSelected.push(element.value);
    });
    this.getFilteredGridResults();
  }
  onLastUpdatedOnSelected(lastUpdatedOn) {
    this.automationRuleModel.filterVariables.from = 0;
    this.automationRuleModel.filterVariables.lastUpdatedFromTimeStamp = this.getDateAndTime(lastUpdatedOn, 'startDateValue', 'startTime');
    this.automationRuleModel.filterVariables.lastUpdatedToTimeStamp = this.getDateAndTime(lastUpdatedOn, 'endDateValue', 'endTime');
    this.getFilteredGridResults();
  }

  getDateAndTime(lastUpdatedOn, dateValue, timeValue) {
    return lastUpdatedOn[dateValue] && lastUpdatedOn[timeValue] ?
      `${lastUpdatedOn[dateValue]} ${lastUpdatedOn[timeValue].split('')[0] !== '0' ?
        lastUpdatedOn[timeValue] : lastUpdatedOn[timeValue].split('').slice(1).join('')} CST` : '';
  }

  onStatusSelected(data) {
    this.automationRuleModel.filterVariables.from = 0;
    this.automationRuleModel.filterVariables.statusSelected = [];
    if (data && data.value) {
      this.automationRuleModel.filterVariables.statusSelected.push(data.value);
    }
    this.getFilteredGridResults();
  }

  getLastUpdatedBy(data) {
    let lastUpdatedBy = [];
    if (data && data.hits && data.hits.hits && data.hits.hits.length > 0) {
      lastUpdatedBy = data.hits.hits.map((value) => {
        return {
          'label': `${value._source.LastUpdateProgramName} (${value._source.LastUpdateUserID.toUpperCase()})`,
          'value': value._source.LastUpdateUserID
        };
      });
      lastUpdatedBy = utils.uniqBy(lastUpdatedBy, 'value');
    }
    return lastUpdatedBy;
  }

  removeDuplicateOperator(params: Array<AttributeType>, property: string): Array<AttributeType> {
    return params.filter((obj, value, arr) => {
      return arr.map(mapObj => mapObj[property]).indexOf(obj[property]) === value;
    });
  }
  onLastUpdatedBySelected(event) {
    this.automationRuleModel.filterVariables.from = 0;
    this.automationRuleModel.filterVariables.lastUpdatedBySelected = [];
    this.automationRuleModel.filterVariables.lastUpdatedBySelected = event.map((lastUpdatedBy) => {
      return lastUpdatedBy.value;
    });
    this.getFilteredGridResults();
  }

  getFilteredGridResults() {
    this.pageReset.emit({
      filterQuery: this.automationRuleModel.filterVariables
    });
  }
  onClearFilters() {
    this.filterComponents.forEach(filterCompItem => {
      filterCompItem.onReset(false);
    });
    this.automationRuleModel.filterVariables.ruleNameSelected = [];
    this.automationRuleModel.filterVariables.associationLevelSelected = [];
    this.automationRuleModel.filterVariables.ruleCategorySelected = [];
    this.automationRuleModel.filterVariables.lastUpdatedBySelected = [];
    this.automationRuleModel.filterVariables.statusSelected = [];
    this.automationRuleModel.filterVariables.lastUpdatedFromTimeStamp = '';
    this.automationRuleModel.filterVariables.lastUpdatedToTimeStamp = '';
    this.automationRuleModel.filterVariables.from = 0;
    this.automationRuleModel.filterVariables.size = 25;
    this.onCloseFilterPanel();
    this.getFilteredGridResults();
  }

  onCloseFilterPanel() {
    this.filterComponents.forEach(filterCompItem => {
      filterCompItem.closePanel();
    });
  }

  onFilterIconClicked() {
    this.filterComponents.forEach(filterCompItem => {
      switch (filterCompItem.constructor.name) {
        case 'ListingFilterComponent':
        case 'AutocompleteFilterComponent':
          if (filterCompItem.selectedValues.length === 0) {
            filterCompItem.closePanel();
          }
          break;
        case 'RadioFilterComponent':
          if (!filterCompItem.selectedValue) {
            filterCompItem.closePanel();
          }
          break;
        case 'DateFilterComponent':
          if (!filterCompItem.validDate.startDate && !filterCompItem.validDate.endDate
            && !filterCompItem.validDate.startDateValue && !filterCompItem.validDate.endDateValue
            && !filterCompItem.validDate.startTime && !filterCompItem.validDate.endTime) {
            filterCompItem.closePanel();
          }
          break;
      }
    });
    this.changeDetector.detectChanges();
  }
}
