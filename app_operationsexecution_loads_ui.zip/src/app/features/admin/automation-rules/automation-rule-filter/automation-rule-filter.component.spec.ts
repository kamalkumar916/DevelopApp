import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MessageService } from 'primeng/components/common/messageservice';
import { PanelModule } from 'primeng/panel';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { RadioButtonModule } from 'primeng/radiobutton';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';

import { JbhFiltersModule } from '../../../../shared/jbh-filters/jbh-filters.module';

import { AutomationRuleFilterComponent } from './automation-rule-filter.component';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { AssociationLevelModel } from '../predefined-rules/predefined-rules-filter/model/predefined-rules-filter.interface';
import { configureTestSuite } from 'ng-bullet';

describe('AutomationRuleFilterComponent', () => {
  let component: AutomationRuleFilterComponent;
  let fixture: ComponentFixture<AutomationRuleFilterComponent>;
  let dataElastic: ElasticResponseModel;
  let associationLevelListData: AssociationLevelModel;
  const rule = [{
    'label': 'check',
    'value': 'check'
  }];

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule, JbhFiltersModule,
        PanelModule, CheckboxModule, FormsModule, CalendarModule, AutoCompleteModule, RadioButtonModule],
      providers: [UserService, AppConfigService, MessageService],
      declarations: [AutomationRuleFilterComponent]
    })
      .compileComponents();
  });


  beforeEach(() => {
    fixture = TestBed.createComponent(AutomationRuleFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getFilteredGridResults should emit pageReset', () => {
    spyOn(component.pageReset, 'emit');
    component.onClearFilters();
    expect(component.pageReset.emit).toHaveBeenCalled();
  });

  it('translateValues have been called', () => {
    const returnValue = component.translateValues('test');
    expect(returnValue).toMatch('test');
  });
  it('getRuleName should return an array of object with label property equal to automation', () => {
    dataElastic = {
      hits: {
        hits: [{
          sort: [],
          _id: '',
          _index: '',
          _score: null,
          _type: '',
          _source: {
            RuleName: 'automation'
          }
        }],
        max_score: 1,
        total: 1
      },
      timed_out: false,
      took: 1,
      _shards: {
        total: 1,
        successful: 1,
        skipped: 1,
        failed: 1
      },
      aggregations: ''
    };
    const returnValue = component.getRuleName(dataElastic);
    expect(returnValue[0].label).toEqual('automation');
  });
  it('associationLevelList has been called', () => {
    associationLevelListData = {
      _embedded: {
        ruleTypes: [{
          createTimestamp: '',
          createProgramName: '',
          lastUpdateProgramName: '',
          createUserId: '',
          lastUpdateUserId: '',
          ruleCategoryCode: '',
          ruleCategoryDescription: '',
          ruleTypeDescription: 'check',
          ruleTypeCode: '',
          effectiveTimestamp: '',
          expirationTimestamp: '',
          lastUpdateTimestampString: '',
          _links: {
            self: {
              href: '',
              templated: ''
            },
            ruleCategory: {
              href: '',
              templated: ''
            }
          }
        }]
      },
      _links: {
        self: {
          href: '',
          templated: ''
        },
        profile: {
          href: '',
          templated: ''
        }
      },
      page: {
        size: 1,
        totalElements: 1,
        totalPages: 1,
        number: 1
      }
    };
    const associationData = component.associationLevelList(associationLevelListData);
    expect(associationData).toBeDefined(rule);
  });

  it('ruleCategoryList should return an array of length 1', () => {
    const returnValue = component.ruleCategoryList({
      _embedded: {
        ruleCategories: [{
          ruleCategoryDescription: ''
        }]
      }
    });
    expect(returnValue.length).toEqual(1);
  });

  it('getDateAndTime to form date time string', () => {
    expect(component.getDateAndTime('', '', '')).toBe('');
  });

  it('getLastUpdatedBy should return an array of object of length 1', () => {
    const data = {
      hits: {
        hits: [{
          _source: {
            LastUpdateProgramName: '',
            LastUpdateUserID: ''
          }
        }]
      }
    };
    expect(component.getLastUpdatedBy(data).length).toEqual(1);
  });

  it('onStatusSelected should set the value of from property to 0', () => {
    spyOn(component, 'getFilteredGridResults');
    const data = {
      value: {}
    };
    component.onStatusSelected(data);
    expect(component.automationRuleModel.filterVariables.from).toBe(0);
  });

  it('removeDuplicateOperator should return the params array of length 1', () => {
    const returnValue = component.removeDuplicateOperator([{ label: '', value: { code: '', description: '' } }], 'label');
    expect(returnValue.length).toEqual(1);
  });

  it('onLastUpdatedBySelected should set the value of from equal to 0', () => {
    component.onLastUpdatedBySelected([{ value: '' }]);
    expect(component.automationRuleModel.filterVariables.from).toEqual(0);
  });

  it('setSelectedValue should set the value of from to 0', () => {
    spyOn(component, 'getFilteredGridResults');
    component.setSelectedValue([{ value: '' }], '');
    expect(component.automationRuleModel.filterVariables.from).toEqual(0);
  });

  it('onRuleNameSelected should set the value of from to 0', () => {
    spyOn(component, 'getFilteredGridResults');
    component.onRuleNameSelected([{ label: '', value: '' }]);
    expect(component.automationRuleModel.filterVariables.from).toEqual(0);
  });

  it('onLastUpdatedOnSelected should set the value of from to 0', () => {
    component.onLastUpdatedOnSelected({ startTime: '10', startDateValue: '10' });
    expect(component.automationRuleModel.filterVariables.from).toEqual(0);
  });

  it('onFilterIconClicked is called with name ListingFilterComponent', () => {
    const data = [{
      constructor: {
        name: 'ListingFilterComponent'
      },
      selectedValues: [],
      closePanel: jasmine.createSpy()
    }];
    component.filterComponents = data;
    component.onFilterIconClicked();
    expect(component.filterComponents[0].closePanel).toHaveBeenCalled();
  });

  it('onFilterIconClicked is called with name RadioFilterComponent', () => {
    const data = [{
      constructor: {
        name: 'RadioFilterComponent'
      },
      selectedValues: [],
      selectedValue: null,
      closePanel: jasmine.createSpy()
    }];
    component.filterComponents = data;
    component.onFilterIconClicked();
    expect(component.filterComponents[0].closePanel).toHaveBeenCalled();
  });

  it('onFilterIconClicked is called with name DateFilterComponent', () => {
    const data = [{
      constructor: {
        name: 'DateFilterComponent'
      },
      selectedValues: [],
      validDate: {},
      closePanel: jasmine.createSpy()
    }];
    component.filterComponents = data;
    component.onFilterIconClicked();
    expect(component.filterComponents[0].closePanel).toHaveBeenCalled();
  });
});
