export interface PredefinedRulesData {
  ruleName: string;
  ruleDescription: string;
  associationLevel: string;
  ruleCategory: string;
}

export interface PredefinedQueryData {
  first: number;
  size: number;
  searchValue: string;
  ruleName: string[] | '';
  ruleNameQuery: string;
  associationLevel: Array<string>;
  associationLevelQuery: string;
  ruleCategory: Array<string>;
  ruleCategoryQuery: string;
}
export interface PageEvent {
  first: number;
  rows: number;
}
export interface RowSelect {
  data: RowSelectRuleId;
  index: number;
   type: string;
}
export interface RowSelectRuleId {
  ruleDetailId: number;
}
export interface ColumnSorting {
  name: string;
  queryKey: string;
}
