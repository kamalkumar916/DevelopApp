import { Breadcrumb } from '../../../../model/breadcrumb.interface';
import { PredefinedQueryData, PredefinedRulesData, ColumnSorting } from '../model/predefined-rules.interface';
import { MenuItem } from 'primeng/api';

export class PredefinedRulesModel {
    breadcrumb: Breadcrumb[];
    subscribeFlag: boolean;
    predefinedRulesList: Array<PredefinedRulesData>;
    totalRecords: number;
    first: number;
    size: number;
    from: number;
    searchValue: string;
    searchInputValue: string;
    items: Array<MenuItem>;
    listEmptyFlag: boolean;
    filterFlag: boolean;
    predefinedObj: PredefinedQueryData;
    loadingFlag: boolean;
    showFilter: boolean;
    tableColumnHeaders: ColumnSorting[];
    sortField: string;
    sortOrder: string;
    ascendingOrder: string;
    decendingOrder: string;

    constructor() {
        this.breadcrumb = [
            { label: 'Administration', routerLink: [''] },
            {
                label: 'Automation Rules',
                routerLink: ['/admin/automationrules']
            }];
        this.predefinedObj = {
            first: 0,
            size: 25,
            searchValue: '',
            ruleName: [],
            ruleNameQuery: '*',
            associationLevel: [],
            associationLevelQuery: '*',
            ruleCategory: [],
            ruleCategoryQuery: '*'
        };
        this.subscribeFlag = true;
        this.first = 0;
        this.size = 25;
        this.predefinedRulesList = [];
        this.searchValue = '';
        this.searchInputValue = '';
        this.listEmptyFlag = false;
        this.filterFlag = true;
        this.loadingFlag = false;
        this.showFilter = false;
        this.ascendingOrder = 'asc';
        this.decendingOrder = 'desc';
        this.tableColumnHeaders = [{
            'name': 'Rule Name',
            'queryKey': 'RuleName.keyword'
        },
        {
            'name': 'Rule Description',
            'queryKey': 'RuleDescription.keyword'
        },
        {
            'name': 'Association Level',
            'queryKey': 'RuleTypeDescription.keyword'
        },
        {
            'name': 'Rule Category',
            'queryKey': 'RuleCategoryDescription.keyword'
        }];
    }
}
