import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, takeWhile } from 'rxjs/operators';
import * as moment from 'moment';

import { SpinnerService } from '../../../../shared/spinner/index';

import { PredefinedRulesModel } from './model/predefined-rules.model';
import { PredefinedRulesService } from './services/predefined-rules.service';
import { PredefinedRulesQuery } from './query/predefined-rules.query';
import { PredefinedRulesUtility } from './services/predefined-rules.utility';
import {
  ElasticResponseModel,
  HitsModel
} from '../../../model/elastic-response.interface';
import { PredefinedRulesFilterComponent } from './predefined-rules-filter/predefined-rules-filter.component';
import {
  PageEvent,
  PredefinedQueryData,
  RowSelect,
  ColumnSorting
} from './model/predefined-rules.interface';

@Component({
  selector: 'app-predefined-rules',
  templateUrl: './predefined-rules.component.html',
  styleUrls: ['./predefined-rules.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [PredefinedRulesFilterComponent]
})
export class PredefinedRulesComponent implements OnDestroy, OnInit {
  @ViewChild('predefinedRulesTable') predefinedRules;
  @ViewChild('downloadExcel') downloadExcel: ElementRef;
  @ViewChild(PredefinedRulesFilterComponent)
  predefinedRulesFilter: PredefinedRulesFilterComponent;
  searchTerms: Subject<string>;
  predefinedRulesModel: PredefinedRulesModel;
  constructor(
    private readonly predefinedRuleService: PredefinedRulesService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly spinnerService: SpinnerService,
    private readonly router: Router
  ) {
    this.predefinedRulesModel = new PredefinedRulesModel();
    this.searchTerms = new Subject<string>();
    this.predefinedRulesModel.sortField = 'Rule Name';
    this.predefinedRulesModel.sortOrder = this.predefinedRulesModel.ascendingOrder;
  }
  ngOnInit() {
    this.spinnerService.show();
    this.overFlowMenuData();
    this.subjectBehaviour();
    this.fetchPredefinedRules();
  }

  ngOnDestroy() {
    this.predefinedRulesModel.subscribeFlag = false;
  }

  fetchPredefinedRules() {
    this.predefinedRulesModel.loadingFlag = true;
    const automationQuery = PredefinedRulesQuery.getPredefinedRulesQuery(
      this.predefinedRulesModel.predefinedObj,
      this.predefinedRulesModel.predefinedObj.first,
      this.predefinedRulesModel.predefinedObj.size,
      this.predefinedRulesModel.tableColumnHeaders,
      this.predefinedRulesModel.sortField,
      this.predefinedRulesModel.sortOrder
    );
    this.predefinedRuleService
      .getPredefinedRules(automationQuery)
      .pipe(takeWhile(() => this.predefinedRulesModel.subscribeFlag))
      .subscribe((data: ElasticResponseModel) => {
        if (data && data.hits && data.hits.hits) {
          this.spinnerService.hide();
          this.predefinedRulesModel.loadingFlag = false;
          this.predefinedRulesModel.predefinedRulesList = data.hits.hits.map(
            (value: HitsModel) => {
              return {
                ruleName: value._source.RuleName,
                ruleDescription: value._source.RuleDescription,
                associationLevel: value._source.RuleTypeDescription,
                ruleCategory: value._source.RuleCategoryDescription,
                ruleDetailId: value._source.RuleDetailID
              };
            }
          );
          this.predefinedRulesModel.totalRecords = data.hits.total;
          this.changeDetector.detectChanges();
        } else {
          this.predefinedRulesModel.loadingFlag = false;
        }
      });
  }

  onRowSelect(event: RowSelect) {
    this.router.navigate(['/admin/automationrules/configurenewrule'], {
      queryParams: {
        ruledetailid: event.data.ruleDetailId
      }
    });
  }

  overFlowMenuData() {
    this.predefinedRulesModel.items = [
      {
        label: 'Export to Excel',
        command: onclick => {
          this.exportToExcel();
        }
      }
    ];
  }

  onSearch(event: string) {
    this.searchTerms.next(event);
  }
  subjectBehaviour() {
    this.searchTerms
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeWhile(() => this.predefinedRulesModel.subscribeFlag)
      )
      .subscribe(shareData => {
        if (shareData) {
          if (shareData['target']['value'].match('^[0-9,]*$')) {
            this.predefinedRulesModel.searchValue = shareData['target'][
              'value'
            ].replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
            this.predefinedRulesModel.searchValue = this.predefinedRulesModel.searchValue.replace(
              /\,/g,
              ''
            );
          } else if (shareData['target']['value'].match('[()]')) {
            this.predefinedRulesModel.searchValue = shareData['target'][
              'value'
            ].replace(/[()]/g, '');
          } else {
            this.predefinedRulesModel.searchValue = shareData['target'][
              'value'
            ].replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
          }
          if (this.predefinedRulesModel.searchValue) {
            this.predefinedRulesModel.predefinedObj['first'] = 0;
            this.predefinedRulesModel.predefinedObj['size'] = 25;
            this.predefinedRulesModel.predefinedObj[
              'searchValue'
            ] = this.predefinedRulesModel.searchValue;
            this.fetchPredefinedRules();
          } else {
            this.predefinedRulesModel.predefinedObj['first'] = 0;
            this.predefinedRules.first = 0;
            this.predefinedRulesModel.predefinedObj['size'] = 25;
            this.predefinedRulesModel.predefinedObj['searchValue'] = '';
            this.fetchPredefinedRules();
          }
        }
      });
  }

  resetPredefinedRuleFilter() {
    this.predefinedRulesModel.predefinedObj['ruleName'] = '';
    this.predefinedRulesModel.predefinedObj['ruleNameQuery'] = '*';
    this.predefinedRulesModel.predefinedObj['associationLevel'] = [];
    this.predefinedRulesModel.predefinedObj['associationLevelQuery'] = '*';
    this.predefinedRulesModel.predefinedObj['ruleCategory'] = [];
    this.predefinedRulesModel.predefinedObj['ruleCategoryQuery'] = '*';
  }
  exportToExcel() {
    const excelParam = {};
    const displayFields = PredefinedRulesUtility.getExcelHeaders();
    excelParam['displayFields'] = displayFields;
    this.predefinedRulesModel.size = 1000;
    this.predefinedRulesModel.from = 0;
    PredefinedRulesUtility.objectParamValue(this.predefinedRulesModel);
    const excelDownloadQuery = PredefinedRulesQuery.getPredefinedRulesQuery(
      this.predefinedRulesModel.predefinedObj,
      this.predefinedRulesModel.from,
      this.predefinedRulesModel.size,
      this.predefinedRulesModel.tableColumnHeaders,
      this.predefinedRulesModel.sortField,
      this.predefinedRulesModel.sortOrder
    );
    excelParam['elasticSearchQuery'] = excelDownloadQuery;
    this.exportToExcelFunction(excelParam, this.downloadExcel);
  }
  exportToExcelFunction(tableParam: object, downloadExcel: ElementRef) {
    this.predefinedRuleService
      .excelDownload(tableParam)
      .pipe(takeWhile(() => this.predefinedRulesModel.subscribeFlag))
      .subscribe((data: object) => {
        if (data) {
          this.downloadFile(data, downloadExcel);
        }
        this.changeDetector.detectChanges();
      });
  }
  downloadFile(data: object, downloadExcel: ElementRef) {
    const fileName = `Predefined Rules ${moment().format(
      'YYYY-MM-DD'
    )} at ${moment().format('hh.mm.ss A')}.xlsx`;
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      downloadExcel.nativeElement.href = URL.createObjectURL(data);
      downloadExcel.nativeElement.download = fileName;
      downloadExcel.nativeElement.click();
    }
  }
  onPage(event: PageEvent) {
    this.predefinedRulesModel.predefinedObj['first'] = event.first;
    this.predefinedRulesModel.predefinedObj['size'] = event.rows;
    this.fetchPredefinedRules();
  }
  filterValues(event: PredefinedQueryData) {
    this.predefinedRulesModel.predefinedObj['ruleName'] = event.ruleName
      ? event.ruleName
      : '';
    this.predefinedRulesModel.predefinedObj['ruleNameQuery'] =
      event.ruleName.length > 0 ? '' : '*';
    this.predefinedRulesModel.predefinedObj['associationLevel'] =
      event.associationLevel;
    this.predefinedRulesModel.predefinedObj['associationLevelQuery'] =
      event.associationLevel.length > 0 ? '' : '*';
    this.predefinedRulesModel.predefinedObj['ruleCategory'] =
      event.ruleCategory;
    this.predefinedRulesModel.predefinedObj['ruleCategoryQuery'] =
      event.ruleCategory.length > 0 ? '' : '*';
    this.predefinedRules.first = 0;
    this.predefinedRulesModel.predefinedObj.first = 0;
    this.predefinedRulesModel.predefinedObj.size = 25;
    this.fetchPredefinedRules();
  }
  onShowFilter() {
    if (this.predefinedRulesModel.showFilter) {
      this.predefinedRulesFilter.filterPanelreset();
    }
    this.predefinedRulesModel.filterFlag = !this.predefinedRulesModel.filterFlag;
    this.predefinedRulesModel.showFilter = true;
  }
  onSortSelect(selectedColumnName: ColumnSorting) {
    this.predefinedRulesModel.predefinedObj['first'] = 0;
    this.predefinedRulesModel.predefinedObj['size'] = 25;
    this.predefinedRules.first = 0;
    this.predefinedRules.size = 25;
    if (
      this.predefinedRulesModel.sortField &&
      this.predefinedRulesModel.sortField === selectedColumnName['name']
    ) {
      this.predefinedRulesModel.sortField = selectedColumnName['name'];
      this.predefinedRulesModel.sortOrder =
        this.predefinedRulesModel.sortOrder ===
          this.predefinedRulesModel.decendingOrder ? this.predefinedRulesModel.ascendingOrder : this.predefinedRulesModel.decendingOrder;
      this.fetchPredefinedRules();
    } else {
      this.predefinedRulesModel.sortField = selectedColumnName['name'];
      this.predefinedRulesModel.sortOrder = this.predefinedRulesModel.ascendingOrder;
      this.fetchPredefinedRules();
    }
  }
}
