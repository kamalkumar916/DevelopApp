import { FilterValues, RuleDetail } from './predefined-rules-filter.interface';
import { ListItem } from '../../../../../model/listitem.interface';

export class PredefinedRulesFilterModel {
    searchResults: boolean;
    subscribeFlag: boolean;
    ruleNameList: string[];
    ruleNameInput: string[];
    invalidRuleName: boolean;
    associationLevelList: ListItem[];
    ruleCategoryList: ListItem[];
    filterData: FilterValues;
    associationLevelInput: string[];
    ruleCategoryInput: string[];
    ruleNamePanelFlag: boolean;
    associationPanelFlag: boolean;
    ruleCategoryPanelFlag: boolean;
    constructor() {
        this.subscribeFlag = true;
        this.invalidRuleName = false;
        this.ruleNameInput = [];
        this.ruleNameList = [];
        this.associationLevelInput = [];
        this.ruleCategoryInput = [];
        this.filterData = {
            'ruleName': [],
            'associationLevel': [],
            'ruleCategory': []
        };
        this.ruleNamePanelFlag = true;
        this.associationPanelFlag = true;
        this.ruleCategoryPanelFlag = true;
    }
}
