import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';


import { UserService } from '../../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { PanelModule } from 'primeng/panel';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule } from '@angular/forms';

import { JbhFiltersModule } from '../../../../../shared/jbh-filters/jbh-filters.module';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import {
  RuleNameValues
} from './model/predefined-rules-filter.interface';
import { PredefinedRulesFilterService } from './services/predefined-rules-filter.service';

import { PredefinedRulesFilterComponent } from './predefined-rules-filter.component';
import { AssociationLevelModel } from './model/predefined-rules-filter.interface';
import { configureTestSuite } from 'ng-bullet';

describe('PredefinedRulesFilterComponent', () => {
  let component: PredefinedRulesFilterComponent;
  let fixture: ComponentFixture<PredefinedRulesFilterComponent>;
  let ruleNameTypeaheadData: ElasticResponseModel;
  let associationLevelListData: AssociationLevelModel;
  const rule: RuleNameValues[] = [];

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule, JbhFiltersModule, CheckboxModule, PanelModule, FormsModule],
      providers: [UserService, AppConfigService, PredefinedRulesFilterService],
      declarations: [PredefinedRulesFilterComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedRulesFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('resetValues have been called', () => {
    component.resetValues();
    expect(component.predefinedRulesFilterModel.ruleNameInput.length).toBe(0);
  });
  it('associationLevelList have been called', () => {
    associationLevelListData = {
      _embedded: {
        ruleTypes: [{
          createTimestamp: '',
          createProgramName: '',
          lastUpdateProgramName: '',
          createUserId: '',
          lastUpdateUserId: '',
          ruleCategoryCode: '',
          ruleCategoryDescription: '',
          ruleTypeDescription: 'check',
          ruleTypeCode: '',
          effectiveTimestamp: '',
          expirationTimestamp: '',
          lastUpdateTimestampString: '',
          _links: {
            self: {
              href: '',
              templated: ''
            },
            ruleCategory: {
              href: '',
              templated: ''
            }
          }
        }]
      },
      _links: {
        self: {
          href: '',
          templated: ''
        },
        profile: {
          href: '',
          templated: ''
        }
      },
      page: {
        size: 1,
        totalElements: 1,
        totalPages: 1,
        number: 1
      },
    };
    const checkData = component.associationLevelList(associationLevelListData);
    expect(checkData).toBeDefined([{ 'lable': 'check', 'value': 'check' }]);
  });
  it('ruleNameTypeahead should return ruleNameType array', () => {
    ruleNameTypeaheadData = {
      hits: {
        hits: [{
          sort: [],
          _id: '',
          _index: '',
          _score: null,
          _source: {
            RuleName: ''
          },
          _type: ''
        }],
        max_score: 1,
        total: 1
      },
      timed_out: false,
      took: 1,
      _shards: {
        total: 1,
        successful: 1,
        skipped: 1,
        failed: 1
      },
      aggregations: ''
    };
    const ruleNameType = component.ruleNameTypeahead(ruleNameTypeaheadData);
    expect(ruleNameType).toBeDefined();
  });
  it('ruleCategoryList should return the ruleCategory array', () => {
    const data = {
      _embedded: {
        ruleCategories: [{
          ruleCategoryDescription: ''
        }]
      }
    };
    const ruleCategory = component.ruleCategoryList(data);
    expect(ruleCategory).toBeDefined();
  });
  it('onClearFilters should call the spy resetValues', () => {
    spyOn(component, 'resetValues');
    spyOn(component, 'onCloseFilterPanel');
    spyOn(component, 'onFilter');
    component.predefinedRulesFilterModel.ruleNameInput = [''];
    component.onClearFilters();
    expect(component.resetValues).toHaveBeenCalled();
  });
  it('onClearFilters should call the spy onCloseFilterPanel', () => {
    spyOn(component, 'resetValues');
    spyOn(component, 'onCloseFilterPanel');
    spyOn(component, 'onFilter');
    component.predefinedRulesFilterModel.associationLevelInput = [''];
    component.onClearFilters();
    expect(component.onCloseFilterPanel).toHaveBeenCalled();
  });
  it('onClearFilters should call the spy onFilter', () => {
    spyOn(component, 'resetValues');
    spyOn(component, 'onCloseFilterPanel');
    spyOn(component, 'onFilter');
    component.predefinedRulesFilterModel.ruleCategoryInput = [''];
    component.onClearFilters();
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onFilter should emit filterValues', () => {
    spyOn(component.filterValues, 'emit');
    component.onFilter();
    expect(component.filterValues.emit).toHaveBeenCalled();
  });
  it('setSelectedValue should call the spy onFilter', () => {
    spyOn(component, 'onFilter');
    component.setSelectedValue([{ value: [] }], 'ruleCategoryInput');
    expect(component.onFilter).toHaveBeenCalled();
  });
});
