import { ListItem } from '../../../../../model/listitem.interface';

export interface Page {
    size: number;
    totalElements: number;
    totalPages: number;
    number: number;
}

export interface Links {
    self: Self;
    profile: Self;
}

export interface Self {
    href: string;
    templated?: string;
}

export interface RuleCategoryEmbedded {
    ruleCategories: RuleDetail[];
}

export interface AssociationLevelEmbedded {
    ruleTypes: RuleDetail[];
}

export interface RuleDetail {
    createTimestamp: string;
    createProgramName: string;
    lastUpdateProgramName: string;
    createUserId: string;
    lastUpdateUserId: string;
    ruleCategoryCode?: string;
    ruleCategoryDescription?: string;
    ruleTypeDescription?: string;
    ruleTypeCode?: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: RuleLinks;
}

export interface RuleLinks {
    self: Self;
    ruleCategory: Self;
}

export interface RuleCategoryModel {
    _embedded: RuleCategoryEmbedded;
    _links: Links;
    page: Page;
}

export interface AssociationLevelModel {
    _embedded: AssociationLevelEmbedded;
    _links: Links;
    page: Page;
}

export interface FilterValues {
    ruleName: string[];
    associationLevel: string[];
    ruleCategory: string[];
}

export interface RuleNameValues {
    label: string;
    value: string;
}

export interface FilterConfigFields {
    title: string;
    url: string;
    query?: any;
    callback: ListItem[];
}

export interface FilterConfig {
    ruleName: FilterConfigFields;
    associationLevel: FilterConfigFields;
    ruleCategory: FilterConfigFields;
}
