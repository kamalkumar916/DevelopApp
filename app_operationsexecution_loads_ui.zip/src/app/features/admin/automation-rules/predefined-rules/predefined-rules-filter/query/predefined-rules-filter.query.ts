export class PredefinedRulesFilterQuery {
  static ruleNameFilterQuery() {
    return {
      query: {
        bool: {
          must: [
            {
              query_string: {
                default_field: 'RuleName',
                query: '*search-query-text*',
                default_operator: 'AND'
              }
            },
            {
              match: {
                RuleTypeCode: 'busunit'
              }
            },
            {
              range: {
                ExpirationTimestamp: {
                  gte: 'now'
                }
              }
            }
          ]
        }
      },
      sort: [
        {
          'RuleName.keyword': {
            order: 'asc'
          }
        }
      ],
      _source: [
        'RuleName'
      ]
    };
  }
}
