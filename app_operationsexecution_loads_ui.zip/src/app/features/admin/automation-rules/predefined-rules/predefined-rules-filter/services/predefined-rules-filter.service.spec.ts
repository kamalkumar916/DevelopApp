import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { PredefinedRulesFilterService } from './predefined-rules-filter.service';
import { AppConfigService } from '../../../../../../shared/service/app-config.service';


describe('PredefinedRulesFiltersServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [PredefinedRulesFilterService, AppConfigService]
    });
  });

  it('should be created', inject([PredefinedRulesFilterService], (service: PredefinedRulesFilterService) => {
    expect(service).toBeTruthy();
  }));
});
