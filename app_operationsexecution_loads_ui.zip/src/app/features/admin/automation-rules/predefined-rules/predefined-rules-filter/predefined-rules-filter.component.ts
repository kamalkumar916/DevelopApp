import {
  Component, EventEmitter, OnDestroy, OnInit, Output, ViewChild, ViewChildren
} from '@angular/core';

import { PredefinedRulesFilterModel } from './model/predefined-rules-filter.model';
import { PredefinedRulesFilterService } from './services/predefined-rules-filter.service';
import { AutocompleteFilterComponent } from '../../../../../shared/jbh-filters/autocomplete-filter/autocomplete-filter.component';
import { ElasticResponseModel, HitsModel } from '../../../../model/elastic-response.interface';
import {
  AssociationLevelModel, FilterConfig, FilterValues, RuleNameValues
} from './model/predefined-rules-filter.interface';

import { ListItem } from '../../../../model/listitem.interface';

@Component({
  selector: 'app-predefined-rules-filter',
  templateUrl: './predefined-rules-filter.component.html',
  styleUrls: ['./predefined-rules-filter.component.scss'],
})
export class PredefinedRulesFilterComponent implements OnInit, OnDestroy {

  @Output() readonly filterValues: EventEmitter<FilterValues> = new EventEmitter();

  @ViewChild(AutocompleteFilterComponent) autoCompleteFilter: AutocompleteFilterComponent;
  @ViewChildren('filtercomp') filterComponents;

  filterConfig: FilterConfig;
  predefinedRulesFilterModel: PredefinedRulesFilterModel;
  constructor(
    private readonly predefinedRuleFilterService: PredefinedRulesFilterService,
  ) {
    this.predefinedRulesFilterModel = new PredefinedRulesFilterModel();
    this.filterConfig = this.predefinedRuleFilterService.getFilterConfig(this);
  }
  ngOnInit() {
  }
  ruleNameTypeahead(data: ElasticResponseModel): ListItem[] {
    let rule: RuleNameValues[] = [];
    if (data && data.hits && data.hits.hits) {
      rule = data.hits.hits.map((value: HitsModel) => {
        return {
          'label': value._source.RuleName,
          'value': value._source.RuleName
        };
      });
    }
    return rule;
  }
  associationLevelList(data: AssociationLevelModel) {
    let associationLevel = [];
    if (data && data._embedded && data._embedded.ruleTypes) {
      associationLevel = data._embedded.ruleTypes.map((value) => {
        return {
          'label': value.ruleTypeDescription,
          'value': value.ruleTypeDescription
        };
      });
    }
    return associationLevel;
  }
  ruleCategoryList(data) {
    let ruleCategory = [];
    if (data && data._embedded && data._embedded.ruleCategories) {
      ruleCategory = data._embedded.ruleCategories.map((value) => {
        return {
          'label': value.ruleCategoryDescription,
          'value': value.ruleCategoryDescription
        };
      });
    }
    return ruleCategory;
  }
  setSelectedValue(event, filterField) {
    this.predefinedRulesFilterModel[filterField] = event.map((data) => {
      return data.value;
    });
    this.onFilter();
  }
  onFilter() {
    this.predefinedRulesFilterModel.filterData = {
      'ruleName': this.predefinedRulesFilterModel.ruleNameInput,
      'associationLevel': this.predefinedRulesFilterModel.associationLevelInput,
      'ruleCategory': this.predefinedRulesFilterModel.ruleCategoryInput
    };
    this.filterValues.emit(this.predefinedRulesFilterModel.filterData);
  }
  onClearFilters() {
    if (this.predefinedRulesFilterModel.ruleNameInput.length > 0 ||
      this.predefinedRulesFilterModel.associationLevelInput.length > 0 ||
      this.predefinedRulesFilterModel.ruleCategoryInput.length > 0) {
      this.resetValues();
      this.onCloseFilterPanel();
      this.onFilter();
    }
  }
  resetValues() {
    this.filterComponents.forEach(filterCompItem => {
      filterCompItem.onReset(false);
    });
    this.predefinedRulesFilterModel.ruleNameInput = [];
    this.predefinedRulesFilterModel.associationLevelInput = [];
    this.predefinedRulesFilterModel.ruleCategoryInput = [];
  }
  onCloseFilterPanel() {
    this.filterComponents.forEach(filterCompItem => {
      filterCompItem.closePanel();
    });
  }
  filterPanelreset() {
    this.filterComponents.forEach(filterCompItem => {
      if (filterCompItem.selectedValues.length === 0) {
        filterCompItem.closePanel();
      }
    });
  }
  ngOnDestroy() {
    this.predefinedRulesFilterModel.subscribeFlag = false;
  }
}
