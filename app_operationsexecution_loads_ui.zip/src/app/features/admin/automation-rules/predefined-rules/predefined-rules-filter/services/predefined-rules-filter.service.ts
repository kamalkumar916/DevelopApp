import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { AppConfigService } from '../../../../../../shared/service/app-config.service';
import { PredefinedRulesFilterQuery } from '../query/predefined-rules-filter.query';
import { FilterConfig } from '../model/predefined-rules-filter.interface';

@Injectable()
export class PredefinedRulesFilterService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('automationRules');
  }

  getFilterConfig(componentInstance: any): FilterConfig {
    return {
      ruleName: {
        title: 'Rule Name',
        url: this.endpoint.predefinedRulesList,
        callback: componentInstance.ruleNameTypeahead,
        query: PredefinedRulesFilterQuery.ruleNameFilterQuery()
      },
      associationLevel: {
        title: 'Association Level',
        url: this.endpoint.associationLevel,
        callback: componentInstance.associationLevelList,
      },
      ruleCategory: {
        title: 'Rule Category',
        url: this.endpoint.ruleCategory,
        callback: componentInstance.ruleCategoryList,
      }
    };
  }
}
