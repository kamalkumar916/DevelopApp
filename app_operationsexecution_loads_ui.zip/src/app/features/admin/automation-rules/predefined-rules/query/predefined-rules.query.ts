import { PredefinedQueryData, ColumnSorting } from '../model/predefined-rules.interface';
import * as lodashutils from 'lodash';

export class PredefinedRulesQuery {
  static getPredefinedRulesQuery(predefinedData: PredefinedQueryData, fromData: number, sizeData: number,
    tableColumnHeaders: ColumnSorting[], sortField: string, orderBy: string) {
    return {
      from: fromData,
      size: sizeData,
      query: {
        bool: {
          must: [
            {
              bool: {
                should: [
                  {
                    query_string: {
                      default_field: 'RuleName',
                      query: `*${predefinedData.searchValue}*`,
                      default_operator: 'AND'
                    }
                  },
                  {
                    query_string: {
                      default_field: 'RuleDescription',
                      query: `*${predefinedData.searchValue}*`,
                      default_operator: 'AND'
                    }
                  },
                  {
                    query_string: {
                      default_field: 'RuleTypeDescription',
                      query: `*${predefinedData.searchValue}*`,
                      default_operator: 'AND'
                    }
                  },
                  {
                    query_string: {
                      default_field: 'RuleCategoryDescription',
                      query: `*${predefinedData.searchValue}*`,
                      default_operator: 'AND'
                    }
                  }
                ]
              }
            },
            {
              bool: {
                must: [
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'RuleName',
                            query: `${predefinedData.ruleNameQuery}`
                          }
                        },
                        {
                          terms: {
                            'RuleName.keyword': (predefinedData.ruleName.length > 0) ?
                            predefinedData.ruleName : ['']
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'RuleCategoryDescription',
                            query: `${predefinedData.ruleCategoryQuery}`
                          }
                        },
                        {
                          terms: {
                            'RuleCategoryDescription.keyword':
                              (predefinedData.ruleCategory.length > 0) ? predefinedData.ruleCategory : ['']
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'RuleTypeDescription',
                            query: `${predefinedData.associationLevelQuery}`
                          }
                        },
                        {
                          terms: {
                            'RuleTypeDescription.keyword':
                              (predefinedData.associationLevel.length > 0) ? predefinedData.associationLevel : ['']
                          }
                        }
                      ]
                    }
                  }
                ]
              }
            },
            {
              match: {
                RuleTypeCode: 'busunit'
              }
            },
            {
              range: {
                ExpirationTimestamp: {
                  gte: 'now'
                }
              }
            }
          ]
        }
      },
      sort: [this.sortObject(tableColumnHeaders, sortField, orderBy)]
    };
  }
  static sortObject(tableColumnHeaders: ColumnSorting[] , sortField: string, orderBy: string): object {
    const sortObj = {};
    const responseData = lodashutils.find(tableColumnHeaders, { name: sortField });
    sortObj[responseData.queryKey] = { order: orderBy };
    return sortObj;
  }
}
