import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';


import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { FormsModule } from '@angular/forms';
import { PanelModule } from 'primeng/panel';
import { CheckboxModule } from 'primeng/checkbox';
import { TooltipModule } from 'primeng/tooltip';

import { DirectivesModule } from '../../../../shared/directives/directives.module';
import { JbhFiltersModule } from '../../../../shared/jbh-filters/jbh-filters.module';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { SpinnerService } from '../../../../shared/spinner/index';
import { PredefinedRulesService } from './services/predefined-rules.service';
import { PredefinedRulesComponent } from './predefined-rules.component';
import { PredefinedRulesFilterComponent } from './predefined-rules-filter/predefined-rules-filter.component';
import { configureTestSuite } from 'ng-bullet';
import { Router } from '@angular/router';
import { of } from 'rxjs/internal/observable/of';
import { By } from '@angular/platform-browser';

const getPredefinedRulesData = {
  timed_out: false,
  took: 9,
  _shards: {
    failed: 0,
    skipped: 0,
    successful: 3,
    total: 3
  },
  hits: {
    max_score: null,
    total: 48,
    timed_out: false,
    hits: [{
      _id: '31',
      _index: 'operationsexecution-automationrules-ruledetail-1-2019.06.04',
      _score: null,
      _type: 'doc',
      sort: ['Allowed Switch Distance'],
      _source: {
        CreateProgramName: 'SSIS',
        CreateTimestamp: '',
        CreateUserID: '',
        EffectiveTimestamp: '',
        ExpirationTimestamp: '',
        LastUpdateProgramName: 'SSIS',
        LastUpdateTimestamp: '',
        LastUpdateUserID: '',
        RuleBusinessProcessCode: 'Execution',
        RuleBusinessProcessDescription: 'Execution',
        RuleCategoryCode: 'AutoSwtch',
        RuleCategoryDescription: 'Automated Switch',
        RuleCategoryTypeAssociationID: 1,
        RuleCode: 'AlwStchDst',
        RuleComment: 'Check the configurable distance between the location of the truck and Switch location',
        RuleDescription: 'Check the configurable distance between the location of the truck and Switch location',
        RuleDetailID: 1,
        RuleInclusionExclusionTypeCode: 'Inclusion',
        RuleName: 'Allowed Switch Distance',
        RuleSequenceNumber: 0,
        RuleTypeCode: 'BusUnit',
        RuleTypeDescription: 'Business Unit',
        SendCustomerNotificationIndicator: 'N',
        _type: 'doc',
        RuleParameter: [{
          ParameterDefaultCharValue: 'NULL',
          ParameterDefaultDateValue: null,
          ParameterDefaultNumberValue: 100,
          ParameterTypeName: 'Allowed Switch Distance',
          RuleParameterCriteriaCode: 'AllSwtchDs',
          RuleParameterID: null,
          RuleParameterTypeCode: 'Miles',
          RuleParameterTypeDescription: 'Miles',
          RuleParameterValueTypeCode: 'Number'
        }],
        RuleCriteria: [{
          RuleCriteriaCode: 'BusUnit',
          RuleCriteriaDescription: 'Business Unit',
          RuleCriteriaDetailID: 31,
          RuleCriteriaLogicalOperatorAssociationID: 2,
          RuleLogicalOperator: [{
            RuleLogicalOperatorCode: 'Equal',
            RuleLogicalOperatorDescription: 'Equals'
          }]
        }]
      }
    }]
  }
};
class MockPredefinedRulesService {
  constructor() { }
  getPredefinedRules(automationQuery) {
    return of(getPredefinedRulesData);
  }
  excelDownload() {
    return of({});
  }
}

describe('PredefinedRulesComponent', () => {
  let component: PredefinedRulesComponent;
  let fixture: ComponentFixture<PredefinedRulesComponent>;
  const predefinedRulesFilter = jasmine.createSpyObj('PredefinedRulesFilterComponent', ['filterPanelreset']);

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, TooltipModule, BreadcrumbModule, TableModule,
        DirectivesModule, MenuModule, FormsModule, JbhFiltersModule, PanelModule,
        CheckboxModule],
      providers: [SpinnerService, UserService, AppConfigService,
        { provide: PredefinedRulesService, useClass: MockPredefinedRulesService }],
      declarations: [PredefinedRulesComponent, PredefinedRulesFilterComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('resetPredefinedRuleFilter should set the ruleName property to be empty string', () => {
    component.resetPredefinedRuleFilter();
    expect(component.predefinedRulesModel.predefinedObj['ruleName']).toBe('');
  });

  it('exportToExcel should set the size value to 1000', () => {
    spyOn(component, 'downloadFile');
    component.exportToExcel();
    expect(component.predefinedRulesModel.size).toEqual(1000);
  });

  it('onPage should set the first value to 0', () => {
    spyOn(component, 'fetchPredefinedRules');
    component.onPage({ first: 0, rows: 10 });
    expect(component.predefinedRulesModel.first).toEqual(0);
  });

  it('filterValues should set the size property to 25', () => {
    spyOn(component, 'fetchPredefinedRules');
    const event = {
      first: 0,
      size: 100,
      searchValue: '',
      ruleName: [''],
      ruleNameQuery: '',
      associationLevel: [''],
      associationLevelQuery: '',
      ruleCategory: [''],
      ruleCategoryQuery: ''
    };
    component.filterValues(event);
    expect(component.predefinedRulesModel.predefinedObj.size).toBe(25);
  });

  it('filterValues should call the spy fetchPredefinedRules', () => {
    spyOn(component, 'fetchPredefinedRules');
    const event = {
      first: 0,
      size: 100,
      searchValue: '',
      ruleName: [],
      ruleNameQuery: '',
      associationLevel: [],
      associationLevelQuery: '',
      ruleCategory: [],
      ruleCategoryQuery: ''
    };
    component.filterValues(event);
    expect(component.fetchPredefinedRules).toHaveBeenCalled();
  });

  it('onShowFilter should negate the filterFlag ', () => {
    component.predefinedRulesModel.showFilter = true;
    component.predefinedRulesModel.filterFlag = false;
    component.predefinedRulesFilter = predefinedRulesFilter;
    component.onShowFilter();
    expect(component.predefinedRulesModel.filterFlag).toBeTruthy();
  });

  it('onSortSelect should set the sortField property equal to descending', () => {
    spyOn(component, 'fetchPredefinedRules');
    component.predefinedRulesModel.sortField = 'descending';
    component.predefinedRulesModel.decendingOrder = 'descending';
    component.onSortSelect({ name: 'descending', queryKey: '' });
    expect(component.predefinedRulesModel.sortField).toEqual('descending');
  });

  it('onSortSelect should set the sortField property equal to ascending', () => {
    spyOn(component, 'fetchPredefinedRules');
    component.predefinedRulesModel.sortField = '';
    component.predefinedRulesModel.ascendingOrder = 'ascending';
    component.onSortSelect({ name: 'ascending', queryKey: '' });
    expect(component.predefinedRulesModel.sortField).toEqual('ascending');
  });

  it('onRowSelect should call the navigate spy', () => {
    const routerstub: Router = TestBed.get(Router);
    spyOn(routerstub, 'navigate');
    component.onRowSelect({ data: { ruleDetailId: 1 }, index: null, type: '' });
    expect(routerstub.navigate).toHaveBeenCalledWith(['/admin/automationrules/configurenewrule'], {
      queryParams: {
        ruledetailid: 1
      }
    });
  });

  it('fetchPredefinedRules should set the loadingFlag to be false', () => {
    const predefinedRuleService: PredefinedRulesService = TestBed.get(PredefinedRulesService);
    spyOn(predefinedRuleService, 'getPredefinedRules').and.returnValue(of({}));
    component.fetchPredefinedRules();
    expect(component.predefinedRulesModel.loadingFlag).toBeFalsy();
  });

  it('subjectBehaviour should call the spy fetchPredefinedRules', fakeAsync(() => {
    spyOn(component, 'fetchPredefinedRules');
    const input = fixture.debugElement.query(By.css('#predefinedRulesSearchText'));
    input.triggerEventHandler('input', { target: { value: '' } });
    tick(300);
    expect(component.fetchPredefinedRules).toHaveBeenCalled();
  }));
});
