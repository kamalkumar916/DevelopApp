import { PredefinedRulesModel } from '../model/predefined-rules.model';

export class PredefinedRulesUtility {

    static getExcelHeaders() {
        return ['ruleName', 'ruleDescription', 'associationLevel', 'ruleCategory'];
    }
    static objectParamValue(model) {
        model.objectParam = {};
        model.objectParam['from'] = model.from;
        model.objectParam['size'] = model.size;
        model.objectParam['searchValue'] =
        (model.searchValue)
          ? model.searchValue : '';
    }
}
