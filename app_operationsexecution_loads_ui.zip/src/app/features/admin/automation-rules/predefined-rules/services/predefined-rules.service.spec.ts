import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { PredefinedRulesService } from './predefined-rules.service';
import { configureTestSuite } from 'ng-bullet';
import { of } from 'rxjs/internal/observable/of';

describe('PredefinedRulesService', () => {
  let service: PredefinedRulesService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [PredefinedRulesService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(PredefinedRulesService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('getPredefinedRules have been created', () => {
    const predefinedRulesQuery = '';
    service.getPredefinedRules(predefinedRulesQuery).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.predefinedRulesList);
    expect(req.request.method).toEqual('POST');
  });

  it('getSearchPredefinedRules have been created', () => {
    const automationQuery = {};
    service.getSearchPredefinedRules(automationQuery).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.predefinedRulesList);
    expect(req.request.method).toEqual('POST');
  });

  it('excelDownload have been created', () => {
    let rtnval;
    spyOn(service, 'downloadExcel').and.returnValue(of(null));
    service.excelDownload({}).subscribe((data) => {
      rtnval = data;
    });
    expect(rtnval).toEqual(null);
  });

  it('downloadExcel have been called', () => {
    service.downloadExcel('abc', {}).subscribe();
    const req = httpTestingController.expectOne('abc');
    expect(req.request.method).toEqual('POST');
  });
});
