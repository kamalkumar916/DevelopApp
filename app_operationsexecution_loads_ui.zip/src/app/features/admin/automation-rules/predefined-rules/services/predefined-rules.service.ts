import { ElementRef, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
@Injectable()
export class PredefinedRulesService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('automationRules');
  }

  getPredefinedRules(predefinedRulesQuery: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.predefinedRulesList, predefinedRulesQuery);
  }
  getSearchPredefinedRules(automationQuery: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.predefinedRulesList, automationQuery);
  }
  excelDownload(requestParam: object): Observable<any> {
    return this.downloadExcel(this.endpoint.predefinedRulesDownloadExcel, requestParam);
  }
  downloadExcel<Response>(url: string, body: object, headers?: HttpHeaders | null, responseType?: 'blob'): Observable<any> {
    return this.http.post(url, body, { headers, responseType: 'blob' });
  }
}
