import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { SpinnerService } from '../../../shared/spinner/index';
import { UserService } from '../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../shared/service/app-config.service';
import { AutomationRulesService } from './services/automation-rules.service';

import { AutomationRulesComponent } from './automation-rules.component';

import { configureTestSuite } from 'ng-bullet';
import { DirectivesModule } from '../../../shared/directives/directives.module';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MenuModule } from 'primeng/menu';
import { PaginatorModule } from 'primeng/paginator';
import { PanelModule } from 'primeng/panel';
import { CheckboxModule } from 'primeng/checkbox';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { RadioButtonModule } from 'primeng/radiobutton';

import { AutomationRuleFilterComponent } from './automation-rule-filter/automation-rule-filter.component';
import { JbhFiltersModule } from '../../../shared/jbh-filters/jbh-filters.module';
import { TooltipModule } from 'primeng/tooltip';
import { FilterData } from './model/automation-rules.interface';
import { DateUtils } from '../../../shared/jbh-app-services/date-utils';
import { Router } from '@angular/router';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';

const selectedRule = {
  _index: '',
  _type: '',
  _id: '',
  _version: null,
  found: true,
  _source: {
    RuleDescription: '',
    LastUpdateUserID: '',
    RuleBusinessProcessCode: '',
    RuleBusinessProcessDescription: '',
    RuleCategoryDescription: '',
    RuleTypeCode: '',
    RuleCategoryCode: '',
    RuleCategoryTypeAssociationID: null,
    RuleSupersedeTypeCode: '',
    RuleDetailID: null,
    RuleTypeDescription: '',
    RuleCriteriaSetID: 1,
    RuleCode: '',
    RuleName: '',
    LastUpdateProgramName: '',
    ruleCriteriaDetails: [{
      ruleCriteriaCode: '',
      ruleCriteriaDescription: '',
      ruleLogicalOperatorCode: '',
      ruleLogicalOperatorDescription: '',
      ruleCriteriaValues: [{
        ruleCriteriaValue: '',
        ruleCriteriaDetailId: 1,
        ruleCriteriaValueDescription: ''
      }],
      editable: true,
      hasNoResult: true,
      ruleCriteriaId: null,
      compType: '',
      attributeItems: [{ label: '', value: '' }],
      isCheck: true
    }],
    RuleParameter: [{
      ruleParameterId: 1,
      ruleParameterCriteriaCode: '',
      ruleParameterTypeDescription: '',
      ruleParameterTypeName: '',
      ruleParameterTypeCode: '',
      ruleParameterValueTypeCode: '',
      ruleLogicalOperatorCode: '',
      ruleLogicalOperatorDescription: '',
      parameterNumberValue: null,
      parameterCharValue: '',
      parameterDateValue: ''
    }],
    EffectiveTimestamp: '',
    Status: '',
    ExpirationTimestamp: '',
    LastUpdateTimestamp: '',
  }
};
const getAutomationRulesData = {
  timed_out: false,
  took: 9,
  _shards: {
    failed: 0,
    skipped: 0,
    successful: 3,
    total: 3
  },
  hits: {
    max_score: null,
    total: 179,
    timed_out: false,
    hits: [{
      _id: '28',
      _index: 'operationsexecution-automationrules-ruleconfigurationdetail-1-2019.05.15',
      _score: null,
      _type: 'doc',
      _source: {
        EffectiveTimestamp: '',
        ExpirationTimestamp: '',
        LastUpdateProgramName: 'SSIS',
        LastUpdateTimestamp: '',
        LastUpdateUserID: '',
        RuleBusinessProcessCode: 'Execution',
        RuleBusinessProcessDescription: 'Execution',
        RuleCategoryCode: 'AutoSwtch',
        RuleCategoryDescription: 'Automated Switch',
        RuleCategoryTypeAssociationID: '1',
        RuleCode: 'AlwStchDst',
        RuleCriteriaSetID: 2,
        RuleDescription: 'Check the configurable distance between the location of the truck and Switch location',
        RuleDetailID: 1,
        RuleName: 'Allowed Switch Distance',
        RuleSupersedeTypeCode: null,
        RuleTypeCode: 'BusUnit',
        RuleTypeDescription: 'Business Unit',
        Status: 'Active',
        RuleParameter: [{
          ParameterCharValue: 'NULL',
          ParameterDateValue: null,
          ParameterNumberValue: 10,
          RuleLogicalOperatorCode: 'Equal',
          RuleLogicalOperatorDescription: 'Equals',
          RuleParameterCriteriaAssociationID: null,
          RuleParameterCriteriaCode: 'AllSwtchDs',
          RuleParameterID: 4,
          RuleParameterTypeCode: 'Miles',
          RuleParameterTypeDescription: 'Miles',
          RuleParameterValueTypeCode: 'Number'
        }],
        RuleCriteriaDetail: [{
          RuleCriteriaCode: 'BusUnit',
          RuleCriteriaDescription: 'Business Unit',
          RuleCriteriaLogicalOperatorAssociationID: 2,
          RuleDetailCriteriaAssociationID: 1,
          RuleLogicalOperatorCode: 'Equal',
          RuleLogicalOperatorDescription: 'Equals',
          RuleCriteriaValue: [{
            RuleCriteriaDetailID: 8,
            RuleCriteriaValue: 'JBT',
          }]
        }]
      },
      sort: ['Allowed Switch Distance']
    }]
  }
};

class MockautomationRuleService {
  constructor() { }
  getAutomationRules() {
    return of(getAutomationRulesData);
  }
  excelDownload() {
    return of({});
  }
}

describe('AutomationRulesComponent', () => {
  let component: AutomationRulesComponent;
  let fixture: ComponentFixture<AutomationRulesComponent>;
  const automationRuleFilter = jasmine.createSpyObj('AutomationRuleFilterComponent', ['onFilterIconClicked']);
  let eventData: FilterData;
  eventData = {
    filterQuery: {
      from: 1,
      size: 25,
      searchValue: '',
      ruleNameSelected: [],
      associationLevelSelected: [],
      ruleCategorySelected: [],
      lastUpdatedValueSelected: new Date(),
      lastUpdatedBySelected: [],
      statusSelected: [],
      lastUpdatedFromTimeStamp: '',
      lastUpdatedToTimeStamp: ''
    }
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, TableModule, FormsModule, MenuModule, BreadcrumbModule, DirectivesModule, PaginatorModule, JbhFiltersModule,
        PanelModule, CheckboxModule, CalendarModule, AutoCompleteModule, RadioButtonModule, TooltipModule],
      providers: [UserService, SpinnerService, AppConfigService, MessageService,
        { provide: AutomationRulesService, useClass: MockautomationRuleService }],
      declarations: [AutomationRulesComponent, AutomationRuleFilterComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutomationRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onClickFilterIcon should set showFilter value to be true', () => {
    component.automationRulesModel.showFilter = true;
    component.automationRuleFilter = automationRuleFilter;
    component.onClickFilterIcon();
    expect(component.automationRulesModel.showFilter).toBe(true);
  });

  it('onPageReset should call the spy fetchAutomationRules', () => {
    spyOn(component, 'fetchAutomationRules');
    component.automationRules = { first: 1 };
    component.onPageReset(eventData);
    expect(component.fetchAutomationRules).toHaveBeenCalled();
  });

  it('onSortSelect should set the value of first to 0', () => {
    spyOn(component, 'fetchAutomationRules');
    component.automationRules = {};
    component.automationRulesModel.sortField = 'Rule Name';
    component.automationRulesModel.descendingOrder = 'descending';
    component.onSortSelect('Rule Name');
    expect(component.automationRules.first).toEqual(0);
  });

  it('onSortSelect should set the sortOrder value to ascending', () => {
    spyOn(component, 'fetchAutomationRules');
    component.automationRules = {};
    component.automationRulesModel.sortField = 'Rule';
    component.automationRulesModel.ascendingOrder = 'ascending';
    component.onSortSelect('Rule Name');
    expect(component.automationRulesModel.sortOrder).toEqual('ascending');
  });

  it('getDefaultTimeZone', () => {
    spyOn(DateUtils, 'convertOffsetDateByDefaultTimeZone').and.returnValue('10/31/2019 12:05 AM CDT');
    expect(component.getDefaultTimeZone('10-31-2019 05:52:46')).toEqual('10/31/2019 12:05 AM CDT');
  });

  it('onRowSelect', () => {
    const routerstub: Router = TestBed.get(Router);
    spyOn(routerstub, 'navigate');
    component.onRowSelect(selectedRule);
    expect(routerstub.navigate).toHaveBeenCalledWith(['/admin/automationrules/viewconfigurerule'], {
      queryParams: { ruleCriteriaSetId: 1 }
    });
  });

  it('fetchAutomationRules should set loadingFlag to be false', () => {
    const automationRuleService: AutomationRulesService = TestBed.get(AutomationRulesService);
    spyOn(automationRuleService, 'getAutomationRules').and.returnValue(throwError(null));
    component.automationRulesModel.filterVariables.lastUpdatedFromTimeStamp = 'abc';
    component.fetchAutomationRules();
    expect(component.automationRulesModel.loadingFlag).toBeFalsy();
  });

  it('onPage should call the spy fetchAutomationRules', () => {
    spyOn(component, 'fetchAutomationRules');
    component.onPage({ first: 0, rows: 10 });
    expect(component.fetchAutomationRules).toHaveBeenCalled();
  });

  it('exportToExcel should set the size value equal to 1000', () => {
    spyOn(component, 'downloadFile');
    component.exportToExcel();
    expect(component.automationRulesModel.filterVariables.size).toEqual(1000);
  });
});
