import { ColumnSorting } from '../model/automation-rules.interface';
import * as lodashutils from 'lodash';

export class AutomationRulesQuery {
  static readonly searchQueryText = 'search-query-text';
  static readonly ruleNameKeyword = 'RuleName.keyword';
  static getRuleNameQuery() {
    return {
      size: 6,
      'query': {
        'function_score': {
          'query': {
            'query_string': {
              'fields': [
                'RuleName'
              ],
              'query': `${this.searchQueryText}*`,
              'default_operator': 'AND'
            }
          },
          'functions': [
            {
              'script_score': {
                'script': {
                  'lang': 'painless',
                  'source': `return (doc['RuleName.keyword'].value.toLowerCase().indexOf('${this.searchQueryText}') == 0)? 40: 0`
                }
              }
            },
            {
              'filter': {
                'query_string': {
                  'fields': [
                    'RuleName'
                  ],
                  'query': `${this.searchQueryText}*`,
                  'default_operator': 'AND'
                }
              },
              'weight': 30
            }
          ],
          'score_mode': 'sum'
        }
      },
      'sort': [
        {
          '_score': {
            'order': 'desc'
          }
        },
        {
          [this.ruleNameKeyword]: {
            'order': 'asc'
          }
        }
      ],
      '_source': [
        'RuleName'
      ]
    };
  }

  static getfilterLastUpdatedByQuery() {
    return {
      'query': {
        'function_score': {
          'query': {
            'query_string': {
              'fields': [
                'LastUpdateUserID',
                'LastUpdateProgramName'
              ],
              'query': `${this.searchQueryText}*`,
              'default_operator': 'AND'
            }
          },
          'functions': [
            {
              'script_score': {
                'script': {
                  'lang': 'painless',
                  'source':
                    `return (doc['LastUpdateProgramName.keyword'].value.toLowerCase().indexOf('${this.searchQueryText}') == 0)? 40: 0`
                }
              }
            },
            {
              'filter': {
                'query_string': {
                  'fields': [
                    'LastUpdateProgramName'
                  ],
                  'query': `${this.searchQueryText}*`,
                  'default_operator': 'AND'
                }
              },
              'weight': 30
            }
          ],
          'score_mode': 'sum'
        }
      },
      'sort': [
        {
          '_score': {
            'order': 'desc'
          }
        },
        {
          'LastUpdateProgramName.keyword': {
            'order': 'asc'
          }
        }
      ],
      '_source': [
        'LastUpdateUserID',
        'LastUpdateProgramName'
      ]
    };

  }
  static automationRuleGridSearchQuery(filterVariables, fromVal: number, sizeVal: number, sortField: string, sortOrder: string,
    tableColumnHeaders: ColumnSorting[]) {
    return {
      from: fromVal,
      size: sizeVal,
      'query': {
        'bool': {
          'must': [
            {
              'bool': {
                'should': [
                  {
                    'query_string': {
                      'default_field': 'RuleName',
                      'query': `*${filterVariables.searchValue}*`,
                      'default_operator': 'AND'
                    }
                  },
                  {
                    'query_string': {
                      'default_field': 'RuleCategoryDescription',
                      'query': `*${filterVariables.searchValue}*`,
                      'default_operator': 'AND'
                    }
                  },
                  {
                    'query_string': {
                      'default_field': 'RuleTypeDescription',
                      'query': `*${filterVariables.searchValue}*`,
                      'default_operator': 'AND'
                    }
                  },
                  {
                    'query_string': {
                      'default_field': 'Status',
                      'query': `*${filterVariables.searchValue}*`,
                      'default_operator': 'AND'
                    }
                  },
                  {
                    'query_string': {
                      'default_field': 'LastUpdateProgramName',
                      'query': `*${filterVariables.searchValue}*`,
                      'default_operator': 'AND'
                    }
                  },
                  {
                    'query_string': {
                      'default_field': 'LastUpdateTimestamp',
                      'query': `*${filterVariables.searchValue}*`,
                      'default_operator': 'AND'
                    }
                  },
                  {
                    'query_string': {
                      'default_field': 'LastUpdateUserID',
                      'query': `*${filterVariables.searchValue}*`,
                      'default_operator': 'AND'
                    }
                  }
                ]
              }
            },
            {
              'bool': {
                'must': [
                  {
                    'bool': {
                      'should': [

                        {
                          'query_string': {
                            'default_field': 'RuleName',
                            'query': filterVariables.ruleNameSelected[0] ? '' : '*'
                          }
                        },

                        {
                          'terms': {
                            [this.ruleNameKeyword]: (filterVariables.ruleNameSelected.length > 0) ?
                              filterVariables.ruleNameSelected : ['']
                          }
                        }
                      ]
                    }
                  },
                  {
                    'bool': {
                      'should': [
                        {
                          'query_string': {
                            'default_field': 'RuleCategoryDescription',
                            'query': filterVariables.ruleCategorySelected[0] ? '' : '*'
                          }
                        },
                        {
                          'terms': {
                            'RuleCategoryDescription.keyword': filterVariables.ruleCategorySelected
                          }
                        }
                      ]
                    }
                  },
                  {
                    'bool': {
                      'should': [
                        {
                          'query_string': {
                            'default_field': 'RuleTypeDescription',
                            'query': filterVariables.associationLevelSelected[0] ? '' : '*'
                          }
                        },
                        {
                          'terms': {
                            'RuleTypeDescription.keyword':
                              filterVariables.associationLevelSelected
                          }
                        }
                      ]
                    }
                  },
                  {
                    'bool': {
                      'should': [
                        {
                          'query_string': {
                            'default_field': 'Status',
                            'query': filterVariables.statusSelected.length > 0 ? '' : '*'
                          }
                        },
                        {
                          'terms': {
                            'Status.keyword': filterVariables.statusSelected
                          }
                        }
                      ]
                    }
                  },
                  {
                    'bool': {
                      'should': [
                        {
                          'bool': {
                            'should': [
                              {
                                'query_string': {
                                  'default_field': 'LastUpdateUserID',
                                  'query': filterVariables.lastUpdatedBySelected[0] ? '' : '*'
                                }
                              },
                              {
                                'terms': {
                                  'LastUpdateUserID.keyword': filterVariables.lastUpdatedBySelected
                                }
                              }
                            ]
                          }
                        },
                        {
                          'bool': {
                            'should': [
                              {
                                'query_string': {
                                  'default_field': 'LastUpdateProgramName',
                                  'query': filterVariables.lastUpdatedBySelected[0] ? '' : '*'
                                }
                              },
                              {
                                'terms': {
                                  'LastUpdateProgramName.keyword': filterVariables.lastUpdatedBySelected
                                }
                              }
                            ]
                          }
                        }
                      ]
                    }
                  },
                  {
                    'bool': {
                      'should': [
                        {
                          'query_string': {
                            'default_field': 'LastUpdateTimestamp',
                            'query': '*'
                          }
                        }
                      ]
                    }
                  }
                ]
              }
            }
          ]
        }
      },
      'sort': [this.getSortObject(sortField, sortOrder, tableColumnHeaders)]
    };
  }
  static getFilterQueryObjectForLastUpdatedTime() {
    return {
      'bool': {
        'should': [
          {
            'range': {
              'LastUpdateTimestamp.date': {
              }
            }
          }
        ]
      }
    };
  }
  static getSortObject(sortField: string, sortOrder: string, tableColumnHeaders: ColumnSorting[]) {
    const sortObj = {};
    if (sortField && sortOrder) {
      const responseData = lodashutils.find(tableColumnHeaders, { name: sortField });
      sortObj[responseData.queryKey] = { order: sortOrder };
    } else {
      sortObj[tableColumnHeaders[0].queryKey] = { order: 'asc' };
    }
    return sortObj;
  }
}
