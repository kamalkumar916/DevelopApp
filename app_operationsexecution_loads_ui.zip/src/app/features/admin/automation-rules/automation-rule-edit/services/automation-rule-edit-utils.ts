import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Injectable } from '@angular/core';
import * as LodashUtils from 'lodash';
import { AttributeType, RuleOperators, ExistingRule, RuleParameters, RuleCriteriaDetails } from '../../model/automation-rule.interface';
import { ListItem } from '../../../../model/listitem.interface';
import { FormValidationUtils } from '../../../../../shared/jbh-app-services/form-validation-utils';

export class AutomationRuleEditUtils {
    static getEditFormArray(rowIndex: number, value: string): any {
        return {
            'rowIndex_attribute': value,
            'rowIndex_operator': value,
            'rowIndex_value': value
        };
    }
    static getOverViewDetails(editModel, data) {
        editModel.attributeItems = JSON.parse(JSON.stringify(this.populateAttributes(data)));
        editModel.filterAttributeItems = this.populateAttributes(data);
        editModel.paramItems = this.populateParameters(data);
        editModel.booleanResultSets = this.populateBooleanResults(data);
    }
    static populateAttributes(dataSource: ExistingRule): Array<ListItem> {
        return dataSource._source.RuleCriteria.map((Items: RuleOperators) => {
            return {
                label: Items.RuleCriteriaDescription,
                value: Items.RuleCriteriaCode
            };
        });
    }
    static populateOPGroupValues(dataSource): Array<AttributeType> {
        return dataSource._embedded.operationalGroups.map((Items) => {
            return {
                'label': Items.operationalGroupDescription,
                'value': Items.operationalGroupDescription
            };
        });
    }
    static populateBooleanResults(dataSource): AttributeType[] {
        const ruleParameter = LodashUtils.cloneDeep(dataSource._source.RuleParameter);
        const booleanParameter = LodashUtils.filter(ruleParameter, { 'RuleParameterTypeCode': 'Boolean' });
        if (booleanParameter && booleanParameter.length > 0) {
            return booleanParameter.map((criteriaSets: any) => {
                return {
                    label: criteriaSets.ParameterTypeName,
                    value: criteriaSets.RuleParameterCriteriaCode
                };
            });
        } else {
            return [];
        }
    }
    static populateParameters(dataSource): Array<AttributeType> {
        return dataSource._source.RuleCriteria.map((Items: RuleOperators) => {
            return {
                label: Items.RuleLogicalOperator.RuleLogicalOperatorDescription,
                value: Items.RuleLogicalOperator.RuleLogicalOperatorCode
            };
        });
    }
    static populateValues(dataSource): Array<AttributeType> {
        return dataSource._embedded.serviceOfferingBusinessUnitTransitModeAssociations.map((Items) => {
            return {
                label: Items.financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode,
                value: Items.financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode
            };
        });
    }

    static getOperationalGroupRecords(dataSource): Array<AttributeType> {
        return dataSource.hits.hits.map((items) => {
            return {
                label: `${items._source.OperationalGroupDescription}(${items._source.OperationalGroupCode})`,
                value: items._source.OperationalGroupCode
            };
        });
    }
    static getScacRecords(dataSource): Array<AttributeType> {
        return dataSource.hits.hits.map((Items => {
            return {
                value: Items._source.scac,
                label: Items._source.scac
            };
        }));
    }
    static getRuleParamDetails(dataSource): any {
        const textRuleValue = dataSource.editRuleForm.controls.txtResultSetting.controls;
        const resultValue = dataSource.editRuleForm.controls.resultSetting.value;
        let paramDetails = [];
        const sourceRuleParameters = dataSource.ruleOverViewDetails.RuleParameter;
        if (resultValue && Array.isArray(resultValue)) {
            paramDetails = resultValue.map((paramValue) => {
                const ruleIndex = LodashUtils.findIndex(sourceRuleParameters, { 'RuleParameterCriteriaCode': paramValue.value });
                return this.getRuleDetails(dataSource, ruleIndex, 'Y');
            });
        }
        if (textRuleValue && textRuleValue.length > 0) {
            let i = 0;
            textRuleValue.forEach((ruleValue) => {
                const value = ruleValue.controls.resultValue.value;
                const ruleIndex = LodashUtils.findIndex(dataSource.ruleOverViewDetails.RuleParameter,
                    { 'RuleParameterCriteriaCode': dataSource.textResultValue[i].ruleParameterCriteriaCode });
                paramDetails.push(this.getRuleDetails(dataSource, ruleIndex, value));
                i++;
            });
        }
        return paramDetails;
    }
    static getRuleDetails(dataSource, index, paramValue): RuleParameters {
        const ruleParameter = dataSource && dataSource.ruleOverViewDetails && dataSource.ruleOverViewDetails.RuleParameter &&
            dataSource.ruleOverViewDetails.RuleParameter[index] ? dataSource.ruleOverViewDetails.RuleParameter[index] : null;
        const ruleParameterValueTypeCode = this.getRuleValueOrNull(ruleParameter, 'RuleParameterValueTypeCode');
        return {
            ruleParameterId: null,
            ruleParameterCriteriaCode: this.getRuleValueOrNull(ruleParameter, 'RuleParameterCriteriaCode'),
            ruleParameterTypeName: null,
            ruleParameterTypeCode: this.getRuleValueOrNull(ruleParameter, 'RuleParameterTypeDescription'),
            ruleParameterValueTypeCode,
            ruleLogicalOperatorCode: dataSource.logicalOperatorCode,
            ruleLogicalOperatorDescription: dataSource.logicalOperatorDescription,
            parameterNumberValue: ruleParameterValueTypeCode &&
                ruleParameterValueTypeCode.toLowerCase() === 'number' ? paramValue : null,
            parameterCharValue: ruleParameterValueTypeCode &&
                ruleParameterValueTypeCode.toLowerCase() === 'char' ?
                paramValue : null,
            parameterDateValue: ruleParameterValueTypeCode &&
                ruleParameterValueTypeCode.toLowerCase() === 'date' ?
                paramValue : null
        };
    }
    static getRuleValueOrNull(ruleParameter, fieldName) {
        return ruleParameter && ruleParameter[fieldName] ? ruleParameter[fieldName] : null;
    }
    static getTextResultValue(resultArray) {
        return resultArray.map((parameterValues) => {
            if (parameterValues.ruleParameterValueTypeCode.toLowerCase() === 'number') {
                return {
                    resultValue: parameterValues.parameterNumberValue
                };
            } else if (parameterValues.ruleParameterValueTypeCode.toLowerCase() === 'char') {
                return {
                    resultValue: parameterValues.parameterCharValue
                };
            } else {
                return {
                    resultValue: parameterValues.parameterDateValue
                };
            }
        });
    }
    static getAttributeValue(ruleAttributesArray): AttributeType {
        return ruleAttributesArray.ruleCriteriaValues.map((ruleCriteriaValues) => {
            return {
                label: ruleCriteriaValues.ruleCriteriaValueDescription,
                value: ruleCriteriaValues.ruleCriteriaValue
            };
        });
    }
    static getAttribute(ruleAttributesArray) {
        const attribute: AttributeType[] = [];
        attribute.push({
            label: ruleAttributesArray.ruleCriteriaDescription,
            value: ruleAttributesArray.ruleCriteriaCode
        });
        return attribute;
    }
    static getOperatorValue(ruleAttributesArray) {
        const operatorVal: AttributeType[] = [];
        operatorVal.push({
            label: ruleAttributesArray.ruleLogicalOperatorDescription,
            value: ruleAttributesArray.ruleLogicalOperatorCode
        });
        return operatorVal;
    }
    static generateTimeStamp() {
        return new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60 * 1000).toISOString().substr(0, 19);
    }
    static setResultSettingValues(data, editModel) {
        if (editModel.textResultValue && editModel.textResultValue.length > 0) {
            let indx = 0;
            editModel.textResultValue.forEach((ruleArray) => {
                if (ruleArray.ruleParameterValueTypeCode.toLowerCase() === 'number') {
                    editModel.editRuleForm.controls['txtResultSetting']['controls']
                    [indx].get('resultValue').setValue(ruleArray.parameterNumberValue);
                } else if (ruleArray.ruleParameterValueTypeCode.toLowerCase() === 'char') {
                    editModel.editRuleForm.controls['txtResultSetting']['controls'][indx].get('resultValue').setValue(
                        ruleArray.parameterCharValue);
                } else {
                    editModel.editRuleForm.controls['txtResultSetting']['controls']
                    [indx].get('resultValue').setValue(ruleArray.parameterDateValue);
                }
                indx++;
            });

        }
        if (editModel.booleanResult) {
            this.prepopulateResultSetting(data, editModel);
        }
    }
    static prepopulateResultSetting(data, editModel) {
        editModel.resultValue = [];
        const ruleParameters = LodashUtils.filter(data.ruleParameters, { 'ruleParameterTypeDescription': 'Boolean' });
        if (ruleParameters && ruleParameters.length > 0) {
            for (const ruleValue of ruleParameters) {
                if (ruleValue.ruleParameterValueTypeCode.toLowerCase() === 'number') {
                    this.getNumberValue(ruleValue.ParamterNumberValue, editModel);
                } else if (ruleValue.ruleParameterValueTypeCode.toLowerCase() === 'char') {
                    this.getCharValue(ruleValue, editModel);
                } else {
                    this.getDateValue(ruleValue, editModel);
                }
            }
        }
    }
    static getNumberValue(parameterNumberValue, editModel) {
        const numberValue = (parameterNumberValue) ? parameterNumberValue : '';
        editModel.resultValue.push({
            label: numberValue,
            value: numberValue
        });
    }
    static getCharValue(ruleValue, editModel) {
        const charValue = (ruleValue.parameterTypeName) ?
            ruleValue.parameterTypeName : '';
        editModel.resultValue.push({
            label: charValue,
            value: ruleValue.ruleParameterCriteriaCode
        });
    }
    static getDateValue(ruleValue, editModel) {
        const dateValue = (ruleValue.parameterDateValue) ?
            ruleValue.parameterDateValue : '';
        editModel.resultValue.push({
            label: dateValue,
            value: dateValue
        });
    }
    static prepopulateCriteriaValue(index: number, selectedRule: RuleCriteriaDetails, editmodel, changeDetector) {
        let ruleCriteriaValue: AttributeType[] = [];
        ruleCriteriaValue = editmodel.ruleAttributes[index].ruleCriteriaValues.map((item) => {
            return {
                label: (editmodel.ruleAttributes[index].ruleCriteriaDescription === 'Trailing Equipment Sub Class')
                    ? item.ruleCriteriaValueDescription.toUpperCase() : item.ruleCriteriaValueDescription,
                value: item.ruleCriteriaValue
            };
        });
        editmodel.editRuleForm.controls['inlineTableForm']['controls'][index].patchValue({
            attribute: {
                label: selectedRule.ruleCriteriaDescription,
                value: selectedRule.ruleCriteriaCode
            },
            operator: {
                label: selectedRule.ruleLogicalOperatorDescription,
                value: selectedRule.ruleLogicalOperatorCode
            },
            attributeValue: ruleCriteriaValue
        });
        changeDetector.markForCheck();
        changeDetector.detectChanges();
    }
    static addValidRow(editModel, changeDetector, attributeArrayValue) {
        editModel.editRuleForm.controls['inlineTableForm']['controls'][0].get('attribute').reset();
        editModel.editRuleForm.controls['inlineTableForm']['controls'][0].get('operator').reset();
        editModel.editRuleForm.controls['inlineTableForm']['controls'][0].get('attributeValue').reset();
        editModel.ruleAttributes.unshift({
            ruleCriteriaCode: '',
            ruleCriteriaDescription: '',
            ruleLogicalOperatorCode: '',
            ruleLogicalOperatorDescription: '',
            ruleCriteriaId: 0,
            hasNoResult: false,
            ruleCriteriaValues: [],
            editable: true,
            compType: 'multiselect',
            attributeItems: attributeArrayValue,
            isCheck: true
        });
        changeDetector.markForCheck();
        changeDetector.detectChanges();
        editModel.addAttribute = false;
        editModel.save = true;
        editModel.cancel = true;
    }
    static setUnCheckedValues(editModel) {
        editModel.selectedRows = [];
        editModel.selectedRowIndex = [];
        for (const item of editModel.ruleAttributes) {
            if (item.editable) {
                item.editable = false;
                item.isCheck = false;
            }
        }
    }
    static setCheckedValues(editModel) {
        const rules = editModel.ruleAttributes;
        rules.forEach((item, index) => {
            editModel.selectedRowIndex.push(index);
            if (item.ruleCriteriaValues.length === 0 && item.editable) {
                editModel.ruleAttributes.splice(index, 1);
                LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['controls'], index);
                LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['value'], index);
                if (editModel.ruleAttributes.length === 0) {
                    editModel.selectedRows = [];
                }
            }
        });
        editModel.editRuleForm.controls['inlineTableForm'].setErrors(null);
    }
    static setRuleAttributeValues(index: number, editModel) {
        const operator = editModel.editRuleForm['controls']['inlineTableForm']['controls'][index]
        ['controls']['operator'].value;
        const attribute = editModel.editRuleForm['controls']['inlineTableForm']['controls'][index]
        ['controls']['attribute'].value;
        if (editModel.editRuleForm['controls']['inlineTableForm']['controls'][index].valid) {
            editModel.ruleAttributes[index].ruleCriteriaDescription = attribute.label;
            editModel.ruleAttributes[index].ruleCriteriaCode = attribute.value;
            editModel.ruleAttributes[index].ruleLogicalOperatorCode = operator.value;
            editModel.ruleAttributes[index].ruleLogicalOperatorDescription = operator.label;
            editModel.ruleAttributes[index].editable = false;
            editModel.ruleAttributes[index].isCheck = false;
        } else {
            FormValidationUtils.validateAllFormFields(editModel.editRuleForm);
        }
    }
    static cancelInlineUtility(editModel) {
        if (editModel.selectedRowIndex.length < 1) {
            editModel.editRuleForm.controls['inlineTableForm']['controls'][0].get('attribute').reset();
            editModel.editRuleForm.controls['inlineTableForm']['controls'][0].get('operator').reset();
            editModel.editRuleForm.controls['inlineTableForm']['controls'][0].get('attributeValue').reset();
            LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['controls'], 0);
            LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['value'], 0);
            LodashUtils.pullAt(editModel.ruleAttributes, 0);
        }
        editModel.remove = false;
        editModel.cancel = false;
        editModel.save = false;
        editModel.selectedRows = [];
        editModel.selectedRowIndex = [];
        editModel.addAttribute = true;
        editModel.isSave = !(editModel.selectedRows.length > 0);
        editModel.editRuleForm.controls['inlineTableForm'].setErrors(null);
    }
    static inlineRemove(editModel) {
        if (!editModel.editRuleForm.controls['inlineTableForm'].valid) {
            const rules = editModel.ruleAttributes;
            rules.forEach((element, index) => {
                editModel.selectedRowIndex.push(index);
                if (element.ruleCriteriaValues.length === 0 && element.editable) {
                    editModel.ruleAttributes.splice(index, 1);
                    LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['controls'], index);
                    LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['value'], index);
                    if (editModel.ruleAttributes.length === 0) {
                        editModel.selectedRows = [];
                    }
                }
            });
        }
        editModel.addAttribute = true;
        editModel.save = false;
        editModel.remove = false;
        editModel.cancel = false;
        editModel.selectedRows = [];
        editModel.selectedRowIndex = [];
        editModel.editRuleForm.controls['inlineTableForm'].setErrors(null);
    }
    static removeInlineAttributes(editModel) {
        const newRowIndex = editModel.ruleAttributes;
        const removedItems = editModel.selectedRows;
        for (const item of removedItems) {
            for (let i = 0; i < newRowIndex.length; i++) {
                if (editModel.ruleAttributes[i] &&
                    editModel.ruleAttributes[i].ruleCriteriaCode &&
                    editModel.ruleAttributes[i].ruleCriteriaCode === item.ruleCriteriaCode) {
                    editModel.editRuleForm.controls['inlineTableForm']['controls'][i].reset();
                    LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['controls'], i);
                    LodashUtils.pullAt(editModel.editRuleForm.controls['inlineTableForm']['value'], i);
                    LodashUtils.pullAt(editModel.ruleAttributes, i);
                    break;
                }
            }
        }
    }
    static removeDuplicateAttribute(editModel) {
        const attributeArray = JSON.parse(JSON.stringify(editModel.attributeItems));
        editModel.ruleAttributes.map((attributeItem) => {
            const attributeIndex = attributeArray.findIndex((attribute) => {
                if (attributeItem.ruleCriteriaDescription === attribute.label) {
                    return attribute;
                }
            });
            attributeArray.splice(attributeIndex, 1);
            return {};
        });
        return attributeArray;
    }
    static onRowUnSelect(deselectedRule: RuleCriteriaDetails, editModel) {
        editModel.addAttribute = !(editModel.selectedRows.length > 0);
        editModel.cancel = !(editModel.addAttribute);
        editModel.addAttribute = !(editModel.selectedRows.length > 0);
        editModel.save = false;
        editModel.remove = editModel.selectedRows.length > 0;
        editModel.cancel = editModel.selectedRows.length > 0;
        const selIndex = editModel.ruleAttributes.findIndex((item) =>
            item['ruleCriteriaCode'] === deselectedRule.ruleCriteriaCode);
        editModel.ruleAttributes[selIndex].editable = false;
        editModel.ruleAttributes[selIndex].isCheck = false;
        editModel.ruleAttributes[selIndex].attributeItems.pop();
    }
    static setheaderValues(editModel) {
        editModel.selectedRows = [];
        editModel.selectedRowIndex = [];
        editModel.addAttribute = true;
        editModel.save = false;
        editModel.cancel = false;
        editModel.remove = false;
    }
    static constructRuleCriteriaDetailsJson(editModel, ruleAttributesArray: RuleCriteriaDetails[]) {
        editModel.ruleCriteriaDetailsJSON = [];
        for (const item of ruleAttributesArray) {
            if (item && item.ruleCriteriaValues) {
                for (const element of item.ruleCriteriaValues) {
                    editModel.ruleCriteriaDetailsJSON.push({
                        'ruleCriteriaDetailId': null,
                        'ruleCriteriaCode': item.ruleCriteriaCode,
                        'ruleCriteriaDescription': item.ruleCriteriaDescription,
                        'ruleLogicalOperatorCode': item.ruleLogicalOperatorCode,
                        'ruleLogicalOperatorDescription': item.ruleLogicalOperatorDescription,
                        'ruleCriteriaValue': element.ruleCriteriaValue
                    });
                }
            }
        }
    }
    static showMissingInputvalidation(toastMessage, duplicateError?) {
        toastMessage.clear();
        toastMessage.add({
            severity: 'error',
            summary: duplicateError ? 'Duplicate Rule' : 'Missing Required Information',
            detail: duplicateError ? 'An automation rule has already been set for this combination of configurable attributes'
                : 'Provide the required information in the highlighted fields and submit the form again'
        });
    }
    static attributeValueMapping(item) {
        return {
            'ruleCriteriaDetailId': null,
            'ruleCriteriaValue': item.value,
            'ruleCriteriaValueDescription': item.label
        };
    }
    static removeDuplicateOperator(params: Array<AttributeType>, property: string): Array<AttributeType> {
        return params.filter((obj, value, arr) => {
            if (obj.label) {
                return arr.map(mapObj => mapObj[property]).indexOf(obj[property]) === value;
            }
        });
    }
    static createFormGroup(formBuilder: FormBuilder, attribute?: AttributeType[],
        operator?: AttributeType[], attributeVal?: AttributeType): FormGroup {
        return formBuilder.group({
            attribute: [attribute ? attribute : [{ 'label': '', 'value': '' }], Validators.required],
            operator: [operator ? operator : [{ 'label': '', 'value': '' }], Validators.required],
            attributeValue: [attributeVal ? attributeVal : [{ 'label': '', 'value': '' }], Validators.required]
        });
    }
    static resultSettingForm(formBuilder: FormBuilder, resultValue?: any) {
        return formBuilder.group({
            resultValue: [resultValue ? resultValue : [{ 'resultValue': '' }], Validators.required],
        });
    }
}


