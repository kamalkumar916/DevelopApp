import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import {
  BusinessUnit, RuleAttribute, RuleOverviewDetails, LobResponse, TeamsData,
  ActiveInactivate, OperationalGroup
} from '../../model/automation-rule.interface';
import { EditRequest, EditResponse } from '../model/automation-rule-edit.interface';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { OperationalPlanTypeObject, OperationalPlanSubtypeObject, StopReasonObject,
  EquipmentClassificationObject, EquipmentSubClass, ClassificationType} from '../../model/automation-rules.interface';

@Injectable()
export class AutomationRuleEditService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('automationRules');
  }
  getRuleAttributes(ruleCriteriaSetId: number): Observable<RuleAttribute> {
    return this.http.get<RuleAttribute>(`${this.endpoint.ruleAttributes}/${ruleCriteriaSetId}`);
  }
  getRuleOverview(ruleCriteriaSetId: number): Observable<RuleOverviewDetails> {
    return this.http.get<RuleOverviewDetails>(`${this.endpoint.ruleOverview}/${ruleCriteriaSetId}`);
  }
  getRuleDetails(ruleDetailId: number): Observable<any> {
    return this.http.get(`${this.endpoint.configureNewPredefined}/${ruleDetailId}`);
  }
  getBusinessUnitData(): Observable<BusinessUnit> {
    return this.http.get<BusinessUnit>(this.endpoint.businessUnitData);
  }
  getOperationalGroupValues(): Observable<OperationalGroup> {
    return this.http.get<OperationalGroup>(this.endpoint.getOperationalGroup);
  }
  getOWOSubtypeData(): Observable<any> {
    return this.http.get(this.endpoint.owoSubTypes);
  }
  getCorporateAccountData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(`${this.endpoint.corporateAccountData}?size=5`, queryParamValue);
  }
  getOperationalGroupData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(`${this.endpoint.operationalGroupData}?size=5`, queryParamValue);
  }
  getLineOfBusinessData(queryParamValue: any): Observable<LobResponse> {
    return this.http.post<LobResponse>(this.endpoint.lineOfBusinessData, queryParamValue);
  }
  getBillToAccountData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.billToAccountData, queryParamValue);
  }
  getTeamData(queryParamValue: string, dateTimeStamp: string): Observable<TeamsData> {
    const param = `${this.endpoint.teamData}?teamName=${queryParamValue}&expirationTimestamp=${dateTimeStamp}`;
    return this.http.get<TeamsData>(param);
  }
  getLocationData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.locationData, queryParamValue);
  }
  getSCACData(queryParamValue: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.scacData, queryParamValue);
  }
  editRule(requestObj: EditRequest): Observable<EditResponse> {
    return this.http.patch<EditResponse>(`${this.endpoint.createRule}/${requestObj.ruleCriteriaSetId}`, requestObj);
  }
  copyRule(requestObj: EditRequest): Observable<EditResponse> {
    return this.http.post<EditResponse>(this.endpoint.createRule, requestObj);
  }
  getActiveInactiveRule(ruleCriteriaSetId: number, ruleStatus: boolean): Observable<ActiveInactivate> {
    return this.http.patch<ActiveInactivate>(`${this.
      endpoint.activeInactiveRule}/${ruleCriteriaSetId}?status=${ruleStatus}`, ruleStatus);
  }
  getDriverData(queryParamValue: any): Observable<ElasticResponseModel> {
    const url = this.endpoint.getDrivers;
    return this.http.post<ElasticResponseModel>(url, queryParamValue);
  }
  getTruckData(queryParamValue: any): Observable<ElasticResponseModel> {
    const url = this.endpoint.getTrucks;
    return this.http.post<ElasticResponseModel>(url, queryParamValue);
  }
  getOperationalPlanType(): Observable<OperationalPlanTypeObject> {
    return this.http.get<OperationalPlanTypeObject>(this.endpoint.getOperationalPlanTypes);
  }
  getOperationalPlanSubtype(): Observable<OperationalPlanSubtypeObject> {
    return this.http.get<OperationalPlanSubtypeObject>(this.endpoint.getOperationalPlanSubtype);
  }
  getStopReason(): Observable<StopReasonObject> {
    return this.http.get<StopReasonObject>(this.endpoint.getStopReason);
  }
  getEquipmentClassification(): Observable<EquipmentClassificationObject> {
    return this.http.get<EquipmentClassificationObject>(this.endpoint.getEquipmentClassification);
  }
  getEquipmentSubClass(): Observable<EquipmentSubClass> {
    return this.http.get<EquipmentSubClass>(this.endpoint.getEquipmentSubClass);
  }
  getClassificationPlan(): Observable<ClassificationType> {
    return this.http.get<ClassificationType>(`${this.endpoint.getClassificationPlanType}`);
  }
}
