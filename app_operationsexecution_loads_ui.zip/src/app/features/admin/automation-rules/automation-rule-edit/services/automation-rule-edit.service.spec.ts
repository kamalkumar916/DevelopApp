import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AutomationRuleEditService } from './automation-rule-edit.service';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { configureTestSuite } from 'ng-bullet';

describe('AutomationRuleEditService', () => {
  let service: AutomationRuleEditService;
  let httpTestingController: HttpTestingController;

  const requestObj = {
    ruleDetailId: 1,
    ruleCriteriaSetId: 1,
    orderRuleSupersedeTypeCode: 2,
    ruleCriteriaDetails: [{
      ruleCriteriaDetailId: '',
      ruleCriteriaCode: '',
      ruleCriteriaDescription: '',
      ruleLogicalOperatorCode: '',
      ruleLogicalOperatorDescription: '',
      ruleCriteriaValue: '',
    }],
    ruleParameters: [{
      ruleParameterId: 1,
      ruleParameterCriteriaCode: '',
      ruleParameterTypeName: '',
      ruleParameterTypeCode: '',
      ruleParameterValueTypeCode: '',
      ruleLogicalOperatorCode: '',
      ruleLogicalOperatorDescription: '',
      parameterNumberValue: 1,
      parameterCharValue: '',
      parameterDateValue: '',
    }]
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AutomationRuleEditService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(AutomationRuleEditService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('getRuleAttributes have been called', () => {
    const ruleCriteriaSetId = 1;
    service.getRuleAttributes(ruleCriteriaSetId).subscribe();
    const url = `${service.endpoint.ruleAttributes}/${ruleCriteriaSetId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getRuleOverview have been called', () => {
    const ruleCriteriaSetId = 1;
    service.getRuleOverview(ruleCriteriaSetId).subscribe();
    const url = `${service.endpoint.ruleOverview}/${ruleCriteriaSetId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getRuleDetails have been called', () => {
    const ruleDetailId = 1;
    service.getRuleDetails(ruleDetailId).subscribe();
    const url = `${service.endpoint.configureNewPredefined}/${ruleDetailId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getBusinessUnitData have been called', () => {
    service.getBusinessUnitData().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.businessUnitData);
    expect(req.request.method).toEqual('GET');
  });

  it('getOperationalGroupValues have been called', () => {
    service.getOperationalGroupValues().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalGroup);
    expect(req.request.method).toEqual('GET');
  });

  it('getOWOSubtypeData have been called', () => {
    service.getOWOSubtypeData().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.owoSubTypes);
    expect(req.request.method).toEqual('GET');
  });

  it('getCorporateAccountData have been called', () => {
    const queryParamValue = '';
    service.getCorporateAccountData(queryParamValue).subscribe();
    const url = `${service.endpoint.corporateAccountData}?size=5`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('POST');
  });

  it('getOperationalGroupData have been called', () => {
    const queryParamValue = '';
    service.getOperationalGroupData(queryParamValue).subscribe();
    const url = `${service.endpoint.operationalGroupData}?size=5`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('POST');
  });

  it('getLineOfBusinessData have been called', () => {
    const queryParamValue = '';
    service.getLineOfBusinessData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.lineOfBusinessData);
    expect(req.request.method).toEqual('POST');
  });

  it('getBillToAccountData have been called', () => {
    const queryParamValue = '';
    service.getBillToAccountData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.billToAccountData);
    expect(req.request.method).toEqual('POST');
  });

  it('getTeamData have been called', () => {
    const queryParamValue = '';
    const dateTimeStamp = '';
    service.getTeamData(queryParamValue, dateTimeStamp).subscribe();
    const url = `${service.endpoint.teamData}?teamName=${queryParamValue}&expirationTimestamp=${dateTimeStamp}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getLocationData have been called', () => {
    const queryParamValue = '';
    service.getLocationData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.locationData);
    expect(req.request.method).toEqual('POST');
  });

  it('getSCACData have been called', () => {
    const queryParamValue = '';
    service.getSCACData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.scacData);
    expect(req.request.method).toEqual('POST');
  });

  it('editRule have been called', () => {
    service.editRule(requestObj).subscribe();
    const url = `${service.endpoint.createRule}/${requestObj.ruleCriteriaSetId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PATCH');
  });

  it('copyRule have been called', () => {
    service.copyRule(requestObj).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.createRule);
    expect(req.request.method).toEqual('POST');
  });

  it('getActiveInactiveRule have been called', () => {
    const ruleCriteriaSetId = 1;
    const ruleStatus = true;
    const url = `${service.endpoint.activeInactiveRule}/${ruleCriteriaSetId}?status=${ruleStatus}`;
    service.getActiveInactiveRule(ruleCriteriaSetId, ruleStatus).subscribe();
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PATCH');
  });

  it('getDriverData have been called', () => {
    const queryParamValue = '';
    service.getDriverData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getDrivers);
    expect(req.request.method).toEqual('POST');
  });

  it('getTruckData have been called', () => {
    const queryParamValue = '';
    service.getTruckData(queryParamValue).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getTrucks);
    expect(req.request.method).toEqual('POST');
  });

  it('getOperationalPlanType have been called', () => {
    service.getOperationalPlanType().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalPlanTypes);
    expect(req.request.method).toEqual('GET');
  });

  it('getOperationalPlanSubtype have been called', () => {
    service.getOperationalPlanSubtype().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getOperationalPlanSubtype);
    expect(req.request.method).toEqual('GET');
  });

  it('getStopReason have been called', () => {
    service.getStopReason().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getStopReason);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentClassification have been called', () => {
    service.getEquipmentClassification().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentClassification);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentSubClass have been called', () => {
    service.getEquipmentSubClass().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentSubClass);
    expect(req.request.method).toEqual('GET');
  });

  it('${this.endpoint.getClassificationPlanType} have been called', () => {
    service.getClassificationPlan().subscribe();
    const url = `${service.endpoint.getClassificationPlanType}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });
});



