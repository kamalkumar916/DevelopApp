import { AutomationRuleEditUtils } from './automation-rule-edit-utils';
import { FormBuilder, Validators } from '@angular/forms';
import { FormValidationUtils } from '../../../../../shared/jbh-app-services/form-validation-utils';

describe('AutomationRuleEditUtils', () => {
    const formBuilder: FormBuilder = new FormBuilder();
    const configuredRuleDetails = {
        CreateProgramName: '',
        CreateTimestamp: '',
        CreateUserID: '',
        EffectiveTimestamp: '',
        ExpirationTimestamp: '',
        LastUpdateProgramName: '',
        LastUpdateTimestamp: '',
        LastUpdateUserID: '',
        RuleBusinessProcessCode: '',
        RuleBusinessProcessDescription: '',
        RuleCategoryCode: '',
        RuleCategoryDescription: '',
        RuleCategoryTypeAssociationID: 1,
        RuleCode: '',
        RuleComment: '',
        RuleCriteria: [{
            RuleCriteriaCode: '',
            RuleCriteriaDescription: '',
            RuleLogicalOperator: {
                RuleLogicalOperatorDescription: 'description',
                RuleLogicalOperatorCode: 'code'
            }
        }],
        RuleDescription: '',
        RuleDetailID: '',
        RuleInclusionExclusionTypeCode: '',
        RuleName: '',
        RuleParameter: [{
            ParameterDefaultCharValue: '',
            ParameterDefaultNumberValue: 1,
            RuleParameterCriteriaCode: 'code',
            RuleParameterTypeCode: '',
            RuleParameterTypeDescription: '',
            RuleParameterValueTypeCode: ''
        }],
        RuleSequenceNumber: '',
        RuleTypeCode: '',
        RuleTypeDescription: '',
        SendCustomerNotificationIndicator: ''
    };
    const existingRule = {
        _index: '',
        _type: '',
        _id: 1,
        _version: 1,
        found: true,
        _source: configuredRuleDetails
    };
    const operationalGroupData = {
        _embedded: {
            operationalGroups: [{
                operationalGroupDescription: 'abc'
            }]
        }
    };
    const populateValuesData = {
        _embedded: {
            serviceOfferingBusinessUnitTransitModeAssociations: [{
                financeBusinessUnitServiceOfferingAssociation: {
                    effectiveTimestamp: '',
                    expirationTimestamp: '',
                    financeBusinessUnitCode: 'a',
                    financeBusinessUnitServiceOfferingAssociationID: '',
                    lastUpdateTimestampString: '',
                    serviceOfferingCode: '',
                },
                freightShippingType: '',
                lastUpdateTimestampString: '',
                transitMode: '',
                utilizationClassification: '',
                _links: {
                    self: {
                        self: {
                            href: ''
                        }
                    }
                }
            }]
        }
    };
    const elasticResponseModelData = {
        hits: {
            hits: [{
                sort: ['', ''],
                _id: '',
                _index: '',
                _score: 1,
                _source: {
                    OperationalGroupDescription: 'description',
                    OperationalGroupCode: 'code',
                    scac: ''
                },
                _type: '',
            }],
            max_score: 12,
            total: null
        },
        timed_out: true,
        took: 1,
        _shards: {
            total: 1,
            successful: null,
            skipped: null,
            failed: 1
        }
    };
    const ruleattributesarray = {
        ruleCriteriaCode: '',
        ruleCriteriaDescription: '',
        ruleLogicalOperatorCode: 'code',
        ruleLogicalOperatorDescription: '',
        ruleCriteriaValues: [{
            ruleCriteriaValue: '',
            ruleCriteriaDetailId: 1,
            ruleCriteriaValueDescription: 'description',
        }],
        editable: true,
        hasNoResult: true,
        ruleCriteriaId: 1,
        compType: '',
        attributeItems: [{
            label: '',
            value: ''
        }],
        isCheck: false
    };
    const ruleattributedata = {
        ruleDetailId: 1,
        ruleCriteriaSetID: 1,
        ruleStatus: '',
        ruleSupersedeTypeCode: '',
        ruleCriteriaDetails: [ruleattributesarray],
        ruleParameters: [{
            ruleParameterId: 1,
            ruleParameterCriteriaCode: '',
            ruleParameterTypeName: '',
            ruleParameterTypeCode: '',
            ruleParameterValueTypeCode: '',
            ruleLogicalOperatorCode: '',
            ruleLogicalOperatorDescription: '',
            parameterNumberValue: null,
            parameterCharValue: '',
            parameterDateValue: '',
            ruleParameterTypeDescription: 'Boolean'
        }]
    };

    it('getEditFormArray should return rowIndex_attribute value as a', () => {
        const returnValue = AutomationRuleEditUtils.getEditFormArray(0, 'a');
        expect(returnValue['rowIndex_attribute']).toEqual('a');
    });

    it('populateAttributes should return array of length 1', () => {
        const returnValue = AutomationRuleEditUtils.populateAttributes(existingRule);
        expect(returnValue.length).toEqual(1);
    });

    it('populateBooleanResults should return an array of object with value property', () => {
        existingRule._source.RuleParameter[0].RuleParameterTypeCode = 'Boolean';
        const returnValue = AutomationRuleEditUtils.populateBooleanResults(existingRule);
        expect(returnValue[0].value).toEqual('code');
    });

    it('populateBooleanResults should return an array of length 0', () => {
        existingRule._source.RuleParameter[0].RuleParameterTypeCode = '';
        const returnValue = AutomationRuleEditUtils.populateBooleanResults(existingRule);
        expect(returnValue.length).toEqual(0);
    });

    it('populateOPGroupValues should return an array of objects with label property equal to abc', () => {
        const returnValue = AutomationRuleEditUtils.populateOPGroupValues(operationalGroupData);
        expect(returnValue[0].label).toEqual('abc');
    });

    it('populateParameters should return an array of objects with label property equal to description', () => {
        const returnValue = AutomationRuleEditUtils.populateParameters(existingRule);
        expect(returnValue[0].label).toEqual('description');
    });

    it('populateValues should return an array of objects with label property equal to a', () => {
        const returnValue = AutomationRuleEditUtils.populateValues(populateValuesData);
        expect(returnValue[0].label).toEqual('a');
    });

    it('getOperationalGroupRecords have been called', () => {
        const returnValue = AutomationRuleEditUtils.getOperationalGroupRecords(elasticResponseModelData);
        expect(returnValue[0].value).toEqual('code');
    });

    it('getScacRecords should return an array of objects', () => {
        const returnValue = AutomationRuleEditUtils.getScacRecords(elasticResponseModelData);
        expect(returnValue[0].value).toEqual('');
    });

    it('getRuleParamDetails with txtResultSetting have been called', () => {
        spyOn(AutomationRuleEditUtils, 'getRuleDetails').and.returnValue({});
        const dataSource = {
            ruleOverViewDetails: configuredRuleDetails,
            textResultValue: [{
                ruleParameterCriteriaCode: 'code'
            }],
            editRuleForm: formBuilder.group({
                txtResultSetting: formBuilder.array([formBuilder.group({
                    'resultValue': ['']
                })]),
                resultSetting: ['']
            })
        };
        const returnValue = AutomationRuleEditUtils.getRuleParamDetails(dataSource);
        expect(returnValue.length).toEqual(1);
    });

    it('getRuleParamDetails with resultValue  have been called', () => {
        spyOn(AutomationRuleEditUtils, 'getRuleDetails').and.returnValue({});
        const dataSource = {
            ruleOverViewDetails: configuredRuleDetails,
            textResultValue: [{
                ruleParameterCriteriaCode: 'code'
            }],
            editRuleForm: formBuilder.group({
                txtResultSetting: formBuilder.array([]),
                resultSetting: formBuilder.array(['code'])
            })
        };
        const returnValue = AutomationRuleEditUtils.getRuleParamDetails(dataSource);
        expect(returnValue.length).toEqual(1);
    });

    it('getRuleDetails should return an object with ruleParameterId as null', () => {
        const dataSource = {
            ruleOverViewDetails: configuredRuleDetails,
            logicalOperatorCode: null,
            logicalOperatorDescription: null
        };
        const returnValue = AutomationRuleEditUtils.getRuleDetails(dataSource, 0, null);
        expect(returnValue.ruleParameterId).toBeNull();
    });

    it('getTextResultValue if case coverage', () => {
        const resultArray = [{
            ruleParameterValueTypeCode: 'number',
            parameterNumberValue: null
        }];
        const returnValue = AutomationRuleEditUtils.getTextResultValue(resultArray);
        expect(returnValue[0].resultValue).toBeNull();
    });

    it('getTextResultValue else if case coverage', () => {
        const resultArray = [{
            ruleParameterValueTypeCode: 'char',
            parameterCharValue: null
        }];
        const returnValue = AutomationRuleEditUtils.getTextResultValue(resultArray);
        expect(returnValue[0].resultValue).toBeNull();
    });

    it('getTextResultValue  else case coverage', () => {
        const resultArray = [{
            ruleParameterValueTypeCode: '',
            parameterDateValue: null
        }];
        const returnValue = AutomationRuleEditUtils.getTextResultValue(resultArray);
        expect(returnValue.length).toEqual(1);
    });

    it('getAttributeValue should return an array of objects with label property', () => {
        const returnValue = AutomationRuleEditUtils.getAttributeValue(ruleattributesarray);
        expect(returnValue[0].label).toEqual('description');
    });

    it('getAttribute should return an array of length 1', () => {
        const returnValue = AutomationRuleEditUtils.getAttribute(ruleattributesarray);
        expect(returnValue.length).toEqual(1);
    });

    it('getOperatorValue should return an array of objects with value property equal to code', () => {
        const returnValue = AutomationRuleEditUtils.getOperatorValue(ruleattributesarray);
        expect(returnValue[0].value).toEqual('code');
    });

    it('setResultSettingValues should set the value for resultValue control in editRuleForm as number', () => {
        const editModel = {
            resultValue: [],
            textResultValue: [{
                ruleParameterValueTypeCode: 'number',
                parameterNumberValue: 'number'
            }],
            editRuleForm: formBuilder.group({
                txtResultSetting: formBuilder.array([formBuilder.group({
                    'resultValue': ['']
                })]),
                resultSetting: ['']
            }),
            booleanResult: true
        };
        ruleattributedata.ruleParameters[0].ruleParameterValueTypeCode = 'number';
        AutomationRuleEditUtils.setResultSettingValues(ruleattributedata, editModel);
        expect(editModel.editRuleForm.controls.txtResultSetting.value[0].resultValue).toEqual('number');
    });

    it('setResultSettingValues should set the value for resultValue control in editRuleForm as char', () => {
        const editModel = {
            resultValue: [],
            textResultValue: [{
                ruleParameterValueTypeCode: 'char',
                parameterCharValue: 'char'
            }],
            editRuleForm: formBuilder.group({
                txtResultSetting: formBuilder.array([formBuilder.group({
                    'resultValue': ['']
                })]),
                resultSetting: ['']
            }),
            booleanResult: true
        };
        ruleattributedata.ruleParameters[0].ruleParameterValueTypeCode = 'char';
        AutomationRuleEditUtils.setResultSettingValues(ruleattributedata, editModel);
        expect(editModel.editRuleForm.controls.txtResultSetting.value[0].resultValue).toEqual('char');
    });

    it('setResultSettingValues should set the value for resultValue control in editRuleForm as null', () => {
        const editModel = {
            resultValue: [],
            textResultValue: [{
                ruleParameterValueTypeCode: '',
                parameterDateValue: ''
            }],
            editRuleForm: formBuilder.group({
                txtResultSetting: formBuilder.array([formBuilder.group({
                    'resultValue': ['']
                })]),
                resultSetting: ['']
            }),
            booleanResult: true
        };
        ruleattributedata.ruleParameters[0].ruleParameterValueTypeCode = '';
        AutomationRuleEditUtils.setResultSettingValues(ruleattributedata, editModel);
        expect(editModel.editRuleForm.controls.txtResultSetting.value[0].resultValue).toEqual('');
    });

    it('addValidRow should set the cancel property to be true', () => {
        const editModel = {
            cancel: false,
            ruleAttributes: [],
            editRuleForm: formBuilder.group({
                inlineTableForm: formBuilder.array([formBuilder.group({
                    attribute: [''],
                    operator: [''],
                    attributeValue: ['']
                })])
            })
        };
        const changeDetector = {
            markForCheck: () => {
                return null;
            },
            detectChanges: () => {
                return null;
            }
        };
        AutomationRuleEditUtils.addValidRow(editModel, changeDetector, null);
        expect(editModel.cancel).toBeTruthy();
    });

    it('setUnCheckedValues should set the editable property to be false', () => {
        const editModel = {
            cancel: false,
            ruleAttributes: [{
                editable: true,
                isCheck: true
            }],
            selectedRows: [],
            selectedRowIndex: []
        };
        AutomationRuleEditUtils.setUnCheckedValues(editModel);
        expect(editModel.ruleAttributes[0].editable).toBeFalsy();
    });

    it('setCheckedValues should set the errors of inlineTableForm control to be null', () => {
        const editModel = {
            selectedRowIndex: [],
            cancel: false,
            ruleAttributes: [{
                ruleCriteriaValues: '',
                editable: true
            }],
            editRuleForm: formBuilder.group({
                inlineTableForm: formBuilder.array([formBuilder.group({
                    attribute: [''],
                    operator: [''],
                    attributeValue: ['']
                })])
            })
        };
        AutomationRuleEditUtils.setCheckedValues(editModel);
        expect(editModel.editRuleForm.controls['inlineTableForm'].errors).toBeNull();
    });

    it('setRuleAttributeValues should set the ruleCriteriaDescription property to be a', () => {
        const editModel = {
            selectedRowIndex: [],
            cancel: false,
            ruleAttributes: [{
                ruleCriteriaValues: '',
                editable: true,
                ruleCriteriaDescription: '',
                ruleCriteriaCode: '',
                ruleLogicalOperatorCode: '',
                ruleLogicalOperatorDescription: '',
                isCheck: true
            }],
            editRuleForm: formBuilder.group({
                inlineTableForm: formBuilder.array([formBuilder.group({
                    attribute: [{ value: 'a', label: 'a' }],
                    operator: [{ value: 'o', label: 'o' }],
                    attributeValue: ['']
                })])
            })
        };
        AutomationRuleEditUtils.setRuleAttributeValues(0, editModel);
        expect(editModel.ruleAttributes[0].ruleCriteriaDescription).toEqual('a');
    });

    it('setRuleAttributeValues should call the validateAllFormFields spy', () => {
        spyOn(FormValidationUtils, 'validateAllFormFields');
        const editModel = {
            selectedRowIndex: [],
            cancel: false,
            ruleAttributes: [{
                ruleCriteriaValues: '',
                editable: true,
                ruleCriteriaDescription: '',
                ruleCriteriaCode: '',
                ruleLogicalOperatorCode: '',
                ruleLogicalOperatorDescription: '',
                isCheck: true
            }],
            editRuleForm: formBuilder.group({
                inlineTableForm: formBuilder.array([formBuilder.group({
                    attribute: ['', Validators.required],
                    operator: ['', Validators.required],
                    attributeValue: ['']
                })])
            })
        };
        AutomationRuleEditUtils.setRuleAttributeValues(0, editModel);
        expect(FormValidationUtils.validateAllFormFields).toHaveBeenCalled();
    });

    it('cancelInlineUtility should set the remove property to be false', () => {
        const editModel = {
            selectedRows: [],
            selectedRowIndex: [],
            cancel: false,
            remove: true,
            ruleAttributes: [{
                ruleCriteriaValues: '',
                editable: true,
                ruleCriteriaDescription: '',
                ruleCriteriaCode: '',
                ruleLogicalOperatorCode: '',
                ruleLogicalOperatorDescription: '',
                isCheck: true
            }],
            editRuleForm: formBuilder.group({
                inlineTableForm: formBuilder.array([formBuilder.group({
                    attribute: ['', Validators.required],
                    operator: ['', Validators.required],
                    attributeValue: ['']
                })])
            })
        };
        AutomationRuleEditUtils.cancelInlineUtility(editModel);
        expect(editModel.remove).toBeFalsy();
    });

    it('inlineRemove should set the cancel property to be false', () => {
        const editModel = {
            selectedRows: [],
            selectedRowIndex: [],
            cancel: true,
            remove: true,
            ruleAttributes: [{
                ruleCriteriaValues: '',
                editable: true,
                ruleCriteriaDescription: '',
                ruleCriteriaCode: '',
                ruleLogicalOperatorCode: '',
                ruleLogicalOperatorDescription: '',
                isCheck: true
            }],
            editRuleForm: formBuilder.group({
                inlineTableForm: formBuilder.array([formBuilder.group({
                    attribute: [null, Validators.required],
                    operator: ['', Validators.required],
                    attributeValue: ['']
                })])
            })
        };
        AutomationRuleEditUtils.inlineRemove(editModel);
        expect(editModel.cancel).toBeFalsy();
    });

    it('setheaderValues should set the cancel property to be false', () => {
        const editModel = {
            selectedRows: [],
            selectedRowIndex: [],
            cancel: true,
            remove: true
        };
        AutomationRuleEditUtils.setheaderValues(editModel);
        expect(editModel.cancel).toBeFalsy();
    });

    it('constructRuleCriteriaDetailsJson should set the length of ruleCriteriaDetailsJSON array as 1', () => {
        const editModel = {
            ruleCriteriaDetailsJSON: [],
        };
        AutomationRuleEditUtils.constructRuleCriteriaDetailsJson(editModel, [ruleattributesarray]);
        expect(editModel.ruleCriteriaDetailsJSON.length).toBe(1);
    });

    it('attributeValueMapping should set the ruleCriteriaDetailId property to be null', () => {
        const returnValue = AutomationRuleEditUtils.attributeValueMapping({ value: '', label: '' });
        expect(returnValue.ruleCriteriaDetailId).toBeNull();
    });

    it('createFormGroup should return a formgroup with attribute control value as a', () => {
        const returnValue = AutomationRuleEditUtils.createFormGroup(formBuilder, [{ label: 'a', value: 'a' }]);
        expect(returnValue.controls['attribute'].value[0].label).toEqual('a');
    });

    it('resultSettingForm should return a formgroup with resultValue control value as a', () => {
        const returnValue = AutomationRuleEditUtils.resultSettingForm(formBuilder, [{ resultValue: 'a' }]);
        expect(returnValue.controls['resultValue'].value[0].resultValue).toEqual('a');
    });
});
