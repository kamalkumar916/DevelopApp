import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as LodashUtils from 'lodash';
import { MessageService } from 'primeng/components/common/messageservice';
import { ConfirmationService } from 'primeng/api';
import { timer } from 'rxjs';
import { takeWhile, finalize } from 'rxjs/operators';


import { AutomationRuleEditModel } from './model/automation-rule-edit.model';
import { EditResponse } from './model/automation-rule-edit.interface';
import {
  AttributeType, BusinessUnit, ActiveInactivate,
  LobResponse, RuleAttribute, RuleCriteriaDetails, RuleOverviewDetails, ValueType, TeamsData,
} from '../model/automation-rule.interface';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { AutomationRuleEditService } from './services/automation-rule-edit.service';
import { AutomationRuleEditUtils } from './services/automation-rule-edit-utils';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';
import {
  ScacCodeQuery, EmployeeprofileQuery, OperationalGroupQuery,
  AccountHierarchyQuery, AccountservicesQuery, LocationDetailsQuery, AssetdetailQuery
} from '../../../query/elastic-search.query';
import { AutomationRulesUtility } from '../services/automation-rules.utility';
import { ErrorUtils } from '../../../../shared/jbh-app-services/error-utils';

@Component({
  selector: 'app-automation-rules-edit',
  templateUrl: './automation-rule-edit.component.html',
  styleUrls: ['./automation-rule-edit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AutomationRuleEditComponent implements OnInit, OnDestroy {
  automationRuleEditModel: AutomationRuleEditModel;
  resultControl: FormArray;

  constructor(private readonly automationRuleEditService: AutomationRuleEditService,
    private readonly activatedRoute: ActivatedRoute, private readonly fb: FormBuilder,
    private readonly changeDetector: ChangeDetectorRef, private readonly router: Router,
    private readonly toastMessage: MessageService, private readonly confirmationService: ConfirmationService) {
    this.automationRuleEditModel = new AutomationRuleEditModel();
  }

  ngOnInit() {
    this.editAttributes(this.activatedRoute.queryParams['value']['ruleCriteriaSetId']);
    this.automationRuleEditModel.editRuleForm = this.fb.group({
      inlineTableForm: this.fb.array([]),
      resultSetting: ['']
    });
    if (this.activatedRoute.queryParams['value'].copyRule) {
      this.automationRuleEditModel.showInactivate = false;
    }
  }
  editAttributes(ruleCriteriaSetId: number): void {
    this.automationRuleEditModel.isLoading = true;
    this.automationRuleEditService.getRuleAttributes(ruleCriteriaSetId).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe),
      finalize(() => this.automationRuleEditModel.isLoading = false)).subscribe((data: RuleAttribute) => {
        if (data) {
          this.setEditRuleAttributes(data);
          if (data.ruleParameters && data.ruleParameters.length > 0) {
            this.automationRuleEditModel.editRuleParam = data.ruleParameters;
            this.setBooleanResultSet(this.automationRuleEditModel.editRuleParam);
            this.setResultSettingFormControl();
          }
          this.setResultSetting(data);
        }

      }, (error: Error) => {
        this.automationRuleEditModel.editRuleParam = null;
        this.automationRuleEditModel.isLoading = false;
      });
  }
  setBooleanResultSet(editRuleParam: any) {
    const editedParam = LodashUtils.cloneDeep(editRuleParam);
    const ruleParameters = LodashUtils.filter(editedParam, { 'ruleParameterTypeDescription': 'Boolean' });
    if (ruleParameters && ruleParameters.length > 0) {
      this.automationRuleEditModel.booleanResult = true;
    }
    this.automationRuleEditModel.textResultValue = editedParam.filter(function (element) {
      return element.ruleParameterTypeDescription.toLowerCase() !== 'boolean';
    });
    if (this.automationRuleEditModel.textResultValue &&
      this.automationRuleEditModel.textResultValue.length > 0) {
      this.automationRuleEditModel.isTextCriteria = true;
      const control = [];
      this.automationRuleEditModel.ruleResults = [];
      this.automationRuleEditModel.textResultValue.forEach((value) => {
        control.push(this.initializeResultSetting());
        this.automationRuleEditModel.ruleResults.push((value.parameterNumberValue) || (value.parameterDateValue));
      });
      this.automationRuleEditModel.editRuleForm.addControl('txtResultSetting', this.fb.array(control));
      this.resultControl = this.automationRuleEditModel.editRuleForm.get('txtResultSetting')['controls'];
    }
  }
  initializeResultSetting(): FormGroup {
    return this.fb.group({
      'resultValue': ['', Validators.required]
    });
  }
  getResultSettingLabel(index: number) {
    return this.automationRuleEditModel.textResultValue[index].ruleParameterTypeDescription;
  }
  setEditRuleAttributes(data) {
    this.automationRuleEditModel.isEditRule = true;
    this.automationRuleEditModel.isLoading = false;
    this.automationRuleEditModel.ruleAttributes = data.ruleCriteriaDetails;
    this.automationRuleEditModel.ruleAttributeReplica = JSON.parse(JSON.stringify(data.ruleCriteriaDetails));
    this.automationRuleEditModel.ruleDetailId = data.ruleDetailId;
    this.automationRuleEditModel.ruleOverviewStatus = data.ruleStatus;
    this.automationRuleEditModel.ruleCriteriaSetId = data.ruleCriteriaSetID;
    if (this.automationRuleEditModel.ruleDetailId) {
      this.getRuleDetails(this.automationRuleEditModel.ruleDetailId);
    }
  }
  setResultSettingFormControl() {
    if (this.automationRuleEditModel.editRuleParam) {
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].setValidators([Validators.required]);
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].updateValueAndValidity();
    } else {
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].clearValidators();
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].updateValueAndValidity();
    }
  }
  setResultSetting(data) {
    this.loadBusinessUnit();
    this.automationRuleEditModel.resultSettingValue = (data.ruleParameters && data.ruleParameters[0] &&
      data.ruleParameters[0].ruleParameterTypeDescription) ? data.ruleParameters[0].ruleParameterTypeDescription : '';
    AutomationRuleEditUtils.setResultSettingValues(data, this.automationRuleEditModel);
  }
  onRowSelect(selectedRule: any) {
    this.automationRuleEditModel.addAttribute = false;
    this.automationRuleEditModel.save = true;
    this.automationRuleEditModel.remove = true;
    this.automationRuleEditModel.cancel = true;
    const rules = this.automationRuleEditModel.ruleAttributes;
    rules.forEach((item, index) => {
      if (item.ruleCriteriaValues.length === 0 && item.editable) {
        this.automationRuleEditModel.ruleAttributes.splice(index, 1);
        LodashUtils.pullAt(this.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'], index);
        if (this.automationRuleEditModel.ruleAttributes.length === 0) {
          this.automationRuleEditModel.selectedRows = [];
        }
      }
    });
    this.automationRuleEditModel.selectedRuleAttribute = selectedRule.data;
    const selIndex = this.automationRuleEditModel.ruleAttributes.findIndex((item) =>
      item['ruleCriteriaCode'] === selectedRule.data.ruleCriteriaCode);
    this.automationRuleEditModel.selectedRowIndex.push(selIndex);
    this.automationRuleEditModel.ruleAttributes[selIndex].editable = true;
    this.automationRuleEditModel.ruleAttributes[selIndex].isCheck = false;
    this.automationRuleEditModel.ruleAttributes[selIndex].attributeItems = [];
    this.automationRuleEditModel.ruleAttributes[selIndex].attributeItems.push({
      label: this.automationRuleEditModel.ruleAttributes[selIndex].ruleCriteriaDescription,
      value: this.automationRuleEditModel.ruleAttributes[selIndex].ruleCriteriaCode
    });
    this.prepopulateValue(selIndex, selectedRule.data);
    const attributeArrayValue = AutomationRuleEditUtils.removeDuplicateAttribute(this.automationRuleEditModel);
    attributeArrayValue.push({ label: selectedRule.data.ruleCriteriaDescription, value: selectedRule.data.ruleCriteriaCode });
    this.automationRuleEditModel.ruleAttributes[selIndex].attributeItems = attributeArrayValue;
    this.changeDetector.detectChanges();
  }
  isThisRowChecked(rowIndex: number, selectedRule): boolean {
    const selIndex = this.automationRuleEditModel.ruleAttributes.findIndex((ruleAttributes) =>
      ruleAttributes && ruleAttributes.editable && ruleAttributes.ruleCriteriaCode === selectedRule.ruleCriteriaCode);
    return (selIndex >= 0);
  }
  onRowUnCheck(deselectedRule: RuleCriteriaDetails) {
    AutomationRuleEditUtils.onRowUnSelect(deselectedRule, this.automationRuleEditModel);
    const selIndex = this.automationRuleEditModel.ruleAttributes.findIndex((item) =>
      item['ruleCriteriaCode'] === deselectedRule.ruleCriteriaCode);
    this.changeDetector.detectChanges();
    this.automationRuleEditModel.selectedRowIndex.splice(selIndex, 1);
  }
  ngOnDestroy() {
    this.automationRuleEditModel.canSubscribe = false;
  }
  generateFormControl() {
    this.automationRuleEditModel.editRuleForm = this.fb.group({
      inlineTableForm: this.fb.array(this.loadFormArrayElements()),
      txtResultSetting: this.fb.array(this.loadResultSettingElements()),
      resultSetting: [this.automationRuleEditModel.resultSettingHours]
    });
    if (this.automationRuleEditModel.resultSettingHours) {
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].setValidators([Validators.required]);
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].updateValueAndValidity();
    } else {
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].clearValidators();
      this.automationRuleEditModel.editRuleForm.controls['resultSetting'].updateValueAndValidity();
    }
  }
  loadFormArrayElements(): Array<FormGroup> {
    const elementsArr: Array<FormGroup> = new Array<FormGroup>();
    for (const item of this.automationRuleEditModel.ruleAttributes) {
      const attributeVal: AttributeType = AutomationRuleEditUtils.getAttributeValue(item);
      const attribute: AttributeType[] = AutomationRuleEditUtils.getAttribute(item);
      const operator: AttributeType[] = AutomationRuleEditUtils.getOperatorValue(item);
      elementsArr.push(AutomationRuleEditUtils.createFormGroup(this.fb, attribute, operator, attributeVal));
    } return elementsArr;
  }
  loadResultSettingElements(): Array<FormGroup> {
    const elementsArr: Array<FormGroup> = new Array<FormGroup>();
    if (this.automationRuleEditModel.textResultValue) {
      const resultVal = AutomationRuleEditUtils.getTextResultValue(this.automationRuleEditModel.textResultValue);
      for (const item of resultVal) {
        elementsArr.push(AutomationRuleEditUtils.resultSettingForm(this.fb, item));
      }
    }
    return elementsArr;
  }
  getRuleDetails(ruleDetailId) {
    this.automationRuleEditModel.canSubscribe = true;
    this.automationRuleEditService.getRuleDetails(ruleDetailId).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: RuleOverviewDetails) => {
        if (data) {
          AutomationRuleEditUtils.getOverViewDetails(this.automationRuleEditModel, data);
          this.automationRuleEditModel.ruleOverViewDetails = data._source;
          if (this.automationRuleEditModel.ruleOverViewDetails.RuleTypeDescription.toLowerCase() === 'company') {
            this.automationRuleEditModel.isRuleStatusAvailable = false;
          } else {
            this.automationRuleEditModel.isRuleStatusAvailable = true;
          }
          this.generateFormControl();
          this.automationRuleEditModel.paramItems =
            AutomationRuleEditUtils.removeDuplicateOperator(this.automationRuleEditModel.paramItems, 'label');
          this.changeDetector.detectChanges();
        }
      });
  }
  onSelectAttribute(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttributeValue = selectedAttribute;
    if (this.automationRuleEditModel.selectedAttributeValue) {
      this.automationRuleEditModel.ruleAttributes[index].ruleCriteriaDescription =
        this.automationRuleEditModel.selectedAttributeValue.value;
    }
    this.automationRuleEditModel.ruleAttributes[index].ruleCriteriaValues = [];
    this.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][index].get('operator').reset();
    this.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][index].get('attributeValue').reset();
    switch (selectedAttribute.label) {
      case 'Business Unit  of Driver/Truck':
      case 'Business Unit':
      case 'Business Unit of Load':
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
        this.setAttributeValuesBU(selectedAttribute, index);
        break;
      case 'Equipment Maintenance Status':
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
        this.automationRuleEditModel.valueItems[index] = this.automationRuleEditModel.equipmentStatusRuleValue;
        break;
      case 'Operational Work Order Sub-Type':
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
        this.setAttributeValuesSubType(selectedAttribute, index);
        break;
      case 'Operational Plan Type':
        this.setOperationalPlanType(selectedAttribute, index);
        break;
      case 'Operational Plan Subtype':
        this.setOperationalPlanSubType(selectedAttribute, index);
        break;
      case 'Stop Reason':
        this.setStopReason(selectedAttribute, index);
        break;
      case 'Trailing Equipment Type':
        this.setEquipmentClassification(selectedAttribute, index);
        break;
      case 'Trailing Equipment Sub Class':
        this.setEquipmentSubClass(selectedAttribute, index);
        break;
      default:
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.autocomplete;
        this.setAttributeValues(selectedAttribute.label, index);
    }
  }
  onSelectOperator(selectedOperator: ValueType, rowIndex: number) {
    this.automationRuleEditModel.ruleAttributes[rowIndex].ruleLogicalOperatorCode = selectedOperator.code;
    this.automationRuleEditModel.ruleAttributes[rowIndex].ruleLogicalOperatorDescription = selectedOperator.description;
  }
  onSelectValueField(selectedValue: AttributeType, rowIndex: number) {
    this.automationRuleEditModel.ruleAttributes[rowIndex].ruleCriteriaValues = [];
    const valueObj = this.automationRuleEditModel.editRuleForm['controls']['inlineTableForm']
    ['controls'][rowIndex]['controls'];
    if (valueObj && valueObj.attributeValue) {
      const valuelist = valueObj.attributeValue.value.map(item => {
        return AutomationRuleEditUtils.attributeValueMapping(item);
      });
      this.automationRuleEditModel.ruleAttributes[rowIndex].ruleCriteriaValues = valuelist;
    }
  }
  setEquipmentSubClass(selectedAttribute: AttributeType, index: number, selectedRule?) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.automationRuleEditService.getEquipmentSubClass().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: any) => {
        if (data) {
          this.automationRuleEditModel.valueItems[index] = AutomationRulesUtility.getEquipmentSubClass(data);
        }
        AutomationRuleEditUtils.prepopulateCriteriaValue(index, selectedRule, this.automationRuleEditModel,
          this.changeDetector);
      });
  }
  onSelectValue(selectedValue: AttributeType, rowIndex: number) {
    if (selectedValue.value.length > 0) {
      const valueObj = this.automationRuleEditModel.editRuleForm['controls']['inlineTableForm']['controls'][rowIndex].value;
      this.automationRuleEditModel.ruleAttributes[rowIndex].ruleCriteriaValues = [];
      const valuelist = valueObj.attributeValue.map(item => {
        return AutomationRuleEditUtils.attributeValueMapping(item);
      });
      this.automationRuleEditModel.ruleAttributes[rowIndex].ruleCriteriaValues = valuelist;
    } else {
      this.automationRuleEditModel.editRuleForm['controls']['inlineTableForm']['controls'][rowIndex].setValue('');
    }
  }
  onRemoveValues(removedValue: AttributeType, index: number) {
    const indexNum = this.automationRuleEditModel.ruleAttributes[index].ruleCriteriaValues.findIndex((item) =>
      item.ruleCriteriaValueDescription === removedValue.label);
    this.automationRuleEditModel.ruleAttributes[index].ruleCriteriaValues.splice(indexNum, 1);
  }
  prepopulateValue(index: number, selectedRule: RuleCriteriaDetails) {
    const attributeSelected: any = this.automationRuleEditModel.ruleAttributes[index].ruleCriteriaDescription;
    switch (attributeSelected) {
      case 'Business Unit':
      case 'Business Unit  of Driver/Truck':
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
        this.setAttributeValuesBU(attributeSelected, index);
        break;
      case 'Operational Work Order Sub-Type':
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
        this.setAttributeValuesSubType(attributeSelected, index);
        break;
      case 'Operational Plan Type':
        this.setOperationalPlanType(attributeSelected, index);
        break;
      case 'Operational Plan Subtype':
        this.setOperationalPlanSubType(attributeSelected, index);
        break;
      case 'Stop Reason':
        this.setStopReason(attributeSelected, index);
        break;
      case 'Trailing Equipment Type':
        this.setEquipmentClassification(attributeSelected, index);
        break;
      case 'Trailing Equipment Sub Class':
        this.setEquipmentSubClass(attributeSelected, index, selectedRule);
        break;
      case 'Operational Plan Classification':
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
        this.setClassification(attributeSelected, index);
        break;
      default:
        this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.autocomplete;
        break;
    }
    this.changeDetector.markForCheck();
    this.changeDetector.detectChanges();
    AutomationRuleEditUtils.prepopulateCriteriaValue(index, selectedRule, this.automationRuleEditModel,
      this.changeDetector);
  }
  setAttributeValuesBU(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.loadBusinessUnit(index);
  }
  setAttributeValuesSubType(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.loadOWOSubType(index);
  }
  setOperationalPlanType(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.loadOperationalPlanType(index);
  }
  setOperationalPlanSubType(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.loadOperationalPlanSubType(index);
  }
  setStopReason(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.loadStopReason(index);
  }
  setEquipmentClassification(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.loadEquipmentClassification(index);
  }
  setClassification(selectedAttribute: AttributeType, index: number) {
    this.automationRuleEditModel.selectedAttribute = selectedAttribute;
    this.automationRuleEditModel.ruleAttributes[index].compType = this.automationRuleEditModel.multiSelect;
    this.getClassificationTypeCode(index);
  }
  getClassificationTypeCode(index: number) {
    this.automationRuleEditService.getClassificationPlan().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: any) => {
        if (data) {
          const indexValue = (index) ? index : 0;
          this.automationRuleEditModel.valueItems[indexValue] = AutomationRulesUtility.populateClassificationTypeValues(data);
          this.changeDetector.detectChanges();
        }
      });
  }
  loadBusinessUnit(index?: number) {
    this.automationRuleEditService.getBusinessUnitData().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: BusinessUnit) => {
        if (data) {
          const indexValue = (index) ? index : 0;
          this.automationRuleEditModel.valueItems[indexValue] = AutomationRuleEditUtils.populateValues(data);
          this.changeDetector.detectChanges();
        }
      });
  }
  loadOWOSubType(index: number) {
    this.automationRuleEditService.getOWOSubtypeData().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: any) => {
        if (data) {
          this.automationRuleEditModel.valueItems[index] = AutomationRulesUtility.populateSubTypeValues(data);
          this.changeDetector.detectChanges();
        }
      });
  }
  loadOperationalPlanType(index: number) {
    this.automationRuleEditService.getOperationalPlanType().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: any) => {
        if (data) {
          this.automationRuleEditModel.valueItems[index] = AutomationRulesUtility.getOperationalPlanType(data);
          this.changeDetector.detectChanges();
        }
      });
  }
  loadOperationalPlanSubType(index: number) {
    this.automationRuleEditService.getOperationalPlanSubtype().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: any) => {
        if (data) {
          this.automationRuleEditModel.valueItems[index] = AutomationRulesUtility.getOperationalPlanSubType(data);
          this.changeDetector.detectChanges();
        }
      });
  }
  loadStopReason(index: number) {
    this.automationRuleEditService.getStopReason().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: any) => {
        if (data) {
          this.automationRuleEditModel.valueItems[index] = AutomationRulesUtility.getStopReason(data);
          this.changeDetector.detectChanges();
        }
      });
  }
  loadEquipmentClassification(index: number) {
    this.automationRuleEditService.getEquipmentClassification().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: any) => {
        if (data) {
          this.automationRuleEditModel.valueItems[index] = AutomationRulesUtility.getEquipmentClassification(data);
          this.changeDetector.detectChanges();
        }
      });
  }
  setAttributeValues(typedText: string, rowIndex: number) {
    const typeaheadInputText = `${typedText.trim().replace(/[^a-zA-Z0-9\s]/g, ' ')}${'*'}`;
    const attribute = this.automationRuleEditModel.editRuleForm.controls['inlineTableForm']
    ['controls'][rowIndex].get('attribute').value.label;
    if (typeaheadInputText.length > 1) {
      switch (attribute) {
        case 'Corporate Account': this.populateCorporateAccountValues(typeaheadInputText, rowIndex);
          break;
        case 'Line of Business': this.populateLineOfBusinessValues(typeaheadInputText, rowIndex);
          break;
        case 'Bill To': this.populateBillToAccountValues(typeaheadInputText, rowIndex);
          break;
        case 'Team': this.populateTeamValues(typeaheadInputText, rowIndex);
          break;
        case 'Location':
        case 'Destination Location':
        case 'Stop Location':
        case 'Origin Location': this.populateLocationValues(typeaheadInputText, rowIndex);
          break;
        case 'SCAC Code': this.populateSCACCodeValues(typeaheadInputText, rowIndex);
          break;
        case 'Operational Group of Driver/Truck':
          this.getOperationalGroup(rowIndex);
          break;
        case 'Operational Group':
          this.populateOperationalGroupValues(typeaheadInputText, rowIndex);
          break;
        case 'Driver':
          this.populateDriverValues(typeaheadInputText, rowIndex);
          break;
        case 'Truck':
          this.populateTruckValues(typeaheadInputText, rowIndex);
          break;
      }
    }
  }

  getOperationalGroup(index: number) {
    this.automationRuleEditService.getOperationalGroupValues().pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe(data => {
        if (data) {
          this.automationRuleEditModel.valueItems[index] = AutomationRuleEditUtils.populateOPGroupValues(data);
        }
      });
  }

  populateDriverValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getDriverData(EmployeeprofileQuery.getDriverQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getDriverRecords(data), rowIndex);
        }
      });
  }

  populateTruckValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getTruckData(AssetdetailQuery.getTruckQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getTruckRecords(data), rowIndex);
        }
      });
  }

  setPopulatedValues(valueItems: Array<AttributeType>, rowIndex: number) {
    this.automationRuleEditModel.valueItemsComplete = valueItems;
    this.automationRuleEditModel.ruleAttributes[rowIndex].hasNoResult =
      this.automationRuleEditModel.valueItemsComplete.length === 0;
    this.changeDetector.detectChanges();
  }

  populateOperationalGroupValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getOperationalGroupData(OperationalGroupQuery.getOperationalGroupQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRuleEditUtils.getOperationalGroupRecords(data), rowIndex);
        }
      });
  }
  populateCorporateAccountValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getCorporateAccountData(AccountHierarchyQuery.getCorporateAccountQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ElasticResponseModel) =>
        this.setAccountRecordsPopulatedValues(data, rowIndex));
  }
  setAccountRecordsPopulatedValues(data: ElasticResponseModel, rowIndex: number) {
    if (data) {
      this.setPopulatedValues(AutomationRulesUtility.getCorporateAccountRecords(data), rowIndex);
    }
  }
  populateLineOfBusinessValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getLineOfBusinessData(AccountHierarchyQuery.getLineofBusinessQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: LobResponse) => {
        if (data && data.aggregations.unique.buckets) {
          this.setPopulatedValues(data.aggregations.unique.buckets.map((item) => {
            return AutomationRulesUtility.getLobRecords(item.Level.hits.hits);
          }), rowIndex);
        }
      });
  }
  populateBillToAccountValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getBillToAccountData(AccountservicesQuery.getBilToAccountQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ElasticResponseModel) =>
        this.setPopulatedValues(AutomationRulesUtility.getBillToData(data), rowIndex));
  }
  populateTeamValues(typeaheadInputText: string, rowIndex: number) {
    const typeaheadInput = `${typeaheadInputText.trim().replace(/[^a-zA-Z0-9\s]/g, ' ')}`;
    const dateTimeStamp = AutomationRuleEditUtils.generateTimeStamp();
    this.automationRuleEditService.getTeamData(typeaheadInput, dateTimeStamp).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: TeamsData) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getTeamRecords(data), rowIndex);
        }
      });
  }
  populateLocationValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getLocationData(LocationDetailsQuery.getOriginDestinationQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRulesUtility.getLocationRecords(data), rowIndex);
        }
      });
  }
  populateSCACCodeValues(typeaheadInputText: string, rowIndex: number) {
    this.automationRuleEditService.getSCACData(ScacCodeQuery.getSCACCodeQuery(typeaheadInputText)).pipe(
      takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ElasticResponseModel) => {
        if (data) {
          this.setPopulatedValues(AutomationRuleEditUtils.getScacRecords(data), rowIndex);
        }
      });
  }
  addNewRow() {
    const editArray = this.automationRuleEditModel.editRuleForm.controls['inlineTableForm'] as FormArray;
    this.automationRuleEditModel.valueItems[editArray.length] = [];
    const attributeArrayValue = AutomationRuleEditUtils.removeDuplicateAttribute(this.automationRuleEditModel);
    if (editArray.valid) {
      editArray.push(AutomationRuleEditUtils.createFormGroup(this.fb));
      AutomationRuleEditUtils.addValidRow(this.automationRuleEditModel, this.changeDetector, attributeArrayValue);
    }
  }
  onHeaderCheckboxToggle(event: boolean) {
    this.automationRuleEditModel.addAttribute = !event;
    this.automationRuleEditModel.save = false;
    this.automationRuleEditModel.cancel = (!this.automationRuleEditModel.addAttribute);
    this.automationRuleEditModel.remove = (!this.automationRuleEditModel.addAttribute);
    if (!event) {
      AutomationRuleEditUtils.setUnCheckedValues(this.automationRuleEditModel);
    } else {
      AutomationRuleEditUtils.setCheckedValues(this.automationRuleEditModel);
    }
  }
  onInlineSave() {
    this.automationRuleEditModel.ruleAttributes.forEach((element, index) => {
      for (const item of this.automationRuleEditModel.selectedRowIndex) {
        if (index === item && element.editable) {
          AutomationRuleEditUtils.setRuleAttributeValues(index, this.automationRuleEditModel);
        }
      }
    });
    if (this.automationRuleEditModel.ruleAttributes[0].editable) {
      AutomationRuleEditUtils.setRuleAttributeValues(0, this.automationRuleEditModel);
    }
    if (this.automationRuleEditModel.editRuleForm.controls['inlineTableForm'].valid) {
      AutomationRuleEditUtils.setheaderValues(this.automationRuleEditModel);
    } else {
      AutomationRuleEditUtils.showMissingInputvalidation(this.toastMessage);
      this.automationRuleEditModel.addAttribute = false;
      this.automationRuleEditModel.save = true;
      this.automationRuleEditModel.cancel = true;
    }
    this.changeDetector.detectChanges();
    this.automationRuleEditModel.isSave = true;
    this.automationRuleEditModel.remove = this.automationRuleEditModel.selectedRows.length > 0;
  }
  onCancelEdit() {
    this.router.navigate(['/admin/automationrules']);
  }
  onInlineCancel() {
    if (this.automationRuleEditModel.selectedRows && this.automationRuleEditModel.selectedRows.length > 0) {
      for (const item of this.automationRuleEditModel.selectedRowIndex) {
        if (this.automationRuleEditModel.ruleAttributes[item].editable !== undefined) {
          this.automationRuleEditModel.ruleAttributes[item].editable = false;
          this.automationRuleEditModel.ruleAttributes[item].isCheck = false;
          if (this.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][item].invalid) {
            this.prepopulateValue(item, this.automationRuleEditModel.selectedRuleAttribute);
          }
          this.changeDetector.detectChanges();
        }
      }
    }
    AutomationRuleEditUtils.cancelInlineUtility(this.automationRuleEditModel);
  }
  onInlineRemove() {
    this.automationRuleEditModel.isSave = true;
    AutomationRuleEditUtils.removeInlineAttributes(this.automationRuleEditModel);
    AutomationRuleEditUtils.inlineRemove(this.automationRuleEditModel);
  }
  onClickSave() {
    if (!this.automationRuleEditModel.isSave) {
      AutomationRuleEditUtils.constructRuleCriteriaDetailsJson(this.automationRuleEditModel,
        this.automationRuleEditModel.ruleAttributeReplica);
    } else {
      AutomationRuleEditUtils.constructRuleCriteriaDetailsJson(this.automationRuleEditModel,
        this.automationRuleEditModel.ruleAttributes);
    }
    if (this.activatedRoute.queryParams['value'].copyRule) {
      this.copyEditAttributes();
    } else {
      this.onEditAttributes();
    }
  }
  copyEditAttributes() {
    this.automationRuleEditModel.editRequest.ruleCriteriaSetId = null;
    this.automationRuleEditModel.editRequest.ruleDetailId = this.automationRuleEditModel.ruleDetailId;
    this.automationRuleEditModel.editRequest.orderRuleSupersedeTypeCode = null;
    this.automationRuleEditModel.editRequest.ruleCriteriaDetails = this.automationRuleEditModel.ruleCriteriaDetailsJSON;
    this.automationRuleEditModel.editRequest.ruleParameters = [];
    if (this.automationRuleEditModel.editRuleParam) {
      this.automationRuleEditModel.editRequest.ruleParameters = (AutomationRuleEditUtils.
        getRuleParamDetails(this.automationRuleEditModel));
    } else {
      this.automationRuleEditModel.editRequest.ruleParameters = [];
    }
    this.validateRequestJson(this.automationRuleEditModel.editRequest);
    if (this.automationRuleEditModel.editRequest.ruleCriteriaDetails.length > 0 &&
      this.automationRuleEditModel.editRuleForm.valid) {
      this.automationRuleEditService.copyRule(this.automationRuleEditModel.editRequest).pipe(
        takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: EditResponse) => {
          this.editSuccess(data);
        }, (error: Error) => {
          this.duplicateCheck(error);
        });
    } else {
      FormValidationUtils.validateAllFormFields(this.automationRuleEditModel.editRuleForm);
      AutomationRuleEditUtils.showMissingInputvalidation(this.toastMessage);
    }
  }
  editSuccess(data: EditResponse) {
    if (data) {
      this.router.navigate(['/admin/automationrules/viewconfigurerule'],
        {
          queryParams: {
            ruleCriteriaSetId: data.ruleCriteriaSetId,
            ruleDetailId: this.activatedRoute.queryParams['_value'].ruledetailid
          }
        });
    }
  }
  onEditAttributes() {
    this.automationRuleEditModel.editRequest.ruleCriteriaSetId = this.activatedRoute.queryParams['value']['ruleCriteriaSetId'];
    this.automationRuleEditModel.editRequest.ruleDetailId = this.automationRuleEditModel.ruleDetailId;
    this.automationRuleEditModel.editRequest.orderRuleSupersedeTypeCode = null;
    this.automationRuleEditModel.editRequest.ruleCriteriaDetails = this.automationRuleEditModel.ruleCriteriaDetailsJSON;
    this.automationRuleEditModel.editRequest.ruleParameters = [];
    if (this.automationRuleEditModel.editRuleParam) {
      this.automationRuleEditModel.editRequest.ruleParameters = (AutomationRuleEditUtils.
        getRuleParamDetails(this.automationRuleEditModel));
    } else {
      this.automationRuleEditModel.editRequest.ruleParameters = [];
    }
    this.validateRequestJson(this.automationRuleEditModel.editRequest);
    if (this.automationRuleEditModel.editRequest.ruleCriteriaDetails.length > 0 &&
      this.automationRuleEditModel.editRuleForm.valid) {
      this.automationRuleEditService.editRule(this.automationRuleEditModel.editRequest).pipe(
        takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: EditResponse) => {
          this.editSuccess(data);
        }, (error: Error) => {
          this.duplicateCheck(error);
        });
    } else {
      FormValidationUtils.validateAllFormFields(this.automationRuleEditModel.editRuleForm);
      AutomationRuleEditUtils.showMissingInputvalidation(this.toastMessage);
    }
  }
  duplicateCheck(error) {
    if (error['status'] === 409) {
      if (error.error['inactiveRuleCriteriaSetId']) {
        this.automationRuleEditModel.duplicateRulePopUp = true;
        this.automationRuleEditModel.duplicateError = error.error;
        this.changeDetector.detectChanges();
      } else {
        this.automationRuleEditModel.duplicateError = null;
        AutomationRuleEditUtils.showMissingInputvalidation(this.toastMessage, true);
      }
    } else if (error && error['status'] === 500) {
      this.toastMessage.add({
        severity: 'error',
        summary: 'Server Error',
        detail: ErrorUtils.getErrorMessage(error['status'])
      });
    }
  }
  duplicateRuleReject() {
    this.automationRuleEditModel.duplicateRulePopUp = false;
    this.changeDetector.detectChanges();
    AutomationRuleEditUtils.showMissingInputvalidation(this.toastMessage, true);
  }
  duplicateRuleAccept() {
    this.automationRuleEditModel.duplicateRulePopUp = false;
    this.changeDetector.detectChanges();
    if (this.automationRuleEditModel.duplicateError && this.automationRuleEditModel.duplicateError.inactiveRuleCriteriaSetId) {
      this.router.navigate(['/admin/automationrules/viewconfigurerule'],
        {
          queryParams: {
            ruleCriteriaSetId: this.automationRuleEditModel.duplicateError.inactiveRuleCriteriaSetId,
          }
        });
    }
  }
  validateRequestJson(editRequest) {
    if (editRequest.ruleCriteriaDetails.length === 0) {
      AutomationRuleEditUtils.showMissingInputvalidation(this.toastMessage);
    } else if (this.automationRuleEditModel.editRuleForm.controls['resultSetting'].value === '') {
      this.automationRuleEditModel.resultSettingError = true;
    }
  }
  onInactivate(status: boolean) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to inactivate the rule ?',
      header: 'Inactivate Rule',
      key: 'Inactivate',
      accept: (): void => {
        this.activeInactivate(status);
      }
    });
  }
  onActivate(status: boolean) {
    this.activeInactivate(status);
  }
  activeInactivate(status: boolean) {
    this.automationRuleEditService.getActiveInactiveRule(this.activatedRoute.queryParams['value']['ruleCriteriaSetId'], status)
      .pipe(takeWhile(() => this.automationRuleEditModel.canSubscribe)).subscribe((data: ActiveInactivate) => {
        if (data) {
          timer(2000).pipe(takeWhile(() => this.automationRuleEditModel.canSubscribe))
            .subscribe((_: any) => {
              this.router.navigate(['/admin/automationrules']);
            });
        }
        this.changeDetector.detectChanges();
      });
  }
  getresultSettingControls() {
    return this.automationRuleEditModel.editRuleForm.controls['txtResultSetting'];
  }
  getResultSettingList(form: FormArray) {
    if (form) {
      return form;
    }
    return [];
  }
  onChangeResultSetting(resultValue) {
    if (resultValue && resultValue.length === 0) {
      this.automationRuleEditModel.editRuleForm.controls.resultSetting.setErrors({ invalid: true });
    }
  }
}
