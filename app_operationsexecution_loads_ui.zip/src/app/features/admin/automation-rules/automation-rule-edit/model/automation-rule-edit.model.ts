import { FormGroup, FormArray } from '@angular/forms';
import { Breadcrumb } from '../../../../model/breadcrumb.interface';
import { EditRequest, EditResponse } from './automation-rule-edit.interface';
import {
    RuleCriteriaDetails, AttributeType,
    SourceDetails, ValueType, RuleCriteriaDetailsItem, RuleParameters
} from '../../model/automation-rule.interface';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../../../config/app.config';

export class AutomationRuleEditModel {
    breadcrumb: Breadcrumb[];
    canSubscribe: boolean;
    ruleAttributes: RuleCriteriaDetails[];
    ruleAttributeReplica: RuleCriteriaDetails[];
    ruleOverViewDetails: SourceDetails;
    editRuleForm: FormGroup;
    ruleOverviewStatus: string;
    isRuleStatusAvailable: boolean;
    resultSettingValue: string;
    resultSettingHours: number | string;
    isEditRule: boolean;
    ruleDetailId: number;
    paramItems: AttributeType[];
    attributeItems: AttributeType[];
    filterAttributeItems: AttributeType[];
    selectedAttributeValue: AttributeType;
    compType: string;
    selectedAttribute: AttributeType;
    valueItems: AttributeType[][];
    valueItemsComplete: AttributeType[];
    hasNoResult: boolean;
    selectedRows: RuleCriteriaDetails[];
    addAttribute: boolean;
    remove: boolean;
    save: boolean;
    cancel: boolean;
    criteriaValues: AttributeType[];
    ruleCriteriaDetailsJSON: RuleCriteriaDetailsItem[];
    editRequest: EditRequest;
    ruleCriteriaSetId: number;
    isLoading: boolean;
    selectedRowIndex: number[];
    editRuleParam: RuleParameters[];
    resultSettingError: boolean;
    isSave: boolean;
    showInactivate: boolean;
    inputNumberPatternRegEx: RegExp;
    selectedRuleAttribute: any;
    isCheck: boolean;
    multiSelect: string;
    autocomplete: string;
    equipmentStatusRuleValue: AttributeType[];
    booleanResult: boolean;
    booleanResultSets: AttributeType[];
    ruleResults: any;
    resultValue: AttributeType[];
    logicalOperatorCode: string;
    logicalOperatorDescription: string;
    isTextCriteria: boolean;
    textResultValue: any;
    duplicateRulePopUp: boolean;
    duplicateError: EditResponse;
    appConfig;
    editButton: SecureModel;
    inactivateButton: SecureModel;
    constructor() {
        this.breadcrumb = [
            { label: 'Administration', routerLink: [''] },
            { label: 'Automation Rules', routerLink: ['/admin/automationrules'] },
            { label: 'Edit Rule' }];
        this.canSubscribe = true;
        this.ruleAttributes = [];
        this.selectedRows = [];
        this.isCheck = true;
        this.isRuleStatusAvailable = false;
        this.paramItems = [];
        this.attributeItems = [];
        this.filterAttributeItems = [];
        this.compType = 'multiselect';
        this.addAttribute = true;
        this.selectedRowIndex = [];
        this.ruleAttributeReplica = [];
        this.editRequest = {
            ruleDetailId: null,
            ruleCriteriaSetId: null,
            orderRuleSupersedeTypeCode: null,
            ruleCriteriaDetails: [],
            ruleParameters: []
        };
        this.showInactivate = true;
        this.inputNumberPatternRegEx = /^[0-9.]*$/;
        this.multiSelect = 'multiselect';
        this.autocomplete = 'autocomplete';
        this.equipmentStatusRuleValue = [{
            label: 'Operational',
            value: 'Operational'
        }];
        this.booleanResult = false;
        this.booleanResultSets = [];
        this.isTextCriteria = false;
        this.logicalOperatorCode = 'Equal';
        this.logicalOperatorDescription = 'Equals';
        this.valueItems = [];
        this.duplicateRulePopUp = false;
        this.duplicateError = null;
        this.appConfig = AppConfig.getConfig();
        this.editButton = { url: this.appConfig.api.automationRules.createRule, operation: 'C' };
        this.inactivateButton = { url: this.appConfig.api.automationRules.activeInactiveRule, operation: 'C' };
    }
}
