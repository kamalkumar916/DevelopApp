import {
    RuleCriteriaDetailsItem, RuleParameters
} from '../../model/automation-rule.interface';
export interface EditRequest {
    ruleDetailId: number;
    ruleCriteriaSetId: number;
    orderRuleSupersedeTypeCode: number;
    ruleCriteriaDetails: RuleCriteriaDetailsItem[];
    ruleParameters: RuleParameters[];
}

export interface EditResponse {
    ruleDetailId: string;
    ruleCriteriaSetId: number;
    ruleStatus: string;
    ruleSupersedeTypeCode: string;
    ruleCriteriaDetails: string;
    ruleParameters: string;
    inactiveRuleCriteriaSetId: number;
}
