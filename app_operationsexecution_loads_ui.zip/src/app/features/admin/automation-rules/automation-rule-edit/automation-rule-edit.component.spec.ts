import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { AutomationRuleEditComponent } from './automation-rule-edit.component';
import { MessageService } from 'primeng/components/common/messageservice';
import { DialogModule } from 'primeng/dialog';
import { AutomationRuleEditService } from './services/automation-rule-edit.service';

import { configureTestSuite } from 'ng-bullet';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MultiSelectModule } from 'primeng/multiselect';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { RuleOverviewComponent } from '../rule-overview/rule-overview.component';
import { DirectivesModule } from '../../../../shared/directives/directives.module';
import { AutomationRuleEditUtils } from './services/automation-rule-edit-utils';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../../../../shared/jbh-esa/index';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { AutomationRulesUtility } from '../services/automation-rules.utility';
import { Router } from '@angular/router';

const ruleAttributes = [{
  ruleCriteriaCode: '',
  ruleCriteriaDescription: '',
  ruleLogicalOperatorCode: '',
  ruleLogicalOperatorDescription: '',
  ruleCriteriaValues: [{
    ruleCriteriaValue: '',
    ruleCriteriaDetailId: 1,
    ruleCriteriaValueDescription: ''
  }],
  editable: true,
  hasNoResult: true,
  ruleCriteriaId: 1,
  compType: '',
  attributeItems: [{
    label: '',
    value: ''
  }],
  isCheck: true
}];
const selectedRuleData = {
  ruleCriteriaCode: '',
  ruleCriteriaDescription: '',
  ruleLogicalOperatorCode: 'code',
  ruleLogicalOperatorDescription: '',
  ruleCriteriaValues: [{
    ruleCriteriaValue: '',
    ruleCriteriaDetailId: 1,
    ruleCriteriaValueDescription: 'description',
  }],
  editable: true,
  hasNoResult: true,
  ruleCriteriaId: 1,
  compType: '',
  attributeItems: [{
    label: '',
    value: ''
  }],
  isCheck: false
};
const editRuleParam = [
  {
    ruleParameterId: 1,
    ruleParameterCriteriaCode: '',
    ruleParameterTypeDescription: 'Boolean',
    ruleParameterTypeName: '',
    ruleParameterTypeCode: '',
    ruleParameterValueTypeCode: '',
    ruleLogicalOperatorCode: '',
    ruleLogicalOperatorDescription: '',
    parameterNumberValue: 1,
    parameterCharValue: '',
    parameterDateValue: '',
  }, {
    ruleParameterId: 1,
    ruleParameterCriteriaCode: '',
    ruleParameterTypeDescription: '',
    ruleParameterTypeName: '',
    ruleParameterTypeCode: '',
    ruleParameterValueTypeCode: '',
    ruleLogicalOperatorCode: '',
    ruleLogicalOperatorDescription: '',
    parameterNumberValue: 1,
    parameterCharValue: '',
    parameterDateValue: '',
  }
];
const ruleattributesarray = {
  ruleCriteriaCode: '',
  ruleCriteriaDescription: '',
  ruleLogicalOperatorCode: 'code',
  ruleLogicalOperatorDescription: '',
  ruleCriteriaValues: [{
    ruleCriteriaValue: '',
    ruleCriteriaDetailId: 1,
    ruleCriteriaValueDescription: 'description',
  }],
  editable: true,
  hasNoResult: true,
  ruleCriteriaId: 1,
  compType: '',
  attributeItems: [{
    label: '',
    value: ''
  }],
  isCheck: false
};
const getRuleAttributesData = {
  ruleStatus: 'Active',
  ruleSupersedeTypeCode: null,
  inactiveRuleCriteriaSetId: null,
  ruleCriteriaSetId: 28,
  ruleDetailId: 31,
  ruleParameters: [{
    parameterCharValue: 'NULL',
    parameterDateValue: null,
    parameterNumberValue: 100,
    parameterTypeName: 'Allowed Switch Distance',
    ruleLogicalOperatorCode: 'Equal',
    ruleLogicalOperatorDescription: 'Equals',
    ruleParameterCriteriaCode: 'AllSwtchDs',
    ruleParameterId: 54,
    ruleParameterTypeDescription: 'Miles',
    ruleParameterValueTypeCode: 'Number'
  }],
  ruleCriteriaDetails: []
};
const getRuleDetailsData = {
  found: true,
  _id: '31',
  _index: '',
  _type: 'doc',
  _version: 6,
  _source: {
    CreateProgramName: 'SSIS',
    CreateTimestamp: '',
    CreateUserID: '',
    EffectiveTimestamp: '',
    ExpirationTimestamp: '',
    LastUpdateProgramName: 'SSIS',
    LastUpdateTimestamp: '',
    LastUpdateUserID: '',
    RuleBusinessProcessCode: 'Execution',
    RuleBusinessProcessDescription: 'Execution',
    RuleCategoryCode: 'AutoSwtch',
    RuleCategoryDescription: 'Automated Switch',
    RuleCategoryTypeAssociationID: 1,
    RuleCode: 'AlwStchDst',
    RuleComment: 'Check the configurable distance between the location of the truck and Switch location',
    RuleDescription: 'Check the configurable distance between the location of the truck and Switch location',
    RuleDetailID: 31,
    RuleInclusionExclusionTypeCode: 'Inclusion',
    RuleName: 'Allowed Switch Distance',
    RuleSequenceNumber: 0,
    RuleTypeCode: 'BusUnit',
    RuleTypeDescription: 'Business Unit',
    SendCustomerNotificationIndicator: 'N',
    RuleCriteria: [],
    RuleParameter: [{
      ParameterDefaultCharValue: 'NULL',
      ParameterDefaultDateValue: null,
      ParameterDefaultNumberValue: 100,
      ParameterTypeName: 'Allowed Switch Distance',
      RuleParameterCriteriaCode: 'AllSwtchDs',
      RuleParameterID: null,
      RuleParameterTypeCode: 'Miles',
      RuleParameterTypeDescription: 'Miles',
      RuleParameterValueTypeCode: 'Number'
    }]
  }
};
const getEquipmentSubClassData = {
  _embedded: {
    equipmentTypes: [{
      equipmentTypeDescription: '',
      equipmentTypeCode: ''
    }]
  }
};
const getSCACDataValue = {
  took: null,
  timed_out: false,
  hits: {
    max_score: null,
    total: null,
    hits: [{
      sort: [],
      _id: '',
      _index: '',
      _score: null,
      _source: {},
      _type: ''
    }]
  },
  _shards: {
    total: null,
    successful: null,
    skipped: null,
    failed: null
  }
};

class MockAutomationRuleEditService {
  constructor() { }
  getRuleAttributes() {
    return of(getRuleAttributesData);
  }
  getRuleDetails() {
    return of(getRuleDetailsData);
  }
  getEquipmentSubClass() {
    return of(getEquipmentSubClassData);
  }
  getClassificationPlan() {
    return throwError(null);
  }
  getBusinessUnitData() {
    return throwError(null);
  }
  getOWOSubtypeData() {
    return throwError(null);
  }
  getOperationalPlanType() {
    return throwError(null);
  }
  getOperationalPlanSubtype() {
    return throwError(null);
  }
  getStopReason() {
    return throwError(null);
  }
  getEquipmentClassification() {
    return throwError(null);
  }
  getOperationalGroupValues() {
    return throwError(null);
  }
  getDriverData() {
    return throwError(null);
  }
  getTruckData() {
    return throwError(null);
  }
  getOperationalGroupData() {
    return throwError(null);
  }
  getCorporateAccountData() {
    return throwError(null);
  }
  getLineOfBusinessData() {
    return throwError(null);
  }
  getBillToAccountData() {
    return throwError(null);
  }
  getTeamData() {
    return throwError(null);
  }
  getLocationData() {
    return throwError(null);
  }
  getSCACData() {
    return of(getSCACDataValue);
  }
  copyRule() {
    return throwError(null);
  }
  editRule() {
    return throwError(null);
  }
  getActiveInactiveRule() {
    return throwError(null);
  }
}

describe('AutomationRuleEditComponent', () => {
  let component: AutomationRuleEditComponent;
  let fixture: ComponentFixture<AutomationRuleEditComponent>;
  const formbuilder: FormBuilder = new FormBuilder();

  const editRuleForm = formbuilder.group({
    txtResultSetting: formbuilder.array([formbuilder.group({
      'resultValue': ['']
    })]),
    resultSetting: [''],
    inlineTableForm: formbuilder.array([formbuilder.group({
      attribute: [[{}]],
      operator: [''],
      attributeValue: ['']
    })])
  });
  const editRuleFormInvalid = formbuilder.group({
    txtResultSetting: formbuilder.array([formbuilder.group({
      'resultValue': ['']
    })]),
    resultSetting: [''],
    inlineTableForm: formbuilder.array([formbuilder.group({
      attribute: ['', Validators.required],
      operator: [''],
      attributeValue: ['']
    })])
  });

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, RouterTestingModule, HttpClientModule,
        BreadcrumbModule, CheckboxModule, AutoCompleteModule, DropdownModule, MultiSelectModule, FormsModule,
        ReactiveFormsModule, TableModule, ConfirmDialogModule, DirectivesModule, DialogModule],
      providers: [MessageService, AppConfigService, ConfirmationService,
        { provide: AutomationRuleEditService, useClass: MockAutomationRuleEditService }, UserService],
      declarations: [AutomationRuleEditComponent, RuleOverviewComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutomationRuleEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onInlineRemove should set isSave property to be true', () => {
    spyOn(AutomationRuleEditUtils, 'removeInlineAttributes');
    spyOn(AutomationRuleEditUtils, 'inlineRemove');
    component.onInlineRemove();
    expect(component.automationRuleEditModel.isSave).toBe(true);
  });

  it('generateFormControl should set resultSetting control value as result', () => {
    spyOn(component, 'loadFormArrayElements').and.returnValue([]);
    spyOn(component, 'loadResultSettingElements').and.returnValue([]);
    component.automationRuleEditModel.editRuleForm = null;
    component.automationRuleEditModel.resultSettingHours = 'result';
    component.generateFormControl();
    expect(component.automationRuleEditModel.editRuleForm.controls['resultSetting'].value).toEqual('result');
  });

  it('generateFormControl should set resultSetting control value as empty string', () => {
    spyOn(component, 'loadFormArrayElements').and.returnValue([]);
    spyOn(component, 'loadResultSettingElements').and.returnValue([]);
    component.automationRuleEditModel.resultSettingHours = '';
    component.generateFormControl();
    expect(component.automationRuleEditModel.editRuleForm.controls['resultSetting'].value).toEqual('');
  });

  it('onClickSave should call the spy constructRuleCriteriaDetailsJson', () => {
    spyOn(AutomationRuleEditUtils, 'constructRuleCriteriaDetailsJson');
    spyOn(component, 'copyEditAttributes');
    TestBed.get(ActivatedRoute).queryParams = {
      value: {
        ruleCriteriaSetId: '',
        copyRule: true
      }
    };
    component.automationRuleEditModel.isSave = false;
    component.onClickSave();
    expect(AutomationRuleEditUtils.constructRuleCriteriaDetailsJson).toHaveBeenCalled();
  });

  it('onClickSave else case should call the spy constructRuleCriteriaDetailsJson', () => {
    spyOn(AutomationRuleEditUtils, 'constructRuleCriteriaDetailsJson');
    spyOn(component, 'onEditAttributes');
    component.automationRuleEditModel.isSave = true;
    component.onClickSave();
    expect(AutomationRuleEditUtils.constructRuleCriteriaDetailsJson).toHaveBeenCalled();
  });

  it('duplicateRuleAccept should set duplicateRulePopUp to be false', () => {
    const router: Router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.automationRuleEditModel.duplicateError = {
      ruleDetailId: '',
      ruleCriteriaSetId: null,
      ruleStatus: '',
      ruleSupersedeTypeCode: '',
      ruleCriteriaDetails: '',
      ruleParameters: '',
      inactiveRuleCriteriaSetId: 1
    };
    component.duplicateRuleAccept();
    expect(component.automationRuleEditModel.duplicateRulePopUp).toBe(false);
  });

  it('loadFormArrayElements should return an array of length 1', () => {
    spyOn(AutomationRuleEditUtils, 'getAttributeValue').and.returnValue([]);
    spyOn(AutomationRuleEditUtils, 'getAttribute').and.returnValue([]);
    spyOn(AutomationRuleEditUtils, 'getOperatorValue').and.returnValue([]);
    spyOn(AutomationRuleEditUtils, 'createFormGroup').and.returnValue(formbuilder.group({}));
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    expect(component.loadFormArrayElements().length).toEqual(1);
  });

  it('loadResultSettingElements should return an array of length 1', () => {
    spyOn(AutomationRuleEditUtils, 'getTextResultValue').and.returnValue([{ resultValue: '' }]);
    spyOn(AutomationRuleEditUtils, 'resultSettingForm').and.returnValue(formbuilder.group({
      resultValue: ['a']
    }));
    component.automationRuleEditModel.textResultValue = [{}];
    expect(component.loadResultSettingElements().length).toEqual(1);
  });

  it('onSelectAttribute should call the spy setAttributeValuesBU', () => {
    spyOn(component, 'setAttributeValuesBU');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Business Unit  of Driver/Truck', value: '' }, 0);
    expect(component.setAttributeValuesBU).toHaveBeenCalled();
  });

  it('onSelectAttribute with label Equipment Maintenance Status have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.multiSelect = '';
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Equipment Maintenance Status', value: '' }, 0);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('');
  });

  it('onSelectAttribute with label Operational Work Order Sub-Type have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    spyOn(component, 'setAttributeValuesSubType');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Operational Work Order Sub-Type', value: '' }, 0);
    expect(component.setAttributeValuesSubType).toHaveBeenCalled();
  });

  it('onSelectAttribute with label Operational Plan Type have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    spyOn(component, 'setOperationalPlanType');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Operational Plan Type', value: '' }, 0);
    expect(component.setOperationalPlanType).toHaveBeenCalled();
  });

  it('onSelectAttribute with label Operational Plan Subtype have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    spyOn(component, 'setOperationalPlanSubType');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Operational Plan Subtype', value: '' }, 0);
    expect(component.setOperationalPlanSubType).toHaveBeenCalled();
  });

  it('onSelectAttribute with label Stop Reason have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    spyOn(component, 'setStopReason');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Stop Reason', value: '' }, 0);
    expect(component.setStopReason).toHaveBeenCalled();
  });

  it('onSelectAttribute with label Trailing Equipment Type have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    spyOn(component, 'setEquipmentClassification');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Trailing Equipment Type', value: '' }, 0);
    expect(component.setEquipmentClassification).toHaveBeenCalled();
  });

  it('onSelectAttribute with label Trailing Equipment Sub Class have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    spyOn(component, 'setEquipmentSubClass');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: 'Trailing Equipment Sub Class', value: '' }, 0);
    expect(component.setEquipmentSubClass).toHaveBeenCalled();
  });

  it('onSelectAttribute with default value have been called', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    spyOn(component, 'setAttributeValues');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectAttribute({ label: '', value: '' }, 0);
    expect(component.setAttributeValues).toHaveBeenCalled();
  });

  it('onSelectOperator should set the value of ruleLogicalOperatorCode property to a', () => {
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onSelectOperator({ code: 'a', description: '' }, 0);
    expect(component.automationRuleEditModel.ruleAttributes[0].ruleLogicalOperatorCode).toEqual('a');
  });

  it('onSelectValueField should push one value into ruleCriteriaValues array', () => {
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.editRuleForm = formbuilder.group({
      inlineTableForm: formbuilder.array([formbuilder.group({
        attribute: [''],
        operator: [''],
        attributeValue: [[{ label: '', value: '' }]]
      })])
    });
    component.onSelectValueField({ label: '', value: '' }, 0);
    expect(component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaValues.length).toEqual(1);
  });

  it('onSelectValue if case coverage', () => {
    spyOn(AutomationRuleEditUtils, 'attributeValueMapping');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.editRuleForm = formbuilder.group({
      inlineTableForm: formbuilder.array([formbuilder.group({
        attribute: [''],
        operator: [''],
        attributeValue: [[{ label: '', value: '' }]]
      })])
    });
    component.onSelectValue({ label: '', value: 'a' }, 0);
    expect(component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaValues.length).toEqual(1);
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Business Unit', () => {
    spyOn(component, 'loadBusinessUnit');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.multiSelect = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Business Unit';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Operational Work Order Sub-Type', () => {
    spyOn(component, 'loadOWOSubType');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.multiSelect = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Operational Work Order Sub-Type';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Operational Plan Type', () => {
    spyOn(component, 'loadOperationalPlanType');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.multiSelect = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Operational Plan Type';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Operational Plan Subtype', () => {
    spyOn(component, 'loadOperationalPlanSubType');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.multiSelect = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Operational Plan Subtype';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Stop Reason', () => {
    spyOn(component, 'loadStopReason');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.multiSelect = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Stop Reason';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Trailing Equipment Type', () => {
    spyOn(component, 'loadEquipmentClassification');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.multiSelect = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Trailing Equipment Type';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Trailing Equipment Sub Class', () => {
    spyOn(component, 'setEquipmentSubClass');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Trailing Equipment Sub Class';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.setEquipmentSubClass).toHaveBeenCalled();
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to empty string', () => {
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.autocomplete = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = '';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('prepopulateValue is called with ruleCriteriaDescription value equal to Operational Plan Classification', () => {
    spyOn(component, 'getClassificationTypeCode');
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.multiSelect = 'abc';
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaDescription = 'Operational Plan Classification';
    component.prepopulateValue(0, selectedRuleData);
    expect(component.automationRuleEditModel.ruleAttributes[0].compType).toEqual('abc');
  });

  it('onRemoveValues set the ruleCriteriaValues array to be empty', () => {
    component.automationRuleEditModel.ruleAttributes = [{
      ruleCriteriaCode: '',
      ruleCriteriaDescription: '',
      ruleLogicalOperatorCode: '',
      ruleLogicalOperatorDescription: '',
      ruleCriteriaValues: [{
        ruleCriteriaValue: '',
        ruleCriteriaDetailId: 1,
        ruleCriteriaValueDescription: 'a'
      }],
      editable: true,
      hasNoResult: true,
      ruleCriteriaId: 1,
      compType: '',
      attributeItems: [{
        label: '',
        value: ''
      }],
      isCheck: true
    }];
    component.onRemoveValues({ label: 'a', value: '' }, 0);
    expect(component.automationRuleEditModel.ruleAttributes[0].ruleCriteriaValues.length).toEqual(0);
  });

  it('setAttributeValues with Corporate Account have been called', () => {
    spyOn(component, 'populateCorporateAccountValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Corporate Account', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateCorporateAccountValues).toHaveBeenCalled();
  });

  it('setAttributeValues with Line of Business have been called', () => {
    spyOn(component, 'populateLineOfBusinessValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Line of Business', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateLineOfBusinessValues).toHaveBeenCalled();
  });

  it('setAttributeValues with Bill To have been called', () => {
    spyOn(component, 'populateBillToAccountValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Bill To', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateBillToAccountValues).toHaveBeenCalled();
  });

  it('setAttributeValues with Team have been called', () => {
    spyOn(component, 'populateTeamValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Team', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateTeamValues).toHaveBeenCalled();
  });

  it('setAttributeValues with Location have been called', () => {
    spyOn(component, 'populateLocationValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Location', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateLocationValues).toHaveBeenCalled();
  });

  it('setAttributeValues with SCAC Code have been called', () => {
    spyOn(component, 'populateSCACCodeValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'SCAC Code', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateSCACCodeValues).toHaveBeenCalled();
  });

  it('setAttributeValues with Operational Group of Driver/Truck have been called', () => {
    spyOn(component, 'getOperationalGroup');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Operational Group of Driver/Truck', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.getOperationalGroup).toHaveBeenCalled();
  });

  it('setAttributeValues with Operational Group have been called', () => {
    spyOn(component, 'populateOperationalGroupValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Operational Group', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateOperationalGroupValues).toHaveBeenCalled();
  });

  it('setAttributeValues with Driver have been called', () => {
    spyOn(component, 'populateDriverValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Driver', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateDriverValues).toHaveBeenCalledWith('abc*', 0);
  });

  it('setAttributeValues with Truck have been called', () => {
    spyOn(component, 'populateTruckValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.editRuleForm.controls['inlineTableForm']['controls'][0]['controls']['attribute'].patchValue({
      label: 'Truck', value: ''
    });
    component.setAttributeValues('abc', 0);
    expect(component.populateTruckValues).toHaveBeenCalledWith('abc*', 0);
  });

  it('addNewRow should call the spy addValidRow', () => {
    spyOn(AutomationRuleEditUtils, 'createFormGroup').and.returnValue(formbuilder.group({}));
    spyOn(AutomationRuleEditUtils, 'removeDuplicateAttribute');
    spyOn(AutomationRuleEditUtils, 'addValidRow');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.addNewRow();
    expect(AutomationRuleEditUtils.addValidRow).toHaveBeenCalled();
  });

  it('onHeaderCheckboxToggle should set the property save to be false', () => {
    spyOn(AutomationRuleEditUtils, 'setCheckedValues');
    component.onHeaderCheckboxToggle(true);
    expect(component.automationRuleEditModel.save).toBeFalsy();
  });

  it('onHeaderCheckboxToggle else case coverage', () => {
    spyOn(AutomationRuleEditUtils, 'setUnCheckedValues');
    component.onHeaderCheckboxToggle(false);
    expect(component.automationRuleEditModel.save).toBeFalsy();
  });

  it('onInlineSave should set the property isSave to be true', () => {
    spyOn(AutomationRuleEditUtils, 'setRuleAttributeValues');
    spyOn(AutomationRuleEditUtils, 'setheaderValues');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.selectedRowIndex = [0];
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onInlineSave();
    expect(component.automationRuleEditModel.isSave).toBeTruthy();
  });

  it('onInlineSave else branch coverage', () => {
    spyOn(AutomationRuleEditUtils, 'setRuleAttributeValues');
    spyOn(AutomationRuleEditUtils, 'setheaderValues');
    component.automationRuleEditModel.editRuleForm = editRuleFormInvalid;
    component.automationRuleEditModel.selectedRowIndex = [0];
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.onInlineSave();
    expect(component.automationRuleEditModel.cancel).toBeTruthy();
  });

  it('onInlineCancel have been called', () => {
    spyOn(component, 'prepopulateValue');
    spyOn(AutomationRuleEditUtils, 'cancelInlineUtility');
    component.automationRuleEditModel.selectedRows = ruleAttributes;
    component.automationRuleEditModel.selectedRowIndex = [0];
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.editRuleForm = editRuleFormInvalid;
    component.onInlineCancel();
    expect(component.automationRuleEditModel.ruleAttributes[0].editable).toBeFalsy();
  });

  it('duplicateRuleReject should set the property duplicateRulePopUp to be false', () => {
    component.duplicateRuleReject();
    expect(component.automationRuleEditModel.duplicateRulePopUp).toBeFalsy();
  });

  it('validateRequestJson should set resultSettingError property to be true', () => {
    const editRequest = {
      ruleCriteriaDetails: [{
        ruleCriteriaDetailId: '',
        ruleCriteriaCode: '',
        ruleCriteriaDescription: '',
        ruleLogicalOperatorCode: '',
        ruleLogicalOperatorDescription: '',
        ruleCriteriaValue: '',
      }]
    };
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.validateRequestJson(editRequest);
    expect(component.automationRuleEditModel.resultSettingError).toBeTruthy();
  });

  it('validateRequestJson should call the spy showMissingInputvalidation', () => {
    spyOn(AutomationRuleEditUtils, 'showMissingInputvalidation');
    const editRequest = {
      ruleCriteriaDetails: []
    };
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.validateRequestJson(editRequest);
    expect(AutomationRuleEditUtils.showMissingInputvalidation).toHaveBeenCalled();
  });

  it('getResultSettingList should return empty array', () => {
    expect(component.getResultSettingList(null).length).toEqual(0);
  });

  it('getResultSettingList should return formArray', () => {
    const form = formbuilder.array([]);
    expect(component.getResultSettingList(form).length).toEqual(0);
  });

  it('onChangeResultSetting should set errors to the resultSetting control', () => {
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.onChangeResultSetting([]);
    expect(component.automationRuleEditModel.editRuleForm.controls.resultSetting.errors['invalid']).toBeTruthy();
  });

  it('setBooleanResultSet should set the property booleanResult to be true', () => {
    component.setBooleanResultSet(editRuleParam);
    expect(component.automationRuleEditModel.booleanResult).toBeTruthy();
  });

  it('onRowSelect should call the spy prepopulateValue', () => {
    spyOn(component, 'prepopulateValue');
    spyOn(AutomationRuleEditUtils, 'removeDuplicateAttribute').and.returnValue([]);
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.selectedRowIndex = [];
    component.onRowSelect({ data: { ruleCriteriaCode: '', ruleCriteriaDescription: '' } });
    expect(component.prepopulateValue).toHaveBeenCalled();
  });

  it('onRowUnCheck should call the spy onRowUnSelect', () => {
    spyOn(AutomationRuleEditUtils, 'onRowUnSelect');
    component.automationRuleEditModel.editRuleForm = editRuleForm;
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.automationRuleEditModel.selectedRowIndex = [];
    component.onRowUnCheck(selectedRuleData);
    expect(AutomationRuleEditUtils.onRowUnSelect).toHaveBeenCalled();
  });

  it('editAttributes should set isLoading to be false', () => {
    const automationRuleEditService: AutomationRuleEditService = TestBed.get(AutomationRuleEditService);
    spyOn(automationRuleEditService, 'getRuleAttributes').and.returnValue(throwError(null));
    component.editAttributes(1);
    expect(component.automationRuleEditModel.isLoading).toBeFalsy();
  });

  it('setEquipmentSubClass should call the spy prepopulateCriteriaValue', () => {
    spyOn(AutomationRulesUtility, 'getEquipmentSubClass').and.returnValue([]);
    spyOn(AutomationRuleEditUtils, 'prepopulateCriteriaValue');
    component.automationRuleEditModel.ruleAttributes = ruleAttributes;
    component.setEquipmentSubClass({ label: '', value: '' }, 0);
    expect(AutomationRuleEditUtils.prepopulateCriteriaValue).toHaveBeenCalled();
  });

  it('onCancelEdit should call the navigate spy', () => {
    const router: Router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.onCancelEdit();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('editSuccess should call the navigate spy', () => {
    const router: Router = TestBed.get(Router);
    spyOn(router, 'navigate');
    const data = {
      ruleDetailId: '',
      ruleCriteriaSetId: null,
      ruleStatus: '',
      ruleSupersedeTypeCode: '',
      ruleCriteriaDetails: '',
      ruleParameters: '',
      inactiveRuleCriteriaSetId: null
    };
    component.editSuccess(data);
    expect(router.navigate).toHaveBeenCalled();
  });

  it('onInactivate should call the spy activeInactivate', () => {
    spyOn(component, 'activeInactivate');
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirm) => {
      confirm.accept();
    });
    component.onInactivate(false);
    expect(component.activeInactivate).toHaveBeenCalled();
  });

  it('duplicateCheck should set duplicateRulePopUp to be true', () => {
    component.duplicateCheck({
      status: 409,
      error: { inactiveRuleCriteriaSetId: 1 }
    });
    expect(component.automationRuleEditModel.duplicateRulePopUp).toBeTruthy();
  });

  it('duplicateCheck should set duplicateError  to be null', () => {
    spyOn(AutomationRuleEditUtils, 'showMissingInputvalidation');
    component.duplicateCheck({
      status: 409,
      error: { inactiveRuleCriteriaSetId: null }
    });
    expect(component.automationRuleEditModel.duplicateError).toEqual(null);
  });

  it('populateSCACCodeValues should call the spy setPopulatedValues', () => {
    spyOn(component, 'setPopulatedValues');
    spyOn(AutomationRuleEditUtils, 'getScacRecords');
    component.populateSCACCodeValues('', 0);
    expect(component.setPopulatedValues).toHaveBeenCalled();
  });

  it('getResultSettingLabel should return null', () => {
    component.automationRuleEditModel.textResultValue = [{
      ruleParameterTypeDescription: null
    }];
    expect(component.getResultSettingLabel(0)).toEqual(null);
  });
});
