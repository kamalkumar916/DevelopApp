import { SourceDetails } from '../../model/automation-rule.interface';

export class RuleOverviewModel {
  ruleOverViewDetails: SourceDetails;
  statusFlag: boolean;
  ruleOverviewStatus: string;
  constructor() {
    this.ruleOverViewDetails = null;
    this.ruleOverviewStatus = '';
    this.statusFlag = false;
  }
}
