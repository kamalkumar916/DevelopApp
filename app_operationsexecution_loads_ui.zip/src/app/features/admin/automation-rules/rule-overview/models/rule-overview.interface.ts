export interface SourceDetails {
  RuleDescription: string;
  LastUpdateUserID: null;
  RuleBusinessProcessCode: string;
  RuleBusinessProcessDescription: string;
  RuleCategoryDescription: string;
  RuleTypeCode: string;
  RuleCategoryCode: string;
  RuleCategoryTypeAssociationID: number;
  RuleSupersedeTypeCode: null;
  RuleDetailID: number;
  RuleTypeDescription: string;
  RuleCriteriaSetID: number;
  RuleCode: string;
  RuleName: string;
  LastUpdateProgramName: string;
  ruleCriteriaDetails: Array<RuleCriteriaDetails>;
  RuleParameter: Array<RuleParameter>;
  EffectiveTimestamp: string;
  Status: string;
  ExpirationTimestamp: string;
  LastUpdateTimestamp: string;
}
export interface RuleCriteriaDetails {
  RuleLogicalOperatorDescription: null;
  RuleLogicalOperatorCode: null;
  RuleCriteriaCode: null;
  RuleCriteriaLogicalOperatorAssociationID: null;
  RuleCriteriaValue: RuleCriteriaValue;
  RuleCriteriaDescription: null;
}
export interface RuleCriteriaValue {
  RuleCriteriaValue: null;
  RuleCriteriaDetailID: null;
}
export interface RuleParameter {
  RuleParameterValueTypeCode: string;
  RuleLogicalOperatorDescription: string;
  RuleParameterTypeCode: string;
  RuleParameterID: number;
  ParameterNumberValue: number;
  ParameterDateValue: null;
  RuleParameterCriteriaCode: string;
  ParameterCharValue: null;
  RuleLogicalOperatorCode: string;
  RuleParameterTypeDescription: string;
}
