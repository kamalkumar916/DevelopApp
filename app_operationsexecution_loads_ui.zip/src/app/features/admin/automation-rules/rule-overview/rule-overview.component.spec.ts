import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';

import { RuleOverviewComponent } from './rule-overview.component';
import { configureTestSuite } from 'ng-bullet';

describe('RuleOverviewComponent', () => {
  let component: RuleOverviewComponent;
  let fixture: ComponentFixture<RuleOverviewComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, RouterTestingModule],
      providers: [UserService, AppConfigService],
      declarations: [RuleOverviewComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
