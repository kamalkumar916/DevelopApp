import { Component, OnInit, Input } from '@angular/core';

import { RuleOverviewModel } from './models/rule-overview.model';
import { SourceDetails } from '../model/automation-rule.interface';

@Component({
  selector: 'app-rule-overview',
  templateUrl: './rule-overview.component.html',
  styleUrls: ['./rule-overview.component.scss']
})
export class RuleOverviewComponent implements OnInit {
  @Input() set ruleOverview(ruleOverViewDetails: SourceDetails) {
    if (ruleOverViewDetails) {
      this.ruleOverviewModel.ruleOverViewDetails = ruleOverViewDetails;
      this.ruleOverviewModel.statusFlag = true;
    }
  }
  @Input() set ruleOverviewPredefined(ruleOverViewDetails: SourceDetails) {
    if (ruleOverViewDetails) {
      this.ruleOverviewModel.ruleOverViewDetails = ruleOverViewDetails;
      this.ruleOverviewModel.statusFlag = false;
    }
  }
  @Input() set ruleOverviewStatus(ruleOverviewStatus: string) {
    if (ruleOverviewStatus) {
      this.ruleOverviewModel.ruleOverviewStatus = ruleOverviewStatus;
    }
  }
  ruleOverviewModel: RuleOverviewModel;

  constructor() {
    this.ruleOverviewModel = new RuleOverviewModel();
  }

  ngOnInit() {
  }

}
