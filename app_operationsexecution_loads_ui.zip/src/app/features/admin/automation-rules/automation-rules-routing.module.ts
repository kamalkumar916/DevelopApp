import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AutomationRulesComponent } from './automation-rules.component';
import { PredefinedRulesComponent } from './predefined-rules/predefined-rules.component';
import { AutomationRuleViewComponent } from './automation-rule-view/automation-rule-view.component';
import { AutomationRuleCreateComponent } from './automation-rule-create/automation-rule-create.component';
import { AutomationRuleEditComponent } from './automation-rule-edit/automation-rule-edit.component';

const routes: Routes = [
  { path: '', component: AutomationRulesComponent },
  { path: 'configurenewrule', component: AutomationRuleCreateComponent },
  { path: 'predefinedRules', component: PredefinedRulesComponent },
  { path: 'viewconfigurerule', component: AutomationRuleViewComponent },
  { path: 'editconfigurerule', component: AutomationRuleEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AutomationRulesRoutingModule { }

