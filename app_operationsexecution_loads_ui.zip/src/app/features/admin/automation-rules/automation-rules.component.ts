
import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component,
  OnDestroy, OnInit, ViewChild, ElementRef
} from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeWhile } from 'rxjs/operators';
import * as moment from 'moment';
import { Router } from '@angular/router';

import { SpinnerService } from '../../../shared/spinner/index';

import { AutomationRulesModel } from './model/automation-rules.model';
import { AutomationRulesService } from './services/automation-rules.service';
import { AutomationRulesQuery } from './query/automation-rules.query';
import { AutomationRulesUtility } from './services/automation-rules.utility';
import { FilterData } from './model/automation-rules.interface';
import { AutomationRuleFilterComponent } from './automation-rule-filter/automation-rule-filter.component';
import { RuleOverviewDetails } from './model/automation-rule.interface';
import { DateUtils } from '../../../shared/jbh-app-services/date-utils';

@Component({
  selector: 'app-automation-rules',
  templateUrl: './automation-rules.component.html',
  styleUrls: ['./automation-rules.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AutomationRulesComponent implements OnDestroy, OnInit {
  @ViewChild('automationRulesPagination') automationRules;
  @ViewChild(AutomationRuleFilterComponent) automationRuleFilter: AutomationRuleFilterComponent;
  @ViewChild('downloadExcel') downloadExcel: ElementRef;
  @ViewChild('filterControl') filterControl: any;
  automationRulesModel: AutomationRulesModel;
  searchTerms: Subject<string>;
  constructor(
    private readonly automationRuleService: AutomationRulesService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly spinnerService: SpinnerService,
    private readonly router: Router) {
    this.automationRulesModel = new AutomationRulesModel();
    this.searchTerms = new Subject<string>();
    this.automationRulesModel.filterFlag = false;
    this.automationRulesModel.sortField = 'Rule Name';
    this.automationRulesModel.sortOrder = this.automationRulesModel.ascendingOrder;
  }
  ngOnInit() {
    this.overFlowMenuData();
    this.subjectBehaviour();
    this.fetchAutomationRules();
  }
  ngOnDestroy() {
    this.automationRulesModel.subscribeFlag = false;
  }
  onPage(event) {
    this.automationRulesModel.filterVariables.from = event.first;
    this.automationRulesModel.filterVariables.size = event.rows;
    this.fetchAutomationRules();
  }
  overFlowMenuData() {
    this.automationRulesModel.items = [
      {
        label: 'Export to Excel', command: (onclick) => {
          this.exportToExcel();
        }
      }
    ];
  }
  fetchAutomationRules() {
    this.spinnerService.hide();
    this.automationRulesModel.loadingFlag = true;
    let automationQuery = AutomationRulesQuery.automationRuleGridSearchQuery(this.automationRulesModel.filterVariables,
      this.automationRulesModel.filterVariables.from, this.automationRulesModel.filterVariables.size,
      this.automationRulesModel.sortField, this.automationRulesModel.sortOrder, this.automationRulesModel.tableColumnHeaders);
    if (this.automationRulesModel.filterVariables.lastUpdatedFromTimeStamp ||
      this.automationRulesModel.filterVariables.lastUpdatedToTimeStamp) {
      automationQuery =
        AutomationRulesUtility.frameQueryForLastUpdatedTime(automationQuery, this.automationRulesModel, AutomationRulesQuery);
    }
    this.automationRuleService.getAutomationRules(automationQuery)
      .pipe(takeWhile(() => this.automationRulesModel.subscribeFlag))
      .subscribe((data) => {
        this.automationRulesModel.loadingFlag = false;
        if (data && data.hits && data.hits.hits) {
          this.automationRulesModel.automationRulesList = data.hits.hits;
          this.automationRulesModel.totalRecords = data.hits.total;
        }
        this.changeDetector.detectChanges();
      }, (error: Error) => {
        this.automationRulesModel.loadingFlag = false;
        this.automationRulesModel.automationRulesList = [];
        this.automationRulesModel.totalRecords = 0;
      });
  }

  onSearch(event: string) {
    if (event) {
      this.searchTerms.next(event);
    }
  }
  subjectBehaviour() {
    this.searchTerms.pipe(debounceTime(300), distinctUntilChanged(),
      takeWhile(() => this.automationRulesModel.subscribeFlag)).subscribe((shareData) => {
        if (shareData) {
          if (shareData['target']['value'].match('^[0-9,]*$')) {
            this.automationRulesModel.searchValue = shareData['target']['value'].replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
            this.automationRulesModel.searchValue = this.automationRulesModel.searchValue.replace(/\,/g, '');
          } else if (shareData['target']['value'].match('[()]')) {
            this.automationRulesModel.searchValue = shareData['target']['value'].replace(/[()]/g, '');
          } else {
            this.automationRulesModel.searchValue = shareData['target']['value'].replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
          }
          if (this.automationRulesModel.searchValue) {
            this.automationRulesModel.filterVariables.from = 0;
            this.automationRulesModel.filterVariables.size = 25;
            this.automationRulesModel.filterVariables.searchValue = this.automationRulesModel.searchValue;
            AutomationRulesUtility.objectParamValue(this.automationRulesModel);
            this.fetchAutomationRules();
          } else {
            this.automationRulesModel.filterVariables.searchValue = '';
            this.fetchAutomationRules();
          }
        }
      }, (error: Error) => {
        this.automationRulesModel.automationRulesList = [];
        this.automationRulesModel.totalRecords = 0;
      });
  }
  exportToExcel() {
    const excelParam = {};
    const displayFields = AutomationRulesUtility.getExcelHeaders();
    excelParam['displayFields'] = displayFields;
    this.automationRulesModel.filterVariables.size = 1000;
    this.automationRulesModel.filterVariables.from = 0;
    AutomationRulesUtility.objectParamValue(this.automationRulesModel);
    let excelDownloadQuery: object = AutomationRulesQuery.automationRuleGridSearchQuery(this.automationRulesModel.filterVariables,
      this.automationRulesModel.filterVariables.from, this.automationRulesModel.filterVariables.size,
      this.automationRulesModel.sortField, this.automationRulesModel.sortOrder, this.automationRulesModel.tableColumnHeaders);
    if (this.automationRulesModel.filterVariables.lastUpdatedFromTimeStamp ||
      this.automationRulesModel.filterVariables.lastUpdatedToTimeStamp) {
      excelDownloadQuery =
        AutomationRulesUtility.frameQueryForLastUpdatedTime(excelDownloadQuery, this.automationRulesModel, AutomationRulesQuery);
    }
    excelParam['elasticSearchQuery'] = excelDownloadQuery;
    this.exportToExcelFunction(excelParam, this.downloadExcel);
  }
  exportToExcelFunction(tableParam: object, downloadExcel: ElementRef) {
    this.automationRuleService.excelDownload(tableParam)
      .pipe(takeWhile(() => this.automationRulesModel.subscribeFlag))
      .subscribe((data: object) => {
        if (data) {
          this.downloadFile(data, downloadExcel);
        }
        this.changeDetector.detectChanges();
      });
  }
  downloadFile(data: object, downloadExcel: ElementRef) {
    const fileName = `Configured Rules ${moment().format('YYYY-MM-DD')} at ${moment().format('hh.mm.ss A')}.xlsx`;
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      downloadExcel.nativeElement.href = URL.createObjectURL(data);
      downloadExcel.nativeElement.download = fileName;
      downloadExcel.nativeElement.click();
    }
  }
  onRowSelect(selectedRule: RuleOverviewDetails) {
    this.router.navigate(['/admin/automationrules/viewconfigurerule'],
      { queryParams: { ruleCriteriaSetId: selectedRule._source.RuleCriteriaSetID } });
  }
  onClickFilterIcon() {
    if (this.automationRulesModel.showFilter) {
      this.automationRuleFilter.onFilterIconClicked();
    }
    this.automationRulesModel.filterFlag = !this.automationRulesModel.filterFlag;
    if (!this.automationRulesModel.filterFlag) {
      this.filterControl['filterComponents'].forEach(element => {
        element.closePanel();
      });
    }
    this.automationRulesModel.showFilter = true;
  }
  onPageReset(event: FilterData) {
    if (this.automationRules && this.automationRules.first) {
      this.automationRules.first = 0;
      this.automationRules.size = 25;
    }
    this.automationRulesModel.filterVariables = event.filterQuery;
    this.automationRulesModel.filterVariables.searchValue = this.automationRulesModel.searchValue;
    this.fetchAutomationRules();
    this.changeDetector.detectChanges();
  }
  onSortSelect(selectedColumnName) {
    this.automationRules.first = 0;
    this.automationRules.size = 25;
    this.automationRulesModel.filterVariables.from = 0;
    this.automationRulesModel.filterVariables.size = 25;
    if (
      this.automationRulesModel.sortField &&
      this.automationRulesModel.sortField === selectedColumnName
    ) {
      this.automationRulesModel.sortField = selectedColumnName;
      this.automationRulesModel.sortOrder =
        this.automationRulesModel.sortOrder ===
          this.automationRulesModel.descendingOrder
          ? this.automationRulesModel.ascendingOrder
          : this.automationRulesModel.descendingOrder;
      this.fetchAutomationRules();
    } else {
      this.automationRulesModel.sortField = selectedColumnName;
      this.automationRulesModel.sortOrder = this.automationRulesModel.ascendingOrder;
      this.fetchAutomationRules();
    }
  }
  getDefaultTimeZone(timeStamp: string) {
    const dateAndTime = timeStamp.slice(0, -4);
    return DateUtils.convertOffsetDateByDefaultTimeZone(dateAndTime, 'MM/DD/YYYY hh:mm A z');
  }
}

