import { AttributeType } from '../model/automation-rules.interface';


export class AutomationRulesUtility {

    static getExcelHeaders() {
        return ['ruleName', 'ruleTypeDescription', 'ruleCategoryDescription', 'status', 'lastUpdated', 'lastUpdatedBy'];
    }


    static objectParamValue(model) {
        model.objectParam = {};
        model.objectParam['from'] = model.from;
        model.objectParam['size'] = model.size;
        if (model.searchValue) {
            model.objectParam['searchValue'] = model.searchValue;
        } else {
            model.objectParam['searchValue'] = '';
        }
    }
    static frameQueryForLastUpdatedTime(payLoadObject, automationRuleModel, AutomationRulesQuery) {
        let lastUpdatedTimeObject = {};
        if (automationRuleModel.filterVariables.lastUpdatedFromTimeStamp &&
            automationRuleModel.filterVariables.lastUpdatedToTimeStamp) {
            lastUpdatedTimeObject = {
                'gte': automationRuleModel.filterVariables.lastUpdatedFromTimeStamp,
                'lte': automationRuleModel.filterVariables.lastUpdatedToTimeStamp
            };
        } else if (automationRuleModel.filterVariables.lastUpdatedFromTimeStamp) {
            lastUpdatedTimeObject = {
                'gte': automationRuleModel.filterVariables.lastUpdatedFromTimeStamp
            };
        } else if (automationRuleModel.filterVariables.lastUpdatedToTimeStamp) {
            lastUpdatedTimeObject = {
                'lte': automationRuleModel.filterVariables.lastUpdatedToTimeStamp
            };
        }
        const requestQueryObject = AutomationRulesQuery.getFilterQueryObjectForLastUpdatedTime();
        requestQueryObject['bool']['should'][0]['range']['LastUpdateTimestamp.date'] = lastUpdatedTimeObject;
        payLoadObject['query']['bool']['must'][1]['bool']['must'][5] = requestQueryObject;
        return payLoadObject;
    }
    static getLocationRecords(dataSource) {
        return dataSource.hits.hits.map((Items => {
            return {
                locationName: Items._source.LocationName,
                locationCode: Items._source.LocationCode,
                value: Items._source.LocationID,
                address: `${Items._source.Address.AddressLine1} ,${Items._source.Address.AddressLine2} ,
                ${Items._source.Address.CityName} ,${Items._source.Address.StateName},
                ${Items._source.Address.PostalCode} ','${Items._source.Address.CountryName}`,
                label: `${Items._source.LocationName}(${Items._source.LocationCode})
                ${Items._source.Address.AddressLine1} ,${Items._source.Address.AddressLine2},
                ${Items._source.Address.CityName} ,${Items._source.Address.StateName},
                ${Items._source.Address.PostalCode} ,${Items._source.Address.CountryName}`
            };
        }));
    }
    static getScacRecords(dataSource): Array<AttributeType> {
        return dataSource.hits.hits.map((Items => {
            return {
                value: Items._source.scac,
                label: Items._source.scac
            };
        }));
    }
    static getDriverRecords(dataSource) {
        return dataSource.hits.hits.map((Items => {
            return {
                label: this.getUserName(Items),
                value: Items._source.emplid,
            };
        }));
    }

    static getTruckRecords(dataSource) {
        return dataSource.hits.hits.map((Items => {
            return {
                label: (Items && Items._source && Items._source.prefixWithEquipmentNumber) ? Items._source.prefixWithEquipmentNumber : '',
                value: Items._source.equipmentID,
            };
        }));
    }

    static getUserName(item: any): string {
        let name = '';
        if (item) {
            if (item._source && item._source.personDTO && item._source.personDTO.prefName) {
                name = item._source.personDTO.prefName;
            } else if (item._source.firstName) {
                name = item._source.firstName;
            }
            name += name ? ` ${item._source.lastName ? item._source.lastName : ''}(${item._source.userID ? item._source.userID : ''})` : '';
        }
        return name;
    }

    static getCorporateAccountRecords(dataSource) {
        return dataSource.hits.hits.map((Items) => {
            return {
                label: `${Items._source.OrganizationName} (${Items._source.OrganizationCode})`,
                value: Items._source.OrganizationID
            };
        });
    }
    static getLobRecords(dataSource) {
        return {
            label: dataSource[0]._source.OrganizationName,
            value: dataSource[0]._source.OrganizationID
        };
    }
    static getTeamRecords(dataSource) {
        return dataSource._embedded.teams.map((Items => {
            return {
                value: Items.teamID,
                label: Items.teamName
            };
        }));
    }
    static populateSubTypeValues(dataSource) {
        return dataSource._embedded.operationalWorkOrderSubtypes.map((data) => {
            return {
                label: data.operationalWorkOrderSubtypeDescription,
                value: data.operationalWorkOrderSubtypeCode
            };
        });
    }
    static populateClassificationTypeValues(dataSource) {
        return dataSource._embedded.operationalPlanClassificationCodes.map((data) => {
            return {
                label: data.operationalPlanClassificationDescription,
                value: data.operationalPlanClassificationCode
            };
        });
    }
    static getOperationalPlanType(dataSource) {
        return dataSource._embedded.operationalPlanTypes.map((data) => {
            return {
                label: data.operationalPlanTypeDescription,
                value: data.operationalPlanTypeCode
            };
        });
    }
    static getOperationalPlanSubType(dataSource) {
        return dataSource._embedded.operationalPlanSubtypes.map((data) => {
            return {
                label: data.operationalPlanSubtypeDescription,
                value: data.operationalPlanSubtypeCode
            };
        });
    }
    static getStopReason(dataSource) {
        return dataSource._embedded.stopReasons.map((data) => {
            return {
                label: data.stopReasonDescription,
                value: data.stopReasonCode
            };
        });
    }
    static getEquipmentClassification(dataSource) {
        return dataSource._embedded.equipmentClassifications.map((data) => {
            return {
                label: data.equipmentClassificationDescription,
                value: data.equipmentClassificationCode
            };
        });
    }
    static getBillToData(dataSource) {
        return dataSource.hits.hits.map((Items) => {
            return {
                label: `${Items._source.OrganizationName} (${Items._source.CustomerCode})`,
                value: Items._source.PartyID
            };
        });
    }
    static getEquipmentSubClass(dataSource) {
        return dataSource._embedded.equipmentTypes.map((data) => {
            return {
                label: data.equipmentTypeDescription,
                value: data.equipmentTypeCode
            };
        });
    }
}
