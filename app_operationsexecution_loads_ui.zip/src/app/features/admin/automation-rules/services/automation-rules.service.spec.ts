
import { inject, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AutomationRulesService } from './automation-rules.service';

import { AppConfigService } from '../../../../shared/service/app-config.service';
import { configureTestSuite } from 'ng-bullet';
import { of } from 'rxjs/internal/observable/of';
import { AutomationRulesQuery } from '../query/automation-rules.query';

describe('AutomationRulesService', () => {
  let service: AutomationRulesService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AutomationRulesService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(AutomationRulesService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('getAutomationRules have been called', () => {
    const automationQuery = '';
    service.getAutomationRules(automationQuery).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.automationRulesList);
    expect(req.request.method).toEqual('POST');
  });

  it('getAutomationRules have been called', () => {
    const automationQuery = {};
    service.getSearchConfigureRules(automationQuery).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.automationRulesList);
    expect(req.request.method).toEqual('POST');
  });

  it('excelDownload have been called', () => {
    let rtnval;
    spyOn(service, 'downloadExcel').and.returnValue(of(null));
    service.excelDownload({}).subscribe((data) => {
      rtnval = data;
    });
    expect(rtnval).toBeNull();
  });

  it('downloadExcel have been called', () => {
    service.downloadExcel('abc', {}).subscribe();
    const req = httpTestingController.expectOne('abc');
    expect(req.request.method).toEqual('POST');
  });

  it('getRuleNameData have been called', () => {
    const reqObject = '';
    service.getRuleNameData(reqObject).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.automationRulesList);
    expect(req.request.method).toEqual('POST');
  });

  it('getfilteredAutomationRules have been called', () => {
    const automationQuery = '';
    service.getfilteredAutomationRules(automationQuery).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.automationRulesList);
    expect(req.request.method).toEqual('POST');
  });

  it('getfilteredLastUpdatedBy have been called', () => {
    const automationQuery = '';
    service.getfilteredLastUpdatedBy(automationQuery).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.automationRulesList);
    expect(req.request.method).toEqual('POST');
  });

  it('getFilterLevel have been called', () => {
    service.getFilterLevel().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.automationfilter);
    expect(req.request.method).toEqual('GET');
  });

  it('getFilterType have been called', () => {
    service.getFilterType().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.automationFilterType);
    expect(req.request.method).toEqual('GET');
  });

  it('getFilterConfig have been called', () => {
    spyOn(AutomationRulesQuery, 'getRuleNameQuery').and.returnValue('');
    spyOn(AutomationRulesQuery, 'getfilterLastUpdatedByQuery').and.returnValue('');
    const componentInstance = {
      getRuleName: '',
      associationLevelList: '',
      ruleCategoryList: '',
      getLastUpdatedBy: ''
    };
    const rtnval = service.getFilterConfig(componentInstance);
    expect(rtnval.ruleName.title).toEqual('Rule Name');
  });
});




