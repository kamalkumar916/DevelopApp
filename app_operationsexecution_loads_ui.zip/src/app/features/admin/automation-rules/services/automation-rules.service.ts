import { ElementRef, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { AutomationRuleQuery, RuleType, RuleCategory } from '../model/automation-rules.interface';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { AutomationRulesQuery } from '../query/automation-rules.query';

@Injectable()
export class AutomationRulesService {

  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('automationRules');
  }

  getAutomationRules(automationQuery: any): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.automationRulesList, automationQuery);
  }
  getSearchConfigureRules(automationQuery: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.automationRulesList, automationQuery);
  }
  excelDownload(requestParam: object): Observable<any> {
    return this.downloadExcel(this.endpoint.configuredRulesDownloadExcel, requestParam);
  }
  downloadExcel<Response>(url: string, body: object, headers?: HttpHeaders | null, responseType?: 'blob'): Observable<any> {
    return this.http.post(url, body, { headers, responseType: 'blob' });
  }
  getRuleNameData(reqObject): Observable<any> {
    return this.http.post(this.endpoint.automationRulesList, reqObject);
  }
  getfilteredAutomationRules(automationQuery): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.automationRulesList, automationQuery);
  }
  getfilteredLastUpdatedBy(automationQuery): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.automationRulesList, automationQuery);
  }
  getFilterLevel(): Observable<RuleCategory> {
    return this.http.get<RuleCategory>(this.endpoint.automationfilter);
  }
  getFilterType(): Observable<RuleType> {
    return this.http.get<RuleType>(this.endpoint.automationFilterType);
  }
  getFilterConfig(componentInstance: any) {
    return {
      ruleName: {
        title: 'Rule Name',
        url: this.endpoint.automationRulesList,
        callback: componentInstance.getRuleName,
        query: AutomationRulesQuery.getRuleNameQuery()
      },
      associationLevel: {
        title: 'Association Level',
        url: this.endpoint.automationFilterType,
        callback: componentInstance.associationLevelList,
      },
      ruleCategory: {
        title: 'Rule Category',
        url: this.endpoint.automationfilter,
        callback: componentInstance.ruleCategoryList,
      },
      lastUpdatedOn: {
        title: 'Last Updated'
      },
      lastUpdatedBy: {
        title: 'Last Updated By',
        url: this.endpoint.automationRulesList,
        callback: componentInstance.getLastUpdatedBy,
        query: AutomationRulesQuery.getfilterLastUpdatedByQuery()
      },
      status: {
        title: 'Status',
        data: [
          { label: 'Active', value: 'Active' },
          { label: 'Inactive', value: 'Inactive' }
        ],
        defaultSelectedValue: { label: 'Active', value: 'Active' }
      }
    };
  }
}
