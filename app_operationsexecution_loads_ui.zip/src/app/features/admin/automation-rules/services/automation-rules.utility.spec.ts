import { AutomationRulesUtility } from './automation-rules.utility';
const datasource = {
    took: null,
    timed_out: false,
    hits: {
        max_score: null,
        total: null,
        hits: [{
            sort: [],
            _id: '',
            _index: '',
            _score: null,
            _source: {
                LocationName: '',
                LocationCode: null,
                LocationID: null,
                Address: {
                    AddressLine1: null,
                    AddressLine2: null,
                    CityName: null,
                    StateName: null,
                    PostalCode: null,
                    CountryName: null
                },
            },
            _type: ''
        }]
    },
    _shards: {
        total: null,
        successful: null,
        skipped: null,
        failed: null
    }
};
const getScacRecordsData = {
    took: null,
    timed_out: false,
    hits: {
        hits: [{
            sort: [],
            _id: '',
            _index: '',
            _score: null,
            _type: '',
            _source: {
                scac: null
            }
        }]
    },
    _shards: {
        total: null,
        successful: null,
        skipped: null,
        failed: null
    }
};
const getDriverRecordsData = {
    took: null,
    timed_out: false,
    hits: {
        hits: [{
            sort: [],
            _id: '',
            _index: '',
            _score: null,
            _type: '',
            _source: {
                emplid: null
            }
        }]
    },
    _shards: {
        total: null,
        successful: null,
        skipped: null,
        failed: null
    }
};
describe('AutomationRulesUtility', () => {

    it('getLocationRecords  should return an array of length 1', () => {
        const returnValue = AutomationRulesUtility.getLocationRecords(datasource);
        expect(returnValue.length).toEqual(1);
    });

    it('getScacRecords should return label value as null', () => {
        expect(AutomationRulesUtility.getScacRecords(getScacRecordsData)[0].label).toEqual(null);
    });

    it('getDriverRecords should return the label value as empty string', () => {
        spyOn(AutomationRulesUtility, 'getUserName').and.returnValue('');
        expect(AutomationRulesUtility.getDriverRecords(getDriverRecordsData)[0].label).toEqual('');
    });

    it('objectParamValue should set the searchValue property of objectParam equal to abc', () => {
        const objectParamValueData = { objectParam: null, searchValue: 'abc', from: 0, size: 0 };
        AutomationRulesUtility.objectParamValue(objectParamValueData);
        expect(objectParamValueData.objectParam['searchValue']).toEqual('abc');
    });

    it('getUserName should return abc de', () => {
        const item = {
            _source: {
                personDTO: {
                    prefName: 'abc'
                },
                lastName: 'd',
                userID: 'e'
            }
        };
        expect(AutomationRulesUtility.getUserName(item)).toEqual('abc d(e)');
    });

    it('getUserName should return abc d', () => {
        const item = {
            _source: {
                personDTO: null,
                firstName: 'abc',
                lastName: 'd',
                userID: ''
            }
        };
        expect(AutomationRulesUtility.getUserName(item)).toEqual('abc d()');
    });

    it('getUserName should return empty string', () => {
        const item = {
            _source: {
                personDTO: null,
                firstName: '',
                lastName: 'd',
                userID: ''
            }
        };
        expect(AutomationRulesUtility.getUserName(item)).toEqual('');
    });

    it('getLobRecords should return label value as null', () => {
        const getLobRecordsData = [{
            _source: {
                OrganizationName: null,
                OrganizationID: null
            }
        }];
        expect(AutomationRulesUtility.getLobRecords(getLobRecordsData).label).toEqual(null);
    });
});
