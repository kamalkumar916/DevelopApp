import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { EquipmentGroupDetails, StatusData } from './../../model/equipment-group.interface';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

@Injectable()
export class EquipmentGroupViewService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('manageEquipmentGroup');
  }
  viewEquipmentDetails(equipmentId: number): Observable<EquipmentGroupDetails> {
    return this.http.get<EquipmentGroupDetails>(`${this.endpoint.equipmentDetails}/${equipmentId}`);
  }
  viewEquipmentStatus(statusData: StatusData, equipmentGroupID: number): Observable<any> {
    return this.http.patch<any>(`${this.endpoint.equipmentDetails}/${equipmentGroupID}/status`, statusData);
  }
}
