import { inject, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { EquipmentGroupViewService } from './equipment-group-view.service';

describe('EquipmentGroupViewService', () => {
  let service: EquipmentGroupViewService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        EquipmentGroupViewService,
        AppConfigService
      ],
    });
  });

  beforeEach(() => {
    service = TestBed.get(EquipmentGroupViewService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('viewEquipmentDetails expected calls', () => {
    const equipmentId = 10;
    const url = `${service.endpoint.equipmentDetails}/${equipmentId}`;
    service.viewEquipmentDetails(equipmentId).subscribe();
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('viewEquipmentStatus expected calls', () => {
    const statusData = {
      status: 'abcd'
    };
    const equipmentGroupID = 10;
    const url = `${service.endpoint.equipmentDetails}/${equipmentGroupID}/status`;
    service.viewEquipmentStatus(statusData, equipmentGroupID).subscribe();
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PATCH');
  });

});
