import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router, ActivatedRoute } from '@angular/router';

import { configureTestSuite } from 'ng-bullet';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MenuModule } from 'primeng/menu';
import { DropdownModule } from 'primeng/dropdown';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';

import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { JbhFiltersModule } from '../../../../shared/jbh-filters/jbh-filters.module';
import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';

import { EquipmentGroupViewService } from './services/equipment-group-view.service';
import { EquipmentGroupViewComponent } from './equipment-group-view.component';
import { UnitMetricsImperialPipe } from '../pipes/unit-metrics-imperial.pipe';

const equipmentGroupDetails = {
  standardEquipmentGroupID: 1,
  equipmentGroupName: 'jbt001',
  equipmentGroupDescription: 'chassis',
  equipmentGroupComment: 'chassis',
  equipmentGroupTypeCode: 'chas001',
  equipmentGroupTypeCodeDescription: 'chassis-001',
  countryCode: '+91',
  countryDescription: 'country-side',
  status: 'available',
  expirationTimestamp: '29-09-2020',
  standardEquipmentGroupMembers: [{
    standardEquipmentGroupMemberId: 1,
    standardEquipmentGroupStackingId: 1,
    stackedStandardEquipmentGroupMemberId: null,
    equipmentGroupSequenceNumber: 1,
    equipmentClassificationCode: 'jbt123',
    equipmentClassificationDescription: 'chassis-jbt123',
    equipmentTypeCode: 'chas-jbt',
    equipmentTypeDescription: 'jbt-chassis',
    lengthSpecificationCode: '---',
    lengthSpecificationDescription: '22 ft',
    widthSpecificationCode: 'jbt-chassis-30',
    widthSpecificationDescription: '30 ft',
    heightSpecificationCode: 'jbt-chassis-15',
    heightSpecificationDescription: '15 ft',
    stackedEquipments: null,
    lengthSpecificationsVal: '22 feet',
    widthSpecificationsVal: '30 feet',
    heightSpecificationsVal: '15 feet',
  }]
};

describe('EquipmentGroupViewComponent', () => {
  let component: EquipmentGroupViewComponent;
  let fixture: ComponentFixture<EquipmentGroupViewComponent>;
  let equipmentGroupViewService: EquipmentGroupViewService;
  let router: Router;
  const mockActivatedRoute = {
    queryParams: of({ standardEquipmentGroupID: 1234 })
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule, ConfirmDialogModule, JbhFiltersModule,
        RouterTestingModule.withRoutes([]), BreadcrumbModule, MenuModule, DropdownModule, DirectivesModule, JbhLoaderModule],
      providers: [UserService, AppConfigService, MessageService, ConfirmationService, EquipmentGroupViewService,
        { provide: ActivatedRoute, useValue: mockActivatedRoute }
      ],
      declarations: [EquipmentGroupViewComponent, UnitMetricsImperialPipe]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    equipmentGroupViewService = TestBed.get(EquipmentGroupViewService);
    router = TestBed.get(Router);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('viewEquipmentDetails should be called', () => {
    spyOn(EquipmentGroupViewService.prototype, 'viewEquipmentDetails').and.returnValue(of(equipmentGroupDetails));
    component.viewEquipmentDetails(123);
    expect(component.equipmentGroupViewModel.isLoading).toBeFalsy();
  });

  it('viewEquipmentDetails should be called on service call error', () => {
    spyOn(EquipmentGroupViewService.prototype, 'viewEquipmentDetails').and.returnValue(throwError(null));
    component.viewEquipmentDetails(1);
    expect(component.equipmentGroupViewModel.isLoading).toBeFalsy();
  });

  it('onEdit should be called', () => {
    const routerNavigate = spyOn(router, 'navigate');
    component.onEdit();
    expect(routerNavigate).toHaveBeenCalledWith(['/admin/manageequipment/edit'],
      { queryParams: { standardEquipmentGroupID: 1234 } });
  });

  it('onValueChange should be called', () => {
    component.onValueChange('abc');
    expect(component.equipmentGroupViewModel.isDefaultValue).toBeFalsy();
  });

  it('checkCumulativeEmpty to return expected value should be called', () => {
    const returnValue = component.checkCumulativeEmpty(10);
    expect(returnValue).toEqual('10');
  });

  it('checkCumulativeEmpty to return default value should be called', () => {
    const returnValue = component.checkCumulativeEmpty(undefined);
    expect(returnValue).toBeNull();
  });

  it('emptyCheck to return feet and inches value should be called', () => {
    const returnValue = component.emptyCheck('10', true);
    expect(returnValue).toBe('0.2540 m');
  });

  it('emptyCheck to return meter to feet inches value should be called', () => {
    const returnValue = component.emptyCheck('10');
    expect(returnValue).toBe('32 ft 10 in');
  });

  it('emptyCheck to return default value should be called', () => {
    const returnValue = component.emptyCheck(undefined);
    expect(returnValue).toBeNull();
  });

  it('onValueChange should be called', () => {
    component.onValueChange('');
    expect(component.equipmentGroupViewModel.isDefaultValue).toBe(false);
  });

  it('onValueChange should be called', () => {
    spyOn(component, 'activeInactivate');
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.accept();
    });
    component.onActivate('test');
    expect(component.activeInactivate).toHaveBeenCalled();
  });
});
