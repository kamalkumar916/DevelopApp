import { MenuItem, SelectItem } from 'primeng/api';
import { ActivatedRoute } from '@angular/router';
import { EquipmentGroupMembers, EquipmentGroupDetails } from './../../model/equipment-group.interface';
import { ManageEquipmentGroupRoutelinks } from '../../manage-equipment-group-route-links';
import { AppConfig } from '../../../../../../config/app.config';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';
export class EquipmentGroupViewModel {
    canSubscribe: boolean;
    equipmentDetails: EquipmentGroupDetails;
    equipmentGroup: EquipmentGroupMembers[];
    unitTypes: SelectItem[];
    viewHistory: MenuItem[];
    statusValue: string;
    isEquipmentStatus: boolean;
    isLoading: boolean;
    isDefaultValue: boolean;
    isImperialMetricFlag: boolean;
    systemAdjustedLengthValue: string;
    systemAdjustedHeightValue: string;
    equipmentid: number;
    overviewHeight: string;
    overviewLength: string;
    overviewWidth: string;
    appConfig;
    activationButton: SecureModel;
    editButton: SecureModel;
    overflowMenuOptions: any[];
    constructor(private readonly activatedRoute: ActivatedRoute) {
        this.canSubscribe = true;
        this.unitTypes = [
            { label: 'Imperial', value: 'Imperial' },
            { label: 'Metric', value: 'Metric' },
        ];
        this.viewHistory = [
            {
                label: 'View Equipment Group History',
                routerLink: [ManageEquipmentGroupRoutelinks.auditListUrl],
                queryParams: { standardEquipmentGroupID: this.activatedRoute.queryParams['value']['standardEquipmentGroupID'] }
            }
        ];
        this.appConfig = AppConfig.getConfig();
        this.overflowMenuOptions = [{
            label: 'View Equipment Group History',
            url: this.appConfig.api.uiAccessList.manageEquipmentAuditlist,
            operation: 'R'
        }];
        this.activationButton = { url: this.appConfig.api.manageEquipmentGroup.equipmentDetails, operation: 'C' };
        this.editButton = { url: this.appConfig.api.manageEquipmentGroup.createEquipmentGroup, operation: 'C' };
        this.isEquipmentStatus = false;
        this.isLoading = false;
        this.isDefaultValue = true;
        this.isImperialMetricFlag = true;
    }
}
