import { Component, OnInit, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { timer } from 'rxjs';
import { takeWhile } from 'rxjs/operators';
import { MessageService } from 'primeng/components/common/messageservice';

import * as LodashUtils from 'lodash';

import { EquipmentGroupDetails, StatusData } from './../model/equipment-group.interface';
import { EquipmentGroupViewModel } from './model/equipment-group-view.model';
import { EquipmentGroupViewService } from './services/equipment-group-view.service';
import { EquipmentGroupUtility } from './../services/equipment-group.utility';
import { UnitMetricsImperialPipe } from '../pipes/unit-metrics-imperial.pipe';
import { ManageEquipmentGroupRoutelinks } from '../manage-equipment-group-route-links';
import { UserService } from '../../../../shared/jbh-esa';

@Component({
  selector: 'app-equipment-group-view',
  templateUrl: './equipment-group-view.component.html',
  styleUrls: ['./equipment-group-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EquipmentGroupViewComponent implements OnInit, OnDestroy {
  equipmentGroupViewModel: EquipmentGroupViewModel;
  equipmentGroupRoutes = ManageEquipmentGroupRoutelinks;
  constructor(private readonly router: Router,
    private readonly activatedRoute: ActivatedRoute,
    private readonly confirmationService: ConfirmationService,
    private readonly equipmentGroupViewService: EquipmentGroupViewService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly toastMessage: MessageService,
    private readonly userService: UserService) {
    this.equipmentGroupViewModel = new EquipmentGroupViewModel(activatedRoute);
    this.equipmentGroupViewModel.viewHistory
      = this.userService.getEsaMenuCheckItems(this.equipmentGroupViewModel.viewHistory, this.equipmentGroupViewModel.overflowMenuOptions);
  }
  ngOnInit() {
    if (this.activatedRoute.queryParams['value']['standardEquipmentGroupID']) {
      this.viewEquipmentDetails(this.activatedRoute.queryParams['value']['standardEquipmentGroupID']);
    }
  }
  ngOnDestroy() {
    this.equipmentGroupViewModel.canSubscribe = false;
  }
  viewEquipmentDetails(equipmentId: number) {
    this.equipmentGroupViewModel.isLoading = true;
    this.equipmentGroupViewService.viewEquipmentDetails(equipmentId)
      .pipe(takeWhile(() => this.equipmentGroupViewModel.canSubscribe))
      .subscribe((data: EquipmentGroupDetails) => {
        if (data) {
          this.equipmentGroupViewModel.isLoading = false;
          this.equipmentGroupViewModel.equipmentDetails = data;
          this.convertlengthSpecification();
          this.equipmentGroupViewModel.equipmentGroup = LodashUtils.
            sortBy(data.standardEquipmentGroupMembers, 'equipmentGroupSequenceNumber');
          const SpecificationCodeDimension =
            new UnitMetricsImperialPipe().transform(this.equipmentGroupViewModel.equipmentGroup, 'lengthWidthHeigthCalculation');
          const overviewtotalheight =
            new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'height');
          const overviewtotallenth =
            new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'length');
          const overviewtotalwidth =
            new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'width');
          this.equipmentGroupViewModel.overviewHeight = EquipmentGroupUtility.maxWidthGroupOverview(overviewtotalheight);
          this.equipmentGroupViewModel.overviewLength = EquipmentGroupUtility.feetInchesGroupOverview(overviewtotallenth);
          this.equipmentGroupViewModel.overviewWidth = EquipmentGroupUtility.maxWidthGroupOverview(overviewtotalwidth);
          this.equipmentGroupViewModel.systemAdjustedLengthValue =
            EquipmentGroupUtility.systemAdjustedLength(this.equipmentGroupViewModel.overviewLength);
          this.equipmentGroupViewModel.systemAdjustedHeightValue =
            EquipmentGroupUtility.systemAdjustedHeight(this.equipmentGroupViewModel.overviewHeight);
          this.equipmentGroupViewModel.statusValue = data.status;
          this.equipmentGroupViewModel.isEquipmentStatus = (this.equipmentGroupViewModel.statusValue.toLowerCase() === 'active');
          this.changeDetector.detectChanges();
        }
      }, (error: Error) => {
        this.equipmentGroupViewModel.isLoading = false;
      });
  }
  convertlengthSpecification() {
    const standardEquipmentGrop = this.equipmentGroupViewModel.equipmentDetails.standardEquipmentGroupMembers;
    if (standardEquipmentGrop) {
      for (const stdEquip of standardEquipmentGrop) {
        stdEquip.lengthSpecificationCode =
          this.checkCumulativeEmpty(EquipmentGroupUtility.getCumulativeValues(stdEquip.lengthSpecificationCode));
        const stackedEquipment = stdEquip.stackedEquipments;
        if (stackedEquipment && stackedEquipment.length > 0) {
          for (const stackEquip of stackedEquipment) {
            stackEquip.lengthSpecificationCode =
              this.checkCumulativeEmpty(EquipmentGroupUtility.getCumulativeValues(stackEquip.lengthSpecificationCode));
          }
        }
      }
    }
  }
  checkCumulativeEmpty(value: number): string {
    return value ? value.toString() : null;
  }
  onEdit() {
    this.router.navigate([ManageEquipmentGroupRoutelinks.editUrl],
      { queryParams: { standardEquipmentGroupID: this.activatedRoute.queryParams['value']['standardEquipmentGroupID'] } });
  }
  onActivate(status: string) {
    this.confirmationService.confirm({
      message: (status === 'Activate') ? `Are you sure you want to ${status} the Equipment Group?` :
        `Are you sure you want to ${status.toLowerCase()} the Equipment Group ?`,
      header: 'Confirmation',
      key: 'Inactivate',
      accept: (): void => {
        (status === 'activate') ? this.activeInactivate('Active') : this.activeInactivate('Inactive');
      }
    });
  }
  activeInactivate(status: string) {
    const equipmentid = this.activatedRoute.queryParams['value']['standardEquipmentGroupID'];
    const equipmentStatus = (this.equipmentGroupViewModel.statusValue.toLowerCase() === 'active') ? 'Inactive' : 'Active';
    const statusData: StatusData = {
      status: equipmentStatus
    };
    this.equipmentGroupViewModel.isLoading = true;
    this.equipmentGroupViewService.viewEquipmentStatus(statusData, this.activatedRoute.queryParams['value']['standardEquipmentGroupID'])
      .pipe(takeWhile(() => this.equipmentGroupViewModel.canSubscribe))
      .subscribe((data: any) => {
        timer(2000).subscribe(() => {
          if (equipmentStatus === 'Active') {
            this.toastMessage.clear();
            this.toastMessage.add({
              severity: 'success',
              summary: 'Equipment Group Activated',
              detail: `Equipment Group (${equipmentid}) has been Activated successfully`
            });
          } else {
            this.toastMessage.clear();
            this.toastMessage.add({
              severity: 'success',
              summary: 'Equipment Group Inactivated',
              detail: `Equipment Group (${equipmentid}) has been Inactivated successfully`
            });
          }
          this.equipmentGroupViewModel.isLoading = false;
          this.router.navigate([ManageEquipmentGroupRoutelinks.listUrl]);
        });
        this.changeDetector.detectChanges();
      }, (error: Error) => {
        this.equipmentGroupViewModel.isLoading = false;
      });
  }
  onValueChange(value: string) {
    this.equipmentGroupViewModel.isDefaultValue = false;
    if (this.equipmentGroupViewModel.equipmentGroup) {
      for (const element of this.equipmentGroupViewModel.equipmentGroup) {
        if (value.toLowerCase() === 'metric') {
          this.equipmentGroupViewModel.isImperialMetricFlag = false;
          element['lengthSpecificationsVal'] = this.emptyCheck(
            element.lengthSpecificationCode, true);
          element['widthSpecificationsVal'] = this.emptyCheck(
            element.widthSpecificationCode, true);
          element['heightSpecificationsVal'] = this.emptyCheck(
            element.heightSpecificationCode, true);
        } else {
          this.equipmentGroupViewModel.isImperialMetricFlag = true;
          element['lengthSpecificationsVal'] = this.emptyCheck(
            element.lengthSpecificationsVal);
          element['widthSpecificationsVal'] = this.emptyCheck(
            element.widthSpecificationsVal);
          element['heightSpecificationsVal'] = this.emptyCheck(
            element.heightSpecificationsVal);
        }
      }
    }
  }
  emptyCheck(value: string, isMetric = false): string {
    return value ? isMetric ? EquipmentGroupUtility.feetandInches(value) : EquipmentGroupUtility.meterToFeetInches(value) : null;
  }
}
