export class EquipmentGroupListUtility {
    static objectParamValue(model) {
        model.filterVariables['from'] = model.from;
        model.filterVariables['size'] = model.size;
        model.filterVariables['searchValue'] = model.searchValue ? model.searchValue : '';
    }
    static getLastupdatedByData(payLoadObject, equipmentGroupList, EquipmentGroupListQuery) {
        let lastUpdatedTimeObject = {};
        if (equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp &&
            equipmentGroupList.filterVariables.lastUpdatedToTimeStamp) {
            lastUpdatedTimeObject = {
                'gte': equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp,
                'lte': equipmentGroupList.filterVariables.lastUpdatedToTimeStamp
            };
        } else if (equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp) {
            lastUpdatedTimeObject = {
                'gte': equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp
            };
        } else {
            lastUpdatedTimeObject = {
                'lte': equipmentGroupList.filterVariables.lastUpdatedToTimeStamp
            };
        }
        const requestQueryObject = EquipmentGroupListQuery.getLastUpdatedByQuery();
        requestQueryObject['bool']['should'][0]['range']['LastUpdateTimestamp'] = lastUpdatedTimeObject;
        payLoadObject['query']['bool']['must'][1]['bool']['must'][5] = requestQueryObject;
        return payLoadObject;
    }
    static getExcelHeaders() {
        return [
            'equipmentGroupName',
            'equipmentGroupDescription',
            'countryName',
            'standardEquipmentGroupTypeDescription',
            'equipmentLengthDescription',
            'equipmentWidthDescription',
            'equipmentHeightDescription',
            'systemAdjustmentLengthDescription',
            'systemAdjustmentHeightDescription',
            'equipmentGroupComment',
            'lastUpdatedBy',
            'lastUpdateTimestamp',
            'status',
        ];
    }
}
