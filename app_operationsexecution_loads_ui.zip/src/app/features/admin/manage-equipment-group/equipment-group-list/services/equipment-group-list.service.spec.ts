import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { EquipmentGroupListService } from './equipment-group-list.service';
import { configureTestSuite } from 'ng-bullet';

describe('EquipmentGroupListService', () => {
  let service: EquipmentGroupListService;
  let httpTestingController: HttpTestingController;


  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        EquipmentGroupListService,
        AppConfigService
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.get(EquipmentGroupListService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getEquipmentGroups expected calls', () => {
    const request = { value: true };
    service.getEquipmentGroups(request).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentGroup);
    expect(req.request.method).toEqual('POST');
  });

  it('excelDownload expected calls', () => {
    const requestParam = { value: true };
    service.excelDownload(requestParam).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.manageEquipmentExcelDownload);
    expect(req.request.method).toEqual('POST');
  });


});






