import { EquipmentGroupListUtility } from './equipment-group-list-utility.service';

describe('EquipmentGroupListUtility', () => {

    it('should be created', () => {
        expect(EquipmentGroupListUtility).toBeTruthy();
    });
    it('getExcelHeaders have been called', () => {
        const call = EquipmentGroupListUtility.getExcelHeaders();
        expect(call).toBeDefined();
    });
    it('objectParamValue have been called', () => {
        const modelData = {
            from: 'test',
            size: 'test1',
            searchValue: 'test3',
            filterVariables: []
        };
        EquipmentGroupListUtility.objectParamValue(modelData);
        expect(modelData.size).toEqual('test1');
    });
});
