import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { Observable } from 'rxjs';
import { EquipmentGroupListValues } from '../model/equipment-group-list.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import { EquipmentGroupListQuery } from '../query/equipment-group-list-query';

@Injectable()
export class EquipmentGroupListService {
  endpoint: any;

  constructor(
    private readonly http: HttpClient,
    private readonly appConfigService: AppConfigService
  ) {
    this.endpoint = appConfigService.getApi('manageEquipmentGroup');
  }
  getEquipmentGroups(request: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(
      this.endpoint.getEquipmentGroup,
      request
    );
  }
  excelDownload(requestParam: object): Observable<any> {
    return this.downloadExcel(
      this.endpoint.manageEquipmentExcelDownload,
      requestParam
    );
  }
  downloadExcel<Response>(
    url: string,
    body: object,
    headers?: HttpHeaders | null,
    responseType?: 'blob'
  ): Observable<any> {
    return this.http.post(url, body, { headers, responseType: 'blob' });
  }

  getFilterConfig(componentInstance: any) {
    return {
      nameListing: {
        title: 'Name',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery('EquipmentGroupName'),
        callback: componentInstance.getEquipmentFilterData
      },
      descriptionAutocomplete: {
        title: 'Description',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentDescription(),
        callback: componentInstance.getEquipmentDescriptionData
      },
      countryListing: {
        title: 'Country',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery('CountryName'),
        callback: componentInstance.getEquipmentFilterData
      },
      typeListing: {
        title: 'Type',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery(
          'StandardEquipmentGroupTypeDescription'
        ),
        callback: componentInstance.getEquipmentFilterData
      },
      lengthListing: {
        title: 'Length',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery(
          'EquipmentLengthDetails.EquipmentLengthDescription'
        ),
        callback: componentInstance.getEquipmentFilterData
      },
      widthListing: {
        title: 'Width',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery(
          'EquipmentWidthDetails.EquipmentWidthDescription'
        ),
        callback: componentInstance.getEquipmentFilterData
      },
      heightListing: {
        title: 'Height',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery(
          'EquipmentHeightDetails.EquipmentHeightDescription'
        ),
        callback: componentInstance.getEquipmentFilterData
      },
      systemAdjustedLength: {
        title: 'System Adjusted Length',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery(
          'SystemAdjustmentLengthDetails.SystemAdjustmentLengthDescription'
        ),
        callback: componentInstance.getEquipmentFilterData
      },
      systemAdjustedHeight: {
        title: 'System Adjusted Height',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery(
          'SystemAdjustmentHeightDetails.SystemAdjustmentHeightDescription'
        ),
        callback: componentInstance.getEquipmentFilterData
      },
      lastUpdatedBy: {
        title: 'Last Updated By',
        url: this.endpoint.getEquipmentGroup,
        query: EquipmentGroupListQuery.getEquipmentQuery(
          'LastUpdateProgramName'
        ),
        callback: componentInstance.getEquipmentFilterData
      },
      lastUpdatedOn: {
        title: 'Last Updated On'
      },
      statusRadio: {
        title: 'Status',
        data: [
          { label: 'Active', value: 'Active' },
          { label: 'Inactive', value: 'Inactive' }
        ]
      }
    };
  }
}
