import { Component, OnInit, ChangeDetectorRef, OnDestroy, ChangeDetectionStrategy, ViewChild, ElementRef } from '@angular/core';
import { takeWhile, finalize, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';

import * as utils from 'lodash';
import * as moment from 'moment';

import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { EquipmentGroupList } from './model/equipment-group-list.model';
import { EquipmentGroupListService } from './services/equipment-group-list.service';
import { ColumnSorting } from './model/equipment-group-list.interface';
import { ElasticResponseModel } from '../../../model/elastic-response.interface';
import { EquipmentGroupListQuery } from './query/equipment-group-list-query';
import { EquipmentGroupListUtility } from './services/equipment-group-list-utility.service';
import { EquipmentGroupFilterComponent } from './equipment-group-filter/equipment-group-filter.component';
import { ManageEquipmentGroupRoutelinks } from '../manage-equipment-group-route-links';
import { UserService } from '../../../../shared/jbh-esa';

@Component({
  selector: 'app-equipment-group-list',
  templateUrl: './equipment-group-list.component.html',
  styleUrls: ['./equipment-group-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EquipmentGroupListComponent implements OnInit, OnDestroy {
  @ViewChild('equipmentGroup') equipmentGroup;
  @ViewChild(EquipmentGroupFilterComponent)
  equipmentFilterComponent: EquipmentGroupFilterComponent;
  @ViewChild('downloadExcel') downloadExcel: ElementRef;
  equipmentGroupList: EquipmentGroupList;
  searchTerms: Subject<string>;
  constructor(
    private readonly equipmentGroupListService: EquipmentGroupListService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly router: Router,
    private readonly userService: UserService
  ) {
    this.equipmentGroupList = new EquipmentGroupList();
    this.searchTerms = new Subject<string>();
    this.equipmentGroupList.sortField = 'Last Updated On';
    this.equipmentGroupList.sortOrder = this.equipmentGroupList.decendingOrder;
    }

  ngOnInit() {
    this.overflowData();
    this.fetchEquipmentGroups();
    this.searchByKeyword();
  }
  ngOnDestroy() {
    this.equipmentGroupList.subscribeFlag = false;
  }

  onPage(event) {
    this.equipmentGroupList.filterVariables.from = event.first;
    this.equipmentGroupList.filterVariables.size = event.rows;
    this.fetchEquipmentGroups();
  }
  overflowData() {
    this.equipmentGroupList.menuItems = [
      {
        label: 'Create Equipment Group',
        command: onclick => {
          this.onCreateequipmentGroup();
        }
      }
    ];
    if (this.equipmentGroupList.equipmentGroupData.length > 0) {
      this.equipmentGroupList.menuItems.push(
        {
          label: 'Export to Excel',
          command: onclick => {
            this.exportToExcel();
          }
        });
    }
    this.equipmentGroupList.menuItems
      = this.userService.getEsaMenuCheckItems(this.equipmentGroupList.menuItems, this.equipmentGroupList.manageEquipmentOverflowMenu);
  }

  fetchEquipmentGroups() {
    this.equipmentGroupList.totalRecords = 0;
    let equipmentGroupListQuery = EquipmentGroupListQuery.getEquipmentList(
      this.equipmentGroupList,
      this.equipmentGroupList.sortField,
      this.equipmentGroupList.sortOrder,
      this.equipmentGroupList.filterVariables.from,
      this.equipmentGroupList.filterVariables.size
    );
    if (
      this.equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp ||
      this.equipmentGroupList.filterVariables.lastUpdatedToTimeStamp
    ) {
      equipmentGroupListQuery = EquipmentGroupListUtility.getLastupdatedByData(
        equipmentGroupListQuery,
        this.equipmentGroupList,
        EquipmentGroupListQuery
      );
    }
    this.equipmentGroupList.loading = true;
    this.equipmentGroupListService.getEquipmentGroups(equipmentGroupListQuery)
      .pipe(takeWhile(() => this.equipmentGroupList.subscribeFlag), finalize(() => {
        this.changeDetector.detectChanges();
        this.overflowData();
      })).subscribe((data: ElasticResponseModel) => {
        this.equipmentGroupList.loading = false;
        if (data && data.hits && data.hits.hits && !utils.isEmpty(data.hits.hits)) {
          this.equipmentGroupList.equipmentGroupData = data.hits.hits;
          this.equipmentGroupList.totalRecords = data.hits.total;
          this.equipmentGroupList.noFilterData = false;
          this.equipmentGroupList.isNoResultsFound = false;
        } else {
          this.equipmentGroupList.equipmentGroupData = [];
          this.equipmentGroupList.noFilterData = true;
          this.equipmentGroupList.isNoResultsFound = true;
        }
      }, (error: Error) => {
        this.equipmentGroupList.equipmentGroupData = [];
        this.equipmentGroupList.loading = false;
      });
  }

  getFormattedTime(lastUpdatedTimeStamp: string): string {
    return `${DateUtils.getFormattedDateAndTime(lastUpdatedTimeStamp, ' hh:mm A')} CST`;
  }

  getFormattedDate(lastUpdatedTimeStamp: string): string {
    return DateUtils.getFormattedDateAndTime(lastUpdatedTimeStamp, 'MM/DD/YYYY');
  }

  onSearch(event: string) {
    if (event) {
      this.searchTerms.next(event);
    }
  }
  searchByKeyword() {
    this.searchTerms.pipe(debounceTime(300), distinctUntilChanged(),
      takeWhile(() => this.equipmentGroupList.subscribeFlag), finalize(() => {
        this.changeDetector.detectChanges();
      })).subscribe(shareData => {
        this.equipmentGroupList.isNoResultsFound = true;
        if (shareData) {
          this.equipmentGroupList.searchString = shareData['target']['value'];
          if (this.equipmentGroupList.searchString) {
            this.formatSearch(this.equipmentGroupList.searchString);
          } else {
            this.equipmentGroupList.filterVariables['searchValue'] = '';
            this.equipmentGroup.first = 0;
            this.equipmentGroupList.filterVariables.from = 0;
            this.equipmentGroupList.filterVariables.size = 25;
          }
        }
        this.fetchEquipmentGroups();
      }, (error: Error) => {
        this.equipmentGroupList.equipmentGroupData = [];
        this.equipmentGroupList.loading = false;
      });
  }
  formatSearch(searchString: string) {
    if (searchString.match('^[0-9,]*$ ')) {
      this.equipmentGroupList.searchValue = searchString.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
      this.equipmentGroupList.searchValue = this.equipmentGroupList.searchValue.replace(/\,/g, '');
    } else if (searchString.match('[()]')) {
      this.equipmentGroupList.searchValue = searchString.replace(/[()]/g, '');
    } else {
      this.equipmentGroupList.searchValue = searchString.replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
    }
    this.equipmentGroupList.filterVariables.from = 0;
    this.equipmentGroupList.filterVariables.size = 25;
    EquipmentGroupListUtility.objectParamValue(this.equipmentGroupList);
  }
  onSortSelect(selectedColumnName: ColumnSorting) {
    this.equipmentGroupList.filterVariables.from = 0;
    this.equipmentGroupList.filterVariables.size = 25;
    if (
      this.equipmentGroupList.sortField &&
      this.equipmentGroupList.sortField === selectedColumnName['name']
    ) {
      this.equipmentGroupList.sortField = selectedColumnName['name'];
      this.equipmentGroupList.sortOrder =
        this.equipmentGroupList.sortOrder ===
          this.equipmentGroupList.decendingOrder ? this.equipmentGroupList.ascendingOrder : this.equipmentGroupList.decendingOrder;
      this.fetchEquipmentGroups();
    } else {
      this.equipmentGroupList.sortField = selectedColumnName['name'];
      this.equipmentGroupList.sortOrder = this.equipmentGroupList.ascendingOrder;
      this.fetchEquipmentGroups();
    }
  }
  equipmentFilterValues(filterVariables) {
    filterVariables.from = 0;
    filterVariables.size = 25;
    this.equipmentGroupList.filterVariables = filterVariables;
    this.fetchEquipmentGroups();
    this.equipmentGroup.first = 0;
  }
  onFilterClicked() {
    if (this.equipmentGroupList.showFilter) {
      this.equipmentFilterComponent.onFilterIconClicked();
    }
    this.equipmentGroupList.filterFlag = !this.equipmentGroupList.filterFlag;
    this.equipmentGroupList.showFilter = true;
  }
  onCreateequipmentGroup() {
    this.router.navigate([ManageEquipmentGroupRoutelinks.createUrl]);
  }
  onRowSelect(event: Event) {
    if (event['data']['_source']['StandardEquipmentGroupID']) {
      this.router.navigate([ManageEquipmentGroupRoutelinks.viewUrl], {
        queryParams: {
          standardEquipmentGroupID:
            event['data']['_source']['StandardEquipmentGroupID']
        }
      });
    }
  }
  exportToExcel() {
    const excelParam = {};
    const headerDetails = EquipmentGroupListUtility.getExcelHeaders();
    excelParam['displayFields'] = headerDetails;
    this.equipmentGroupList.filterVariables.size = 1000;
    this.equipmentGroupList.filterVariables.from = 0;
    let excelDownloadQuery: object = EquipmentGroupListQuery.getEquipmentList(
      this.equipmentGroupList, this.equipmentGroupList.sortField, this.equipmentGroupList.sortOrder,
      this.equipmentGroupList.filterVariables.from, this.equipmentGroupList.filterVariables.size);
    if (this.equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp ||
      this.equipmentGroupList.filterVariables.lastUpdatedToTimeStamp) {
      excelDownloadQuery = EquipmentGroupListUtility.getLastupdatedByData(
        excelDownloadQuery, this.equipmentGroupList, EquipmentGroupListQuery);
    }
    excelParam['elasticSearchQuery'] = excelDownloadQuery;
    this.exportToExcelFunction(excelParam, this.downloadExcel);
  }

  exportToExcelFunction(tableParam: object, downloadExcel: ElementRef) {
    this.equipmentGroupListService.excelDownload(tableParam).pipe(
      takeWhile(() => this.equipmentGroupList.subscribeFlag), finalize(() => {
        this.changeDetector.detectChanges();
      })).subscribe((data: object) => {
        if (data) {
          this.downloadFile(data, downloadExcel);
        }
      });
  }
  downloadFile(data: object, downloadExcel: ElementRef) {
    const fileName = `Equipment Groups ${moment().format(
      'YYYY-MM-DD'
    )} at ${moment().format('hh.mm.ss A')}.xlsx`;
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(data, fileName);
    } else {
      downloadExcel.nativeElement.href = URL.createObjectURL(data);
      downloadExcel.nativeElement.download = fileName;
      downloadExcel.nativeElement.click();
    }
  }
  isFilterOrSearch() {
    let isFilterOrSearchExist = false;
    const filterEntries = Object.entries(this.equipmentGroupList.filterVariables);
    filterEntries.forEach((entries, i) => {
      if (entries[1].length > 0) {
        isFilterOrSearchExist = true;
      }
    });
    return !isFilterOrSearchExist;
  }
}
