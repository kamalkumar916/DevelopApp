import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';
import { UserService } from '../../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { EquipmentGroupListService } from '../services/equipment-group-list.service';

import { EquipmentGroupFilterComponent } from './equipment-group-filter.component';
import { configureTestSuite } from 'ng-bullet';

import { JbhFiltersModule } from '../../../../../shared/jbh-filters/jbh-filters.module';
import { DatePipe } from '@angular/common';

const ListItemData = [{
  label: 'test',
  value: 'test2',
  esKey: 'test3'
}];

describe('EquipmentGroupFilterComponent', () => {
  let component: EquipmentGroupFilterComponent;
  let fixture: ComponentFixture<EquipmentGroupFilterComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule, JbhFiltersModule,
        RouterTestingModule],
      providers: [UserService, AppConfigService, MessageService, EquipmentGroupListService, DatePipe],
      declarations: [EquipmentGroupFilterComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('onClearFilters have been called', () => {
    component.onClearFilters();
    expect(component.equipmentGroupList.filterVariables.equipmentName.length).toBe(0);
  });
  it('onCloseFilterPanel have been called', () => {
    component.onCloseFilterPanel();
    expect(component.equipmentGroupList.lastUpdatedOnPanel).toBe(true);
  });
  it('onEquipmentNameSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentNameSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentDescriptionSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentDescriptionSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentCountrySelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentCountrySelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentTypeSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentTypeSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentLengthSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentLengthSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentWidthSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentWidthSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentHeightSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentHeightSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentAdjustedLengthSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentAdjustedLengthSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentAdjustedHeightSelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentAdjustedHeightSelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentLastUpdatedBySelected have been called', () => {
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentLastUpdatedBySelected(ListItemData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('onEquipmentStatusSelected have been called', () => {
    const ListItemobj = {
      label: 'test',
      value: 'test2',
      esKey: 'test3'
    };
    spyOn(component, 'setFilterValue');
    spyOn(component, 'onFilter');
    component.onEquipmentStatusSelected(ListItemobj);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('setFilterValue have been called', () => {
    const call = component.setFilterValue(ListItemData);
    expect(call).toBeDefined();
  });
  it('getEquipmentFilterData have been called', () => {
    const RootHitsModelData = {
      hits: [],
      max_score: 123,
      total: 123,
    };
    const ShardsModelData = {
      total: 123,
      successful: 123,
      skipped: 123,
      failed: 123,
    };
    const ElasticResponseModelData = {
      hits: RootHitsModelData,
      timed_out: true,
      took: 123,
      _shards: ShardsModelData,
      aggregations: {
        equipmentFieldData: {
          buckets: [{
            key: '',
          }],
        },
      },
    };
    const call = component.getEquipmentFilterData(ElasticResponseModelData);
    expect(call).toBeDefined();
  });
  it('onFilterIconClicked have been called case1', () => {
    component.filterComponents = [{
      constructor: {
        name: 'ListingFilterComponent',
      },
      selectedValues: [],
      closePanel: jasmine.createSpy()
    }];
    component.onFilterIconClicked();
    expect(component.filterComponents[0].closePanel).toHaveBeenCalled();
  });
  it('onFilterIconClicked have been called case2', () => {
    component.filterComponents = [{
      constructor: {
        name: 'RadioFilterComponent',
      },
      selectedValues: null,
      closePanel: jasmine.createSpy()
    }];
    component.onFilterIconClicked();
    expect(component.filterComponents[0].closePanel).toHaveBeenCalled();
  });
  it('onFilterIconClicked have been called case3', () => {
    component.filterComponents = [{
      constructor: {
        name: 'DateFilterComponent',
      },
      validDate: {
        startDate: null,
        endDate: null,
        startDateValue: null,
        endDateValue: null,
        startTime: null,
        endTime: null,
      },
      selectedValues: null,
      closePanel: jasmine.createSpy()
    }];
    component.onFilterIconClicked();
    expect(component.filterComponents[0].closePanel).toHaveBeenCalled();
  });
  it('onEquipmentLastUpdatedBySelected have been called', () => {
    const DateTimeFilterData = {
      startDate: '',
      startTime: '',
      startDateValue: '',
      endDate: '',
      endTime: '',
      endDateValue: '',
    };
    spyOn(component, 'onFilter');
    component.onEquipmentLastUpdatedOnSelected(DateTimeFilterData);
    expect(component.onFilter).toHaveBeenCalled();
  });
  it('getEquipmentDescriptionData have been called', () => {
    const RootHitsModelData = {
      hits: [],
      max_score: 123,
      total: 123,
    };
    const ShardsModelData = {
      total: 123,
      successful: 123,
      skipped: 123,
      failed: 123,
    };
    const ElasticResponseModelData = {
      hits: RootHitsModelData,
      timed_out: true,
      took: 123,
      _shards: ShardsModelData,
      aggregations: {
        equipmentFieldData: {
          buckets: [{
            key: '',
          }],
        },
      },
    };
    const call = component.getEquipmentDescriptionData(ElasticResponseModelData);
    expect(call).toBeDefined();
  });
});
