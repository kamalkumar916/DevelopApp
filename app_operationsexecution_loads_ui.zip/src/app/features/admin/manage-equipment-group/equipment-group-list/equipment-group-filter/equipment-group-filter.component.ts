import {
  Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef,
  EventEmitter, Output, ViewChildren
} from '@angular/core';
import * as lodashUtils from 'lodash';
import { DatePipe } from '@angular/common';

import { EquipmentGroupListService } from '../services/equipment-group-list.service';
import { EquipmentGroupList } from '../model/equipment-group-list.model';
import { ListItem } from '../../../../model/listitem.interface';
import { FilterConfig, DateTimeFilter } from '../model/equipment-group-list.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';

@Component({
  selector: 'app-equipment-group-filter',
  templateUrl: './equipment-group-filter.component.html',
  styleUrls: ['./equipment-group-filter.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EquipmentGroupFilterComponent implements OnInit {
  @Output() filterValues = new EventEmitter();
  @ViewChildren('filtercomp') filterComponents;
  equipmentGroupList: EquipmentGroupList;
  filterConfig: FilterConfig;
  constructor(private readonly equipmentGroupListService: EquipmentGroupListService,
    private readonly datePipe: DatePipe,
    private readonly changeDetector: ChangeDetectorRef
  ) {
    this.filterConfig = this.equipmentGroupListService.getFilterConfig(this);
    this.equipmentGroupList = new EquipmentGroupList();
  }

  ngOnInit() {
  }

  getEquipmentFilterData(data: ElasticResponseModel): ListItem[] {
    let nameData: ListItem[] = [];
    if (data && data.aggregations && data.aggregations.equipmentFieldData &&
      (!lodashUtils.isEmpty(data.aggregations.equipmentFieldData.buckets))) {
      nameData = data.aggregations.equipmentFieldData.buckets.map((value) => {
        return {
          label: value.key,
          value: value.key
        };
      });
    }
    return nameData;
  }

  onEquipmentNameSelected(equipmentName: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentName = this.setFilterValue(equipmentName);
    this.onFilter();
  }

  onEquipmentDescriptionSelected(equipmentDescription: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentDescription = this.setFilterValue(equipmentDescription);
    this.onFilter();
  }

  onEquipmentCountrySelected(equipmentCountry: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentCountry = this.setFilterValue(equipmentCountry);
    this.onFilter();
  }

  onEquipmentTypeSelected(equipmentType: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentType = this.setFilterValue(equipmentType);
    this.onFilter();
  }

  onEquipmentLengthSelected(equipmentLength: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentLength = this.setFilterValue(equipmentLength);
    this.onFilter();
  }

  onEquipmentWidthSelected(equipmentWidth: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentWidth = this.setFilterValue(equipmentWidth);
    this.onFilter();
  }

  onEquipmentHeightSelected(equipmentHeight: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentHeight = this.setFilterValue(equipmentHeight);
    this.onFilter();
  }

  onEquipmentAdjustedLengthSelected(equipmentAdjustLength: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentSystemAdjustLength = this.setFilterValue(equipmentAdjustLength);
    this.onFilter();
  }

  onEquipmentAdjustedHeightSelected(equipmentAdjustHeight: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentSystemAdjustHeight = this.setFilterValue(equipmentAdjustHeight);
    this.onFilter();
  }

  onEquipmentLastUpdatedBySelected(equipmentlastUpdatedBy: ListItem[]) {
    this.equipmentGroupList.filterVariables.equipmentlastUpdatedBy = this.setFilterValue(equipmentlastUpdatedBy);
    this.onFilter();
  }

  onEquipmentStatusSelected(equipmentStatus: ListItem) {
    this.equipmentGroupList.filterVariables.equipmentStatus = [];
    if (equipmentStatus && equipmentStatus.value) {
      this.equipmentGroupList.filterVariables.equipmentStatus.push(equipmentStatus.value);
    }
    this.onFilter();
  }
  setFilterValue(setFilterValues: ListItem[]) {
    let filterValue = [];
    filterValue = setFilterValues.map((data) => {
      return data.value;
    });
    return filterValue;
  }
  onFilter() {
    this.filterValues.emit(this.equipmentGroupList.filterVariables);
  }
  onClearFilters() {
    this.filterComponents.forEach(filterCompItem => {
      filterCompItem.onReset(false);
    });
    this.equipmentGroupList.filterVariables.equipmentName = [];
    this.equipmentGroupList.filterVariables.equipmentDescription = [];
    this.equipmentGroupList.filterVariables.equipmentCountry = [];
    this.equipmentGroupList.filterVariables.equipmentType = [];
    this.equipmentGroupList.filterVariables.equipmentStatus = [];
    this.equipmentGroupList.filterVariables.equipmentLength = [];
    this.equipmentGroupList.filterVariables.equipmentHeight = [];
    this.equipmentGroupList.filterVariables.equipmentWidth = [];
    this.equipmentGroupList.filterVariables.equipmentSystemAdjustLength = [];
    this.equipmentGroupList.filterVariables.equipmentSystemAdjustHeight = [];
    this.equipmentGroupList.filterVariables.equipmentlastUpdatedBy = [];
    this.equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp = '';
    this.equipmentGroupList.filterVariables.lastUpdatedToTimeStamp = '';
    this.onCloseFilterPanel();
    this.onFilter();
  }

  onCloseFilterPanel() {
    this.filterComponents.forEach(filterCompItem => {
      filterCompItem.closePanel();
    });
    this.equipmentGroupList.lastUpdatedOnPanel = true;
  }

  onFilterIconClicked() {
    this.filterComponents.forEach(filterCompItem => {
      switch (filterCompItem.constructor.name) {
        case 'ListingFilterComponent':
        case 'AutocompleteFilterComponent':
          if (filterCompItem.selectedValues.length === 0) {
            filterCompItem.closePanel();
          }
          break;
        case 'RadioFilterComponent':
          if (!filterCompItem.selectedValue) {
            filterCompItem.closePanel();
          }
          break;
        case 'DateFilterComponent':
          if (!filterCompItem.validDate.startDate && !filterCompItem.validDate.endDate
            && !filterCompItem.validDate.startDateValue && !filterCompItem.validDate.endDateValue
            && !filterCompItem.validDate.startTime && !filterCompItem.validDate.endTime) {
            filterCompItem.closePanel();
          }
          break;
      }
    });
    this.changeDetector.detectChanges();
  }

  getEquipmentDescriptionData(data: ElasticResponseModel) {
    let descriptionData: ListItem[] = [];
    if (data && data.hits && data.hits.hits) {
      const equipmentDescription = data.hits.hits.map((value) => {
        return value._source.EquipmentGroupDescription;
      });
      const uniqRule = lodashUtils.uniq(equipmentDescription);
      descriptionData = uniqRule.map((description) => {
        return {
          'label': description,
          'value': description
        };
      });
    }
    return descriptionData;
  }
  onEquipmentLastUpdatedOnSelected(lastUpdatedOn: DateTimeFilter) {
    this.equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp = lastUpdatedOn.startDate ? `${lastUpdatedOn.startDate} CST` : '';
    this.equipmentGroupList.filterVariables.lastUpdatedToTimeStamp = lastUpdatedOn.endDate ? `${lastUpdatedOn.endDate} CST` : '';
    this.onFilter();
  }
}
