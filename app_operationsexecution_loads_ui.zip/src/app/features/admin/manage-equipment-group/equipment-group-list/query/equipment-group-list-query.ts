import { EquipmentGroupList } from '../model/equipment-group-list.model';
import * as lodashutils from 'lodash';
import * as bodybuilderUtils from 'bodybuilder';
export class EquipmentGroupListQuery {
  static filterFields = ['EquipmentGroupName', 'EquipmentGroupDescription', 'StandardEquipmentGroupTypeDescription',
  'CountryName', 'EquipmentHeightDetails.EquipmentHeightDescription', 'EquipmentLengthDetails.EquipmentLengthDescription',
  'EquipmentWidthDetails.EquipmentWidthDescription', 'SystemAdjustmentHeightDetails.SystemAdjustmentHeightDescription',
  'SystemAdjustmentLengthDetails.SystemAdjustmentLengthDescription', 'LastUpdateTimestamp.text', 'Status', 'EquipmentGroupComment'];

  static getEquipmentList(model: EquipmentGroupList, sortField: string, orderBy: string, start: number, size: number) {
    const searchString = model.filterVariables.searchValue ? model.filterVariables.searchValue : '';
    return {
      from: model.filterVariables.from,
      size: model.filterVariables.size,
      query: {
        bool: {
          must: [
            {
              bool: {
                should: lodashutils.at(this.getEquipmentDetailQuery(searchString), 'query.bool.should')
              }
            },
            {
              bool: {
                must: [
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'EquipmentGroupName',
                            query: model.filterVariables.equipmentName.length > 0 ? '' : '*'
                          }
                        },
                        {
                          terms: {
                            'EquipmentGroupName.keyword':
                              model.filterVariables.equipmentName.length > 0 ? model.filterVariables.equipmentName : []
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'EquipmentGroupDescription',
                            query: model.filterVariables.equipmentDescription.length > 0 ? '' : '*'
                          }
                        },
                        {
                          terms: {
                            'EquipmentGroupDescription.keyword':
                              model.filterVariables.equipmentDescription.length > 0 ?
                                model.filterVariables.equipmentDescription : []
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'StandardEquipmentGroupTypeDescription',
                            query: model.filterVariables.equipmentType.length > 0 ? '' : '*'
                          }
                        },
                        {
                          terms: {
                            'StandardEquipmentGroupTypeDescription.keyword':
                              model.filterVariables.equipmentType.length > 0 ? model.filterVariables.equipmentType : []
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'CountryName',
                            query: model.filterVariables.equipmentCountry.length > 0 ? '' : '*'
                          }
                        },
                        {
                          terms: {
                            'CountryName.keyword':
                              model.filterVariables.equipmentCountry.length > 0 ? model.filterVariables.equipmentCountry : []
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'SystemAdjustmentLengthDetails.SystemAdjustmentLengthDescription',
                            query: model.filterVariables.equipmentSystemAdjustLength.length > 0 ? '' : '*'
                          }
                        },
                        {
                          terms: {
                            'SystemAdjustmentLengthDetails.SystemAdjustmentLengthDescription.keyword':
                              model.filterVariables.equipmentSystemAdjustLength.length > 0 ?
                                model.filterVariables.equipmentSystemAdjustLength : []
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'SystemAdjustmentHeightDetails.SystemAdjustmentHeightDescription',
                            query: model.filterVariables.equipmentSystemAdjustHeight.length > 0 ? '' : '*'
                          }
                        },
                        {
                          terms: {
                            'SystemAdjustmentHeightDetails.SystemAdjustmentHeightDescription.keyword':
                              model.filterVariables.equipmentSystemAdjustHeight.length > 0 ?
                                model.filterVariables.equipmentSystemAdjustHeight : []
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: {
                      should: [
                        {
                          query_string: {
                            default_field: 'EquipmentWidthDetails.EquipmentWidthDescription',
                            query: model.filterVariables.equipmentWidth.length > 0 ? '' : '*'
                          }
                        },
                        {
                          terms: {
                            'EquipmentWidthDetails.EquipmentWidthDescription.keyword':
                              model.filterVariables.equipmentWidth.length > 0 ? model.filterVariables.equipmentWidth : []
                          }
                        }
                      ]
                    }
                  },
                  {
                    bool: this.getEquipmentLengthQuery(model)
                  },
                  {
                    bool: this.getEquipmentHeightQuery(model)
                  },
                  {
                    bool: this.getLastUpdatedProgramCodeQuery(model)
                  },
                  {
                    bool: this.getLastUpdatedTimeStampQuery()
                  },
                  {
                    bool: this.getStatusQuery(model)
                  }
                ]
              }
            }
          ]
        }
      },
      sort: [this.sortObject(model, sortField, orderBy)]
    };
  }
  static sortObject(model: EquipmentGroupList, sortField: string, orderBy: string): object {
    const sortObj = {};
    const responseData = lodashutils.find(model.tableColumnHeaders, { name: sortField });
    sortObj[responseData.queryKey] = { order: orderBy };
    return sortObj;
  }
  static getEquipmentQuery(fieldData: string) {
    return {
      aggs: {
        equipmentFieldData: {
          terms: { field: `${fieldData}.keyword`, size: 1000 }
        }
      }
    };
  }
  static getEquipmentDescription() {
    return {
      from: 0,
      size: 5,
      query: {
        query_string: {
          default_field: 'EquipmentGroupDescription',
          query: '*search-query-text*',
          default_operator: 'AND'
        }
      },
      sort: [
        {
          'EquipmentGroupDescription.keyword': {
            order: 'asc'
          }
        }
      ],
      _source: [
        'EquipmentGroupDescription'
      ]
    };
  }
  static getLastUpdatedByQuery() {
    return {
      'bool': {
        'should': [
          {
            'range': {
              'LastUpdateTimestamp': {
              }
            }
          }
        ]
      }
    };
  }
  static getStatusQuery(model: EquipmentGroupList) {
    return {
      should: [
        {
          query_string: {
            default_field: 'Status',
            query: model.filterVariables.equipmentStatus.length > 0 ? '' : '*'
          }
        },
        {
          terms: {
            'Status.keyword':
              model.filterVariables.equipmentStatus.length > 0 ? model.filterVariables.equipmentStatus : []
          }
        }
      ]
    };
  }
  static getLastUpdatedTimeStampQuery() {
    return {
      should: [
        {
          query_string: {
            default_field: 'LastUpdateTimestamp',
            query: '*'
          }
        },
        {
          terms: {
            'LastUpdateTimestamp.keyword': [
              ''
            ]
          }
        }
      ]
    };
  }
  static getLastUpdatedProgramCodeQuery(model: EquipmentGroupList) {
    return {
      should: [
        {
          query_string: {
            default_field: 'LastUpdateProgramName',
            query: model.filterVariables.equipmentlastUpdatedBy.length > 0 ? '' : '*'
          }
        },
        {
          terms: {
            'LastUpdateProgramName.keyword':
              model.filterVariables.equipmentlastUpdatedBy.length > 0 ?
                model.filterVariables.equipmentlastUpdatedBy : []
          }
        }
      ]
    };
  }
  static getEquipmentHeightQuery(model: EquipmentGroupList) {
    return {
      should: [
        {
          query_string: {
            default_field: 'EquipmentHeightDetails.EquipmentHeightDescription',
            query: model.filterVariables.equipmentHeight.length > 0 ? '' : '*'
          }
        },
        {
          terms: {
            'EquipmentHeightDetails.EquipmentHeightDescription.keyword':
              model.filterVariables.equipmentHeight.length > 0 ? model.filterVariables.equipmentHeight : []
          }
        }
      ]
    };
  }
  static getEquipmentLengthQuery(model: EquipmentGroupList) {
    return {
      should: [
        {
          query_string: {
            default_field: 'EquipmentLengthDetails.EquipmentLengthDescription',
            query: model.filterVariables.equipmentLength.length > 0 ? '' : '*'
          }
        },
        {
          terms: {
            'EquipmentLengthDetails.EquipmentLengthDescription.keyword':
              model.filterVariables.equipmentLength.length > 0 ? model.filterVariables.equipmentLength : []
          }
        }
      ]
    };
  }
  static getEquipmentDetailQuery(searchString: string) {
    const builder = bodybuilderUtils();
    this.filterFields.forEach((element) => {
      builder.orQuery('query_string', {
          default_field: element,
          query: `*${searchString}*`,
          default_operator: 'AND'
      });
    });
    builder.orQuery('query_string', {
        fields: ['LastUpdateProgramName', 'LastUpdateUserID'],
        query: `*${searchString}*`,
        default_operator: 'AND'
    });
    return builder.build();
  }
}
