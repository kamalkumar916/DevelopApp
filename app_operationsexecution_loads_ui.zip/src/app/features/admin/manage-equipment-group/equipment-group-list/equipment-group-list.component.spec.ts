import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { EquipmentGroupListComponent } from './equipment-group-list.component';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { EquipmentGroupListService } from './services/equipment-group-list.service';

import { configureTestSuite } from 'ng-bullet';


import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { EquipmentGroupFilterComponent } from './equipment-group-filter/equipment-group-filter.component';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { FormsModule } from '@angular/forms';
import { TooltipModule } from 'primeng/tooltip';
import { JbhFiltersModule } from '../../../../shared/jbh-filters/jbh-filters.module';
import { EquipmentGroupListUtility } from './services/equipment-group-list-utility.service';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';

const getEquipmentGroupsData = {
  hits: {
    hits: [{
      sort: [],
      _id: '704',
      _index: 'operationsexecution-equipmentpair',
      _score: null,
      _source: {
        CountryCode: 'USA',
        CountryName: 'USA',
        EffectiveTimestamp: '',
        EquipmentGroupComment: 'manageEquipmentGroupingCreateSingle',
        EquipmentGroupDescription: 'automation run',
        EquipmentGroupName: 'AUTOMATION CHECK 3814',
        EquipmentHeightDetails: {
          EquipmentHeightDescription: '13 ft 6 in',
          TotalEquipmentHeight: 162,
        },
        EquipmentLengthDetails: {
          EquipmentLengthDescription: '214 ft',
          TotalEquipmentLength: 2568,
        },
        EquipmentWidthDetails: {
          EquipmentWidthDescription: '8 ft 6 in',
          TotalEquipmentWidth: 102
        },
        ExpirationTimestamp: '',
        LastUpdateProgramName: 'Balasubramanian Kathiravan',
        LastUpdateTimestamp: '',
        LastUpdateUserID: 'jcnt740',
        StandardEquipmentGroupID: 704,
        StandardEquipmentGroupTypeCode: 'NonMoving',
        StandardEquipmentGroupTypeDescription: 'Non Moving',
        Status: 'Active',
        SystemAdjustmentHeightDetails: {
          SystemAdjustmentHeight: 0,
          SystemAdjustmentHeightDescription: '---',
        },
        SystemAdjustmentLengthDetails: {
          SystemAdjustmentLength: -1788,
          SystemAdjustmentLengthDescription: '-149 ft',
        },
      },
      _type: 'doc',
    }],
    max_score: null,
    total: 55,
  },
  timed_out: false,
  took: 10,
  _shards: {
    failed: 0,
    skipped: 0,
    successful: 3,
    total: 3,
  },
};
class MockEquipmentGroupListService {
  constructor() { }
  getEquipmentGroups() {
    return of(getEquipmentGroupsData);
  }
  excelDownload() {
    return throwError(null);
  }
}

describe('EquipmentGroupListComponent', () => {
  let component: EquipmentGroupListComponent;
  let fixture: ComponentFixture<EquipmentGroupListComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, BreadcrumbModule, TableModule, DirectivesModule, FormsModule, MenuModule, TooltipModule,
        JbhFiltersModule],
      providers: [UserService, AppConfigService, MessageService,
        { provide: EquipmentGroupListService, useClass: MockEquipmentGroupListService }
      ],
      declarations: [EquipmentGroupListComponent, EquipmentGroupFilterComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getFormattedTime have been called', () => {
    const returnValue = component.getFormattedTime('2020-01-01 01:01:01');
    expect(returnValue).toBe(' 01:01 AM CST');
  });

  it('getFormattedDate have been called', () => {
    const returnValue = component.getFormattedDate('2020-01-01 01:01:01');
    expect(returnValue).toBe('01/01/2020');
  });

  it('formatSearch have been called', () => {
    component.formatSearch('');
    expect(component.equipmentGroupList.filterVariables.size).toBe(25);
  });

  it('onFilterClicked have been called', () => {
    component.onFilterClicked();
    expect(component.equipmentGroupList.showFilter).toBe(true);
  });

  it('isFilterOrSearch have been called', () => {
    const returnValue = component.isFilterOrSearch();
    expect(returnValue).toBe(true);
  });

  it('onPage have been called', () => {
    spyOn(component, 'fetchEquipmentGroups');
    component.onPage('test');
    expect(component.fetchEquipmentGroups).toHaveBeenCalled();
  });


  it('onSortSelect have been called', () => {
    const testData = {
      name: 'test',
      queryKey: 'test'
    };
    spyOn(component, 'fetchEquipmentGroups');
    component.onSortSelect(testData);
    expect(component.fetchEquipmentGroups).toHaveBeenCalled();
  });

  it('equipmentFilterValues have been called', () => {
    spyOn(component, 'fetchEquipmentGroups');
    const testData = {
      from: '',
      size: '',
      first: '',
    };
    component.equipmentFilterValues(testData);
    expect(component.fetchEquipmentGroups).toHaveBeenCalled();
  });

  it('exportToExcel have been called', () => {
    spyOn(EquipmentGroupListUtility, 'getExcelHeaders');
    spyOn(EquipmentGroupListUtility, 'getLastupdatedByData');
    spyOn(component, 'exportToExcelFunction');
    component.exportToExcel();
    expect(EquipmentGroupListUtility.getExcelHeaders).toHaveBeenCalled();
  });

  it('onSearch', fakeAsync(() => {
    spyOn(component, 'fetchEquipmentGroups');
    const input = fixture.debugElement.query(By.css('#equipmentGroupListSearchText'));
    input.triggerEventHandler('input', { target: { value: '' } });
    tick(300);
    expect(component.fetchEquipmentGroups).toHaveBeenCalled();
  }));
  it('fetchEquipmentGroups have been called', () => {
    component.equipmentGroupList.filterVariables.lastUpdatedFromTimeStamp = 'test';
    getEquipmentGroupsData.hits.hits = [];
    component.fetchEquipmentGroups();
    expect(component.equipmentGroupList.noFilterData).toBeTruthy();
  });
  it('fetchEquipmentGroups have been called', () => {
    const equipmentGroupListService: EquipmentGroupListService = TestBed.get(EquipmentGroupListService);
    spyOn(equipmentGroupListService, 'getEquipmentGroups').and.returnValue(throwError(null));
    component.fetchEquipmentGroups();
    expect(component.equipmentGroupList.loading).toBeFalsy();
  });
  it('onCreateequipmentGroup have been called', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.onCreateequipmentGroup();
    expect(router.navigate).toHaveBeenCalled();
  });
});
