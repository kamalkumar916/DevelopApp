import { ListItem } from '../../../../model/listitem.interface';

export interface EquipmentGroupListValues {
    StandardEquipmentGroupID: number;
    EquipmentGroupName: string;
    CountryCode: string;
    CountryName: string;
    EquipmentGroupDescription: string;
    StandardEquipmentGroupTypeCode: string;
    StandardEquipmentGroupTypeDescription: string;
    SystemAdjustmentLength: string;
    SystemAdjustmentHeight: string;
    EquipmentHeight: string;
    EquipmentLength: string;
    EquipmentWidth: string;
    UnitOfLengthMeasurementDescription: string;
    UnitOfWidthMeasurementDescription: string;
    UnitOfHeightMeasurementDescription: string;
    UnitOfSystemAdjustmentLengthDescription: string;
    UnitOfSystemAdjustmentHeightDescription: string;
    Status: string;
    LastUpdateTimestamp: string;
    LastUpdateProgramName: string;
    LastUpdateUserID: string;
    EffectiveTimestamp: string;
    ExpirationTimestamp: string;
}

export interface ColumnSorting {
    name: string;
    queryKey: string;
}

export interface FilterValues {
    from: number;
    size: number;
    searchValue: string;
    equipmentName: string[];
    equipmentDescription: string[];
    equipmentCountry: string[];
    equipmentType: string[];
    equipmentLength: string[];
    equipmentWidth: string[];
    equipmentHeight: string[];
    equipmentSystemAdjustLength: string[];
    equipmentSystemAdjustHeight: string[];
    equipmentlastUpdatedBy: string[];
    lastUpdatedFromTimeStamp: string;
    lastUpdatedToTimeStamp: string;
    equipmentStatus: string[];
}

export interface FilterConfigFields {
    title: string;
    url: string;
    query: any;
    callback: ListItem[];

}

export interface FilterConfigDateFields {
    title: string;
}

export interface StatusFilterConfig {
    title: string;
    data: ListItem[];
}
export interface FilterConfig {
    nameListing: FilterConfigFields;
    descriptionAutocomplete: FilterConfigFields;
    countryListing: FilterConfigFields;
    typeListing: FilterConfigFields;
    lengthListing: FilterConfigFields;
    widthListing: FilterConfigFields;
    heightListing: FilterConfigFields;
    systemAdjustedLength: FilterConfigFields;
    systemAdjustedHeight: FilterConfigFields;
    lastUpdatedBy: FilterConfigFields;
    lastUpdatedOn: FilterConfigDateFields;
    statusRadio: StatusFilterConfig;
}
export interface DateTimeFilter {
    startDate: string;
    startTime: string;
    startDateValue: string;
    endDate: string;
    endTime: string;
    endDateValue: string;
}
