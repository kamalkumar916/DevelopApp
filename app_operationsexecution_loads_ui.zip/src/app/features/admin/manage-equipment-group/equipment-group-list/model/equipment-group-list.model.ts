
import { MenuItem } from 'primeng/api';
import { ColumnSorting, FilterValues, FilterConfig } from './equipment-group-list.interface';
import { HitsModel } from '../../../../model/elastic-response.interface';
import { ManageEquipmentGroupRoutelinks } from '../../manage-equipment-group-route-links';
import { AppConfig } from '../../../../../../config/app.config';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';

export class EquipmentGroupList {
    manageEquipmentBreadcrumb: MenuItem[];
    menuItems: MenuItem[];
    loading: boolean;
    totalRecords: number;
    subscribeFlag: boolean;
    equipmentGroupData: HitsModel[];
    searchValue: string;
    searchInputValue: string;
    from: number;
    first: number;
    size: number;
    sortField: string;
    sortOrder: string;
    ascendingOrder: string;
    decendingOrder: string;
    tableColumnHeaders: ColumnSorting[];
    filterFlag: boolean;
    selectedStartDate: string;
    startTime: string;
    selectedEndDate: string;
    endTime: string;
    startDate: string;
    endDate: string;
    filterVariables: FilterValues;
    lastUpdatedOnPanel: boolean;
    filterConfig: FilterConfig;
    searchString: string;
    isNoResultsFound: boolean;
    noFilterData: boolean;
    showFilter: boolean;
    appConfig;
    manageEquipmentCreateButton: SecureModel;
    manageEquipmentOverflowMenu;
    constructor() {
        this.manageEquipmentBreadcrumb = [
            { label: 'Administration', routerLink: [ManageEquipmentGroupRoutelinks.homeUrl] },
            {
                label: 'Manage Equipment Group'
            }
        ];
        this.menuItems = [];
        this.loading = false;
        this.subscribeFlag = true;
        this.searchValue = '';
        this.searchInputValue = '';
        this.from = 0;
        this.first = 0;
        this.size = 25;
        this.ascendingOrder = 'asc';
        this.decendingOrder = 'desc';
        this.searchString = '';
        this.isNoResultsFound = false;
        this.tableColumnHeaders = [{
            'name': 'Name',
            'queryKey': 'EquipmentGroupName.keyword'
        }, {
            'name': 'Description',
            'queryKey': 'EquipmentGroupDescription.keyword'
        }, {
            'name': 'Country',
            'queryKey': 'CountryName.keyword'
        }, {
            'name': 'Type',
            'queryKey': 'StandardEquipmentGroupTypeDescription.keyword'
        }, {
            'name': 'Length',
            'queryKey': 'EquipmentLengthDetails.TotalEquipmentLength'
        }, {
            'name': 'Width',
            'queryKey': 'EquipmentWidthDetails.TotalEquipmentWidth'
        }, {
            'name': 'Height',
            'queryKey': 'EquipmentHeightDetails.TotalEquipmentHeight'
        }, {
            'name': 'System Adjusted Length',
            'queryKey': 'SystemAdjustmentLengthDetails.SystemAdjustmentLength'
        }, {
            'name': 'System Adjusted Height',
            'queryKey': 'SystemAdjustmentHeightDetails.SystemAdjustmentHeight'
        }, {
            'name': 'Comments',
            'queryKey': 'EquipmentGroupComment.keyword'
        }, {
            'name': 'Last Updated By',
            'queryKey': 'LastUpdateProgramName.keyword'
        }, {
            'name': 'Last Updated On',
            'queryKey': 'LastUpdateTimestamp'
        }, {
            'name': 'Status',
            'queryKey': 'Status.keyword'
        },
        ];
        this.filterFlag = true;
        this.selectedStartDate = '';
        this.startTime = '';
        this.selectedEndDate = '';
        this.endTime = '';
        this.startDate = '';
        this.endDate = '';
        this.lastUpdatedOnPanel = true;
        this.filterVariables = {
            from: 0,
            size: 25,
            searchValue: '',
            equipmentName: [],
            equipmentDescription: [],
            equipmentCountry: [],
            equipmentType: [],
            equipmentLength: [],
            equipmentWidth: [],
            equipmentHeight: [],
            equipmentSystemAdjustLength: [],
            equipmentSystemAdjustHeight: [],
            equipmentlastUpdatedBy: [],
            lastUpdatedFromTimeStamp: '',
            lastUpdatedToTimeStamp: '',
            equipmentStatus: []
        };
        this.noFilterData = false;
        this.showFilter = false;
        this.equipmentGroupData = [];
        this.appConfig = AppConfig.getConfig();
        this.manageEquipmentOverflowMenu = [{
            label: 'Create Equipment Group',
            url: this.appConfig.api.manageEquipmentGroup.createEquipmentGroup,
            operation: 'C'
        },
        {
            label: 'Export to Excel'
        }];
        this.manageEquipmentCreateButton = { url: this.appConfig.api.manageEquipmentGroup.createEquipmentGroup, operation: 'C' };
    }
}
