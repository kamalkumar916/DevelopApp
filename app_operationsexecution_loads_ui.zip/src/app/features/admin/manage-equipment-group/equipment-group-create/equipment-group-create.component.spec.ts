import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { EquipmentGroupCreateService } from './services/equipment-group-create.service';

import { EquipmentGroupCreateComponent } from './equipment-group-create.component';
import { configureTestSuite } from 'ng-bullet';

import { DropdownModule } from 'primeng/dropdown';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, FormArray } from '@angular/forms';
import { MenuModule } from 'primeng/menu';
import { DialogModule } from 'primeng/dialog';
import { OrderListModule } from 'primeng/orderlist';
import { TableModule } from 'primeng/table';

import { EquipmentGroupResequenceComponent } from '../equipment-group-resequence/equipment-group-resequence.component';
import { EquipmentGroupStackComponent } from '../equipment-group-stack/equipment-group-stack.component';

import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { UnitMetricsImperialPipe } from '../pipes/unit-metrics-imperial.pipe';
import { EquipmentGroupCreateUtils } from './services/equipment-group-create-utils';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { EquipmentGroupUtility } from '../services/equipment-group.utility';
import { FormValidationUtils } from 'src/app/shared/jbh-app-services/form-validation-utils';

const getEquipmentCategoryData = {
  _links: {
    profile: {
      href: ''
    },
    search: {
      href: ''
    },
    self: {
      href: ''
    }
  },
  _embedded: {
    equipmentClassifications: [{
      createTimestamp: '',
      effectiveTimestamp: '',
      equipmentClassificationCode: 'Air',
      equipmentClassificationDescription: 'AIR',
      equipmentFunctionalGroupCode: 'TrlngEquip',
      expirationTimestamp: ''
    }]
  }
};
const getCountryDetailsData = {
  _links: {
    self: {
      href: '',
      title: ''
    }
  },
  _embedded: {
    countries: [{
      countryCallingCode: '+61',
      countryCode: 'AUS',
      countryID: 10,
      countryName: 'Australia'
    }]
  },
  page: {
    number: 0,
    size: 1,
    totalElements: 1,
    totalPages: 1
  }
};
const getEquipmentValuesData = {
  _links: {
    self: {
      href: ''
    }
  },
  _embedded: {
    equipmentDimensions: [{
      createTimestamp: '',
      defaultDimensionIndicator: 'N',
      effectiveTimestamp: '',
      equipmentDimensionId: 2,
      expirationTimestamp: '',
      heightQuantity: 0,
      lengthQuantity: 28,
      tenantID: 1,
      unitOfHeightMeasurementCode: 'Inches',
      unitOfLengthMeasurementCode: 'Feet',
      unitOfWidthMeasurementCode: 'Inches',
      widthQuantity: 96
    }]
  }
};

class MockEquipmentGroupCreateService {
  constructor() { }
  getEquipmentCategory() {
    return of(getEquipmentCategoryData);
  }
  getCountryDetails() {
    return of(getCountryDetailsData);
  }
  getEquipmentDimension() {
    return of(getEquipmentValuesData);
  }
  createEquipmentGroup() {
    return throwError(null);
  }
  getEquipmentType() {
    return throwError(null);
  }
}

describe('EquipmentGroupCreateComponent', () => {
  let component: EquipmentGroupCreateComponent;
  let fixture: ComponentFixture<EquipmentGroupCreateComponent>;
  const formbuilder: FormBuilder = new FormBuilder();
  const stackingControl = formbuilder.array([formbuilder.group({
    'equipmentCategory': ['', Validators.required],
    'equipmentType': ['', Validators.required],
    'equipmentLength': [''],
    'equipmentWidth': [''],
    'equipmentHeight': [''],
    'equipmentTypeDescription': [''],
    'equipmentGroupSequenceNumber': [1],
    'stackedEquipments': formbuilder.array([formbuilder.group({
      'equipmentType': [''],
      'equipmentCategory': [''],
      'fieldName': [''],
      'equipmentLength': ['1'],
      'equipmentWidth': ['1'],
      'equipmentHeight': ['1']
    })])
  })]);
  const equipmentListForm = formbuilder.group({
    'name': ['', Validators.required],
    'description': '',
    'country': [{ value: { countryCode: '' } }, Validators.required],
    'comments': '',
    'equipmentAddFormGroup': stackingControl
  });

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, DropdownModule, BreadcrumbModule, ConfirmDialogModule, MenuModule, FormsModule,
        ReactiveFormsModule, JbhLoaderModule, DirectivesModule, DialogModule, OrderListModule, TableModule],
      providers: [UserService, AppConfigService, MessageService, ConfirmationService,
        { provide: EquipmentGroupCreateService, useClass: MockEquipmentGroupCreateService }],
      declarations: [EquipmentGroupCreateComponent,
        EquipmentGroupResequenceComponent, EquipmentGroupStackComponent, UnitMetricsImperialPipe]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onRejectRemove should set the isDisplayDialog value to be false', () => {
    component.equipmentGroupCreateModel.isDisplayDialog = true;
    component.onRejectRemove();
    expect(component.equipmentGroupCreateModel.isDisplayDialog).toBe(false);
  });

  it('removeEquipmentAddFormGroup should set the isDisplayDialog value to be true', () => {
    component.equipmentGroupCreateModel.isDisplayDialog = false;
    component.removeEquipmentAddFormGroup(1);
    expect(component.equipmentGroupCreateModel.isDisplayDialog).toBe(true);
  });

  it('onCancel should set the isDisplayDialog value to be false', () => {
    component.onCancel();
    expect(component.equipmentGroupCreateModel.isDisplayDialog).toBe(false);
  });

  it('hasChangeDeteted should return false', () => {
    expect(component.hasChangeDeteted()).toBeFalsy();
  });

  it('selectedEquipment should call the spy thresholdExceedWarning with parameter noChanges', () => {
    spyOn(component, 'removeEquipmentAddForm');
    spyOn(component, 'getEquipmentUpdate');
    spyOn(component, 'thresholdExceedWarning');
    const event = formbuilder.group({
      'equipmentGroupSequenceNumber': [1],
      'stackedEquipments': formbuilder.array([])
    });
    component.equipmentGroupCreateModel.equipmentListForm.controls['equipmentAddFormGroup']['controls'][0]
      .get('stackedEquipments').patchValue([{
        equipmentType: '',
        equipmentCategory: '',
        fieldName: ''
      }]);
    component.equipmentGroupCreateModel.stackingControl = stackingControl['controls'][0] as FormArray;
    component.equipmentGroupCreateModel.systemAdjustedLength = '';
    component.selectedEquipment(event);
    expect(component.thresholdExceedWarning).toHaveBeenCalledWith('noChanges');
  });

  it('selectedEquipment should call the spy getEquipmentUpdate', () => {
    spyOn(component, 'removeEquipmentAddForm');
    spyOn(component, 'getEquipmentUpdate');
    spyOn(component, 'thresholdExceedWarning');
    const event = formbuilder.group({
      'equipmentGroupSequenceNumber': [1],
      'stackedEquipments': formbuilder.array([])
    });
    component.equipmentGroupCreateModel.equipmentListForm.controls['equipmentAddFormGroup']['controls'][0]
      .get('stackedEquipments').patchValue([{
        equipmentType: '',
        equipmentCategory: '',
        fieldName: ''
      }]);
    component.equipmentGroupCreateModel.stackingControl = stackingControl['controls'][0] as FormArray;
    component.equipmentGroupCreateModel.systemAdjustedLength = '---';
    component.selectedEquipment(event);
    expect(component.getEquipmentUpdate).toHaveBeenCalled();
  });

  it('onSelectEquipmentCategory should call the spy resetEquipmentValues', () => {
    spyOn(EquipmentGroupCreateUtils, 'resetEquipmentArray');
    spyOn(component, 'setEquipmentType');
    spyOn(component, 'resetEquipmentValues');
    spyOn(component, 'selectEquipmentValues');
    spyOn(component, 'getEquipmentType');
    component.onSelectEquipmentCategory('', 0, true);
    expect(component.resetEquipmentValues).toHaveBeenCalled();
  });

  it('onSelectEquipmentType should call the spy selectEquipmentValues', () => {
    spyOn(component, 'getEquipmentValues');
    spyOn(component, 'selectEquipmentValues');
    spyOn(component, 'resetEquipmentValues');
    component.equipmentGroupCreateModel.equipmentType = [
      [{
        label: '',
        value: '',
        styleClass: '',
        icon: '',
        title: '',
        disabled: true
      }]
    ];
    component.onSelectEquipmentType('', 0, true);
    expect(component.selectEquipmentValues).toHaveBeenCalled();
  });

  it('resetEquipmentValues should call the spy resetEquipment', () => {
    spyOn(EquipmentGroupCreateUtils, 'resetEquipment');
    component.resetEquipmentValues(0);
    expect(EquipmentGroupCreateUtils.resetEquipment).toHaveBeenCalled();
  });

  it('selectEquipmentValues should call the spy thresholdExceedWarning', () => {
    spyOn(component, 'thresholdExceedWarning');
    spyOn(EquipmentGroupCreateUtils, 'generateRequestObject').and.returnValue({
      standardEquipmentGroupMembers: []
    });
    spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentLengthValues').and.returnValue('');
    spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentWidthValues').and.returnValue('');
    spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentHeightValues').and.returnValue('');
    component.selectEquipmentValues(0, true);
    expect(component.thresholdExceedWarning).toHaveBeenCalled();
  });

  it('selectEquipmentValues should call the spy generateRequestObject', () => {
    spyOn(component, 'thresholdExceedWarning');
    spyOn(EquipmentGroupCreateUtils, 'generateRequestObject').and.returnValue({
      standardEquipmentGroupMembers: []
    });
    spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentLengthValues').and.returnValue('');
    spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentWidthValues').and.returnValue('');
    spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentHeightValues').and.returnValue('');
    component.equipmentGroupCreateModel.equipmentListForm
      .get('equipmentAddFormGroup')['controls'][0].get('stackedEquipments').insert(0, formbuilder.group({
        'equipmentLength': ['1'],
        'equipmentWidth': ['1'],
        'equipmentHeight': ['1']
      }));
    component.selectEquipmentValues('0.0', true);
    expect(EquipmentGroupCreateUtils.generateRequestObject).toHaveBeenCalled();
  });

  it('removeOverviewValues should call the spy setEquipmentType', () => {
    spyOn(component, 'setEquipmentType');
    spyOn(EquipmentGroupCreateUtils, 'generateRequestObject').and.returnValue({
      standardEquipmentGroupMembers: []
    });
    spyOn(EquipmentGroupCreateUtils, 'removeOverviewValue');
    component.equipmentGroupCreateModel.lengthArray = [''];
    component.removeOverviewValues(0);
    expect(component.setEquipmentType).toHaveBeenCalled();
  });

  it('afterResequence should call the spy getEquipmentType', () => {
    spyOn(component, 'getEquipmentType');
    const event = formbuilder.group({
      'equipmentCategory': [''],
      'equipmentType': [''],
      'equipmentLength': [''],
      'equipmentWidth': [''],
      'equipmentHeight': [''],
      'equipmentTypeDescription': [''],
      'equipmentGroupSequenceNumber': [1],
      'stackedEquipments': formbuilder.array([formbuilder.group({
        'equipmentType': [''],
        'equipmentCategory': [''],
        'fieldName': [''],
        'equipmentLength': ['1'],
        'equipmentWidth': ['1'],
        'equipmentHeight': ['1']
      })])
    });
    component.afterResequence([event]);
    expect(component.getEquipmentType).toHaveBeenCalled();
  });

  it('onEquipmentAddFormGroup should set value to equipmentType array', () => {
    spyOn(EquipmentGroupCreateUtils, 'resetEquipmentArray');
    spyOn(component, 'getEquipmentUpdate');
    spyOn(component, 'setSequenceNumber');
    component.equipmentGroupCreateModel.equipmentCategoryValue = [''];
    component.equipmentGroupCreateModel.equipmentType = [
      [{
        label: '',
        value: '',
        styleClass: '',
        icon: '',
        title: '',
        disabled: true
      }]
    ];
    component.onEquipmentAddFormGroup(0);
    expect(component.equipmentGroupCreateModel.equipmentType[1]).toEqual([]);
  });

  it('onAcceptRemove should set the isDisplayDialog value to false', () => {
    spyOn(EquipmentGroupCreateUtils, 'resetEquipmentArray');
    spyOn(component, 'getEquipmentUpdate');
    spyOn(component, 'setSequenceNumber');
    spyOn(component, 'setEquipmentType');
    spyOn(component, 'removeOverviewValues');
    component.equipmentGroupCreateModel.equipmentCategoryValue = [''];
    component.equipmentGroupCreateModel.equipmentType = [];
    component.equipmentGroupCreateModel.removeIndex = 0;
    component.onAcceptRemove();
    expect(component.equipmentGroupCreateModel.isDisplayDialog).toBeFalsy();
  });

  it('menuClick should set menuItems value equal to []', () => {
    spyOn(EquipmentGroupCreateUtils, 'generateMenuItems').and.returnValue([]);
    component.menuClick({}, 0, 'Equipment Menu');
    expect(component.equipmentGroupCreateModel.menuItems).toEqual([]);
  });

  it('menuClick should set stackedMenuItems value equal to []', () => {
    spyOn(EquipmentGroupCreateUtils, 'generateStackedMenuItems').and.returnValue([]);
    component.menuClick({}, 0, 'Stacked Equipment Menu');
    expect(component.equipmentGroupCreateModel.stackedMenuItems).toEqual([]);
  });

  it('addStackedEquipment should set equipmentCategory value to empty string', () => {
    component.addStackedEquipment(0);
    expect(component.equipmentGroupCreateModel.stackingControl.controls['equipmentCategory'].value).toEqual('');
  });

  it('addUnderStackedEquipment shoild call the spy getEquipmentUpdate', () => {
    spyOn(component, 'getEquipmentUpdate');
    component.addUnderStackedEquipment(0, 0);
    expect(component.getEquipmentUpdate).toHaveBeenCalled();
  });

  it('thresholdExceedWarning should call the spy onSelectEquipmentLength', () => {
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.accept();
      confirmation.reject();
    });
    spyOn(component, 'onSelectEquipmentLength');
    component.thresholdExceedWarning(0, 'equipmentLength');
    expect(component.onSelectEquipmentLength).toHaveBeenCalled();
  });

  it('thresholdExceedWarning should call the spy onSelectEquipmentWidth', () => {
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.reject();
    });
    spyOn(component, 'onSelectEquipmentWidth');
    component.thresholdExceedWarning(0, 'equipmentWidth');
    expect(component.onSelectEquipmentWidth).toHaveBeenCalled();
  });

  it('thresholdExceedWarning should call the spy onSelectEquipmentHeight', () => {
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.reject();
    });
    spyOn(component, 'onSelectEquipmentHeight');
    component.thresholdExceedWarning(0, 'equipmentHeight');
    expect(component.onSelectEquipmentHeight).toHaveBeenCalled();
  });

  it('removeStackedEquipment should call the spy setEquipmentType', () => {
    spyOn(component, 'getEquipmentUpdate');
    spyOn(component, 'setEquipmentType');
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.accept();
    });
    component.equipmentGroupCreateModel.equipmentListForm
      .get('equipmentAddFormGroup')['controls'][0].get('stackedEquipments').insert(0, formbuilder.group({
        'equipmentLength': ['1'],
        'equipmentWidth': ['1'],
        'equipmentHeight': ['1']
      }));
    component.removeStackedEquipment(0, 0);
    expect(component.setEquipmentType).toHaveBeenCalled();
  });

  it('onValueChange should set unitOfMeasure equal to unit', () => {
    component.onValueChange('unit');
    expect(component.equipmentGroupCreateModel.unitOfMeasure).toEqual('unit');
  });

  it('getEquipmentCategory should set equipmentCategory to be an empty array', () => {
    const equipmentGroupCreateService: EquipmentGroupCreateService = TestBed.get(EquipmentGroupCreateService);
    spyOn(equipmentGroupCreateService, 'getEquipmentCategory').and.returnValue(throwError(null));
    component.getEquipmentCategory();
    expect(component.equipmentGroupCreateModel.equipmentCategory.length).toEqual(0);
  });

  it('getCountryDetails should set countryDetails  to be an empty array', () => {
    const equipmentGroupCreateService: EquipmentGroupCreateService = TestBed.get(EquipmentGroupCreateService);
    spyOn(equipmentGroupCreateService, 'getCountryDetails').and.returnValue(throwError(null));
    component.getCountryDetails();
    expect(component.equipmentGroupCreateModel.countryDetails.length).toEqual(0);
  });

  it('getEquipmentType should set isLoading value to be false', () => {
    component.getEquipmentType('', 0);
    expect(component.equipmentGroupCreateModel.isLoading).toBeFalsy();
  });

  it('getEquipmentValues should call the spy getEquipmentDetails', () => {
    spyOn(EquipmentGroupCreateUtils, 'getEquipmentDetails');
    component.getEquipmentValues('equipmentLength', 0);
    expect(EquipmentGroupCreateUtils.getEquipmentDetails).toHaveBeenCalled();
  });

  it('getEquipmentValues should set the isLoading value to be false', () => {
    const equipmentGroupCreateService: EquipmentGroupCreateService = TestBed.get(EquipmentGroupCreateService);
    spyOn(equipmentGroupCreateService, 'getEquipmentDimension').and.returnValue(throwError(null));
    component.getEquipmentValues('equipmentLength', 0);
    expect(component.equipmentGroupCreateModel.isLoading).toBeFalsy();
  });

  it('onCreate should call the spy validateAllFormFields', () => {
    spyOn(FormValidationUtils, 'validateAllFormFields');
    spyOn(EquipmentGroupUtility, 'validateEquipmentValues');
    const toast: MessageService = TestBed.get(MessageService);
    spyOn(toast, 'add');
    component.equipmentGroupCreateModel.equipmentListForm.patchValue({
      name: 'form',
      country: { countryCode: '' },
      equipmentAddFormGroup: [{
        'equipmentCategory': 'equipment',
        'equipmentType': 'type'
      }]
    });
    component.onCreate();
    expect(FormValidationUtils.validateAllFormFields).toHaveBeenCalled();
  });
  it('onCreate should call the spy createEquipmentGroup', () => {
    spyOn(FormValidationUtils, 'validateAllFormFields');
    spyOn(EquipmentGroupUtility, 'validateEquipmentValues');
    spyOn(component, 'createEquipmentGroup');
    component.equipmentGroupCreateModel.equipmentListForm.patchValue({
      name: 'form',
      country: { countryCode: '' },
      equipmentAddFormGroup: [{
        'equipmentCategory': 'equipment',
        'equipmentType': 'type'
      }]
    });
    component.onCreate();
    component.equipmentGroupCreateModel.equipmentListForm
      .get('equipmentAddFormGroup')['controls'][0].get('stackedEquipments').insert(0, formbuilder.group({
        'equipmentLength': ['1'],
        'equipmentWidth': ['1'],
        'equipmentHeight': ['1']
      }));
    component.onCreate();
    expect(component.createEquipmentGroup).toHaveBeenCalled();
  });
});
