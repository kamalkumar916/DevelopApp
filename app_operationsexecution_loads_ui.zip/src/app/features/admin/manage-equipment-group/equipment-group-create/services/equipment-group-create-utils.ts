import { FormGroup, FormArray, Validators } from '@angular/forms';
import { EquipmentGroupCreateComponent } from '../equipment-group-create.component';
import { UnitMetricsImperialPipe } from '../../pipes/unit-metrics-imperial.pipe';
import { EquipmentGroupUtility } from '../../services/equipment-group.utility';
import * as lodashutils from 'lodash';

export class EquipmentGroupCreateUtils {
    static getEquipmentCategory(data, equipmentGroupCreateModel) {
        equipmentGroupCreateModel.equipmentCategory = data._embedded.equipmentClassifications.map((equipmentCategory) => {
            return {
                label: equipmentCategory.equipmentClassificationDescription,
                value: equipmentCategory.equipmentClassificationCode
            };
        });
    }
    static getCountryDetails(data, equipmentGroupCreateModel) {
        equipmentGroupCreateModel.countryDetails = data._embedded.countries.map(countries => {
            return {
                label: countries.countryName,
                value: {
                    countryName: countries.countryName,
                    countryCode: countries.countryCode
                }
            };
        });
    }
    static getEquipmentType(data, equipmentGroupCreateModel, index) {
        equipmentGroupCreateModel.equipmentType[index] = data._embedded.equipmentTypes.map(equipmentTypes => {
            return {
                label: equipmentTypes.equipmentTypeDescription,
                value: equipmentTypes.equipmentTypeCode
            };
        });
    }
    static getEquipmentDetails(data, equipmentItem, index, equipmentDimentioName: string) {
        const framedEquipmentDetails = data._embedded.equipmentDimensions
            .map(dimensionsValue => {
                return {
                    label: this.frameDimensionValue(dimensionsValue, equipmentDimentioName),
                    value: this.frameDimensionValue(dimensionsValue, equipmentDimentioName)
                };
            }).filter(value => value);
        equipmentItem[index] = framedEquipmentDetails ? lodashutils.uniqBy(framedEquipmentDetails, 'value') : [];
    }
    static frameDimensionValue(value: any, dimensionName: string): string {
        let framedValue = '';
        if (value) {
            const dimensionValue = value[`${dimensionName.toLowerCase()}Quantity`];
            let dimensionUnit = value[`unitOf${dimensionName}MeasurementCode`];
            dimensionUnit = this.getDimensionUnit(dimensionUnit);
            framedValue += dimensionValue;
            framedValue += dimensionUnit ? ` ${dimensionUnit}` : '';
            framedValue = dimensionUnit === 'in' && dimensionValue ? EquipmentGroupUtility.feetInchesFormat(dimensionValue) : framedValue;
        }
        return framedValue;
    }
    static getDimensionUnit(dimensionUnit) {
        return dimensionUnit ? dimensionUnit.toLowerCase() === 'feet' ? 'ft' :
            dimensionUnit.toLowerCase() === 'inches' ? 'in' : dimensionUnit : '';
    }
    static generateRequestObject(equipmentListForm, equipmentCreateModel, isCreate = false) {
        equipmentCreateModel.requestObject.equipmentGroupName = equipmentListForm.controls.name.value;
        equipmentCreateModel.requestObject.equipmentGroupDescription = equipmentListForm.controls.description.value;
        equipmentCreateModel.requestObject.equipmentGroupComment = equipmentListForm.controls.comments.value;
        equipmentCreateModel.requestObject.countryCode = equipmentListForm.controls.country.value.value.countryCode;
        equipmentCreateModel.requestObject.countryDescription =
            (equipmentCreateModel.requestObject.countryCode === equipmentCreateModel.defaultCountry.value)
                ? equipmentCreateModel.defaultCountry.label : equipmentListForm.controls.country.value.value.countryName;
        equipmentCreateModel.requestObject.groupOverviewDetails = {
            'type': equipmentCreateModel.type,
            'length': (equipmentCreateModel.cumulativeLength) ? equipmentCreateModel.cumulativeLength : '---',
            'lengthValue': (this.getCumulativeValues(equipmentCreateModel.cumulativeLength)) ?
                this.getCumulativeValues(equipmentCreateModel.cumulativeLength) : 0,
            'width': (equipmentCreateModel.cumulativeWidth) ? equipmentCreateModel.cumulativeWidth : '---',
            'widthValue': (this.getCumulativeValues(equipmentCreateModel.cumulativeWidth)) ?
                this.getCumulativeValues(equipmentCreateModel.cumulativeWidth) : 0,
            'height': (equipmentCreateModel.cumulativeHeight) ? equipmentCreateModel.cumulativeHeight : '---',
            'heightValue': (this.getCumulativeValues(equipmentCreateModel.cumulativeHeight)) ?
                (this.getCumulativeValues(equipmentCreateModel.cumulativeHeight)) : 0,
            'systemAdjustedLength': this.getAdjustedLengthValues(equipmentCreateModel.systemAdjustedLength),
            'systemAdjustedHeight': this.getAdjustedLengthValues(equipmentCreateModel.systemAdjustedHeight)
        };
        equipmentCreateModel.requestObject.standardEquipmentGroupMembers = [];
        equipmentCreateModel.requestObject.standardEquipmentGroupMembers = equipmentListForm.controls.
            equipmentAddFormGroup.controls.map((equipmentAddFormGroup, i) => {
                return {
                    'equipmentGroupSequenceNumber': i + 1,
                    'equipmentClassificationCode': equipmentListForm.controls.equipmentAddFormGroup.controls[i].
                        controls.equipmentCategory.value,
                    'equipmentTypeCode': equipmentListForm.controls.equipmentAddFormGroup.controls[i].controls.equipmentType.value,
                    'lengthSpecificationCode': (equipmentListForm.controls.equipmentAddFormGroup.controls[i].controls.
                        equipmentLength.value) ? this.checkCumulativeValues(equipmentListForm.controls.equipmentAddFormGroup.
                            controls[i].controls.equipmentLength.value, isCreate) : null,
                    'widthSpecificationCode': (equipmentListForm.controls.equipmentAddFormGroup.controls[i].controls.
                        equipmentWidth.value) ? this.checkCumulativeValues(equipmentListForm.controls.equipmentAddFormGroup.controls[i].
                            controls.equipmentWidth.value, isCreate) : null,
                    'heightSpecificationCode': (equipmentListForm.controls.equipmentAddFormGroup.controls[i].
                        controls.equipmentHeight.value) ? this.checkCumulativeValues(equipmentListForm.controls.
                            equipmentAddFormGroup.controls[i].controls.equipmentHeight.value, isCreate) : null,
                    'stackedEquipments': this.generateStackedEquipmentDetails(equipmentListForm.controls.equipmentAddFormGroup
                        .controls[i].controls.stackedEquipments, i + 1, isCreate)
                };
            });
        return equipmentCreateModel.requestObject;
    }
    static checkCumulativeValues(dimensionValue: string, isCreateCall: boolean) {
        return isCreateCall ? this.getCumulativeValues(dimensionValue) : dimensionValue;
    }
    static getAdjustedLengthValues(adjustedaValue) {
        const systemAdjustedValue = this.getCumulativeValues(adjustedaValue);
        return {
            value: (systemAdjustedValue) ? systemAdjustedValue : 0,
            description: (adjustedaValue) ? adjustedaValue : '---'
        };
    }
    static getCumulativeValues(adjustedValue): number | undefined {
        if (adjustedValue) {
            if ((adjustedValue.toLowerCase().includes('ft')) && (adjustedValue.toLowerCase().includes('in'))) {
                const feetInch = adjustedValue.split(' ');
                return (parseInt(feetInch[0], 10) * 12) + parseInt(feetInch[2], 10);
            } else if (adjustedValue.toLowerCase().includes('in')) {
                return parseInt(adjustedValue, 10);
            } else {
                return parseInt(adjustedValue, 10) * 12;
            }
        }
    }
    static initializeFormGroup(fb, index): FormGroup {
        return fb.group({
            'equipmentCategory': ['', Validators.required],
            'equipmentType': ['', Validators.required],
            'equipmentLength': [''],
            'equipmentWidth': [''],
            'equipmentHeight': [''],
            'equipmentTypeDescription': [''],
            'equipmentGroupSequenceNumber': [index + 1],
            'stackedEquipments': fb.array([])
        });
    }
    static generateStackedEquipmentDetails(stackedEquipments, sequenceNumber: number, isCreate: boolean): FormArray {
        if (stackedEquipments.controls && stackedEquipments.controls.length > 0) {
            return stackedEquipments.controls.map((stackRequest, index) => {
                return {
                    equipmentGroupSequenceNumber: sequenceNumber,
                    equipmentClassificationCode: stackRequest.controls.equipmentCategory.value,
                    equipmentClassificationDescription: stackRequest.controls.equipmentCategory.value,
                    equipmentTypeCode: stackRequest.controls.equipmentType.value,
                    equipmentTypeDescription: stackRequest.controls.equipmentType.value,
                    lengthSpecificationCode: (stackRequest.controls.equipmentLength.value)
                        ? this.checkCumulativeValues(stackRequest.controls.equipmentLength.value, isCreate) : null,
                    widthSpecificationCode: (stackRequest.controls.equipmentWidth.value)
                        ? this.checkCumulativeValues(stackRequest.controls.equipmentWidth.value, isCreate) : null,
                    heightSpecificationCode: (stackRequest.controls.equipmentHeight.value)
                        ? this.checkCumulativeValues(stackRequest.controls.equipmentHeight.value, isCreate) : null,
                    stackedEquipments: null
                };
            });
        } else {
            return null;
        }
    }
    static generateMenuItems(index: number, EquipmentCreateComponent: EquipmentGroupCreateComponent) {
        const equipmentLengthFlag =
            (EquipmentCreateComponent.equipmentGroupCreateModel.equipmentListForm.get('equipmentAddFormGroup')['controls'].length > 1);
        if (index === 0 && !equipmentLengthFlag) {
            return [
                {
                    label: 'Add Equipment',
                    command: onclick => {
                        EquipmentCreateComponent.onEquipmentAddFormGroup(index);
                    }
                }
            ];
        } else {
            return [
                {
                    label: 'Add Equipment',
                    command: onclick => {
                        EquipmentCreateComponent.onEquipmentAddFormGroup(index);
                    }
                },
                {
                    label: 'Stack Equipment',
                    command: onclick => {
                        EquipmentCreateComponent.addStackedEquipment(index);
                    }
                },
                {
                    label: 'Remove Equipment',
                    command: onclick => {
                        EquipmentCreateComponent.removeEquipmentAddFormGroup(index);
                    }
                }
            ];
        }
    }
    static generateStackedMenuItems(index: number, pIndex: number, EquipmentCreateComponent: EquipmentGroupCreateComponent) {
        return [
            {
                label: 'Add Stacked Equipment',
                command: onclick => {
                    EquipmentCreateComponent.addUnderStackedEquipment(index, pIndex);
                }
            },
            {
                label: 'UnStack Equipment',
                command: onclick => {
                    EquipmentCreateComponent.addUnStackedEquipment(index, pIndex);
                }
            },
            {
                label: 'Remove Equipment',
                command: onclick => {
                    EquipmentCreateComponent.removeStackedEquipment(index, pIndex);
                }
            }
        ];
    }
    static stackEquipmentData(equipmentAddFormGroup, index, equipmentCategory) {
        return {
            'inputOrderList': equipmentAddFormGroup,
            'dialogVisible': true,
            'index': index,
            'stackOnCategory': equipmentCategory
        };
    }
    static onResequenceEquipment(equipmentAddFormGroup) {
        return {
            'inputOrderList': equipmentAddFormGroup,
            'dialogVisible': true
        };
    }
    static getToastMessageData(response?: number, value?: string) {
        let toastData = {};
        switch (response) {
            case 200:
                toastData = {
                    severity: 'success',
                    summary: 'Success',
                    detail: `${value} Group was created successfully`
                };
                break;
            case 409:
                toastData = {
                    severity: 'error',
                    summary: 'Duplicate Equipment',
                    detail: 'An equipment group has already been set for this combination of equipment pair'
                };
                break;
            case 400:
                toastData = {
                    severity: 'error',
                    summary: 'Duplicate Group Name',
                    detail: 'Group Name Already Available'
                };
                break;
            default:
                toastData = {
                    severity: 'error',
                    summary: 'Equipment Group Error',
                    detail: 'Equipment Group must have more than one equipment'
                };
                break;
        }
        return toastData;
    }
    static resetEquipment(index: string | number, equipmentValue: string, equipmentAddForm) {
        if (index.toString().split('.').length > 1) {
            const formIndex = index.toString().split('.');
            equipmentAddForm[formIndex[0]].controls['stackedEquipments']['controls'][formIndex[1]]['controls'][equipmentValue].setValue('');
            equipmentAddForm[formIndex[0]].controls['stackedEquipments']['controls']
            [formIndex[1]]['controls'][equipmentValue].setValidators([]);
            equipmentAddForm[formIndex[0]].controls['stackedEquipments']['controls']
            [formIndex[1]]['controls'][equipmentValue].updateValueAndValidity();
        } else {
            equipmentAddForm[index].controls[equipmentValue].setValue('');
            equipmentAddForm[index].controls[equipmentValue].setValidators([]);
            equipmentAddForm[index].controls[equipmentValue].updateValueAndValidity();
        }
        return null;
    }
    static setDefaultCountry(equipmentGroupCreateModel) {
        if (equipmentGroupCreateModel.equipmentListForm) {
            equipmentGroupCreateModel.equipmentListForm.get('country').patchValue({
                label: 'USA',
                value: {
                    countryName: 'USA',
                    countryCode: 'USA'
                }
            });
        }
        return null;
    }
    static resetEquipmentArray(index: string | number, equipmentGroupCreateModel) {
        equipmentGroupCreateModel.equipmentLength[index] = [];
        equipmentGroupCreateModel.equipmentWidth[index] = [];
        equipmentGroupCreateModel.equipmentHeight[index] = [];
        return null;
    }
    static setEquipmentTypeIndex(equipmentListForm, stackedIndex: string | number) {
        const formIndex = stackedIndex.toString().split('.');
        return equipmentListForm.controls
            .equipmentAddFormGroup.value[formIndex[0]].stackedEquipments[formIndex[1]].equipmentType;

    }
    static calculateEquipmentValues(standardEquipmentGroupMembers, equipmentType) {
        const SpecificationCodeDimension =
            new UnitMetricsImperialPipe().transform(standardEquipmentGroupMembers, 'lengthWidthHeigthCalculation');
        return new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', equipmentType);

    }
    static calculateEquipmentLengthValues(standardEquipmentGroupMembers, equipmentGroupCreateModel) {
        const lengthValues = this.calculateEquipmentValues(standardEquipmentGroupMembers, 'length');
        equipmentGroupCreateModel.cumulativeLength =
            EquipmentGroupUtility.feetInchesGroupOverview(lengthValues);
        return EquipmentGroupUtility.systemAdjustedLength(equipmentGroupCreateModel.cumulativeLength);
    }
    static calculateEquipmentWidthValues(standardEquipmentGroupMembers, equipmentCreateModel) {
        const widthValues = this.calculateEquipmentValues(standardEquipmentGroupMembers, 'width');
        equipmentCreateModel.cumulativeWidth =
            EquipmentGroupUtility.maxWidthGroupOverview(widthValues);
        return EquipmentGroupUtility.systemAdjustedWidth(equipmentCreateModel.cumulativeWidth);
    }
    static calculateEquipmentHeightValues(standardEquipmentGroupMembers, equipmentCreateModel) {
        const heightValues = this.calculateEquipmentValues(standardEquipmentGroupMembers, 'height');
        equipmentCreateModel.cumulativeHeight = EquipmentGroupUtility.maxWidthGroupOverview(heightValues);
        return EquipmentGroupUtility.systemAdjustedHeight(equipmentCreateModel.cumulativeHeight);
    }
    static removeOverviewValue(standardEquipmentGroupMembers, index, equipmentGroupCreateModel) {
        const SpecificationCodeDimension =
            new UnitMetricsImperialPipe().transform(standardEquipmentGroupMembers, 'lengthWidthHeigthCalculation');
        equipmentGroupCreateModel.cumulativeLength = EquipmentGroupUtility.
            feetInchesGroupOverview(new UnitMetricsImperialPipe()
                .transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'length'));
        equipmentGroupCreateModel.widthArray.splice(index, 1);
        equipmentGroupCreateModel.cumulativeWidth = EquipmentGroupUtility.
            maxWidthGroupOverview((new UnitMetricsImperialPipe()
                .transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'width')));
        lodashutils.pullAt(equipmentGroupCreateModel.heightArray, index);
        equipmentGroupCreateModel.cumulativeHeight = EquipmentGroupUtility.
            maxWidthGroupOverview((new UnitMetricsImperialPipe()
                .transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'height')));
        equipmentGroupCreateModel.systemAdjustedLength =
            EquipmentGroupUtility.systemAdjustedLength(equipmentGroupCreateModel.cumulativeLength);
        equipmentGroupCreateModel.systemAdjustedWidth =
            EquipmentGroupUtility.systemAdjustedWidth(equipmentGroupCreateModel.cumulativeWidth);
        equipmentGroupCreateModel.systemAdjustedHeight =
            EquipmentGroupUtility.systemAdjustedHeight(equipmentGroupCreateModel.cumulativeHeight);
        return null;
    }
}
