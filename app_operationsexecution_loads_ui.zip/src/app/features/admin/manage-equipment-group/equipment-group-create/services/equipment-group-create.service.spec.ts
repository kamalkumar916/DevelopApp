import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { EquipmentGroupCreateService } from './equipment-group-create.service';
import { configureTestSuite } from 'ng-bullet';

describe('EquipmentGroupCreateService', () => {
  let service: EquipmentGroupCreateService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        EquipmentGroupCreateService,
        AppConfigService
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.get(EquipmentGroupCreateService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getEquipmentCategory expected calls', () => {
    service.getEquipmentCategory().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentCategory);
    expect(req.request.method).toEqual('GET');
  });

  it('getCountryDetails expected calls', () => {
    service.getCountryDetails().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getCountryDetails);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentType expected calls', () => {
    const equipmentCategoryCode = '';
    service.getEquipmentType(equipmentCategoryCode).subscribe();
    const url = `${service.endpoint.getEquipmentType}?equipmentClassificationCode=${equipmentCategoryCode}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentDimension expected calls', () => {
    const equipmentCategory = '';
    const equipmentType = '';
    service.getEquipmentDimension(equipmentCategory, equipmentType).subscribe();
    const url = `${service.endpoint.
      getEquipmentDimension}?equipmentClassificationCode=${equipmentCategory}&equipmentTypeCode=${equipmentType}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('createEquipmentGroup expected calls', () => {
    const dd = '';
    service.createEquipmentGroup(dd).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.createEquipmentGroup);
    expect(req.request.method).toEqual('POST');
  });


});

