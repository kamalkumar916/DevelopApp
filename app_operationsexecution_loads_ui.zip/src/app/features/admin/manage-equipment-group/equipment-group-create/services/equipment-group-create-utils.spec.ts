import { EquipmentGroupCreateUtils } from '../services/equipment-group-create-utils';
import { EquipmentGroupUtility } from '../../services/equipment-group.utility';
import { FormBuilder } from '@angular/forms';

describe('EquipmentGroupCreateUtils', () => {
    const fb: FormBuilder = new FormBuilder();
    it('should be created', () => {
        expect(EquipmentGroupCreateUtils).toBeTruthy();
    });

    it('getEquipmentCategory expected equipmentCategory equal to 1', () => {
        const data = {
            _embedded: {
                equipmentClassifications: [{
                    equipmentClassificationDescription: null,
                    equipmentClassificationCode: null
                }]
            }
        };
        const equipmentGroupCreateModel = {
            equipmentCategory: []
        };
        const returnvalue = EquipmentGroupCreateUtils.getEquipmentCategory(data, equipmentGroupCreateModel);
        expect(equipmentGroupCreateModel.equipmentCategory.length).toEqual(1);
    });
    it('getCountryDetails expected countryDetails equal to 1', () => {
        const data = {
            _embedded: {
                countries: [{
                    countryName: '',
                    countryCode: '',
                }]
            }
        };
        const equipmentGroupCreateModel = {
            countryDetails: [],
        };
        const call = EquipmentGroupCreateUtils.getCountryDetails(data, equipmentGroupCreateModel);
        expect(equipmentGroupCreateModel.countryDetails.length).toEqual(1);
    });

    it('getEquipmentType expected equipmentType equal to 0', () => {
        const data = {
            _embedded: {
                equipmentTypes: [{
                    equipmentTypeDescription: '',
                    equipmentTypeCode: '',
                }]
            }
        };
        const equipmentGroupCreateModel = {
            equipmentType: [],
        };
        const call = EquipmentGroupCreateUtils.getEquipmentType(data, equipmentGroupCreateModel, 'test');
        expect(equipmentGroupCreateModel.equipmentType.length).toEqual(0);
    });

    it('getEquipmentDetails expected framedValue equal to 0', () => {
        spyOn(EquipmentGroupCreateUtils, 'frameDimensionValue');
        const data = {
            _embedded: {
                equipmentDimensions: [{
                    heightQuantity: null,
                    lengthQuantity: null,
                    unitOfHeightMeasurementCode: '',
                    unitOfLengthMeasurementCode: '',
                    unitOfWidthMeasurementCode: '',
                    widthQuantity: null
                }]
            }
        };
        const equipmentItem = [[{ value: '' }]];
        const call = EquipmentGroupCreateUtils.getEquipmentDetails(data, equipmentItem, '0', 'Height');
        expect(EquipmentGroupCreateUtils.frameDimensionValue).toHaveBeenCalled();
    });

    it('frameDimensionValue return value should be defined', () => {
        const test = {
            feet: []
        };
        spyOn(EquipmentGroupCreateUtils, 'getDimensionUnit');
        const call = EquipmentGroupCreateUtils.frameDimensionValue('test', 'feet');
        expect(call).toBeDefined();
    });

    it('frameDimensionValue should call the spy EquipmentGroupCreateUtils', () => {
        spyOn(EquipmentGroupUtility, 'feetInchesFormat');
        spyOn(EquipmentGroupCreateUtils, 'getDimensionUnit').and.returnValue('in');
        const value = {
            heightQuantity: 2,
            lengthQuantity: null,
            unitOfHeightMeasurementCode: 'in',
            unitOfLengthMeasurementCode: '',
            unitOfWidthMeasurementCode: '',
            widthQuantity: null
        };
        EquipmentGroupCreateUtils.frameDimensionValue(value, 'Height');
        expect(EquipmentGroupCreateUtils.getDimensionUnit).toHaveBeenCalled();
    });

    it('getDimensionUnit should return ft', () => {
        const call = EquipmentGroupCreateUtils.getDimensionUnit('feet');
        expect(call).toEqual('ft');
    });

    it('getDimensionUnit should return in', () => {
        const call = EquipmentGroupCreateUtils.getDimensionUnit('inches');
        expect(call).toEqual('in');
    });

    it('getDimensionUnit should return meter', () => {
        const call = EquipmentGroupCreateUtils.getDimensionUnit('meter');
        expect(call).toEqual('meter');
    });

    it('getDimensionUnit should return empty string', () => {
        const call = EquipmentGroupCreateUtils.getDimensionUnit('');
        expect(call).toEqual('');
    });

    it('checkCumulativeValues should be defined', () => {
        spyOn(EquipmentGroupCreateUtils, 'getCumulativeValues');
        const call = EquipmentGroupCreateUtils.checkCumulativeValues('', false);
        expect(call).toEqual('');
    });

    it('checkCumulativeValues should call the spy getCumulativeValues', () => {
        spyOn(EquipmentGroupCreateUtils, 'getCumulativeValues');
        const call = EquipmentGroupCreateUtils.checkCumulativeValues('', true);
        expect(EquipmentGroupCreateUtils.getCumulativeValues).toHaveBeenCalled();
    });

    it('getAdjustedLengthValues should return an object with value property equal to 0', () => {
        spyOn(EquipmentGroupCreateUtils, 'getCumulativeValues').and.returnValue(0);
        const call = EquipmentGroupCreateUtils.getAdjustedLengthValues('');
        expect(call.value).toEqual(0);
    });

    it('getAdjustedLengthValues should return an object with value property equal to 1', () => {
        spyOn(EquipmentGroupCreateUtils, 'getCumulativeValues').and.returnValue(1);
        const returnValue = EquipmentGroupCreateUtils.getAdjustedLengthValues('1');
        expect(returnValue.value).toEqual(1);
    });

    it('getCumulativeValues should return 1', () => {
        const returnValue = EquipmentGroupCreateUtils.getCumulativeValues('1 in');
        expect(returnValue).toEqual(1);
    });

    it('getCumulativeValues should return 12', () => {
        const returnValue = EquipmentGroupCreateUtils.getCumulativeValues('1');
        expect(returnValue).toEqual(12);
    });

    it('getCumulativeValues should return 13', () => {
        const returnValue = EquipmentGroupCreateUtils.getCumulativeValues('1 ft 1 in');
        expect(returnValue).toEqual(13);
    });

    it('stackEquipmentData should return object', () => {
        const call = EquipmentGroupCreateUtils.stackEquipmentData('', '', '');
        expect(call).toEqual({
            'inputOrderList': '',
            'dialogVisible': true,
            'index': '',
            'stackOnCategory': ''
        });
    });

    it('onResequenceEquipment  expected dialogVisible is true', () => {
        const call = EquipmentGroupCreateUtils.onResequenceEquipment('');
        expect(call.dialogVisible).toEqual(true);
    });

    it('getToastMessageData  expected object', () => {
        const call = EquipmentGroupCreateUtils.getToastMessageData(200, '');
        expect(call).toEqual({
            severity: 'success',
            summary: 'Success',
            detail: ' Group was created successfully'
        });
    });

    it('getToastMessageData  expected object', () => {
        const call = EquipmentGroupCreateUtils.getToastMessageData(409, '');
        expect(call).toEqual({
            severity: 'error',
            summary: 'Duplicate Equipment',
            detail: 'An equipment group has already been set for this combination of equipment pair'
        });
    });

    it('getToastMessageData  expected object', () => {
        const call = EquipmentGroupCreateUtils.getToastMessageData(400, '');
        expect(call).toEqual({
            severity: 'error',
            summary: 'Duplicate Group Name',
            detail: 'Group Name Already Available'
        });
    });

    it('getToastMessageData  expected object', () => {
        const call = EquipmentGroupCreateUtils.getToastMessageData(1, '');
        expect(call).toEqual({
            severity: 'error',
            summary: 'Equipment Group Error',
            detail: 'Equipment Group must have more than one equipment'
        });
    });

    it('setDefaultCountry  expected null', () => {
        const equipmentGroupCreateModel = {
            equipmentListForm: true
        };
        const call = EquipmentGroupCreateUtils.setDefaultCountry('');
        expect(call).toEqual(null);
    });

    it('resetEquipmentArray  expected null', () => {
        const equipmentGroupCreateModel = {
            equipmentLength: [],
            equipmentWidth: [],
            equipmentHeight: []
        };
        const call = EquipmentGroupCreateUtils.resetEquipmentArray(1, equipmentGroupCreateModel);
        expect(call).toEqual(null);
    });


    it('calculateEquipmentLengthValues  expected systemAdjustedLength have been called', () => {
        spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentValues');
        spyOn(EquipmentGroupUtility, 'feetInchesGroupOverview');
        spyOn(EquipmentGroupUtility, 'systemAdjustedLength');
        const call = EquipmentGroupCreateUtils.calculateEquipmentLengthValues(123, {});
        expect(EquipmentGroupUtility.systemAdjustedLength).toHaveBeenCalled();
    });

    it('calculateEquipmentWidthValues  expected systemAdjustedLength have been called', () => {
        spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentValues');
        spyOn(EquipmentGroupUtility, 'maxWidthGroupOverview');
        spyOn(EquipmentGroupUtility, 'systemAdjustedWidth');
        const call = EquipmentGroupCreateUtils.calculateEquipmentWidthValues(123, {});
        expect(EquipmentGroupUtility.systemAdjustedWidth).toHaveBeenCalled();
    });

    it('calculateEquipmentHeightValues  expected systemAdjustedLength have been called', () => {
        spyOn(EquipmentGroupCreateUtils, 'calculateEquipmentValues');
        spyOn(EquipmentGroupUtility, 'maxWidthGroupOverview');
        spyOn(EquipmentGroupUtility, 'systemAdjustedHeight');
        const call = EquipmentGroupCreateUtils.calculateEquipmentHeightValues(123, {});
        expect(EquipmentGroupUtility.systemAdjustedHeight).toHaveBeenCalled();
    });

    it('resetEquipment should set the equipmentLength value to empty string', () => {
        const equipmentAddForm = fb.array([
            fb.group({
                'equipmentCategory': [''],
                'equipmentType': [''],
                'equipmentLength': [''],
                'equipmentWidth': [''],
                'equipmentHeight': [''],
                'equipmentTypeDescription': [''],
                'equipmentGroupSequenceNumber': [1],
                'stackedEquipments': fb.array([])
            })
        ]);
        EquipmentGroupCreateUtils.resetEquipment('0', 'equipmentLength', equipmentAddForm['controls']);
        expect(equipmentAddForm.controls[0]['controls']['equipmentLength'].value).toEqual('');
    });

    it('resetEquipment should return null', () => {
        const equipmentAddForm = fb.array([
            fb.group({
                'equipmentCategory': [''],
                'equipmentType': [''],
                'equipmentLength': [''],
                'equipmentWidth': [''],
                'equipmentHeight': [''],
                'equipmentTypeDescription': [''],
                'equipmentGroupSequenceNumber': [1],
                'stackedEquipments': fb.array([fb.group({
                    'equipmentLength': ['']
                })])
            })
        ]);
        expect(EquipmentGroupCreateUtils.resetEquipment('0.0', 'equipmentLength', equipmentAddForm['controls'])).toEqual(null);
    });

    it('generateStackedEquipmentDetails should return an array of length 1', () => {
        spyOn(EquipmentGroupCreateUtils, 'checkCumulativeValues');
        const stackedEquipments = fb.array([fb.group({
            'equipmentLength': [''],
            'equipmentCategory': [''],
            'equipmentType': [''],
            'equipmentWidth': [''],
            'equipmentHeight': ['']
        })]);
        const returnValue = EquipmentGroupCreateUtils.generateStackedEquipmentDetails(stackedEquipments, 1, true);
        expect(returnValue.length).toEqual(1);
    });

    it('generateStackedEquipmentDetails should call the spy checkCumulativeValues', () => {
        spyOn(EquipmentGroupCreateUtils, 'checkCumulativeValues');
        const stackedEquipments = fb.array([fb.group({
            'equipmentLength': ['1'],
            'equipmentCategory': [''],
            'equipmentType': [''],
            'equipmentWidth': ['1'],
            'equipmentHeight': ['1']
        })]);
        EquipmentGroupCreateUtils.generateStackedEquipmentDetails(stackedEquipments, 1, true);
        expect(EquipmentGroupCreateUtils.checkCumulativeValues).toHaveBeenCalled();
    });

    it('generateStackedEquipmentDetails should return null', () => {
        const stackedEquipments = fb.array([]);
        expect(EquipmentGroupCreateUtils.generateStackedEquipmentDetails(stackedEquipments, 1, true)).toEqual(null);
    });

});
