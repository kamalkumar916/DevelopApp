import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import {
  CountryDetails, EquipmentType, EquipmentClassification, EquipmentDimenstion
} from '../../model/equipment-group.interface';

@Injectable()
export class EquipmentGroupCreateService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('manageEquipmentGroup');
  }
  getEquipmentCategory(): Observable<EquipmentClassification> {
    return this.http.get<EquipmentClassification>(this.endpoint.getEquipmentCategory);
  }
  getCountryDetails(): Observable<CountryDetails> {
    return this.http.get<CountryDetails>(this.endpoint.getCountryDetails);
  }
  getEquipmentType(equipmentCategoryCode: string): Observable<EquipmentType> {
    return this.http.get<EquipmentType>(`${this.endpoint.getEquipmentType}?equipmentClassificationCode=${equipmentCategoryCode}`);
  }
  getEquipmentDimension(equipmentCategory: string, equipmentType: string): Observable<EquipmentDimenstion> {
    return this.http.get<EquipmentDimenstion>(`${this.endpoint.
      getEquipmentDimension}?equipmentClassificationCode=${equipmentCategory}&equipmentTypeCode=${equipmentType}`);
  }
  createEquipmentGroup(requestObj): Observable<any> {
    return this.http.post(this.endpoint.createEquipmentGroup, requestObj);
  }

}
