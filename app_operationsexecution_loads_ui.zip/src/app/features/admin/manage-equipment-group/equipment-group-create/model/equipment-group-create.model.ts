import { MenuItem, SelectItem } from 'primeng/api';
import { FormGroup, FormArray } from '@angular/forms';

import { CreateRequest, EquipmentTypesItem, ResequenceList } from '../../model/equipment-group.interface';
import { EquipmentGroupUtility } from './../../services/equipment-group.utility';
import { AppConfig } from '../../../../../../config/app.config';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';

export class EquipmentGroupCreateModel {
    equipmentListForm: FormGroup;
    menuItems: MenuItem[];
    hasSubscribe: boolean;
    hasSubmited: boolean;
    equipmentCategory: SelectItem[];
    countryDetails: SelectItem[];
    equipmentType: SelectItem[][];
    equipmentTypeList: EquipmentTypesItem[];
    equipmentLength: SelectItem[][];
    equipmentWidth: SelectItem[][];
    equipmentHeight: SelectItem[][];
    equipmentCategoryValue: Array<string>;
    unitTypes: SelectItem[];
    requestObject: CreateRequest;
    type: string;
    width: string;
    height: string;
    systemAdjustedLength: string;
    systemAdjustedHeight: string;
    cumulativeLength: string;
    cumulativeHeight: string;
    cumulativeWidth: string;
    removeIndex: number;
    isDisplayDialog: boolean;
    defaultCountry: SelectItem;
    lengthArray: string[];
    heightArray: string[];
    widthArray: string[];
    inputResequenceList: ResequenceList;
    unitOfMeasure: string;
    sectionLoading: boolean;
    systemAdjustedWidth: string;
    isLoading: boolean;
    stackedMenuItems: MenuItem[];
    inputStackList: ResequenceList;
    stackingControl: FormArray;
    routeLinks: any;
    manageEquipmentCreateURL: string;
    appConfig;
    manageEquipmentCreateButton: SecureModel;
    constructor() {
        this.menuItems = [];
        this.hasSubscribe = true;
        this.hasSubmited = false;
        this.equipmentCategoryValue = [];
        this.equipmentType = [];
        this.equipmentLength = [];
        this.equipmentWidth = [];
        this.equipmentHeight = [];
        this.lengthArray = [];
        this.heightArray = [];
        this.widthArray = [];
        this.countryDetails = [];
        this.equipmentCategory = [];
        this.unitTypes = [
            {
                label: 'Imperial',
                value: 'Imperial'
            },
            {
                label: 'Metric',
                value: 'Metric'
            }
        ];
        this.requestObject = {
            equipmentGroupName: '',
            equipmentGroupDescription: '',
            equipmentGroupComment: '',
            countryCode: '',
            countryDescription: '',
            groupOverviewDetails: null,
            standardEquipmentGroupMembers: []
        };
        this.defaultCountry = {
            label: 'USA',
            value: 'USA'
        };
        this.systemAdjustedLength = '---';
        this.systemAdjustedHeight = '---';
        this.stackedMenuItems = [];
        this.equipmentTypeList = [];
        this.appConfig = AppConfig.getConfig();
        this.manageEquipmentCreateButton = { url: this.appConfig.api.manageEquipmentGroup.createEquipmentGroup, operation: 'C' };
    }
}
