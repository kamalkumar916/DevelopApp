import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';

import * as lodashutils from 'lodash';
import { Router } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { timer } from 'rxjs';

import { EquipmentGroupCreateModel } from './model/equipment-group-create.model';
import { EquipmentGroupCreateService } from './services/equipment-group-create.service';
import { EquipmentGroupCreateUtils } from './services/equipment-group-create-utils';
import { EquipmentGroupUtility } from './../services/equipment-group.utility';
import { ManageEquipmentGroupRoutelinks } from '../manage-equipment-group-route-links';
import { CountryDetails, EquipmentType, EquipmentClassification, EquipmentDimenstion } from '../model/equipment-group.interface';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';
import { ErrorUtils } from '../../../../shared/jbh-app-services/error-utils';

@Component({
  selector: 'app-equipment-group-create',
  templateUrl: './equipment-group-create.component.html',
  styleUrls: ['./equipment-group-create.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EquipmentGroupCreateComponent implements OnInit, OnDestroy {
  @ViewChild('resequence') resequenceButton;
  equipmentGroupCreateModel: EquipmentGroupCreateModel;
  equipmentGroupRoutes = ManageEquipmentGroupRoutelinks;
  constructor(private readonly changeDetector: ChangeDetectorRef, private readonly fb: FormBuilder,
    private readonly equipmentGroupCreateService: EquipmentGroupCreateService, private readonly confirmationService: ConfirmationService,
    private readonly router: Router, private readonly toastMessage: MessageService) {
    this.equipmentGroupCreateModel = new EquipmentGroupCreateModel();
  }
  ngOnInit() {
    this.equipmentGroupCreateModel.equipmentListForm = this.fb.group({
      'name': ['', Validators.required],
      'description': '',
      'country': ['', Validators.required],
      'comments': '',
      equipmentAddFormGroup: this.fb.array([
        EquipmentGroupCreateUtils.initializeFormGroup(this.fb, 0)
      ])
    });
    this.getCountryDetails();
    this.getEquipmentCategory();
  }

  hasChangeDeteted() {
    return this.equipmentGroupCreateModel.equipmentListForm.dirty && !this.equipmentGroupCreateModel.hasSubmited;
  }
  ngOnDestroy() {
    this.equipmentGroupCreateModel.hasSubscribe = false;
    this.equipmentGroupCreateModel.equipmentListForm.removeControl('equipmentAddFormGroup');
  }
  getEquipmentStackedAddFormGroup(form) {
    return form.get('stackedEquipments').controls;
  }
  selectedEquipment(event) {
    if (event) {
      const stackedEquipment = this.equipmentGroupCreateModel.stackingControl.controls['stackedEquipments'];
      if (stackedEquipment.controls.length > 0) {
        for (let i = stackedEquipment.controls.length - 1; i >= 0; i--) {
          this.equipmentGroupCreateModel.equipmentListForm
            .get('equipmentAddFormGroup')['controls'][event.controls.equipmentGroupSequenceNumber.value - 1]
            .get('stackedEquipments').insert(event.controls.stackedEquipments.length, stackedEquipment.controls[i]);
        }
      }
      this.equipmentGroupCreateModel.equipmentListForm
        .get('equipmentAddFormGroup')['controls'][event.controls.equipmentGroupSequenceNumber.value - 1].get('stackedEquipments')
        .insert(event.controls.stackedEquipments.length, this.equipmentGroupCreateModel.stackingControl);
      if (stackedEquipment.controls.length > 0) {
        while (stackedEquipment.length !== 0) {
          stackedEquipment.removeAt(0);
        }
      }
      this.removeEquipmentAddForm(this.equipmentGroupCreateModel.stackingControl.value.equipmentGroupSequenceNumber - 1);
      this.getEquipmentUpdate(0);
      if (this.equipmentGroupCreateModel.systemAdjustedLength !== '---' || this.equipmentGroupCreateModel.systemAdjustedHeight !== '---') {
        this.thresholdExceedWarning('noChanges');
      }
      this.changeDetector.detectChanges();
    }
  }
  get equipmentAddForm() {
    return this.equipmentGroupCreateModel.equipmentListForm.get('equipmentAddFormGroup')['controls'];
  }
  getEquipmentCategory() {
    this.equipmentGroupCreateService.getEquipmentCategory().pipe(takeWhile(() => this.equipmentGroupCreateModel.hasSubscribe))
      .subscribe((data: EquipmentClassification) => {
        if (data) {
          EquipmentGroupCreateUtils.getEquipmentCategory(data, this.equipmentGroupCreateModel);
        }
      }, (error) => {
        this.equipmentGroupCreateModel.equipmentCategory = [];
      });
  }
  getCountryDetails() {
    this.equipmentGroupCreateModel.sectionLoading = true;
    this.equipmentGroupCreateService.getCountryDetails().pipe(takeWhile(() => this.equipmentGroupCreateModel.hasSubscribe))
      .subscribe((data: CountryDetails) => {
        if (data) {
          this.equipmentGroupCreateModel.sectionLoading = false;
          EquipmentGroupCreateUtils.getCountryDetails(data, this.equipmentGroupCreateModel);
          EquipmentGroupCreateUtils.setDefaultCountry(this.equipmentGroupCreateModel);
          this.markAndChangeDetector();
        }
      }, (error) => {
        this.equipmentGroupCreateModel.countryDetails = [];
      });
  }
  markAndChangeDetector() {
    this.changeDetector.markForCheck();
    this.changeDetector.detectChanges();
  }
  onSelectEquipmentCategory(selectedEquipmentCategory: string, index: number, resetFlag: boolean, stackedIndex?: number) {
    let arrayIndex: string | number;
    arrayIndex = (stackedIndex || stackedIndex === 0) ? `${index}.${stackedIndex}` : index;
    this.equipmentGroupCreateModel.equipmentCategoryValue[arrayIndex] = selectedEquipmentCategory;
    EquipmentGroupCreateUtils.resetEquipmentArray(arrayIndex, this.equipmentGroupCreateModel);
    this.setEquipmentType();
    if (arrayIndex.toString().split('.').length > 1) {
      this.equipmentAddForm[index].controls.stackedEquipments.controls[stackedIndex].controls.equipmentType.reset();
    } else {
      this.equipmentAddForm[arrayIndex].controls.equipmentType.reset();
    }
    this.resetEquipmentValues(arrayIndex);
    this.selectEquipmentValues(arrayIndex, false);
    this.getEquipmentType(selectedEquipmentCategory, index, arrayIndex);
    this.changeDetector.detectChanges();
  }
  getEquipmentType(equipmentCode: string, index: string | number, stackedIndex?: string | number) {
    this.equipmentGroupCreateModel.isLoading = true;
    this.equipmentGroupCreateService.getEquipmentType(equipmentCode).pipe(takeWhile(() => this.equipmentGroupCreateModel.hasSubscribe))
      .subscribe((data: EquipmentType) => {
        if (data) {
          this.equipmentGroupCreateModel.isLoading = false;
          this.equipmentGroupCreateModel.equipmentTypeList = data._embedded
            && data._embedded.equipmentTypes ? data._embedded.equipmentTypes : [];
          if (stackedIndex && stackedIndex.toString().split('.').length > 1) {
            EquipmentGroupCreateUtils.getEquipmentType(data, this.equipmentGroupCreateModel, stackedIndex);
            this.equipmentGroupCreateModel.equipmentCategoryValue[stackedIndex] = equipmentCode;
            const typeVal = EquipmentGroupCreateUtils.setEquipmentTypeIndex(this.equipmentGroupCreateModel.equipmentListForm, stackedIndex);
            this.onSelectEquipmentType(typeVal, stackedIndex);
          } else {
            EquipmentGroupCreateUtils.getEquipmentType(data, this.equipmentGroupCreateModel, index);
            const typeVal = this.equipmentGroupCreateModel.equipmentListForm.controls.equipmentAddFormGroup.value[index].equipmentType;
            this.onSelectEquipmentType(typeVal, index);
          }
          this.changeDetector.detectChanges();
        }
      }, (error: Error) => {
        this.equipmentGroupCreateModel.equipmentTypeList = [];
        this.equipmentGroupCreateModel.isLoading = false;
      });
  }
  onSelectEquipmentType(selectedEquipmentType: string, index: string | number, isFlag = false) {
    const formIndex = index.toString().split('.');
    if (isFlag) {
      this.resetEquipmentValues(index);
      this.markAndChangeDetector();
      const selValue = lodashutils.filter(this.equipmentGroupCreateModel.equipmentType[index], ['value', selectedEquipmentType]);
      if (selValue && selValue.length > 0) {
        (formIndex.length > 1) ?
          this.equipmentAddForm[formIndex[0]].controls.stackedEquipments
            .controls[formIndex[1]].controls.equipmentTypeDescription.setValue(selValue[0].label) :
          this.equipmentAddForm[formIndex[0]].controls.equipmentTypeDescription.setValue(selValue[0].label);
      }
    }
    this.getEquipmentValues(selectedEquipmentType, index);
    this.selectEquipmentValues(index, false);
    this.changeDetector.detectChanges();
  }
  resetEquipmentValues(index: string | number) {
    EquipmentGroupCreateUtils.resetEquipment(index, 'equipmentLength', this.equipmentAddForm);
    EquipmentGroupCreateUtils.resetEquipment(index, 'equipmentWidth', this.equipmentAddForm);
    EquipmentGroupCreateUtils.resetEquipment(index, 'equipmentHeight', this.equipmentAddForm);
  }
  onCancel() {
    this.equipmentGroupCreateModel.isDisplayDialog = false;
  }
  selectEquipmentValues(index: string | number, isFlag: boolean) {
    if (index.toString().split('.').length > 1) {
      const formIndex = index.toString().split('.');
      const equipmentAddFormGroup = this.equipmentGroupCreateModel.equipmentListForm.get('equipmentAddFormGroup');
      this.onSelectEquipmentLength(equipmentAddFormGroup['controls'][formIndex[0]].controls
        .stackedEquipments.controls[formIndex[1]].controls['equipmentLength'].value, index, isFlag);
      this.onSelectEquipmentWidth(equipmentAddFormGroup['controls'][formIndex[0]].controls
        .stackedEquipments.controls[formIndex[1]].controls['equipmentWidth'].value, index, isFlag);
      this.onSelectEquipmentHeight(equipmentAddFormGroup['controls'][formIndex[0]].controls
        .stackedEquipments.controls[formIndex[1]].controls['equipmentHeight'].value, index, isFlag);
    } else {
      this.onSelectEquipmentLength(this.equipmentGroupCreateModel.equipmentListForm.
        get('equipmentAddFormGroup')['controls'][index].controls['equipmentLength'].value, index, isFlag);
      this.onSelectEquipmentWidth(this.equipmentGroupCreateModel.equipmentListForm.
        get('equipmentAddFormGroup')['controls'][index].controls['equipmentWidth'].value, index, isFlag);
      this.onSelectEquipmentHeight(this.equipmentAddForm[index].controls['equipmentHeight'].value, index, isFlag);
    }
  }
  onSelectEquipmentLength(selectedEquipmentLength: string, index: string | number, isFlag = false) {
    const requestObj = EquipmentGroupCreateUtils.generateRequestObject(this.equipmentGroupCreateModel.equipmentListForm,
      this.equipmentGroupCreateModel);
    this.equipmentGroupCreateModel.systemAdjustedLength = EquipmentGroupCreateUtils.
      calculateEquipmentLengthValues(requestObj.standardEquipmentGroupMembers, this.equipmentGroupCreateModel);
    if (isFlag && this.equipmentGroupCreateModel.systemAdjustedLength !== '---') {
      this.thresholdExceedWarning(index, 'equipmentLength');
    }
  }
  onSelectEquipmentWidth(selectedEquipmentWidth: string, index: string | number, isFlag = false) {
    const requestObj = EquipmentGroupCreateUtils.generateRequestObject(this.equipmentGroupCreateModel.equipmentListForm,
      this.equipmentGroupCreateModel);
    this.equipmentGroupCreateModel.systemAdjustedWidth =
      EquipmentGroupCreateUtils.calculateEquipmentWidthValues(requestObj.standardEquipmentGroupMembers, this.equipmentGroupCreateModel);
    if (isFlag && this.equipmentGroupCreateModel.systemAdjustedWidth !== '---') {
      this.thresholdExceedWarning(index, 'equipmentWidth');
    }
  }
  onSelectEquipmentHeight(selectedEquipmentHeight: string, index: string | number, isFlag = false) {
    const requestObj = EquipmentGroupCreateUtils.generateRequestObject(this.equipmentGroupCreateModel.equipmentListForm,
      this.equipmentGroupCreateModel);

      this.equipmentGroupCreateModel.systemAdjustedHeight =
      EquipmentGroupCreateUtils.calculateEquipmentHeightValues(requestObj.standardEquipmentGroupMembers, this.equipmentGroupCreateModel);
    if (isFlag && this.equipmentGroupCreateModel.systemAdjustedHeight !== '---') {
      this.thresholdExceedWarning(index, 'equipmentHeight');
    }
  }
  setEquipmentType() {
    this.equipmentGroupCreateModel.type = EquipmentGroupUtility.setOverviewType(this.getEquipmentGroupForm());
  }
  removeOverviewValues(index: number) {
    this.equipmentGroupCreateModel.lengthArray.splice(index, 1);
    const requestObj = EquipmentGroupCreateUtils.generateRequestObject(this.equipmentGroupCreateModel.equipmentListForm,
      this.equipmentGroupCreateModel);
    this.setEquipmentType();
    EquipmentGroupCreateUtils.removeOverviewValue(requestObj.standardEquipmentGroupMembers, index, this.equipmentGroupCreateModel);
  }
  validateFormFields(fieldName: string, index: number) {
    return (this.equipmentAddForm[index].controls[fieldName].invalid && this.equipmentAddForm[index].controls[fieldName].touched);
  }
  validateFormFieldsStacked(fieldName: string, index: number, stackedIndex: number) {
    return (this.equipmentAddForm[index].controls.stackedEquipments.controls[stackedIndex].controls[fieldName].invalid &&
      this.equipmentAddForm[index].controls.stackedEquipments.controls[stackedIndex].controls[fieldName].touched);
  }
  getEquipmentGroupForm(): FormArray {
    return this.equipmentGroupCreateModel.equipmentListForm.controls['equipmentAddFormGroup'] as FormArray;
  }
  onResequence() {
    this.equipmentGroupCreateModel.inputResequenceList = EquipmentGroupCreateUtils.onResequenceEquipment(this.equipmentAddForm);
    this.resequenceButton.nativeElement.blur();
  }
  afterResequence(event) {
    this.equipmentGroupCreateModel.equipmentListForm.setControl('equipmentAddFormGroup', this.fb.array([]));
    const controlVal: FormArray = this.getEquipmentGroupForm();
    for (let i = 0; i < event.length; i++) {
      controlVal.insert(i, event[i]);
      controlVal.controls[i]['controls']['equipmentGroupSequenceNumber'].setValue(i + 1);
      const stackLength = controlVal.controls[i]['controls'].stackedEquipments.controls;
      this.getEquipmentType(event[i].value.equipmentCategory, i);
      for (let j = 0; j < stackLength.length; j++) {
        this.getEquipmentType(stackLength[j].value.equipmentCategory, j, `${i}.${j}`);
      }
    }
  }
  onCreate() {
    this.equipmentGroupCreateModel.hasSubmited = true;
    FormValidationUtils.validateAllFormFields(this.equipmentGroupCreateModel.equipmentListForm);
    EquipmentGroupUtility.validateEquipmentValues(this.equipmentAddForm, this.equipmentGroupCreateModel);
    if (this.equipmentGroupCreateModel.equipmentListForm.valid) {
      if (this.equipmentAddForm.length >= 2 || (this.equipmentAddForm[0] && this.equipmentAddForm[0].controls &&
        this.equipmentAddForm[0].controls.stackedEquipments && this.equipmentAddForm[0].controls.stackedEquipments.length > 0)) {
        this.createEquipmentGroup();
      } else {
        this.toastMessage.add(EquipmentGroupCreateUtils.getToastMessageData());
      }
    }
  }
  getEquipmentValues(equipmentType: string, index: string | number) {
    if (equipmentType) {
      this.equipmentGroupCreateService.getEquipmentDimension(this.equipmentGroupCreateModel.equipmentCategoryValue[index], equipmentType)
      .pipe(takeWhile(() => this.equipmentGroupCreateModel.hasSubscribe)).subscribe((data: EquipmentDimenstion) => {
        if (data) {
          this.equipmentGroupCreateModel.isLoading = false;
          EquipmentGroupCreateUtils.getEquipmentDetails(data, this.equipmentGroupCreateModel.equipmentHeight, index, 'Height');
          EquipmentGroupCreateUtils.getEquipmentDetails(data, this.equipmentGroupCreateModel.equipmentLength, index, 'Length');
          EquipmentGroupCreateUtils.getEquipmentDetails(data, this.equipmentGroupCreateModel.equipmentWidth, index, 'Width');
          this.changeDetector.detectChanges();
        }
      }, (error: Error) => {
        this.equipmentGroupCreateModel.isLoading = false;
      });
    }
  }
  onEquipmentAddFormGroup(index: number) {
    const control: FormArray = this.equipmentGroupCreateModel.equipmentListForm.controls['equipmentAddFormGroup'] as FormArray;
    control.insert(index + 1, EquipmentGroupCreateUtils.initializeFormGroup(this.fb, index));
    this.equipmentGroupCreateModel.equipmentCategoryValue.splice(index + 1, 0, '');
    this.equipmentGroupCreateModel.equipmentType[index + 1] = [];
    EquipmentGroupCreateUtils.resetEquipmentArray(index + 1, this.equipmentGroupCreateModel);
    this.getEquipmentUpdate(index + 2);
    this.setSequenceNumber(index, control);
    this.changeDetector.detectChanges();
  }
  removeEquipmentAddFormGroup(index: number) {
    this.equipmentGroupCreateModel.removeIndex = index;
    this.equipmentGroupCreateModel.isDisplayDialog = true;
  }
  onRejectRemove() {
    this.equipmentGroupCreateModel.isDisplayDialog = false;
  }
  thresholdExceedWarning(index?: string | number, equipmentValue?: string) {
    this.confirmationService.confirm({
      message: `You have reached the equipment sizing threshold.Continuing will result
      in updating adjusted equipment specifications.<p></p>
      Are you sure you want to continue?`,
      header: 'Warning',
      key: 'warning',
      accept: (): void => {
      },
      reject: (): void => {
        this.equipmentGroupCreateModel.equipmentListForm.get('equipmentAddFormGroup')['controls'][index].controls[equipmentValue].reset();
        if (equipmentValue === 'equipmentLength') {
          this.onSelectEquipmentLength(this.equipmentAddForm[index].controls[equipmentValue], index, false);
        } else if (equipmentValue === 'equipmentWidth') {
          this.onSelectEquipmentWidth(this.equipmentAddForm[index].controls[equipmentValue], index, false);
        } else {
          this.onSelectEquipmentHeight(this.equipmentAddForm[index].controls[equipmentValue], index, false);
        }
      }
    });
  }
  onAcceptRemove() {
    this.equipmentGroupCreateModel.isDisplayDialog = false;
    this.removeEquipmentAddForm(this.equipmentGroupCreateModel.removeIndex);
  }
  removeEquipmentAddForm(index: number) {
    const control: FormArray = this.equipmentGroupCreateModel.equipmentListForm.controls['equipmentAddFormGroup'] as FormArray;
    const stackedEquipment = control.controls[index]['controls']['stackedEquipments']['controls'];
    if (stackedEquipment.length > 0) {
      for (let j = stackedEquipment.length - 1; j >= 0; j--) {
        control.insert(index + 1, stackedEquipment[j]);
      }
    }
    control.removeAt(index);
    this.equipmentGroupCreateModel.equipmentCategoryValue.splice(index, 1);
    this.equipmentGroupCreateModel.equipmentType[index] = [];
    EquipmentGroupCreateUtils.resetEquipmentArray(index, this.equipmentGroupCreateModel);
    this.getEquipmentUpdate(0);
    this.setSequenceNumber(index, control);
    this.setEquipmentType();
    this.removeOverviewValues(index);
    this.changeDetector.detectChanges();
  }
  menuClick(event, index, equipmentName, pIndex?: number) {
    switch (equipmentName) {
      case 'Equipment Menu':
        if (event) {
          this.equipmentGroupCreateModel.menuItems = EquipmentGroupCreateUtils.generateMenuItems(index, this);
        }
        break;
      case 'Stacked Equipment Menu':
        if (event) {
          this.equipmentGroupCreateModel.stackedMenuItems = EquipmentGroupCreateUtils.generateStackedMenuItems(index, pIndex, this);
        }
        break;
    }
  }
  addStackedEquipment(index) {
    this.equipmentGroupCreateModel.stackingControl = this.equipmentAddForm[index] as FormArray;
    this.equipmentGroupCreateModel.inputStackList = EquipmentGroupCreateUtils.stackEquipmentData(this.equipmentAddForm,
      index, this.equipmentGroupCreateModel.stackingControl.get(`equipmentCategory`).value);
    this.changeDetector.detectChanges();
  }
  addUnderStackedEquipment(index, pIndex) {
    const control = this.equipmentAddForm[pIndex].get('stackedEquipments') as FormArray;
    control.insert(index + 1, EquipmentGroupCreateUtils.initializeFormGroup(this.fb, index + 1));
    this.getEquipmentUpdate(0);
    this.changeDetector.detectChanges();
  }
  addUnStackedEquipment(index, pIndex) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to unstack this equipment?',
      header: 'Confirmation',
      key: 'unstackEquipment',
      accept: (): void => {
        const control = this.equipmentAddForm[pIndex].get('stackedEquipments') as FormArray;
          this.equipmentGroupCreateModel.equipmentCategoryValue.splice(pIndex + 1, 0,
            this.equipmentGroupCreateModel.equipmentCategoryValue[`${pIndex}.${index}`]);
          this.equipmentGroupCreateModel.equipmentType.splice(pIndex + 1, 0,
            this.equipmentGroupCreateModel.equipmentType[`${pIndex}.${index}`]);
        if (control.length > 0) {
          const insertControl = this.equipmentGroupCreateModel.equipmentListForm.controls.equipmentAddFormGroup as FormArray;
          insertControl.insert(pIndex + 1, control.controls[index]);
          EquipmentGroupCreateUtils.resetEquipmentArray(pIndex + 1, this.equipmentGroupCreateModel);
          control.removeAt(index);
          const controlVal: FormArray = this.getEquipmentGroupForm();
          this.getEquipmentUpdate(0);
          this.setSequenceNumber(pIndex, controlVal);
          this.changeDetector.detectChanges();
        }
      }
    });
  }
  removeStackedEquipment(index, pIndex) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to remove this equipment?',
      header: 'Confirmation',
      key: 'removeEquipment',
      accept: (): void => {
        const control = this.equipmentAddForm[pIndex].get('stackedEquipments') as FormArray;
        if (control.length > 0) {
          control.removeAt(index);
        }
        this.getEquipmentUpdate(0);
        this.setSequenceNumber(index, control);
        this.setEquipmentType();
      }
    });
  }
  getEquipmentUpdate(index: number) {
    const controlVal: FormArray = this.getEquipmentGroupForm();
    for (let i = index; i < controlVal.length; i++) {
      const stackLength = controlVal.controls[i]['controls'].stackedEquipments.controls;
      this.getEquipmentType(controlVal.controls[i]['controls'].equipmentCategory.value, i);
      for (let j = 0; j < stackLength.length; j++) {
        this.getEquipmentType(stackLength[j].value.equipmentCategory, j, `${i}.${j}`);
      }
    }
  }
  setSequenceNumber(index: number, control: FormArray) {
    for (let i = index; i < control.length; i++) {
      control.controls[i]['controls']['equipmentGroupSequenceNumber'].setValue(i + 1);
    }
  }
  onValueChange(value: string) {
    this.equipmentGroupCreateModel.unitOfMeasure = value;
    this.changeDetector.detectChanges();
  }
  createEquipmentGroup() {
    const requestObj = EquipmentGroupCreateUtils.generateRequestObject(this.equipmentGroupCreateModel.equipmentListForm,
      this.equipmentGroupCreateModel, true);
    this.equipmentGroupCreateService.createEquipmentGroup(requestObj).subscribe(data => {
      if (data) {
        timer(2000).subscribe(() => {
          this.toastMessage.add(EquipmentGroupCreateUtils.getToastMessageData(200,
            this.equipmentGroupCreateModel.equipmentListForm.controls.name.value));
          this.router.navigate([ManageEquipmentGroupRoutelinks.listUrl]);
        });
      }
    }, (error: Error) => {
      this.toastMessage.clear();
      switch (error['status']) {
        case 409:
          this.toastMessage.add(EquipmentGroupCreateUtils.getToastMessageData(409));
          break;
        case 400:
          if (error['error']['errors'][0]['code'] === 'DUPLICATE_GROUP_NAME') {
            this.toastMessage.add(EquipmentGroupCreateUtils.getToastMessageData(400));
          }
          break;
        case 500:
          this.toastMessage.add({
            severity: 'error',
            summary: 'Server Error',
            detail: ErrorUtils.getErrorMessage(error['status'])
          });
          break;
      }
    });
  }
}
