import { Pipe, PipeTransform } from '@angular/core';
import * as utils from 'lodash';

import { EquipmentGroupUtility } from '../services/equipment-group.utility';
import {
  EquipmentDetails, EquipmentGroupMembers
} from '../model/equipment-group.interface';
@Pipe({
  name: 'unitMetricsImperial'
})
export class UnitMetricsImperialPipe implements PipeTransform {

  transform(value: any, args?: any, arg1?: string): any {

    if (value && args === 'Metric') {
      if (!value.includes('---') && value.trim().length !== 0) {
        const feetInches = this.feetToInches(value);
        return this.feetInchesToMeter(feetInches.feet, feetInches.inches);
      } else {
        return '---';
      }
    } else if (value && args === 'lengthWidthHeigthCalculation') {
      return this.calculationOfEquipmentValue(value);
    } else if (value && args === 'lengthWidthHeightTotal') {
      return this.lengthWidthHeightTotal(value, arg1);
    } else {
      return value;
    }
  }
  feetToInches(value: string) {
    const index = value.indexOf('t');
    const feetString = index > 0 ? value.substr(0, index + 1) : '';
    const inchesString = value.length > index ? value.substr(index + 1) : '';
    const feetValue = feetString ? this.feetInchesConversion(feetString) : '';
    const inchesValue = inchesString ? this.feetInchesConversion(inchesString) : '';
    return {
      feet: feetValue,
      inches: inchesValue
    };
  }
  feetInchesConversion(feetInchesStingValue): string {
    let feetInches = '';
    const isNegative = (feetInchesStingValue.includes('-'));
    for (const item of feetInchesStingValue) {
      if (!isNaN(item)) {
        feetInches = feetInches + item;
      }
    }
    return (isNegative) ? `-${feetInches.toString()}` : feetInches.toString();
  }
  feetInchesToMeter(feet, inches): string {
    let feetinches, meter;
    feetinches = .3048 * feet + .0254 * inches;
    meter = (feetinches).toFixed(4); // metres
    return meter + ' m';
  }
  meterToFeetInches(meter): string {
    const splitMeter = utils.split(meter, 'm', 1);
    meter = splitMeter;
    const totoalInches = meter * 39.3700787;
    const feet = totoalInches / 12;
    const appoxFeet = feet - Math.floor(feet);
    const finalInches = appoxFeet * 12;
    if (Math.round(finalInches) === 12) {
      const finalFeet = Math.floor(feet) + 1;
      return `${finalFeet} ft`;
    } else {
      const finalFeet = Math.floor(feet);
      return `${finalFeet} ft ${Math.round(finalInches)} in`;
    }
  }
  calculationOfEquipmentValue(value: EquipmentGroupMembers[]) {
    const equipmentLength = [];
    value.forEach((equipmentSpecification: EquipmentGroupMembers) => {
      return equipmentLength.push({
        equipmentValue: {
          length: this.calculateEquipment(equipmentSpecification, 'lengthSpecificationCode'),
          width: this.calculateEquipment(equipmentSpecification, 'widthSpecificationCode'),
          height: this.calculateEquipment(equipmentSpecification, 'heightSpecificationCode')
        },
      });
    });
    return equipmentLength;
  }
  calculateEquipment(value: EquipmentGroupMembers, codeSpecification: string) {
    const equipmentValue = [];
    equipmentValue.push(value[`${codeSpecification}`]);
    if (value.stackedEquipments) {
      value.stackedEquipments.forEach((equipmentSpecification) => {
        equipmentValue.push(equipmentSpecification[`${codeSpecification}`]);
      });
    }
    return equipmentValue;
  }
  lengthWidthHeightTotal(SpecificationCodeDimension: EquipmentDetails, value: string) {
    const stackedArray = utils.filter(SpecificationCodeDimension, (data) => {
      return data.equipmentValue[value].length > 1;
    });
    if (!utils.isEmpty(stackedArray)) {
      if (value === 'height') {
        return this.getSpecificValue(SpecificationCodeDimension, value, false, 'height');
      } else {
        return this.getSpecificValue(SpecificationCodeDimension, value, true);
      }
    } else {
      const specificArray = this.getSpecificValue(SpecificationCodeDimension, value, false);
      if (value === 'length') {
        return specificArray;
      }
      return [EquipmentGroupUtility.maxWidthGroupOverview(specificArray)];
    }
  }
  getSpecificValue(SpecificationCodeDimension: EquipmentDetails, value: string, key: boolean, keyValue?: string) {
    let valueArray = [];
    if (!utils.isEmpty(SpecificationCodeDimension)) {
      utils.forEach(SpecificationCodeDimension, (data: EquipmentDetails) => {
        if (data.equipmentValue[value] && data.equipmentValue[value] !== '---') {
          if (key) {
            valueArray = this.getStackedValue(data.equipmentValue[value], valueArray);
          } else if (keyValue === 'height') {
            valueArray.push(EquipmentGroupUtility.feetInchesGroupOverview(data.equipmentValue[value]));
          } else {
            utils.forEach(data.equipmentValue[value], (equipmentValue: any) => {
              valueArray.push(equipmentValue);
            });
          }
        }
      });
    }
    return valueArray;
  }
  getStackedValue(equipmentValue: string[], valueArray: string[]) {
    if (equipmentValue.length > 1) {
      valueArray.push(EquipmentGroupUtility.maxWidthGroupOverview(equipmentValue));
    } else {
      valueArray.push(equipmentValue[0]);
    }
    return valueArray;
  }
}
