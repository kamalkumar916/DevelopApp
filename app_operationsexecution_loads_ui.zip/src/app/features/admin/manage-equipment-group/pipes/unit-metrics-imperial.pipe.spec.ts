import { UnitMetricsImperialPipe } from './unit-metrics-imperial.pipe';
const calculationOfEquipmentValuedata = [{
  equipmentGroupSequenceNumber: 1,
  equipmentClassificationCode: '',
  equipmentClassificationDescription: '',
  equipmentTypeCode: '',
  equipmentTypeDescription: '',
  lengthSpecificationCode: '',
  lengthSpecificationDescription: '',
  widthSpecificationCode: '',
  widthSpecificationDescription: '',
  heightSpecificationCode: '',
  heightSpecificationDescription: '',
}];

const calculateEquipmentdata = {
  equipmentGroupSequenceNumber: 1,
  equipmentClassificationCode: '',
  equipmentClassificationDescription: '',
  equipmentTypeCode: '',
  equipmentTypeDescription: '',
  lengthSpecificationCode: '',
  lengthSpecificationDescription: '',
  widthSpecificationCode: '',
  widthSpecificationDescription: '',
  heightSpecificationCode: '',
  heightSpecificationDescription: '',
};

describe('UnitMetricsImperialPipe', () => {
  let pipe: UnitMetricsImperialPipe;
  beforeEach(() => {
    pipe = new UnitMetricsImperialPipe();
  });
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('#transform should return real value', () => {
    expect(pipe.transform('12')).toBe('12');
  });

  it('#feetToInches should return real value', () => {
    const dd = { feet: '', inches: '1' };
    expect(pipe.feetToInches('1')).toEqual(dd);
  });

  it('#feetInchesConversion should return real value', () => {
    expect(pipe.feetInchesConversion('')).toBe('');
  });

  it('#feetInchesToMeter should return real value', () => {
    expect(pipe.feetInchesToMeter(1, 1)).toBe('0.3302 m');
  });

  it('#meterToFeetInches should return real value', () => {
    const val = pipe.meterToFeetInches(12);
    expect(val).toBeDefined();
  });

  it('#calculationOfEquipmentValue should return real value', () => {
    const dd = pipe.calculationOfEquipmentValue(calculationOfEquipmentValuedata);
    expect(dd).toBeDefined();
  });

  it('#calculateEquipment should return real value', () => {
    const dd = pipe.calculateEquipment(calculateEquipmentdata, '');
    expect(dd).toBeDefined();
  });

  it('#getStackedValue should return real value', () => {
    expect(pipe.getStackedValue(['test'], ['test1'])).toEqual(['test1', 'test']);
  });

});
