import { MenuItem, SelectItem } from 'primeng/api';

export class ManageEquipmentGroupRoutelinks {
    public static get homeUrl(): string { return '/dashboard'; }
    public static get listUrl(): string { return '/admin/manageequipment/list'; }
    public static get createUrl(): string { return '/admin/manageequipment/create'; }
    public static get editUrl(): string { return '/admin/manageequipment/edit'; }
    public static get viewUrl(): string { return '/admin/manageequipment/view'; }
    public static get auditListUrl(): string { return '/admin/manageequipment/auditlist'; }

    public static generateBreadcrumb(type: string): MenuItem[] {
        let screenLabel = '';
        if (type.toLowerCase() === 'create') {
            screenLabel = 'Create Equipment Group';
        } else if (type.toLowerCase() === 'edit') {
            screenLabel = 'Edit Equipment Group';
        } else if (type.toLowerCase() === 'view') {
            screenLabel = 'View Equipment Group';
        }
        return [
            { label: 'Administration', routerLink: [this.homeUrl] },
            { label: 'Manage Equipment Group', routerLink: [this.listUrl] },
            { label: screenLabel }
        ];
    }
    public static historyBreadCrumb(equipmentID: number): MenuItem[] {
        return [
            { label: 'Administration', routerLink: [this.homeUrl] },
            { label: 'Manage Equipment Group', routerLink: [this.listUrl] },
            {
              label: 'Equipment Group',
              routerLink: [this.viewUrl],
              queryParams: { standardEquipmentGroupID: equipmentID }
            },
            {
              label: 'Equipment Group History',
              queryParams: { standardEquipmentGroupID: equipmentID }
            }
          ];
    }


}

