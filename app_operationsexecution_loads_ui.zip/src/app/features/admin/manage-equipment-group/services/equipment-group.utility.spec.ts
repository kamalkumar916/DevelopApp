import { EquipmentGroupUtility } from '../services/equipment-group.utility';


describe('ValueService', () => {

    it('#feetandInches should return real value', () => {
        expect(EquipmentGroupUtility.feetandInches('')).toBe('');
    });

    it('#splitFeetInchesConversion should return real value', () => {
        expect(EquipmentGroupUtility.splitFeetInchesConversion('')).toBe('');
    });
    it('#feetInchesToMeter should return real value', () => {
        expect(EquipmentGroupUtility.feetInchesToMeter('10', '10')).toBe('3.3020 m');
    });
    it('#meterToFeetInches should return real value', () => {
        expect(EquipmentGroupUtility.meterToFeetInches('1')).toBe('3 ft 3 in');
    });
    it('#meterToFeetInches should return real value', () => {
        expect(EquipmentGroupUtility.meterToFeetInches('1')).toBe('3 ft 3 in');
    });
    it('#feetInchesGroupOverview should return real value', () => {
        spyOn(EquipmentGroupUtility, 'calculateCumulativeInches');
        expect(EquipmentGroupUtility.feetInchesGroupOverview(['1', '1'])).toBe(' 2 in');
    });

    it('#calculateCumulativeInches should return real value', () => {
        expect(EquipmentGroupUtility.calculateCumulativeInches(1, 2, 2)).toBe('4 ft');
    });

    it('#calculateCumulativeFeetInches should return real value', () => {
        expect(EquipmentGroupUtility.calculateCumulativeFeetInches(1, 1)).toBe('---');
    });

    it('#feetInchesFormat should return real value', () => {
        expect(EquipmentGroupUtility.feetInchesFormat(1)).toBe('1 in');
    });
    it('#feetInchesFormat should return real value', () => {
        expect(EquipmentGroupUtility.feetInchesFormat(12)).toBe('1 ft');
    });
    it('#getCumulativeValues should return real value', () => {
        expect(EquipmentGroupUtility.getCumulativeValues('1')).toBe(12);
    });
    it('#getCumulativeValues should return real value', () => {
        expect(EquipmentGroupUtility.getCumulativeValues('')).toBe(null);
    });

    it('#systemAdjustedLength should return real value', () => {
        expect(EquipmentGroupUtility.systemAdjustedLength('')).toBe('---');
    });

    it('#systemAdjustedHeight should return real value', () => {
        expect(EquipmentGroupUtility.systemAdjustedHeight('')).toBe('---');
    });

    it('#systemAdjustedWidth should return real value', () => {
        expect(EquipmentGroupUtility.systemAdjustedWidth('')).toBe('---');
    });






});
