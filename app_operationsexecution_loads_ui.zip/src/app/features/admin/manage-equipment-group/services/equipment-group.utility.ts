import * as LodashUtils from 'lodash';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';

import { FeetInches } from './../model/equipment-group.interface';
export class EquipmentGroupUtility {
    // feet and inches to meter
    static feetandInches(value: string): string {
        if (value) {
            const feetInchesValue = this.feetToInches(value);
            return this.feetInchesToMeter(feetInchesValue.feet, feetInchesValue.inches);
        } else {
            return value;
        }
    }
    static feetToInches(value: string): FeetInches {
        if (value) {
            const index = value.indexOf('t');
            const feetString = index > 0 ? value.substr(0, index + 1) : '';
            const inchesString = value.length > index ? value.substr(index + 1) : '';
            const feet = feetString ? this.splitFeetInchesConversion(feetString) : '';
            const inches = inchesString ? this.splitFeetInchesConversion(inchesString) : '';
            return {
                feet,
                inches
            };
        } else {
            return {
                feet: '0',
                inches: '0'
            };
        }
    }
    static splitFeetInchesConversion(feetInchesValue: string): string {
        let feetInches = '';
        for (const feetInchValue of feetInchesValue) {
            if (!isNaN(parseInt(feetInchValue, 10))) {
                feetInches = feetInches + feetInchValue;
            }
        }
        return feetInches.toString();
    }
    static feetInchesToMeter(feet, inches): string {
        let feetinches, meter;
        feetinches = .3048 * feet + .0254 * inches;
        meter = (feetinches).toFixed(4);
        return `${meter} m`;
    }
    static meterToFeetInches(meter): string {
        const splitMeter = LodashUtils.split(meter, 'm', 1);
        meter = splitMeter;
        const totoalInches = meter * 39.3700787;
        const feet = totoalInches / 12;
        const appoxFeet = feet - Math.floor(feet);
        const finalInches = appoxFeet * 12;
        if (Math.round(finalInches) === 12) {
            const finalFeet = Math.floor(feet) + 1;
            return `${finalFeet} ft`;
        } else {
            const finalFeet = Math.floor(feet);
            return (`${finalFeet} ft ${Math.round(finalInches)} in` === '0 ft 0 in')
                ? '---' : `${finalFeet} ft ${Math.round(finalInches)} in`;
        }
    }

    static feetInchesGroupOverview(feetInches: string[]): string {
        const feetIn = [];
        const inchesIn = [];
        let cummulativeFeet = 0;
        let cummulativeInches = 0;
        let totalFeet = 0;
        let inchesBalance = 0;
        for (const feetInch of feetInches) {
            const feetInchesValue = this.feetToInches(feetInch);
            if (feetInchesValue.feet) {
                feetIn.push(feetInchesValue.feet);
            }
            if (feetInchesValue.inches) {
                inchesIn.push(feetInchesValue.inches);
            }
        }
        for (const feetInchValue of feetIn) {
            cummulativeFeet += parseInt(feetInchValue, 10);
        }
        for (const inchValue of inchesIn) {
            cummulativeInches += parseInt(inchValue, 10);
        }
        if (cummulativeInches >= 12) {
            totalFeet = Math.floor(cummulativeInches / 12);
            inchesBalance = cummulativeInches % 12;
            return this.calculateCumulativeInches(inchesBalance, totalFeet, cummulativeFeet);
        } else {
            return this.calculateCumulativeFeetInches(cummulativeFeet, cummulativeInches);
        }
    }
    static calculateCumulativeInches(inchesBalance, totalFeet, cummulativeFeet) {
        const vl = (inchesBalance > 1) ? ` ${inchesBalance} in` : '';
        return `${totalFeet + cummulativeFeet} ft${(vl)}`;
    }
    static calculateCumulativeFeetInches(cummulativeFeet, cummulativeInches) {
        const cummulativeFeetValue = cummulativeFeet > 1 ? `${cummulativeFeet} ft` : '';
        const cummulativeInchesValue = cummulativeInches > 1 ? `${cummulativeInches} in` : '';
        return (!cummulativeFeetValue && !cummulativeInchesValue) ? '---' : `${cummulativeFeetValue} ${cummulativeInchesValue}`;
    }
    static maxWidthGroupOverview(widthValue: string[]): string {
        const maxWidth = [];
        for (const width of widthValue) {
            if (width && !width.includes('---') && width.trim().length !== 0) {
                const feetInchesValue = this.feetToInches(width);
                const feetToInchesValue = this.getCumulativeValues(feetInchesValue.feet);
                const inches = (feetInchesValue.inches) ? parseInt(feetInchesValue.inches, 10) : 0;
                const completeInches = feetToInchesValue + inches;
                maxWidth.push(completeInches);
            }
        }
        const feetInchesFormat = LodashUtils.max(maxWidth);
        return (feetInchesFormat) ? this.feetInchesFormat(feetInchesFormat) : '---';
    }
    static feetInchesFormat(inchesValue: number): string {
        if (inchesValue >= 12) {
            const totalFeet = Math.floor(inchesValue / 12);
            const inchesBalance = inchesValue % 12;
            return (inchesBalance > 0) ? `${totalFeet} ft ${(inchesBalance)} in` : `${totalFeet} ft`;
        } else {
            return `${inchesValue} in`;
        }
    }
    static getCumulativeValues(adjustedValue: string): number {
        if (adjustedValue) {
            if ((adjustedValue.toLowerCase().includes('ft')) && (adjustedValue.toLowerCase().includes('in'))) {
                const feetInch = adjustedValue.split(' ');
                return (parseInt(feetInch[0], 10) * 12) + parseInt(feetInch[2], 10);
            } else if (adjustedValue.toLowerCase().includes('in')) {
                return parseInt(adjustedValue, 10);
            } else {
                return parseInt(adjustedValue, 10) * 12;
            }
        } else {
            return null;
        }
    }
    static systemAdjustedLength(cummulativelength: string): string {
        const thresholdLengthValue = this.getCumulativeValues('65');
        const cummulativeInches = this.getCumulativeValues(cummulativelength);
        const systemAdjustedLength = thresholdLengthValue - cummulativeInches;
        const sytemAdjustedLengthValue = this.feetInchesFormat(Math.abs(systemAdjustedLength));
        return (cummulativeInches > thresholdLengthValue) ? `-${sytemAdjustedLengthValue}` : '---';
    }
    static systemAdjustedHeight(cummulativeHeight: string): string {
        const thresholdLengthValue = this.getCumulativeValues('13');
        const thresholdLength = thresholdLengthValue + 6;
        const cummulativeInches = this.getCumulativeValues(cummulativeHeight);
        const systemAdjustedHeight = cummulativeInches - thresholdLength;
        const sytemAdjustedLengthValue = this.feetInchesFormat(Math.abs(systemAdjustedHeight));
        return (cummulativeInches > thresholdLength) ? `-${sytemAdjustedLengthValue}` : '---';
    }
    static systemAdjustedWidth(cummulativeWidth: string): string {
        const thresholdWidthValue = this.getCumulativeValues('9');
        const thresholdWidth = thresholdWidthValue + 2;
        const cummulativeInches = this.getCumulativeValues(cummulativeWidth);
        const systemAdjustedWidth = cummulativeInches - thresholdWidth;
        const sytemAdjustedWidthValue = this.feetInchesFormat(Math.abs(systemAdjustedWidth));
        return (cummulativeInches > thresholdWidth) ? `-${sytemAdjustedWidthValue}` : '---';
    }
    static getAllLength(groupForm: FormArray): string[] {
        return groupForm.controls.map(length => length['controls'].equipmentLength.value);
    }
    static getAllWidth(groupForm: FormArray): string[] {
        return groupForm.controls.map(width => width['controls'].equipmentWidth.value);
    }
    static getAllHeight(groupForm: FormArray): string[] {
        return groupForm.controls.map(height => height['controls'].equipmentHeight.value);
    }
    static getAllEquipmentValues(groupForm: FormArray, equipmentValue): string[] {
        return groupForm.controls.map(equipmentForm => equipmentForm['controls'][equipmentValue].value);
    }
    static getEquipmentClassificationId(equipmentTypeList, selectedEquipmentType): any {
        let equipmentClassificationTypeAssociationId;
        equipmentTypeList.map(equipmentTypes => {
            if (selectedEquipmentType === equipmentTypes.equipmentTypeCode) {
                equipmentClassificationTypeAssociationId = equipmentTypes.
                    equipmentClassificationTypeAssociations[0].equipmentClassificationTypeAssociationID;
            }
            return null;
        });
        return equipmentClassificationTypeAssociationId;
    }
    static validateEquipmentValues(equipmentAddForm, equipmentCreateModel) {
        equipmentAddForm.forEach((element, i) => {
            if (equipmentCreateModel.equipmentLength[i].length > 0) {
                this.updateFormFields(equipmentAddForm, i, 'equipmentLength');
            }
            if (equipmentCreateModel.equipmentWidth[i].length > 0) {
                this.updateFormFields(equipmentAddForm, i, 'equipmentWidth');
            }
            if (equipmentCreateModel.equipmentHeight[i].length > 0) {
                this.updateFormFields(equipmentAddForm, i, 'equipmentHeight');
            }
            const stackedEquipments = element.get('stackedEquipments').controls;
            stackedEquipments.forEach((stackedForm, j) => {
                if (equipmentCreateModel.equipmentLength[`${i}.${j}`].length > 0) {
                    this.updateStackedFormFields(equipmentAddForm, i, j, 'equipmentLength');
                }
                if (equipmentCreateModel.equipmentWidth[`${i}.${j}`].length > 0) {
                    this.updateStackedFormFields(equipmentAddForm, i, j, 'equipmentWidth');
                }
                if (equipmentCreateModel.equipmentHeight[`${i}.${j}`].length > 0) {
                    this.updateStackedFormFields(equipmentAddForm, i, j, 'equipmentHeight');
                }
            });
        });
    }
    static updateFormFields(equipmentAddForm, index, equipmentValue) {
        equipmentAddForm[index].controls[equipmentValue].markAsTouched();
        equipmentAddForm[index].controls[equipmentValue].setValidators([Validators.required]);
        equipmentAddForm[index].controls[equipmentValue].updateValueAndValidity();
    }
    static updateStackedFormFields(equipmentAddForm, pIndex, index, equipmentValue) {
        equipmentAddForm[pIndex].controls.stackedEquipments.controls[index].controls[equipmentValue].markAsTouched();
        equipmentAddForm[pIndex].controls.stackedEquipments.controls[index].controls[equipmentValue].setValidators([Validators.required]);
        equipmentAddForm[pIndex].controls.stackedEquipments.controls[index].controls[equipmentValue].updateValueAndValidity();
    }
    static setOverviewType(groupForm: FormArray): string {
        let stackedItems;
        const base = groupForm.controls.map((category) => {
            const baseFlag = category['controls'].equipmentCategory.value.includes('Tractor' || 'Truck');
            if (!baseFlag) {
                if (category['controls'].stackedEquipments && category['controls'].stackedEquipments.length > 0) {
                    stackedItems = this.getStackFlag(category);
                }
            } else {
                return baseFlag;
            }
        });
        return (base.includes(true) || stackedItems && stackedItems.includes(true)) ? 'Power Pair' : 'Non moving';
    }
    static getStackFlag(category) {
        return category['controls'].stackedEquipments.controls.map((stackCategory) => {
            const stackFlag = stackCategory['controls'].equipmentCategory.value.includes('Tractor' || 'Truck');
            if (stackFlag) {
                return stackFlag;
            }
        });
    }
}
