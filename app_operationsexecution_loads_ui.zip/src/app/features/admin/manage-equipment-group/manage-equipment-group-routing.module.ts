import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EquipmentGroupListComponent } from './equipment-group-list/equipment-group-list.component';
import { EquipmentGroupCreateComponent } from './equipment-group-create/equipment-group-create.component';
import { EquipmentGroupViewComponent } from './equipment-group-view/equipment-group-view.component';
import { EquipmentGroupEditComponent } from './equipment-group-edit/equipment-group-edit.component';
import { EquipmentGroupHistoryComponent } from './equipment-group-history/equipment-group-history.component';
import { UnsavedChangesGuard } from '../../../shared/unsaved-changes.guard';

const routes: Routes = [
  { path: '', component: EquipmentGroupListComponent },
  { path: 'list', component: EquipmentGroupListComponent },
  { path: 'create', component: EquipmentGroupCreateComponent, canDeactivate: [UnsavedChangesGuard] },
  { path: 'view', component: EquipmentGroupViewComponent },
  { path: 'edit', component: EquipmentGroupEditComponent },
  { path: 'auditlist', component: EquipmentGroupHistoryComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [UnsavedChangesGuard],
})
export class ManageEquipmentGroupRoutingModule { }
