import { FormArray } from '@angular/forms';
export interface EquipmentClassification {
    _embedded: EquipmentEmbedded;
    _links: EquipmentLinks;
    page: Page;
}
export interface EquipmentEmbedded {
    equipmentClassifications: EquipmentClassificationsItem[];
}
export interface StatusData {
    status: string;
}
export interface EquipmentClassificationsItem {
    equipmentClassificationCode: string;
    equipmentClassificationDescription: string;
    equipmentFunctionalGroupCode: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: EquipmentLinks;
}
export interface EquipmentLinks {
    self: Self;
    equipmentClassification: EquipmentClassification;
    profile?: Profile;
    search?: Search;
}
export interface Self {
    href: string;
    templated?: boolean;
}
export interface EquipmentClassification {
    href: string;
}
export interface Profile {
    href: string;
}
export interface Search {
    href: string;
}
export interface Page {
    size: number;
    totalElements: number;
    totalPages: number;
    number: number;
}
export interface CountryDetails {
    _embedded: Embedded;
    _links: Links;
    page: Page;
}
export interface Embedded {
    countries: CountriesItem[];
}
export interface CountriesItem {
    countryCode: string;
    countryName: string;
    _links: Links;
}
export interface Links {
    self: Self;
    country?: Country;
}
export interface Self {
    href: string;
    title: string;
}
export interface Country {
    href: string;
    templated: boolean;
    title: string;
}
export interface EquipmentType {
    _embedded: EquipmentTypeEmbedded;
    _links: EquipmentTypeLink;
}
export interface EquipmentTypeEmbedded {
    equipmentTypes: EquipmentTypesItem[];
}
export interface EquipmentTypesItem {
    equipmentTypeCode: string;
    equipmentTypeDescription: string;
    equipmentClassificationTypeAssociations: EquipmentClassificationTypeAssociationsItem[];
    effectiveTimestamp: null;
    expirationTimestamp: null;
    lastUpdateTimestampString: null;
    _links: EquipmentTypeLink;
}
export interface EquipmentClassificationTypeAssociationsItem {
    EquipmentClassificationTypeAssociationID: number;
    equipmentClassificationTypeAssociationID: number;
    equipmentClassification: null;
    effectiveTimestamp: null;
    expirationTimestamp: null;
    lastUpdateTimestampString: null;
}
export interface EquipmentTypeLink {
    self: EquipmentTypeSelf;
    equipmentType?: EquipmentType;
}
export interface EquipmentTypeSelf {
    href: string;
}
export interface EquipmentType {
    href: string;
    templated: boolean;
}
export interface EquipmentGroup {
    standardEquipmentGroup: EquipmentGroupDetails;
}
export interface EquipmentGroupDetails {
    standardEquipmentGroupID: number;
    equipmentGroupName: string;
    equipmentGroupDescription: string;
    equipmentGroupComment: string;
    equipmentGroupTypeCode?: string;
    equipmentGroupTypeCodeDescription?: string;
    countryCode: string;
    countryDescription: string;
    status?: string;
    expirationTimestamp: string;
    standardEquipmentGroupMembers: EquipmentGroupMembers[];
}

export interface EquipmentGroupMembers {
    standardEquipmentGroupMemberId?: number;
    standardEquipmentGroupStackingId?: number;
    stackedStandardEquipmentGroupMemberId?: null;
    equipmentGroupSequenceNumber: number;
    equipmentClassificationCode: string;
    equipmentClassificationDescription: string;
    equipmentTypeCode: string;
    equipmentTypeDescription: string;
    lengthSpecificationCode: string;
    lengthSpecificationDescription: string;
    widthSpecificationCode: string;
    widthSpecificationDescription: string;
    heightSpecificationCode: string;
    heightSpecificationDescription: string;
    stackedEquipments?: EquipmentGroupMembers[];
    lengthSpecificationsVal?: string;
    widthSpecificationsVal?: string;
    heightSpecificationsVal?: string;
}

export interface CreateRequest {
    standardEquipmentGroupId?: number;
    equipmentGroupName: string;
    equipmentGroupDescription: string;
    equipmentGroupComment: string;
    countryCode: string;
    countryDescription: string;
    groupOverviewDetails: GroupOverviewDetails;
    standardEquipmentGroupMembers: StandardEquipmentGroupMembersItem[];
    removedEquipmentMemberIds?: number[];
    unStackedEquipmentIds?: number[];
}
export interface GroupOverviewDetails {
    type: string;
    width: string;
    height: string;
    length: string;
    lengthValue: number;
    widthValue: number;
    heightValue: number;
    systemAdjustedLength: SystemAdjustedValue;
    systemAdjustedHeight: SystemAdjustedValue;
}
export interface SystemAdjustedValue {
    value: number;
    description: string;
}
export interface StandardEquipmentGroupMembersItem {
    standardEquipmentGroupMemberId?: number;
    standardEquipmentGroupStackingId?: number;
    equipmentGroupSequenceNumber: number;
    equipmentClassificationCode: string;
    equipmentClassificationDescription: string;
    equipmentTypeCode: string;
    equipmentTypeDescription: string;
    lengthSpecificationCode: string;
    widthSpecificationCode: string;
    heightSpecificationCode: string;
    stackedEquipments?: StackedEquipmentsItem[];
}
export interface StackedEquipmentsItem {
    equipmentGroupSequenceNumber: number;
    equipmentClassificationCode: string;
    equipmentClassificationDescription: string;
    equipmentTypeCode: string;
    equipmentTypeDescription: string;
    lengthSpecificationCode: string;
    widthSpecificationCode: string;
    heightSpecificationCode: string;
}
export interface EquipmentDimenstion {
    heightQuantity: number;
    lengthQuantity: number;
    unitOfHeightMeasurementCode: string;
    unitOfLengthMeasurementCode: string;
    unitOfWidthMeasurementCode: string;
    widthQuantity: number;
}
export interface EquipmentLength {
    _embedded: EquipmentLengthEmbedded;
    _links: EqipmentLengthLinks;
}
export interface EquipmentLengthEmbedded {
    equipmentRequirementSpecificationAssociations: EquipmentRequirementSpecificationAssociationsItem[];
}
export interface EquipmentRequirementSpecificationAssociationsItem {
    equipmentRequirementSpecificationAssociationID: number;
    equipmentRequirementType: EquipmentRequirementType;
    equipmentRequirementSpecification: EquipmentRequirementSpecification;
    effectiveTimestamp: null;
    expirationTimestamp: null;
    equipmentRequirementSpecificationDetail: null;
    lastUpdateTimestampString: null;
    _links: EqipmentLengthLinks;
}
export interface EquipmentRequirementType {
    equipmentRequirementTypeCode: string;
    equipmentRequirementTypeDescription: string;
    effectiveTimestamp: null;
    expirationTimestamp: null;
    lastUpdateTimestampString: null;
}
export interface EquipmentRequirementSpecification {
    equipmentRequirementSpecificationCode: string;
    equipmentRequirementSpecificationDescription: string;
    effectiveTimestamp: null;
    expirationTimestamp: null;
    lastUpdateTimestampString: null;
}
export interface EqipmentLengthLinks {
    self: EquipmentLengthSelf;
    equipmentRequirementSpecificationAssociation?: EquipmentRequirementSpecificationAssociation;
    equipmentClassificationTypeRequirementAssociations?: EquipmentClassificationTypeRequirementAssociations;
}
export interface EquipmentLengthSelf {
    href: string;
}
export interface EquipmentRequirementSpecificationAssociation {
    href: string;
}
export interface EquipmentClassificationTypeRequirementAssociations {
    href: string;
}
export interface FeetInches {
    feet: string;
    inches: string;
}
export interface ResequenceList {
    inputOrderList: FormArray;
    dialogVisible: boolean;
    index?: number;
    stackOnCategory?: string;
}
export interface ColumnModel {
    field: string;
    header: string;
}
export interface EquipmentValue {
    length: string[];
    width: string[];
    heigth: string[];
}
export interface EquipmentDetails {
    equipmentValue: EquipmentValue[];
}
