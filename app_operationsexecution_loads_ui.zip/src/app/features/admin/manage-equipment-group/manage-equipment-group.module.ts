import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { CalendarModule } from 'primeng/calendar';
import { DialogModule } from 'primeng/dialog';
import { OrderListModule } from 'primeng/orderlist';
import { TooltipModule } from 'primeng/tooltip';


import { DirectivesModule } from './../../../shared/directives/directives.module';
import { JbhFiltersModule } from '../../../shared/jbh-filters/jbh-filters.module';
import { JbhLoaderModule } from './../../../shared/jbh-loader/jbh-loader.module';

import { ManageEquipmentGroupRoutingModule } from './manage-equipment-group-routing.module';
import { EquipmentGroupCreateComponent } from './equipment-group-create/equipment-group-create.component';
import { EquipmentGroupEditComponent } from './equipment-group-edit/equipment-group-edit.component';
import { EquipmentGroupEditService } from './equipment-group-edit/services/equipment-group-edit.service';
import { EquipmentGroupListComponent } from './equipment-group-list/equipment-group-list.component';
import { EquipmentGroupViewComponent } from './equipment-group-view/equipment-group-view.component';
import { EquipmentGroupHistoryComponent } from './equipment-group-history/equipment-group-history.component';
import { EquipmentGroupResequenceComponent } from './equipment-group-resequence/equipment-group-resequence.component';
import { EquipmentGroupStackComponent } from './equipment-group-stack/equipment-group-stack.component';
import { EquipmentGroupFilterComponent } from './equipment-group-list/equipment-group-filter/equipment-group-filter.component';
import { EquipmentGroupListService } from './equipment-group-list/services/equipment-group-list.service';
import { EquipmentGroupCreateService } from './equipment-group-create/services/equipment-group-create.service';
import { EquipmentGroupViewService } from './equipment-group-view/services/equipment-group-view.service';
import { PipesModule } from '../../../shared/pipes/pipes.module';
import { EquipmentGroupListUtility } from './equipment-group-list/services/equipment-group-list-utility.service';
import { EquipmentGroupUtility } from './services/equipment-group.utility';
import { UnitMetricsImperialPipe } from './pipes/unit-metrics-imperial.pipe';

@NgModule({
  imports: [
    CommonModule,
    ManageEquipmentGroupRoutingModule, BreadcrumbModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OrderListModule,
    ButtonModule, MenuModule, TableModule, InputTextModule,
    PanelModule, DropdownModule, InputTextareaModule,
    ConfirmDialogModule, CalendarModule, DirectivesModule,
    JbhFiltersModule, DialogModule, OrderListModule, JbhLoaderModule, PipesModule, TooltipModule
  ],
  declarations: [EquipmentGroupCreateComponent, EquipmentGroupEditComponent, EquipmentGroupListComponent,
    EquipmentGroupViewComponent, EquipmentGroupHistoryComponent, EquipmentGroupStackComponent,
    EquipmentGroupResequenceComponent, EquipmentGroupFilterComponent, UnitMetricsImperialPipe],
  providers: [EquipmentGroupListService, EquipmentGroupCreateService, ConfirmationService, DatePipe, EquipmentGroupViewService,
    EquipmentGroupEditService, EquipmentGroupListUtility, EquipmentGroupUtility]
})
export class ManageEquipmentGroupModule { }
