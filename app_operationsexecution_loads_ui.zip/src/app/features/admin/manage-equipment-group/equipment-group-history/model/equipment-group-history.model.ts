import { HitsModel } from '../../../../model/elastic-response.interface';
import { EquipmentHistoryData } from './equipment-group-history.interface';
import { ColumnInterface } from '../../../../model/common.interface';
import { MenuItem } from '../../../../../../../node_modules/primeng/api';



export class EquipmentGroupHistoryModel {
    loading: boolean;
    totalRecords: number;
    subscribeFlag: boolean;
    equipmentGroupHistoryList: HitsModel[];
    breadcrumb: MenuItem[];
    dateFormat: string;
    time: string;
    from: number;
    size: number;
    equipmentId: number;
    equipmentName: string;
    sortField: string;
    sortOrder: string;
    searchInputValue: string;
    searchValue: string;
    historyObj: EquipmentHistoryData;
    tableColumnHeaders: ColumnInterface[];
    ascendingOrder: string;
    descendingOrder: string;
    constructor() {
        this.breadcrumb = [];
        this.tableColumnHeaders = [{
            'name': 'Updated On',
            'queryKey': 'LastUpdateTimestamp'
        }, {
            'name': 'Updated By',
            'queryKey': 'LastUpdateProgramName.keyword'
        }, {
            'name': 'Field',
            'queryKey': 'LastUpdatedField.keyword'
        }, {
            'name': 'Modifier',
            'queryKey': 'Modifier.keyword'
        }, {
            'name': 'Modified Value - From',
            'queryKey': 'ModiefiedValueFrom.keyword'
        }, {
            'name': 'Modified Value - To',
            'queryKey': 'ModiefiedValueTo.keyword'
        }
        ];
        this.loading = false;
        this.subscribeFlag = true;
        this.searchValue = '';
        this.historyObj = {
            from: 0,
            size: 25,
            searchValue: ''
        };
        this.ascendingOrder = 'asc';
        this.descendingOrder = 'desc';
        this.from = 0;
        this.size = 25;
        this.equipmentGroupHistoryList = [];
    }
}
