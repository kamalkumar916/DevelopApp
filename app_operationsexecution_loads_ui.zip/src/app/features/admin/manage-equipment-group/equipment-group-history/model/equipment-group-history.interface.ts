export interface EquipmentHistoryData {
    from: number;
    size: number;
    searchValue: string;
}

export interface EquipmentGroupHistoryInterface {
    LastUpdateTimestamp;
    LastUpdateProgramName;
    LastUpdateUserID;
    LastUpdatedField;
    Modifier;
    ModiefiedValueFrom;
    ModiefiedValueTo;
}
