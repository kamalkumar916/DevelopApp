import { EquipmentGroupHistoryModel } from '../model/equipment-group-history.model';
import * as lodashutils from 'lodash';

export class EquipmentGroupHistoryQuery {
    static sortObject(model: EquipmentGroupHistoryModel, sortField: string, orderBy: string): object {
        const sortObj = {};
        const responseData = lodashutils.find(model.tableColumnHeaders, { name: sortField });
        sortObj[responseData.queryKey] = { order: orderBy };
        return sortObj;
    }

    static fetchSearchHistoryData(model: EquipmentGroupHistoryModel, start: number, size: number, sortField: string, orderBy: string) {
        const searchString = model.historyObj['searchValue'];
        return {

            'from': start,
            'size': size,
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'StandardEquipmentGroupID': {
                                    'value': model.equipmentId
                                }
                            }
                        },

                        {
                            'bool': {
                                'should': [
                                    {
                                        'query_string': {
                                            'default_field': 'LastUpdateTimestamp.text',
                                            'query': `*${searchString}*`,
                                            'default_operator': 'AND'
                                        }
                                    },
                                    {
                                        'query_string': {
                                            'fields': [
                                                'LastUpdateProgramName',
                                                'LastUpdateUserID'
                                            ],
                                            'query': `*${searchString}*`,
                                            'default_operator': 'AND'
                                        }
                                    },
                                    {
                                        'query_string': {
                                            'default_field': 'LastUpdatedField',
                                            'query': `*${searchString}*`,
                                            'default_operator': 'AND'
                                        }
                                    },
                                    {
                                        'query_string': {
                                            'default_field': 'Modifier',
                                            'query': `*${searchString}*`,
                                            'default_operator': 'AND'
                                        }
                                    },
                                    {
                                        'query_string': {
                                            'default_field': 'ModiefiedValueFrom',
                                            'query': `*${searchString}*`,
                                            'default_operator': 'AND'
                                        }
                                    },
                                    {
                                        'query_string': {
                                            'default_field': 'ModiefiedValueTo',
                                            'query': `*${searchString}*`,
                                            'default_operator': 'AND'
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                }
            },
            'sort': [this.sortObject(model, sortField, orderBy), {
                'AuditSequenceNumber': {
                    'order': 'asc'
                }
            }
            ]
        };
    }
}



