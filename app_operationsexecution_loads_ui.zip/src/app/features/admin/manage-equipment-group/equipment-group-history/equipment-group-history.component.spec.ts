import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';

import { EquipmentGroupHistoryComponent } from './equipment-group-history.component';
import { configureTestSuite } from 'ng-bullet';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { FormsModule } from '@angular/forms';
import { TooltipModule } from 'primeng/tooltip';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs/internal/observable/of';
import { EquipmentGroupHistoryService } from './services/equipment-group-history.service';
import { By } from '@angular/platform-browser';

const mockRes = {
  hits: {
    hits: {
      sort: {
        0: 1572507360000,
        1: 1
      },
      _id: 'Cxa-IG4BT-qcQqaToG8E',
      _index: 'operationsexecution-equipmentpair-audit-1-2019.05.15',
      _score: null,
      _source: {
        AuditSequenceNumber: 1,
        EquipmentGroupName: 'AUTOMATION CHECK 274',
        LastUpdateProgramName: 'Process ID',
        LastUpdateTimestamp: '10/31/2019 02:36 AM CDT',
        LastUpdateUserID: 'jcnt740',
        LastUpdatedField: 'Name',
        ModiefiedValueFrom: 'AUTOMATION CHECK 274',
        ModiefiedValueTo: null,
        Modifier: 'Added',
        StandardEquipmentGroupAuditID: '2613',
        StandardEquipmentGroupID: 711
      },
      _type: 'doc',
    },
  },
  timed_out: false,
  took: 7,
  _shards: {
    failed: 0,
    skipped: 0,
    successful: 3,
    total: 3
  }
};
class MockequipmentGroupHistoryService {
  constructor() {
  }
  getEquipmentGroupHistory() {
    return of(mockRes);
  }
}
describe('EquipmentGroupHistoryComponent', () => {
  let component: EquipmentGroupHistoryComponent;
  let fixture: ComponentFixture<EquipmentGroupHistoryComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, BreadcrumbModule, MenuModule, TableModule, DirectivesModule, FormsModule, TooltipModule],
      providers: [UserService, AppConfigService, MessageService, EquipmentGroupHistoryService],
      declarations: [EquipmentGroupHistoryComponent]
    })
      .compileComponents();
    TestBed.overrideComponent(
      EquipmentGroupHistoryComponent,
      {
        set: {
          providers: [
            {
              provide: EquipmentGroupHistoryService, useClass: MockequipmentGroupHistoryService
            }
          ]
        }
      }
    );
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupHistoryComponent);
    component = fixture.componentInstance;
    TestBed.get(ActivatedRoute).queryParams = {
      value: {
        standardEquipmentGroupID: 1
      }
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('onPage have been called', () => {
    spyOn(component, 'fetchEquipmentGroupHistory');
    component.onPage({ first: '', rows: '' });
    expect(component.fetchEquipmentGroupHistory).toHaveBeenCalled();
  });
  it('onSortSelect have been called', () => {
    const columnInterface = {
      name: '',
      queryKey: ''
    };
    spyOn(component, 'fetchEquipmentGroupHistory');
    component.onSortSelect(columnInterface);
    expect(component.fetchEquipmentGroupHistory).toHaveBeenCalled();
  });
  it('onSearch', fakeAsync(() => {
    spyOn(component, 'fetchEquipmentGroupHistory');
    const input = fixture.debugElement.query(By.css('#equipmentGroupHistorySearchText'));
    input.triggerEventHandler('input', { target: { value: '' } });
    tick(300);
    expect(component.fetchEquipmentGroupHistory).toHaveBeenCalled();
  }));
  it('onSearch', fakeAsync(() => {
    spyOn(component, 'fetchEquipmentGroupHistory');
    const input = fixture.debugElement.query(By.css('#equipmentGroupHistorySearchText'));
    input.triggerEventHandler('input', { target: { value: 'abcd' } });
    tick(300);
    expect(component.fetchEquipmentGroupHistory).toHaveBeenCalled();
  }));
});


