import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, OnDestroy, ViewChild } from '@angular/core';
import { distinctUntilChanged, debounceTime, takeWhile, finalize } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

import { EquipmentGroupHistoryService } from './services/equipment-group-history.service';
import { EquipmentGroupHistoryModel } from './model/equipment-group-history.model';
import { EquipmentGroupHistoryQuery } from './query/equipment-group-history-query';
import { ColumnInterface } from './../../../model/common.interface';
import { ManageEquipmentGroupRoutelinks } from '../manage-equipment-group-route-links';
@Component({
  selector: 'app-equipment-group-history',
  templateUrl: './equipment-group-history.component.html',
  styleUrls: ['./equipment-group-history.component.scss'],
  providers: [EquipmentGroupHistoryService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EquipmentGroupHistoryComponent implements OnInit, OnDestroy {
  @ViewChild('equipmentGroupHistory') equipmentGroupHistory;
  equipmentGroupHistoryModel: EquipmentGroupHistoryModel;
  searchTerms: Subject<string>;
  constructor(private readonly changeDetector: ChangeDetectorRef, private readonly activatedRoute: ActivatedRoute,
    private readonly equipmentGroupHistoryService: EquipmentGroupHistoryService) {
    this.equipmentGroupHistoryModel = new EquipmentGroupHistoryModel();
    this.searchTerms = new Subject<string>();
    this.equipmentGroupHistoryModel.sortField = 'Updated On';
    this.equipmentGroupHistoryModel.sortOrder = this.equipmentGroupHistoryModel.descendingOrder;
  }
  ngOnInit() {
    this.searchByText();
    if (this.activatedRoute.queryParams['value']['standardEquipmentGroupID']) {
      this.equipmentGroupHistoryModel.equipmentId = this.activatedRoute.queryParams['value']['standardEquipmentGroupID'];

      this.equipmentGroupHistoryModel.breadcrumb =
        ManageEquipmentGroupRoutelinks.historyBreadCrumb(this.equipmentGroupHistoryModel.equipmentId);
      this.fetchEquipmentGroupHistory();
    }
  }
  ngOnDestroy() {
    this.equipmentGroupHistoryModel.subscribeFlag = false;
  }
  fetchEquipmentGroupHistory() {
    this.equipmentGroupHistoryModel.totalRecords = 0;
    this.equipmentGroupHistoryModel.loading = true;
    const esQuery = EquipmentGroupHistoryQuery.fetchSearchHistoryData(this.equipmentGroupHistoryModel, this.equipmentGroupHistoryModel.from,
      this.equipmentGroupHistoryModel.size, this.equipmentGroupHistoryModel.sortField, this.equipmentGroupHistoryModel.sortOrder);
    this.equipmentGroupHistoryService.getEquipmentGroupHistory(esQuery)
      .pipe(takeWhile(() => this.equipmentGroupHistoryModel.subscribeFlag),
        finalize(() => {
          this.changeDetector.detectChanges();
        })).subscribe((data) => {
          this.equipmentGroupHistoryModel.loading = false;
          if (data && data.hits && data.hits.hits) {
            this.equipmentGroupHistoryModel.equipmentGroupHistoryList = data.hits.hits;
            this.equipmentGroupHistoryModel.equipmentName = this.equipmentGroupHistoryModel.
              equipmentGroupHistoryList[0]._source.EquipmentGroupName;
            this.equipmentGroupHistoryModel.totalRecords = data.hits.total;
          }
        }, (error: Error) => {
          this.equipmentGroupHistoryModel.equipmentGroupHistoryList = [];
          this.equipmentGroupHistoryModel.loading = false;
        });
  }
  onPage(event) {
    this.equipmentGroupHistoryModel.from = event.first;
    this.equipmentGroupHistoryModel.size = event.rows;
    this.fetchEquipmentGroupHistory();
  }
  onSortSelect(selectedColumnName: ColumnInterface) {
    this.equipmentGroupHistoryModel.sortField = selectedColumnName['name'];
    this.equipmentGroupHistoryModel.sortOrder =
      (this.equipmentGroupHistoryModel.sortOrder === this.equipmentGroupHistoryModel.descendingOrder)
        ? this.equipmentGroupHistoryModel.ascendingOrder : this.equipmentGroupHistoryModel.descendingOrder;
    this.fetchEquipmentGroupHistory();
  }
  onSearch(event: string) {
    if (event) {
      this.searchTerms.next(event);
      if (!event['data']) {
        this.equipmentGroupHistory.first = 0;
        this.equipmentGroupHistoryModel.from = 0;
        this.equipmentGroupHistoryModel.size = 25;
        this.fetchEquipmentGroupHistory();

      }
    }
  }
  searchByText() {
    this.searchTerms.pipe(debounceTime(300), distinctUntilChanged(),
      takeWhile(() => this.equipmentGroupHistoryModel.subscribeFlag))
      .subscribe((shareData) => {
        if (shareData) {
          if (shareData['target']['value'].match('^[0-9,]*$')) {
            this.equipmentGroupHistoryModel.searchValue = shareData['target']['value'].replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
            this.equipmentGroupHistoryModel.searchValue = this.equipmentGroupHistoryModel.searchValue.replace(/\,/g, '');
          } else if (shareData['target']['value'].match('[()]')) {
            this.equipmentGroupHistoryModel.searchValue = shareData['target']['value'].replace(/[()]/g, '');
          } else {
            this.equipmentGroupHistoryModel.searchValue = shareData['target']['value'].replace(/[[\]{}()*:\-"~&!\/?\\^$|]/g, '\\$&');
          }
          if (this.equipmentGroupHistoryModel.searchValue) {
            if (this.equipmentGroupHistoryModel.searchValue.length > 2) {
              this.equipmentGroupHistoryModel.from = 0;
              this.equipmentGroupHistoryModel.size = 25;
              this.equipmentGroupHistory.first = 0;
              this.equipmentGroupHistoryModel.historyObj['searchValue'] = this.equipmentGroupHistoryModel.searchValue;
              this.fetchEquipmentGroupHistory();
            }
          } else if (this.equipmentGroupHistoryModel.searchValue === '') {
            this.equipmentGroupHistoryModel.historyObj['searchValue'] = '';
            this.fetchEquipmentGroupHistory();
          }
        }
      }, (error) => {
        this.equipmentGroupHistoryModel.equipmentGroupHistoryList = [];
        this.equipmentGroupHistoryModel.loading = false;
      });
  }
}
