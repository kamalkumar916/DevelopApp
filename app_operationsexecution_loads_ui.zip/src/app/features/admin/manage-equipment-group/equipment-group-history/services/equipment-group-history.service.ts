import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

import { AppConfigService } from './../../../../../shared/service/app-config.service';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';
import { Observable } from 'rxjs';
@Injectable()
export class EquipmentGroupHistoryService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('manageEquipmentGroup');
  }
  getEquipmentGroupHistory(esQuery: Object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getEquipmentGroupHistory, esQuery);
  }
}


