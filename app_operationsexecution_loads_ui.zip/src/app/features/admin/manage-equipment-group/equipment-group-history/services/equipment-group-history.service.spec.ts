import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { EquipmentGroupHistoryService } from './equipment-group-history.service';
import { configureTestSuite } from 'ng-bullet';

describe('EquipmentGroupHistoryService', () => {
  let service: EquipmentGroupHistoryService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        EquipmentGroupHistoryService,
        AppConfigService
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.get(EquipmentGroupHistoryService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getEquipmentGroupHistory expected calls', () => {
    const esQuery = { value: true };
    service.getEquipmentGroupHistory(esQuery).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentGroupHistory);
    expect(req.request.method).toEqual('POST');
  });

});





