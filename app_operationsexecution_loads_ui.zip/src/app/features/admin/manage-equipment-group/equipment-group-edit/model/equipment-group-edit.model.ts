import { FormArray, FormGroup } from '@angular/forms';
import { MenuItem, SelectItem } from 'primeng/api';
import {
    CreateRequest, EquipmentTypesItem, ResequenceList, EquipmentGroupMembers, EquipmentGroupDetails
} from '../../model/equipment-group.interface';
import { ActivatedRoute } from '@angular/router';
import { AppConfig } from '../../../../../../config/app.config';
import { SecureModel } from '../../../../../shared/directives/models/secure.model';

export class EquipmentGroupEdit {
    hasSubscribe: boolean;
    equipmentDetails: EquipmentGroupDetails;
    equipmentGroup: EquipmentGroupMembers[];
    unitTypes: SelectItem[];
    inputResequenceList: ResequenceList;
    equipmentDetailsForm: FormGroup;
    countriesList: SelectItem[];
    equipmentCategoryList: SelectItem[];
    equipmentTypeList: SelectItem[][];
    equipmentTypeIds: EquipmentTypesItem[][];
    equipmentLengthList: SelectItem[][];
    equipmentWidthList: SelectItem[][];
    equipmentHeightList: SelectItem[][];
    hasForm: boolean;
    showActivateBtn: boolean;
    overFlowMenuItems: MenuItem[][];
    stackOverFlowMenuItems: MenuItem[][];
    type: string;
    requestObject: CreateRequest;
    sectionLoading: boolean;
    overviewWidthValue: string;
    overviewLengthValue: string;
    overviewHeightValue: string;
    systemAdjustedLength: string;
    systemAdjustedHeight: string;
    unitOfMeasure: string;
    equipmentId: number;
    removedEquipments: number[];
    unStackedEquipments: number[];
    hasCountryChanged: boolean;
    selectedCountryDetail: SelectItem[];
    isEditedFlag: boolean;
    inputStackList: ResequenceList;
    stackingControl: FormArray;
    stackEquipmentFlag: boolean;
    addStackedEquipmentFlag: boolean;
    routingLink: any;
    appConfig;
    activationButton: SecureModel;
    editButton: SecureModel;
    constructor(private readonly activatedRoute: ActivatedRoute) {
        this.hasSubscribe = true;
        this.sectionLoading = false;
        this.hasForm = false;
        this.showActivateBtn = false;
        this.hasCountryChanged = false;
        this.isEditedFlag = false;
        this.stackEquipmentFlag = false;
        this.addStackedEquipmentFlag = false;
        this.unitTypes = [
            { label: 'Imperial', value: 'Imperial' },
            { label: 'Metric', value: 'Metric' },
        ];
        this.overFlowMenuItems = [];
        this.stackOverFlowMenuItems = [];
        this.countriesList = [];
        this.equipmentCategoryList = [];
        this.equipmentTypeList = [];
        this.equipmentTypeIds = [];
        this.equipmentLengthList = [];
        this.equipmentWidthList = [];
        this.equipmentHeightList = [];
        this.equipmentGroup = [];
        this.removedEquipments = [];
        this.unStackedEquipments = [];
        this.requestObject = {
            equipmentGroupName: '',
            equipmentGroupDescription: '',
            equipmentGroupComment: '',
            countryCode: '',
            countryDescription: '',
            groupOverviewDetails: null,
            standardEquipmentGroupMembers: []
        };
        this.appConfig = AppConfig.getConfig();
        this.activationButton = { url: this.appConfig.api.manageEquipmentGroup.equipmentDetails, operation: 'C' };
        this.editButton = { url: this.appConfig.api.manageEquipmentGroup.createEquipmentGroup, operation: 'C' };
    }
}
