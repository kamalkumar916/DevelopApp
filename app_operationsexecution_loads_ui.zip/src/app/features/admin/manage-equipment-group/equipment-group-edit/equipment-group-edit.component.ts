import { Component, OnInit, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder } from '@angular/forms';
import { ConfirmationService, SelectItem } from 'primeng/api';
import { takeWhile } from 'rxjs/operators';
import { timer } from 'rxjs';
import { MessageService } from 'primeng/components/common/messageservice';
import * as lodashUtils from 'lodash';

import {
  EquipmentType, EquipmentGroupDetails, EquipmentGroupMembers, StatusData
} from '../model/equipment-group.interface';
import { EquipmentGroupUtility } from '../services/equipment-group.utility';
import { EquipmentGroupEdit } from './model/equipment-group-edit.model';
import { EquipmentGroupEditUtils } from './services/equipment-group-edit.utils';
import { EquipmentGroupEditService } from './services/equipment-group-edit.service';
import { UnitMetricsImperialPipe } from '../pipes/unit-metrics-imperial.pipe';
import { ManageEquipmentGroupRoutelinks } from '../manage-equipment-group-route-links';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';

@Component({
  selector: 'app-equipment-group-edit',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './equipment-group-edit.component.html',
  styleUrls: ['./equipment-group-edit.component.scss']
})
export class EquipmentGroupEditComponent implements OnInit, OnDestroy {
  @ViewChild('resequence') resequenceButton;
  equipmentGroupEditModel: EquipmentGroupEdit;
  equipmentGroupRoutes = ManageEquipmentGroupRoutelinks;
  constructor(private readonly router: Router, private readonly confirmationService: ConfirmationService,
    private readonly activatedRoute: ActivatedRoute, private readonly fb: FormBuilder,
    private readonly equipmentGroupEditService: EquipmentGroupEditService,
    private readonly changeDetector: ChangeDetectorRef, private readonly toastMessage: MessageService) {
    this.equipmentGroupEditModel = new EquipmentGroupEdit(activatedRoute);
  }

  ngOnInit() {
    if (this.activatedRoute.queryParams['value']['standardEquipmentGroupID']) {
      EquipmentGroupEditUtils.initializeEquipmentFormDetails(this.equipmentGroupEditModel, this.fb);
      this.getCountryDetails();
      this.getEquipmentCategory();
      this.viewEquipmentDetails(this.activatedRoute.queryParams['value']['standardEquipmentGroupID']);
    }
  }
  ngOnDestroy() {
    if (this.equipmentGroupEditModel.equipmentDetailsForm) {
      this.equipmentGroupEditModel.equipmentDetailsForm.removeControl('equipmentGroupForm');
    }
    this.equipmentGroupEditModel.hasSubscribe = false;
  }
  getEquipmentGroupForm(): FormArray {
    return this.equipmentGroupEditModel.equipmentDetailsForm.controls['equipmentGroupForm'] as FormArray;
  }
  getStackedEquipmentsForm(index: number): FormArray {
    return this.equipmentGroupEditModel.equipmentDetailsForm.
      get('equipmentGroupForm')['controls'][index].get('stackedEquipments') as FormArray;
  }
  get equipmentDetailsForm() {
    return this.equipmentGroupEditModel.equipmentDetailsForm.get('equipmentGroupForm')['controls'];
  }
  validateFormFields(fieldName: string, index: number) {
    return (this.equipmentDetailsForm[index].controls[fieldName].invalid && this.equipmentDetailsForm[index].controls[fieldName].touched);
  }
  validateStackFormFields(fieldName: string, baseIndex: number, stackIndex: number) {
    return (this.equipmentDetailsForm[baseIndex].controls['stackedEquipments'].controls[stackIndex].invalid &&
      this.equipmentDetailsForm[baseIndex].controls['stackedEquipments'].controls[stackIndex].touched);
  }
  initializeEquipmentForm() {
    this.equipmentGroupEditModel.equipmentDetailsForm.setControl('equipmentGroupForm', this.loadFormArrayElements());
    EquipmentGroupEditUtils.populateEquipmentDetailsForm(this.equipmentGroupEditModel, this.fb);
  }
  loadFormArrayElements(): FormArray {
    const equipmentGroup = this.equipmentGroupEditModel.equipmentGroup;
    const elementsArr: FormArray = this.getEquipmentGroupForm();
    for (let i = 0; i < equipmentGroup.length; i++) {
      EquipmentGroupEditUtils.prePopulateDetails(equipmentGroup[i]);
      elementsArr.insert(i, EquipmentGroupEditUtils.setEquipmentFormGroup(this.fb, i));
    }
    return elementsArr;
  }
  initializeStackForm(parentIndex, stackedEquipments) {
    const detailsForm = this.equipmentGroupEditModel.equipmentDetailsForm.get(`equipmentGroupForm`);
    detailsForm['controls'][parentIndex].setControl('stackedEquipments', this.fb.array([]));
    return detailsForm['controls'][parentIndex];
  }
  getCountryDetails() {
    this.equipmentGroupEditModel.sectionLoading = true;
    this.equipmentGroupEditService.getCountryDetails().pipe(takeWhile(() => this.equipmentGroupEditModel.hasSubscribe))
      .subscribe((data: SelectItem[]) => {
        if (data) {
          this.equipmentGroupEditModel.sectionLoading = false;
          this.equipmentGroupEditModel.countriesList = data;
        }
      }, (error: Error) => {
        this.equipmentGroupEditModel.sectionLoading = false;
      });
  }
  getEquipmentCategory() {
    this.equipmentGroupEditModel.sectionLoading = true;
    this.equipmentGroupEditService.getEquipmentCategory().pipe(takeWhile(() => this.equipmentGroupEditModel.hasSubscribe))
      .subscribe((data: SelectItem[]) => {
        this.equipmentGroupEditModel.equipmentCategoryList = data;
        this.equipmentGroupEditModel.sectionLoading = false;
      }, (error: Error) => {
        this.equipmentGroupEditModel.sectionLoading = false;
      });
  }
  viewEquipmentDetails(equipmentId: number) {
    this.equipmentGroupEditModel.sectionLoading = true;
    this.equipmentGroupEditService.getEquipmentDetails(equipmentId)
      .pipe(takeWhile(() => this.equipmentGroupEditModel.hasSubscribe))
      .subscribe((data: EquipmentGroupDetails) => {
        if (data) {
          this.equipmentGroupEditModel.equipmentDetails = data;
          this.equipmentGroupEditModel.equipmentGroup = lodashUtils.
            sortBy(data.standardEquipmentGroupMembers, 'equipmentGroupSequenceNumber');
          if (this.equipmentGroupEditModel.equipmentDetails.status.toLowerCase() === 'inactive') {
            this.equipmentGroupEditModel.showActivateBtn = false;
          }
          this.loadEquipmentType(this.equipmentGroupEditModel.equipmentGroup);
          this.initializeEquipmentForm();
          const equipmentGroupControls = this.equipmentGroupEditModel.equipmentDetailsForm;
          const equipDetail = this.equipmentGroupEditModel.equipmentDetails;
          equipmentGroupControls.patchValue({
            name: equipDetail.equipmentGroupName,
            description: equipDetail.equipmentGroupDescription,
            country: equipDetail.countryCode,
            comments: equipDetail.equipmentGroupComment
          });
          EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel, 'default');
        }
      }, (error: Error) => {
        this.equipmentGroupEditModel.sectionLoading = false;
      });
  }
  onSelectCategory(selectedCategory: string, index: number, resetFlag: boolean, stackedIndex?: number) {
    let arrayIndex;
    if (stackedIndex !== undefined) {
      arrayIndex = `${index}.${stackedIndex}`;
    } else {
      arrayIndex = index;
    }
    if (resetFlag) {
      if (stackedIndex !== undefined) {
        this.equipmentDetailsForm[index].get(`stackedEquipments`).controls[stackedIndex].get(`equipmentType`).setValue('');
        this.equipmentDetailsForm[index].get(`stackedEquipments`).controls[stackedIndex].get(`equipmentLength`).setValue('');
        this.equipmentDetailsForm[index].get(`stackedEquipments`).controls[stackedIndex].get(`equipmentWidth`).setValue('');
        this.equipmentDetailsForm[index].get(`stackedEquipments`).controls[stackedIndex].get(`equipmentHeight`).setValue('');
      } else {
        this.equipmentDetailsForm[index].controls.equipmentType.setValue('');
        this.equipmentDetailsForm[index].controls.equipmentLength.setValue('');
        this.equipmentDetailsForm[index].controls.equipmentWidth.setValue('');
        this.equipmentDetailsForm[index].controls.equipmentHeight.setValue('');
      }
    }
    this.equipmentGroupEditModel.type = EquipmentGroupUtility.setOverviewType(this.getEquipmentGroupForm());
    this.getEquipmentType(selectedCategory, index, arrayIndex);
    EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
  }
  onSelectCountry(countryValue: string) {
    this.equipmentGroupEditModel.selectedCountryDetail =
      lodashUtils.filter(this.equipmentGroupEditModel.countriesList, ['value', countryValue]);
    this.equipmentGroupEditModel.hasCountryChanged = true;
  }
  getEquipmentType(equipmentCode: string, index: string | number, stackedIndex?: string | number) {
    this.equipmentGroupEditModel.sectionLoading = true;
    this.equipmentGroupEditService.getEquipmentType(equipmentCode).pipe(takeWhile(() => this.equipmentGroupEditModel.hasSubscribe))
      .subscribe((data: SelectItem[]) => {
        this.equipmentGroupEditModel.sectionLoading = false;
        if (stackedIndex) {
          this.equipmentGroupEditModel.equipmentTypeList[stackedIndex] = data;
          this.getEquipmentAssociations(equipmentCode, index, stackedIndex);
        } else {
          this.equipmentGroupEditModel.equipmentTypeList[index] = data;
          this.getEquipmentAssociations(equipmentCode, index);
        }
        this.changeDetector.detectChanges();
      }, (error: Error) => {
        this.equipmentGroupEditModel.sectionLoading = false;
      });
  }
  getEquipmentAssociations(equipmentCode: string, index: any, stackedindex?: any) {
    const groupForm = this.equipmentGroupEditModel.equipmentDetailsForm.controls.equipmentGroupForm;
    this.equipmentGroupEditService.getEquipmentTypeIds(equipmentCode).pipe(takeWhile(() => this.equipmentGroupEditModel.hasSubscribe))
      .subscribe((data: EquipmentType) => {
        this.equipmentGroupEditModel.sectionLoading = false;
        if (stackedindex) {
          this.equipmentGroupEditModel.equipmentTypeIds[stackedindex] = data._embedded.equipmentTypes;
          if (lodashUtils.includes(stackedindex, '.')) {
            const formIndex = stackedindex.split('.');
            if (groupForm.value[formIndex[0]].stackedEquipments && groupForm.value[formIndex[0]].stackedEquipments.length > 0) {
              const typeVal = groupForm.value[formIndex[0]].stackedEquipments[formIndex[1]].equipmentType;
              this.onSelectEquipmentType(typeVal, index, stackedindex);
            }
          }
        } else {
          this.equipmentGroupEditModel.equipmentTypeIds[index] = data._embedded.equipmentTypes;
          const typeVal = groupForm.value[index].equipmentType;
          this.onSelectEquipmentType(typeVal, index);
        }
      }, (error: Error) => {
        this.equipmentGroupEditModel.sectionLoading = false;
      });
  }
  selectEquipmentType(selectedType: string, index: number, resetFlag: boolean, stackedIndex?: string | number) {
    let arrayIndex;
    if (stackedIndex !== undefined) {
      arrayIndex = `${index}.${stackedIndex}`;
    } else {
      arrayIndex = index;
    }
    const selValue = lodashUtils.filter(this.equipmentGroupEditModel.equipmentTypeList[arrayIndex], ['value', selectedType]);
    if (resetFlag) {
      if (stackedIndex !== undefined) {
        this.equipmentDetailsForm[index].get(`stackedEquipments`).controls[stackedIndex].get(`equipmentLength`).setValue('');
        this.equipmentDetailsForm[index].get(`stackedEquipments`).controls[stackedIndex].get(`equipmentWidth`).setValue('');
        this.equipmentDetailsForm[index].get(`stackedEquipments`).controls[stackedIndex].get(`equipmentHeight`).setValue('');
      } else {
        this.equipmentDetailsForm[index].controls.equipmentLength.setValue('');
        this.equipmentDetailsForm[index].controls.equipmentWidth.setValue('');
        this.equipmentDetailsForm[index].controls.equipmentHeight.setValue('');
      }
    }
    if (selValue && selValue.length > 0) {
      this.equipmentDetailsForm[index].controls.equipmentTypeDescription.setValue(selValue[0].label);
    }
    if (stackedIndex !== undefined) {
      this.onSelectEquipmentType(selectedType, index, `${index}.${stackedIndex}`);
    } else {
      this.onSelectEquipmentType(selectedType, index);
    }
    EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
  }
  onSelectEquipmentType(selectedType: string, index: number, stackedindex?: string) {
    if (selectedType) {
      this.equipmentGroupEditService.getEquipmentDimension(this.equipmentGroupEditModel, this.changeDetector,
        selectedType, index, stackedindex);
    }
  }
  loadEquipmentType(equipmentGroup: EquipmentGroupMembers[]) {
    if (equipmentGroup) {
      equipmentGroup.forEach((element, index) => {
        this.getEquipmentType(element.equipmentClassificationCode, index);
        if (element.stackedEquipments) {
          const stackedItems = element.stackedEquipments;
          stackedItems.forEach((stack, stackedindex) => {
            const stackData = `${index}.${stackedindex}`;
            this.getEquipmentType(stack.equipmentClassificationCode, stackedindex, stackData);
          });
        }
      });
    }
  }
  thresholdExceedWarning(index?: number, equipmentValue?: string) {
    const detailsForm = this.equipmentGroupEditModel.equipmentDetailsForm.get('equipmentGroupForm')['controls'];
    this.confirmationService.confirm({
      message: `You have reached the equipment sizing threshold.Continuing will result
      in updating adjusted equipment specifications.<p></p>
      Are you sure you want to continue?`,
      header: 'Warning',
      key: 'thresholdWarning',
      accept: (): void => {
      },
      reject: (): void => {
        detailsForm[index].controls[equipmentValue].setValue('');
        EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
      }
    });
  }
  onSelectEquipmentLength(selectedLength: string, index: number) {
    this.equipmentGroupEditModel.overviewLengthValue =
      EquipmentGroupUtility.feetInchesGroupOverview(this.groupOverviewLengthWidthHeight('length'));
    this.equipmentGroupEditModel.systemAdjustedLength =
      EquipmentGroupUtility.systemAdjustedLength(this.equipmentGroupEditModel.overviewLengthValue);
    if (this.equipmentGroupEditModel.systemAdjustedLength !== '---') {
      this.thresholdExceedWarning(index, 'equipmentLength');
    }
  }
  onSelectEquipmentWidth(selectedLength: string, index: number) {
    this.equipmentGroupEditModel.overviewWidthValue =
      EquipmentGroupUtility.maxWidthGroupOverview(this.groupOverviewLengthWidthHeight('width'));
  }
  onSelectEquipmentHeight(selectedLength: string, index: number) {
    this.equipmentGroupEditModel.overviewHeightValue =
      EquipmentGroupUtility.maxWidthGroupOverview(this.groupOverviewLengthWidthHeight('height'));
    this.equipmentGroupEditModel.systemAdjustedHeight =
      EquipmentGroupUtility.systemAdjustedHeight(this.equipmentGroupEditModel.overviewHeightValue);
    if (this.equipmentGroupEditModel.systemAdjustedHeight !== '---') {
      this.thresholdExceedWarning(index, 'equipmentHeight');
    }
  }
  groupOverviewLengthWidthHeight(equipmentType: string) {
    const requestObj = EquipmentGroupEditUtils.generateRequestObject(this.equipmentGroupEditModel.equipmentDetailsForm,
      this.equipmentGroupEditModel);
    const SpecificationCodeDimension =
      new UnitMetricsImperialPipe().transform(requestObj.standardEquipmentGroupMembers, 'lengthWidthHeigthCalculation');
    return new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', equipmentType);
  }
  onClickResequence() {
    this.equipmentGroupEditModel.inputResequenceList = {
      'inputOrderList': this.equipmentGroupEditModel.equipmentDetailsForm.controls.equipmentGroupForm['controls'],
      'dialogVisible': true
    };
    this.resequenceButton.nativeElement.blur();
  }
  afterResequence(resequencedList: FormArray) {
    this.equipmentGroupEditModel.equipmentDetailsForm.setControl('equipmentGroupForm', this.fb.array([]));
    const controlVal: FormArray = this.getEquipmentGroupForm();
    this.equipmentGroupEditModel.isEditedFlag = true;
    for (let i = 0; i < resequencedList.length; i++) {
      controlVal.insert(i, resequencedList[i]);
      controlVal.controls[i]['controls']['equipmentGroupSequenceNumber'].setValue(i + 1);
      this.getEquipmentType(resequencedList[i].value.equipmentCategory, i);
      const stackLength = controlVal.controls[i]['controls'].stackedEquipments.controls;
      if (stackLength && stackLength.length > 0) {
        for (let j = 0; j < stackLength.length; j++) {
          this.getEquipmentType(stackLength[j].value.equipmentCategory, j, `${i}.${j}`);
        }
      }
    }
  }
  generateMenuItems(index: number) {
    const equipmentLengthFlag = (this.equipmentGroupEditModel.equipmentDetailsForm.get('equipmentGroupForm')['controls'].length > 1);
    if (index === 0 && !equipmentLengthFlag) {
      this.equipmentGroupEditModel.overFlowMenuItems[index] = [
        {
          label: 'Add Equipment',
          command: onclick => {
            this.onAddNewEquipment(index);
          }
        }];
    } else {
      this.equipmentGroupEditModel.overFlowMenuItems[index] = [
        {
          label: 'Add Equipment',
          command: onclick => {
            this.onAddNewEquipment(index);
          }
        },
        {
          label: 'Stack Equipment',
          command: onclick => {
            this.onStackEquipment(index);
          }
        },
        {
          label: 'Remove Equipment',
          command: onclick => {
            this.onRemoveEquipment(index);
          }
        }];
    }
  }
  generateStackOverflow(index: number, stackIndex: number) {
    this.equipmentGroupEditModel.stackOverFlowMenuItems[stackIndex] = [
      {
        label: 'Add Stacked Equipment',
        command: onclick => {
          this.onAddStackedEquipment(index, stackIndex);
        }
      },
      {
        label: 'Unstack Equipment',
        command: onclick => {
          this.onUnStackEquipment(index, stackIndex);
        }
      },
      {
        label: 'Remove Equipment',
        command: onclick => {
          this.onRemoveStackedEquipment(index, stackIndex);
        }
      }];
  }
  onAddStackedEquipment(index: number, stackindex: number) {
    const control: FormArray = this.getStackedEquipmentsForm(index);
    control.insert(stackindex + 1, EquipmentGroupEditUtils.setStackEquipmentsForm(this.fb));
    const controlVal: FormArray = this.getEquipmentGroupForm();
    this.populateFormValues(0, controlVal);
  }
  onRemoveStackedEquipment(index, stackIndex) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to remove this equipment?',
      header: 'Confirmation',
      key: 'removeEquipment',
      accept: (): void => {
        const controlVal: FormArray = this.getEquipmentGroupForm();
        const control: FormArray = this.getStackedEquipmentsForm(index);
        this.equipmentGroupEditModel.unStackedEquipments.push(this.equipmentGroupEditModel.equipmentDetailsForm.controls.
          equipmentGroupForm['controls'][index].controls.stackedEquipments['controls'][stackIndex].
          controls.standardEquipmentGroupStackingId.value);
        this.equipmentGroupEditModel.removedEquipments.push(this.equipmentGroupEditModel.equipmentDetailsForm.controls.
          equipmentGroupForm['controls'][index].controls.stackedEquipments['controls'][stackIndex].
          controls.standardEquipmentGroupMemberId.value);
        control.removeAt(stackIndex);
        this.equipmentGroupEditModel.isEditedFlag = true;
        this.equipmentGroupEditModel.type = EquipmentGroupUtility.setOverviewType(this.getEquipmentGroupForm());
        this.populateFormValues(0, controlVal, index);
        EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
      }
    });
  }
  onStackEquipment(index) {
    this.equipmentGroupEditModel.stackingControl = this.equipmentGroupEditModel.equipmentDetailsForm
      .get('equipmentGroupForm')['controls'][index] as FormArray;
    this.equipmentGroupEditModel.inputStackList = {
      'inputOrderList': this.equipmentGroupEditModel.equipmentDetailsForm.controls.equipmentGroupForm['controls'],
      'dialogVisible': true,
      'index': index,
      'stackOnCategory': this.equipmentGroupEditModel.stackingControl.get(`equipmentCategory`).value
    };
    this.changeDetector.detectChanges();
  }
  onUnStackEquipment(index, stackIndex) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to unstack this equipment?',
      header: 'Confirmation',
      key: 'unstackEquipment',
      accept: (): void => {
        const control: FormArray = this.getStackedEquipmentsForm(index);
        const controlVal: FormArray = this.getEquipmentGroupForm();
        const insertControl = this.equipmentGroupEditModel.equipmentDetailsForm.controls.equipmentGroupForm as FormArray;
        insertControl.insert(index + 1, control.controls[stackIndex]);
        this.equipmentGroupEditModel.unStackedEquipments.push(this.equipmentGroupEditModel.equipmentDetailsForm.controls.
          equipmentGroupForm['controls'][index].controls.stackedEquipments['controls'][stackIndex].
          controls.standardEquipmentGroupStackingId.value);
        control.removeAt(stackIndex);
        this.populateFormValues(0, controlVal);
        this.equipmentGroupEditModel.isEditedFlag = true;
        for (let i = index; i < insertControl.length; i++) {
          insertControl.controls[i]['controls']['equipmentGroupSequenceNumber'].setValue(i + 1);
        }
        EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
        this.changeDetector.detectChanges();
      }
    });
  }
  onAddNewEquipment(index: number) {
    const controlVal: FormArray = this.getEquipmentGroupForm();
    controlVal.insert(index + 1, EquipmentGroupEditUtils.setEquipmentFormGroup(this.fb, index + 1));
    this.equipmentGroupEditModel.equipmentTypeList[index + 1] = [];
    this.equipmentGroupEditModel.equipmentLengthList[index + 1] = [];
    this.equipmentGroupEditModel.equipmentWidthList[index + 1] = [];
    this.equipmentGroupEditModel.equipmentHeightList[index + 1] = [];
    this.equipmentGroupEditModel.isEditedFlag = true;
    this.populateFormValues(index + 2, controlVal);
    EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
  }
  onRemoveEquipment(index: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to remove this equipment?',
      header: 'Confirmation',
      key: 'removeEquipment',
      accept: (): void => {
        this.equipmentGroupEditModel.isEditedFlag = true;
        this.equipmentGroupEditModel.removedEquipments.push(this.equipmentGroupEditModel.equipmentDetailsForm.
          controls.equipmentGroupForm['controls'][index].controls.standardEquipmentGroupMemberId.value);
        this.removeStackedParent(index);
        this.equipmentGroupEditModel.type = EquipmentGroupUtility.setOverviewType(this.getEquipmentGroupForm());
        EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
      }
    });
  }
  removeStackedParent(index: number) {
    const controlVal: FormArray = this.getEquipmentGroupForm();
    const stackControl: FormArray = controlVal.controls[index]['controls']['stackedEquipments']['controls'];
    if (stackControl && stackControl.length > 0) {
      for (let j = stackControl.length - 1; j >= 0; j--) {
        this.equipmentGroupEditModel.unStackedEquipments.push(stackControl[j].controls.standardEquipmentGroupStackingId.value);
        controlVal.insert(index + 1, stackControl[j]);
      }
    }
    controlVal.removeAt(index);
    this.equipmentGroupEditModel.isEditedFlag = true;
    this.populateFormValues(index, controlVal);
  }
  selectedEquipmentToStack(event) {
    const controlLength = this.equipmentGroupEditModel.stackingControl.value.equipmentGroupSequenceNumber - 1;
    const stackedEquipments = this.equipmentGroupEditModel.stackingControl.get(`stackedEquipments`) as FormArray;
    const controlVal: FormArray = this.getEquipmentGroupForm();
    this.equipmentGroupEditModel.isEditedFlag = true;
    if (stackedEquipments['controls'] && stackedEquipments['controls'].length > 0) {
      for (let i = stackedEquipments['controls'].length - 1; i >= 0; i--) {
        this.equipmentGroupEditModel.equipmentDetailsForm
          .get('equipmentGroupForm')['controls'][event.controls.equipmentGroupSequenceNumber.value - 1].get('stackedEquipments')
          .insert(event.controls.stackedEquipments.length, stackedEquipments['controls'][i]);

      }
    }
    const insertVal = this.equipmentGroupEditModel.equipmentDetailsForm
      .get(`equipmentGroupForm.${event.controls.equipmentGroupSequenceNumber.value - 1}`).get('stackedEquipments') as FormArray;
    insertVal.insert(event.controls.stackedEquipments.length, this.equipmentGroupEditModel.stackingControl);
    if (stackedEquipments['controls'] && stackedEquipments['controls'].length > 0) {
      while (stackedEquipments['controls'].length !== 0) {
        stackedEquipments.removeAt(0);
      }
    }
    controlVal.removeAt(controlLength);
    this.equipmentGroupEditModel.stackEquipmentFlag = true;
    this.populateFormValues(0, controlVal);
    EquipmentGroupEditUtils.calculationOverview(this.equipmentGroupEditModel);
    if (this.equipmentGroupEditModel.systemAdjustedHeight !== '---' || this.equipmentGroupEditModel.systemAdjustedLength !== '---') {
      this.thresholdExceedWarning();
    }
    this.changeDetector.detectChanges();
  }
  populateFormValues(startIndex: number, basePair: FormArray, stackPairIndex?: number) {
    for (let i = startIndex; i < basePair.length; i++) {
      const control: FormArray = this.getStackedEquipmentsForm(stackPairIndex ? stackPairIndex : i);
      basePair.controls[i]['controls']['equipmentGroupSequenceNumber'].setValue(i + 1);
      this.getEquipmentType(basePair.controls[i]['controls'].equipmentCategory.value, i);
      for (let j = 0; j < control.length; j++) {
        this.getEquipmentType(control.controls[j].value.equipmentCategory, j, `${i}.${j}`);
      }
    }
  }
  onSelectUnitOfMeasure(unitValue) {
    this.equipmentGroupEditModel.unitOfMeasure = unitValue;
  }
  onInactivate() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to inactivate the Equipment Group?',
      header: 'Confirmation',
      key: 'Inactivate',
      accept: (): void => {
        this.activeInactivate('Inactive');
      }
    });
  }
  activeInactivate(statusVal: string) {
    const equipmentid = this.activatedRoute.queryParams['value']['standardEquipmentGroupID'];
    const statusData: StatusData = { status: statusVal };
    this.equipmentGroupEditModel.sectionLoading = true;
    this.equipmentGroupEditService.getEquipmentStatus(statusData, this.activatedRoute.queryParams['value']['standardEquipmentGroupID'])
      .pipe(takeWhile(() => this.equipmentGroupEditModel.hasSubscribe))
      .subscribe((data: any) => {
        timer(2000).subscribe(() => {
          this.equipmentGroupEditModel.sectionLoading = false;
          if (status !== 'Active') {
            this.toastMessage.clear();
            this.toastMessage.add({
              severity: 'success',
              summary: 'Equipment Group Inactivated',
              detail: `Equipment Group (${equipmentid}) has been Inactivated successfully`
            });
          }
          this.router.navigate([ManageEquipmentGroupRoutelinks.listUrl]);
        });
        this.changeDetector.detectChanges();
      }, (error: Error) => {
        this.equipmentGroupEditModel.sectionLoading = false;
      });
  }
  onEditEquipment() {
    FormValidationUtils.validateAllFormFields(this.equipmentGroupEditModel.equipmentDetailsForm);
    if (this.equipmentGroupEditModel.equipmentDetailsForm.valid) {
      if ((this.equipmentDetailsForm && this.equipmentDetailsForm.length > 1) ||
        (this.equipmentDetailsForm && this.equipmentDetailsForm[0]['controls']['stackedEquipments'] &&
          this.equipmentDetailsForm[0]['controls']['stackedEquipments'].length > 0)) {
        this.equipmentGroupEditService.onEditEquipmentGroup(this.equipmentGroupEditModel, this.toastMessage,
          this.router, this.activatedRoute, this.changeDetector);
      } else {
        this.toastMessage.clear();
        this.toastMessage.add({
          severity: 'error',
          summary: 'Equipment Group Error',
          detail: 'Equipment Group must have more than one equipment'
        });
      }
    }
  }
}
