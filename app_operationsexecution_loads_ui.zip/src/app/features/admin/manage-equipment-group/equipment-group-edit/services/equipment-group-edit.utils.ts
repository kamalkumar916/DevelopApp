import { Injectable } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MenuItem, SelectItem } from 'primeng/api';
import * as lodashUtils from 'lodash';

import {
    CountryDetails, EquipmentType, EquipmentClassification, EquipmentLength,
    EquipmentGroupMembers, SystemAdjustedValue, CreateRequest
} from '../../model/equipment-group.interface';
import { EquipmentGroupEdit } from '../model/equipment-group-edit.model';
import { EquipmentGroupUtility } from '../../services/equipment-group.utility';
import { UnitMetricsImperialPipe } from '../../pipes/unit-metrics-imperial.pipe';

export class EquipmentGroupEditUtils {
    static setEquipmentFormGroup(formBuilder: FormBuilder, index: number): FormGroup {
        return formBuilder.group({
            'equipmentCategory': ['', Validators.required],
            'equipmentType': ['', Validators.required],
            'equipmentLength': [''],
            'equipmentWidth': [''],
            'equipmentHeight': [''],
            'standardEquipmentGroupMemberId': [''],
            'standardEquipmentGroupStackingId': [''],
            'equipmentGroupSequenceNumber': [index + 1, ''],
            'equipmentTypeDescription': [''],
            'stackedEquipments': formBuilder.array([])
        });
    }
    static setStackEquipmentsForm(formBuilder: FormBuilder): FormGroup {
        return formBuilder.group({
            'equipmentCategory': ['', Validators.required],
            'equipmentType': ['', Validators.required],
            'equipmentLength': ['', Validators.required],
            'equipmentWidth': ['', Validators.required],
            'equipmentHeight': ['', Validators.required],
            'standardEquipmentGroupMemberId': [''],
            'standardEquipmentGroupStackingId': [''],
            'equipmentGroupSequenceNumber': [''],
            'equipmentTypeDescription': [''],
            'stackedEquipments': formBuilder.array([])
        });
    }
    static prePopulateDetails(equipmentGroup: EquipmentGroupMembers) {
        return {
            equipmentCategory: {
                label: equipmentGroup.equipmentClassificationDescription,
                value: equipmentGroup.equipmentClassificationCode
            },
            equipmentType: {
                label: equipmentGroup.equipmentTypeDescription,
                value: equipmentGroup.equipmentTypeCode
            },
            equipmentLength: {
                label: EquipmentGroupEditUtils.checkDimensionEmpty(equipmentGroup.lengthSpecificationDescription),
                value: EquipmentGroupEditUtils.checkDimensionEmpty(equipmentGroup.lengthSpecificationDescription)
            },
            equipmentWidth: {
                label: EquipmentGroupEditUtils.checkDimensionEmpty(equipmentGroup.widthSpecificationDescription),
                value: EquipmentGroupEditUtils.checkDimensionEmpty(equipmentGroup.widthSpecificationDescription)
            },
            equipmentHeight: {
                label: EquipmentGroupEditUtils.checkDimensionEmpty(equipmentGroup.heightSpecificationDescription),
                value: EquipmentGroupEditUtils.checkDimensionEmpty(equipmentGroup.heightSpecificationDescription)
            },
            groupmemberid: {
                value: equipmentGroup.standardEquipmentGroupMemberId ? equipmentGroup.standardEquipmentGroupMemberId : null
            },
            stackmemberid: {
                value: equipmentGroup.standardEquipmentGroupStackingId ? equipmentGroup.standardEquipmentGroupStackingId : null
            },
            stackedEquipments: this.frameStackedEquipments(equipmentGroup.stackedEquipments)
        };
    }
    static frameStackedEquipments(stackedEquipments: EquipmentGroupMembers[]) {
        const framedStackedEquipments = [];
        if (stackedEquipments && stackedEquipments.length > 0) {
            for (const se of stackedEquipments) {
                framedStackedEquipments.push(this.prePopulateDetails(se));
            }
        }
        return framedStackedEquipments;
    }
    static checkDimensionEmpty(dimensionValue: string) {
        return dimensionValue ? dimensionValue.trim() : null;
    }
    static generateRequestObject(equipmentListForm: FormGroup, equipmentEditModel: EquipmentGroupEdit, isEditSave = false): CreateRequest {
        const controlsVal = equipmentListForm.controls.equipmentGroupForm['controls'];
        equipmentEditModel.requestObject.standardEquipmentGroupId = equipmentEditModel.equipmentId;
        equipmentEditModel.requestObject.equipmentGroupName = equipmentListForm.controls.name.value;
        equipmentEditModel.requestObject.equipmentGroupDescription = equipmentListForm.controls.description.value;
        equipmentEditModel.requestObject.equipmentGroupComment = equipmentListForm.controls.comments.value;
        equipmentEditModel.requestObject.countryCode = equipmentListForm.controls.country.value;
        equipmentEditModel.requestObject.countryDescription = this.setCountryCode(equipmentListForm, equipmentEditModel);
        equipmentEditModel.requestObject.groupOverviewDetails = {
            'type': equipmentEditModel.type,
            'length': equipmentEditModel.overviewLengthValue ? equipmentEditModel.overviewLengthValue : '---',
            'width': equipmentEditModel.overviewWidthValue ? equipmentEditModel.overviewWidthValue : '---',
            'height': equipmentEditModel.overviewHeightValue ? equipmentEditModel.overviewHeightValue : '---',
            'lengthValue': this.getInchesValues(equipmentEditModel.overviewLengthValue),
            'heightValue': this.getInchesValues(equipmentEditModel.overviewHeightValue),
            'widthValue': this.getInchesValues(equipmentEditModel.overviewWidthValue),
            'systemAdjustedLength': this.getAdjustedLengthValues(equipmentEditModel.systemAdjustedLength),
            'systemAdjustedHeight': this.getAdjustedHeightValues(equipmentEditModel.systemAdjustedHeight)
        };
        equipmentEditModel.requestObject.standardEquipmentGroupMembers = [];
        equipmentEditModel.requestObject.removedEquipmentMemberIds = equipmentEditModel.removedEquipments;
        equipmentEditModel.requestObject.unStackedEquipmentIds = equipmentEditModel.unStackedEquipments;
        equipmentEditModel.requestObject.standardEquipmentGroupMembers = controlsVal.map((requestObj, i) => {
            return {
                'standardEquipmentGroupMemberId': requestObj.controls.standardEquipmentGroupMemberId.value,
                'standardEquipmentGroupStackingId': requestObj.controls.standardEquipmentGroupStackingId.value,
                'equipmentGroupSequenceNumber': i + 1,
                'equipmentClassificationCode': requestObj.controls.equipmentCategory.value,
                'equipmentClassificationDescription': requestObj.controls.equipmentCategory.value,
                'equipmentTypeCode': requestObj.controls.equipmentType.value,
                'equipmentTypeDescription': requestObj.controls.equipmentType.value,
                'lengthSpecificationCode': requestObj.controls.equipmentLength.value ?
                this.checkCumulativeValues(requestObj.controls.equipmentLength.value, isEditSave) : null,
                'widthSpecificationCode': requestObj.controls.equipmentWidth.value ?
                this.checkCumulativeValues(requestObj.controls.equipmentWidth.value, isEditSave) : null,
                'heightSpecificationCode': requestObj.controls.equipmentHeight.value ?
                this.checkCumulativeValues(requestObj.controls.equipmentHeight.value, isEditSave) : null,
                'stackedEquipments': this.generateStackedEquipmentDetails(requestObj.controls.stackedEquipments, i + 1, isEditSave)
            };
        });
        return equipmentEditModel.requestObject;
    }

    static checkCumulativeValues(dimensionValue: string, isEditSave: boolean) {
        return isEditSave ? EquipmentGroupUtility.getCumulativeValues(dimensionValue) : dimensionValue;
    }
    static generateStackedEquipmentDetails(stackedEquipments, sequenceNumber: number, isEditSave: boolean): FormArray {
        if (stackedEquipments.controls && stackedEquipments.controls.length > 0) {
            return stackedEquipments.controls.map((stackRequest, index) => {
                return {
                    standardEquipmentGroupMemberId: stackRequest.controls.standardEquipmentGroupMemberId.value,
                    standardEquipmentGroupStackingId: stackRequest.controls.standardEquipmentGroupStackingId.value,
                    equipmentGroupSequenceNumber: sequenceNumber,
                    equipmentClassificationCode: stackRequest.controls.equipmentCategory.value,
                    equipmentClassificationDescription: stackRequest.controls.equipmentCategory.value,
                    equipmentTypeCode: stackRequest.controls.equipmentType.value,
                    equipmentTypeDescription: stackRequest.controls.equipmentType.value,
                    lengthSpecificationCode: stackRequest.controls.equipmentLength.value ?
                        this.checkCumulativeValues(stackRequest.controls.equipmentLength.value, isEditSave) : null,
                    widthSpecificationCode: stackRequest.controls.equipmentWidth.value ?
                    this.checkCumulativeValues(stackRequest.controls.equipmentWidth.value, isEditSave) : null,
                    heightSpecificationCode: stackRequest.controls.equipmentHeight.value ?
                        this.checkCumulativeValues(stackRequest.controls.equipmentHeight.value, isEditSave) : null,
                    stackedEquipments: null
                };
            });
        } else {
            return null;
        }
    }
    static setCountryCode(equipmentListForm: FormGroup, equipmentEditModel: EquipmentGroupEdit): string {
        let countryName = '';
        if (!equipmentEditModel.hasCountryChanged) {
            countryName = equipmentEditModel.equipmentDetails.countryDescription;
        } else {
            countryName = equipmentEditModel.selectedCountryDetail[0].label;
        }
        return countryName;
    }
    static getInchesValues(adjustedValue): number {
        if (adjustedValue !== '---') {
            if ((adjustedValue.toLowerCase().includes('ft')) && (adjustedValue.toLowerCase().includes('in'))) {
                const feetInch = adjustedValue.split(' ');
                return (parseInt(feetInch[0], 10) * 12) + parseInt(feetInch[2], 10);
            } else if (adjustedValue.toLowerCase().includes('in')) {
                return parseInt(adjustedValue, 10);
            } else {
                return parseInt(adjustedValue, 10) * 12;
            }
        } else {
            return 0;
        }
    }
    static getAdjustedLengthValues(systemVal: string): SystemAdjustedValue {
        const systemAdjustedValue = this.getInchesValues(systemVal);
        return {
            value: (systemAdjustedValue) ? systemAdjustedValue : 0,
            description: systemVal
        };
    }
    static getAdjustedHeightValues(systemVal: string): SystemAdjustedValue {
        return {
            value: this.getInchesValues(systemVal),
            description: EquipmentGroupUtility.systemAdjustedHeight(systemVal)
        };
    }
    static calculationOverview(editModel, defalut?: string) {
        let SpecificationCodeDimension;
        if (defalut === 'default') {
            this.convertlengthSpecification(editModel.equipmentGroup);
            SpecificationCodeDimension = new UnitMetricsImperialPipe().transform(editModel.equipmentGroup, 'lengthWidthHeigthCalculation');
        } else {
            const requestObj = this.generateRequestObject(editModel.equipmentDetailsForm, editModel);
            SpecificationCodeDimension =
                new UnitMetricsImperialPipe().transform(requestObj.standardEquipmentGroupMembers, 'lengthWidthHeigthCalculation');
        }
        const overviewtotalheight =
            new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'height');
        const overviewtotallenth =
            new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'length');
        const overviewtotalwidth =
            new UnitMetricsImperialPipe().transform(SpecificationCodeDimension, 'lengthWidthHeightTotal', 'width');
        editModel.overviewHeightValue = EquipmentGroupUtility.maxWidthGroupOverview(overviewtotalheight);
        editModel.overviewLengthValue = EquipmentGroupUtility.feetInchesGroupOverview(overviewtotallenth);
        editModel.overviewWidthValue = EquipmentGroupUtility.maxWidthGroupOverview(overviewtotalwidth);
        editModel.systemAdjustedLength = EquipmentGroupUtility.systemAdjustedLength(editModel.overviewLengthValue);
        editModel.systemAdjustedHeight = EquipmentGroupUtility.systemAdjustedHeight(editModel.overviewHeightValue);
    }
    static convertlengthSpecification(equipmentGroup: EquipmentGroupMembers[]) {
        const standardEquipmentGrop = equipmentGroup;
        if (standardEquipmentGrop) {
            for (const stdEquip of standardEquipmentGrop) {
                stdEquip.lengthSpecificationCode =
                    this.checkLengthSpecEmpty(stdEquip.lengthSpecificationCode);
                const stackedEquipment = stdEquip.stackedEquipments;
                if (stackedEquipment && stackedEquipment.length > 0) {
                    for (const stkEqip of stackedEquipment) {
                        stkEqip.lengthSpecificationCode =
                            this.checkLengthSpecEmpty(stkEqip.lengthSpecificationCode);
                    }
                }
            }
        }
    }
    static checkLengthSpecEmpty(value: string): string {
        return value ? `${value} ft` : null;
    }
    static setValidator(controlName: string, index: number, canValidate: boolean, editmodel, stackedindex?: string) {
        let equipmentCtrls;
        if (editmodel.equipmentDetailsForm.get(`equipmentGroupForm`)) {
            if (stackedindex) {
                if (lodashUtils.includes(stackedindex, '.')) {
                    const stack = stackedindex.split('.');
                    const pIndex = stack[0];
                    const sindex = stack[1];
                    if (editmodel.equipmentDetailsForm
                        .get(`equipmentGroupForm.${pIndex}`).get(`stackedEquipments.${sindex}`)) {
                        equipmentCtrls = editmodel.equipmentDetailsForm.get(`equipmentGroupForm.${pIndex}`).
                            get(`stackedEquipments.${sindex}`).get(controlName);
                        this.setDetailValidator(equipmentCtrls, canValidate);
                    }
                }
            } else {
                equipmentCtrls = editmodel.equipmentDetailsForm.get(`equipmentGroupForm.${index}`)['controls'][controlName];
                this.setDetailValidator(equipmentCtrls, canValidate);
            }
        }
    }
    static setDetailValidator(equipmentCtrls, canValidate: boolean) {
        if (canValidate) {
            equipmentCtrls.setValidators([Validators.required]);
            equipmentCtrls.updateValueAndValidity();
        } else {
            equipmentCtrls.clearValidators();
            equipmentCtrls.updateValueAndValidity();
        }
    }
    static initializeEquipmentFormDetails(editmodel, formbuilder: FormBuilder) {
        editmodel.equipmentDetailsForm = formbuilder.group({
            'name': ['', Validators.required],
            'description': [''],
            'country': ['', Validators.required],
            'comments': [''],
            'equipmentGroupForm': formbuilder.array([])
        });
    }
    static populateEquipmentDetailsForm(editModel, formBuilder: FormBuilder) {
        const equipmentGroup = editModel.equipmentGroup;
        for (let i = 0; i < equipmentGroup.length; i++) {
            const equipmentPairDetails = this.prePopulateDetails(equipmentGroup[i]);
            editModel.equipmentDetailsForm.get(`equipmentGroupForm.${i}`).patchValue({
                'equipmentCategory': equipmentPairDetails.equipmentCategory.value,
                'equipmentType': equipmentPairDetails.equipmentType.value,
                'equipmentLength': equipmentPairDetails.equipmentLength.value,
                'equipmentWidth': equipmentPairDetails.equipmentWidth.value,
                'equipmentHeight': equipmentPairDetails.equipmentHeight.value,
                'equipmentTypeDescription': equipmentPairDetails.equipmentType.label,
                'equipmentGroupSequenceNumber': i + 1,
                'standardEquipmentGroupMemberId': equipmentPairDetails.groupmemberid.value,
                'standardEquipmentGroupStackingId': equipmentPairDetails.stackmemberid.value
            });
            const detailsForm = editModel.equipmentDetailsForm.get(`equipmentGroupForm`);
            detailsForm['controls'][i].setControl('stackedEquipments', this.loadStackElements(i, editModel, formBuilder));
            this.setStackedGroupFormValues(i, editModel);
        }
        editModel.type = EquipmentGroupUtility.setOverviewType(this.getEquipmentGroupForm(editModel));
    }
    static loadStackElements(parentIndex: number, editModel, formBuilder: FormBuilder): FormArray {
        const equipmentGroup = editModel.equipmentGroup[parentIndex].stackedEquipments;
        const elementsArr: FormArray = editModel.equipmentDetailsForm
            .controls['equipmentGroupForm']['controls'][parentIndex]['controls']['stackedEquipments'] as FormArray;
        if (equipmentGroup) {
            equipmentGroup.forEach((stackItem, index) => {
                this.prePopulateDetails(stackItem);
                elementsArr.insert(index, this.setStackEquipmentsForm(formBuilder));
            });
        }
        return elementsArr;
    }
    static setStackedGroupFormValues(parentIndex: number, editModel) {
        const group = editModel.equipmentDetailsForm.get(`equipmentGroupForm.${parentIndex}`);
        const equipmentGroup = editModel.equipmentGroup[parentIndex].stackedEquipments;
        if (equipmentGroup && equipmentGroup.length > 0) {
            equipmentGroup.forEach((stackItem, index) => {
                const stackedPairDetails = this.prePopulateDetails(stackItem);
                if (group.get(`stackedEquipments.${index}`)) {
                    group.get(`stackedEquipments.${index}`).patchValue({
                        'standardEquipmentGroupMemberId': stackedPairDetails.groupmemberid.value,
                        'standardEquipmentGroupStackingId': stackedPairDetails.stackmemberid.value,
                        'equipmentGroupSequenceNumber': index + 1,
                        'equipmentCategory': stackedPairDetails.equipmentCategory.value,
                        'equipmentType': stackedPairDetails.equipmentType.value,
                        'equipmentTypeDescription': stackedPairDetails.equipmentType.label,
                        'equipmentLength': stackedPairDetails.equipmentLength.value,
                        'equipmentWidth': stackedPairDetails.equipmentWidth.value,
                        'equipmentHeight': stackedPairDetails.equipmentHeight.value,
                    });
                }
            });
        }
    }
    static getEquipmentGroupForm(editModel): FormArray {
        return editModel.equipmentDetailsForm.controls['equipmentGroupForm'] as FormArray;
    }
}
