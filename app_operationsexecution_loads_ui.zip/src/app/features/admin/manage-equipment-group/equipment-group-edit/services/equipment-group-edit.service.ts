import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, timer } from 'rxjs';
import { SelectItem } from 'primeng/api';
import * as lodashUtils from 'lodash';
import { takeWhile, finalize, map } from 'rxjs/operators';

import {
  CountryDetails, EquipmentType, EquipmentClassification, EquipmentLength,
  EquipmentGroupDetails, EquipmentDimenstion, CreateRequest, StatusData
} from '../../model/equipment-group.interface';
import { EquipmentGroupUtility } from '../../services/equipment-group.utility';
import { EquipmentGroupEditUtils } from './equipment-group-edit.utils';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ManageEquipmentGroupRoutelinks } from '../../manage-equipment-group-route-links';
import { ErrorUtils } from '../../../../../shared/jbh-app-services/error-utils';

@Injectable()
export class EquipmentGroupEditService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('manageEquipmentGroup');
  }
  getEquipmentDetails(equipmentId: number): Observable<EquipmentGroupDetails> {
    return this.http.get<EquipmentGroupDetails>(`${this.endpoint.equipmentDetails}/${equipmentId}`);
  }
  getEquipmentStatus(statusData: StatusData, equipmentGroupID: number): Observable<any> {
    return this.http.patch<any>(`${this.endpoint.equipmentDetails}/${equipmentGroupID}/status`, statusData);
  }
  getCountryDetails(): Observable<SelectItem[]> {
    return this.http.get<CountryDetails>(this.endpoint.getCountryDetails).pipe(map((country) => {
      return country._embedded.countries.map(countries => {
        return {
          label: countries.countryName,
          value: countries.countryCode
        };
      });
    }));
  }
  getEquipmentCategory(): Observable<SelectItem[]> {
    return this.http.get<EquipmentClassification>(this.endpoint.getEquipmentCategory).pipe(
      map((category: EquipmentClassification) => {
        if (category && category._embedded && category._embedded.equipmentClassifications) {
          return category._embedded.equipmentClassifications.map((equipmentCategory) => {
            return {
              label: equipmentCategory.equipmentClassificationDescription,
              value: equipmentCategory.equipmentClassificationCode
            };
          });
        }
      }));
  }
  getEquipmentType(equipmentCategoryCode: string): Observable<SelectItem[]> {
    return this.http.get<EquipmentType>(`${this.endpoint.
      getEquipmentType}?equipmentClassificationCode=${equipmentCategoryCode}`).pipe(
      map((type: EquipmentType) => {
        if (type && type._embedded && type._embedded.equipmentTypes) {
          return type._embedded.equipmentTypes.map((equipmentTypes) => {
            return {
              label: equipmentTypes.equipmentTypeDescription,
              value: equipmentTypes.equipmentTypeCode
            };
          });
        }
      }));
  }
  getEquipmentTypeIds(equipmentCategoryCode: string): Observable<EquipmentType> {
    return this.http.get<EquipmentType>(`${this.endpoint.getEquipmentType}?equipmentClassificationCode=${equipmentCategoryCode}`);
  }
  getEquipmentValues(equipmentCategory: string, equipmentType: string, valueEndpoint): Observable<EquipmentDimenstion[]> {
    return this.http.get<EquipmentDimenstion[]>(
      `${valueEndpoint}?equipmentClassificationCode=${equipmentCategory}&equipmentTypeCode=${equipmentType}`);
  }
  editEquipmentGroup(requestObj: CreateRequest): Observable<number> {
    return this.http.put<number>(`${this.endpoint.createEquipmentGroup}/${requestObj.standardEquipmentGroupId}`, requestObj);
  }
  getEquipmentDimension(editModel, changeDetector, equipmentType: string, index: number, stackedindex?: string) {
    const indexType: string | number = stackedindex ? stackedindex : index;
    editModel.isLoading = true;
    this.getEquipmentValues(this.getCurrentEquipmentCategory(editModel, index, stackedindex),
      equipmentType, this.endpoint.getEquipmentDimension).pipe(takeWhile(() =>
        editModel.hasSubscribe))
      .subscribe((data: EquipmentDimenstion[]) => {
        if (data) {
          this.frameEquipmentDimensionValues('Length', data, editModel, changeDetector,
            indexType, index, stackedindex);
          this.frameEquipmentDimensionValues('Width', data, editModel, changeDetector,
            indexType, index, stackedindex);
          this.frameEquipmentDimensionValues('Height', data, editModel, changeDetector,
            indexType, index, stackedindex);
        }
        editModel.isLoading = false;
        changeDetector.detectChanges();
      }, (error: Error) => {
        editModel.isLoading = false;
      });
  }
  frameEquipmentDimensionValues(equimentDimensionValue: string, data: EquipmentDimenstion[],
    editModel, changeDetector, indexType: string | number, index: number, stackedindex?: string) {
    editModel[`equipment${equimentDimensionValue}List`][indexType] =
      this.getEquipmentDimensionDetails(data, indexType, equimentDimensionValue);
    if (!lodashUtils.isEmpty(editModel[`equipment${equimentDimensionValue}List`][indexType])) {
      EquipmentGroupEditUtils.setValidator(`equipment${equimentDimensionValue}`, index, true, editModel, stackedindex);
      changeDetector.detectChanges();
    } else {
      EquipmentGroupEditUtils.setValidator(`equipment${equimentDimensionValue}`, index, false, editModel, stackedindex);
    }
  }
  getEquipmentDimensionDetails(data, index, equipmentDimentioName: string) {
    const framedEquipmentDetails = data._embedded.equipmentDimensions
      .map(dimensionsValue => {
        return {
          label: this.frameDimensionValue(dimensionsValue, equipmentDimentioName),
          value: this.frameDimensionValue(dimensionsValue, equipmentDimentioName)
        };
      }).filter(value => value);
    return framedEquipmentDetails ? lodashUtils.uniqBy(framedEquipmentDetails, 'value') : [];
  }
  frameDimensionValue(value: any, dimensionName: string): string {
    let framedValue = '';
    if (value) {
      const dimensionValue = value[`${dimensionName.toLowerCase()}Quantity`];
      let dimensionUnit = value[`unitOf${dimensionName}MeasurementCode`];
      dimensionUnit = this.getDimensionUnit(dimensionUnit);
      framedValue += dimensionValue;
      framedValue += dimensionUnit ? ` ${dimensionUnit}` : '';
      framedValue = dimensionUnit === 'in' && dimensionValue ?
        EquipmentGroupUtility.feetInchesFormat(dimensionValue) : framedValue;
    }
    return framedValue;
  }
  getDimensionUnit(dimensionUnit) {
    return dimensionUnit ? dimensionUnit.toLowerCase() === 'feet' ? 'ft' :
      dimensionUnit.toLowerCase() === 'inches' ? 'in' : dimensionUnit : '';
  }
  getCurrentEquipmentCategory(editModel, index: number, stackedindex?: string) {
    const currentEquipment = editModel.equipmentDetailsForm.controls['equipmentGroupForm']
      .controls[stackedindex ? stackedindex.split('.')[0] : index].controls;
    return stackedindex ? currentEquipment.stackedEquipments.controls
    [stackedindex.split('.')[1]].controls.equipmentCategory.value : currentEquipment.equipmentCategory.value;
  }
  onEditEquipmentGroup(editModel, toastMessage, router, activeRoute, changeDetector) {
    const equipmentid = activeRoute.queryParams['value']['standardEquipmentGroupID'];
    editModel.sectionLoading = true;
    editModel.isLoading = true;
    editModel.equipmentId = activeRoute.queryParams['value']['standardEquipmentGroupID'];
    const requestObj = EquipmentGroupEditUtils.generateRequestObject(editModel.equipmentDetailsForm,
      editModel, true);
    this.editEquipmentGroup(requestObj).pipe(finalize(() => {
      changeDetector.detectChanges();
    })).subscribe(data => {
      editModel.sectionLoading = false;
      editModel.isLoading = false;
      if (data) {
        if (editModel.equipmentDetailsForm.touched || editModel.isEditedFlag) {
          timer(2000).subscribe(() => {
            toastMessage.add({
              severity: 'success',
              summary: 'Success',
              detail: `Equipment Group (${equipmentid}) has been updated successfully`
            });
            router.navigate([ManageEquipmentGroupRoutelinks.listUrl]);
          });
        } else {
          toastMessage.add({
            severity: 'warn',
            summary: 'No Changes Detected',
            detail: `You have not done any changes to Equipment group`
          });
          router.navigate([ManageEquipmentGroupRoutelinks.listUrl]);
        }
      }
    }, (error: Error) => {
      editModel.sectionLoading = false;
      editModel.isLoading = false;
      toastMessage.clear();
      switch (error['status']) {
        case 409:
          toastMessage.add({
            severity: 'error',
            summary: 'Duplicate Equipment',
            detail: 'An equipment group has already been set for this combination of equipment pair'
          });
          break;
        case 400:
          if (error['error']['errors'][0]['code'] === 'DUPLICATE_GROUP_NAME') {
            toastMessage.add({
              severity: 'error',
              summary: 'Duplicate Group Name',
              detail: 'Group Name Already Available'
            });
          }
          break;
        case 500:
          toastMessage.add({
            severity: 'error',
            summary: 'Server Error',
            detail: ErrorUtils.getErrorMessage(error['status'])
          });
          break;
      }
    });
  }
}

