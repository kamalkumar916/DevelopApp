import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { EquipmentGroupEditService } from './equipment-group-edit.service';
import { configureTestSuite } from 'ng-bullet';
import { EquipmentGroupEditUtils } from './equipment-group-edit.utils';
import { EquipmentGroupUtility } from '../../services/equipment-group.utility';
import { of } from 'rxjs/internal/observable/of';

describe('EquipmentGroupEditService', () => {
  let service: EquipmentGroupEditService;
  let httpTestingController: HttpTestingController;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EquipmentGroupEditService, AppConfigService]
    });
  });

  const SystemAdjustedValue = {
    value: 123,
    description: '',
  };
  const GroupOverviewDetails = {
    type: '',
    width: '',
    height: '',
    length: '',
    lengthValue: 123,
    widthValue: 123,
    heightValue: 123,
    systemAdjustedLength: SystemAdjustedValue,
    systemAdjustedHeight: SystemAdjustedValue,
  };
  const StandardEquipmentGroupMembersItem = [{
    equipmentGroupSequenceNumber: 1,
    equipmentClassificationCode: '',
    equipmentClassificationDescription: '',
    equipmentTypeCode: '',
    equipmentTypeDescription: '',
    lengthSpecificationCode: '',
    widthSpecificationCode: '',
    heightSpecificationCode: '',
  }];
  const requestObj = {
    standardEquipmentGroupId: 123,
    equipmentGroupName: '',
    equipmentGroupDescription: '',
    equipmentGroupComment: '',
    countryCode: '',
    countryDescription: '',
    groupOverviewDetails: GroupOverviewDetails,
    standardEquipmentGroupMembers: StandardEquipmentGroupMembersItem,
    removedEquipmentMemberIds: [123],
    unStackedEquipmentIds: [123],
  };

  beforeEach(() => {
    service = TestBed.get(EquipmentGroupEditService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getEquipmentDetails should call http GET', () => {
    const equipmentId = 1;
    service.getEquipmentDetails(equipmentId).subscribe();
    const url = `${service.endpoint.equipmentDetails}/${equipmentId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentStatus should call http PATCH', () => {
    const equipmentGroupID = 1;
    const statusData = {
      status: 'success'
    };
    service.getEquipmentStatus(statusData, equipmentGroupID).subscribe();
    const url = `${service.endpoint.equipmentDetails}/${equipmentGroupID}/status`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PATCH');
  });

  it('getCountryDetails should call http GET', () => {
    const data = {
      _embedded: {
        countries: [{
          countryName: '',
          countryCode: ''
        }]
      }
    };
    service.getCountryDetails().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getCountryDetails);
    req.flush(data);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentCategory should call http GET', () => {
    const data = {
      _embedded: {
        equipmentClassifications: [{
          equipmentClassificationDescription: '',
          equipmentClassificationCode: ''
        }]
      }
    };
    service.getEquipmentCategory().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getEquipmentCategory);
    req.flush(data);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentType should call http GET', () => {
    const data = {
      _embedded: {
        equipmentTypes: [{
          equipmentTypeDescription: '',
          equipmentTypeCode: ''
        }]
      }
    };
    const equipmentCategoryCode = '';
    service.getEquipmentType(equipmentCategoryCode).subscribe();
    const url = `${service.endpoint.getEquipmentType}?equipmentClassificationCode=${equipmentCategoryCode}`;
    const req = httpTestingController.expectOne(url);
    req.flush(data);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentTypeIds should call http GET', () => {
    const equipmentCategoryCode = '';
    service.getEquipmentTypeIds(equipmentCategoryCode).subscribe();
    const url = `${service.endpoint.getEquipmentType}?equipmentClassificationCode=${equipmentCategoryCode}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getEquipmentValues should call http GET', () => {
    const equipmentCategory = '';
    const equipmentType = '';
    const valueEndpoint = 123;
    service.getEquipmentValues(equipmentCategory, equipmentType, valueEndpoint).subscribe();
    const url = `${valueEndpoint}?equipmentClassificationCode=${equipmentCategory}&equipmentTypeCode=${equipmentType}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('editEquipmentGroup should call http PUT', () => {
    service.editEquipmentGroup(requestObj).subscribe();
    const url = `${service.endpoint.createEquipmentGroup}/${requestObj.standardEquipmentGroupId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PUT');
  });

  it('frameEquipmentDimensionValues expected setValidator in EquipmentGroupEditUtils should call', () => {
    const equimentDimensionValue = '_';
    const data = [{
      heightQuantity: 123,
      lengthQuantity: 1,
      unitOfHeightMeasurementCode: '',
      unitOfLengthMeasurementCode: '',
      unitOfWidthMeasurementCode: '',
      widthQuantity: 1,
    }];
    const editModel = {
      equipment_List: {
        desc: []
      }
    };
    spyOn(service, 'getEquipmentDimensionDetails');
    spyOn(EquipmentGroupEditUtils, 'setValidator');
    service.frameEquipmentDimensionValues(equimentDimensionValue, data
      , editModel, 'changeDetector', 'desc', 12);
    expect(EquipmentGroupEditUtils.setValidator).toHaveBeenCalled();
  });

  it('getEquipmentDimensionDetails return value should be defined', () => {
    const dimensionUnit = 'feet';
    spyOn(service, 'frameDimensionValue');
    const data = service.getEquipmentDimensionDetails({
      _embedded: {
        equipmentDimensions: []
      }
    }, 1, dimensionUnit);
    expect(data).toBeDefined();
  });

  it('frameDimensionValue return value should be defined', () => {
    const test = {
      feet: []
    };
    spyOn(service, 'getDimensionUnit');
    const call = service.frameDimensionValue('test', 'feet');
    expect(call).toBeDefined();
  });

  it('frameDimensionValue should call the spy EquipmentGroupCreateUtils', () => {
    spyOn(EquipmentGroupUtility, 'feetInchesFormat');
    spyOn(service, 'getDimensionUnit').and.returnValue('in');
    const value = {
      heightQuantity: 2,
      lengthQuantity: null,
      unitOfHeightMeasurementCode: 'in',
      unitOfLengthMeasurementCode: '',
      unitOfWidthMeasurementCode: '',
      widthQuantity: null
    };
    service.frameDimensionValue(value, 'Height');
    expect(service.getDimensionUnit).toHaveBeenCalled();
  });

  it('getDimensionUnit feet return value should be defined', () => {
    const dimensionUnit = 'feet';
    const data = service.getDimensionUnit(dimensionUnit);
    expect(data).toBeDefined();
  });

  it('getDimensionUnit inches return value should be defined', () => {
    const dimensionUnit = 'inches';
    const data = service.getDimensionUnit(dimensionUnit);
    expect(data).toBeDefined();
  });

  it('getDimensionUnit meter return value should be defined', () => {
    const dimensionUnit = 'meter';
    const data = service.getDimensionUnit(dimensionUnit);
    expect(data).toBeDefined();
  });

  it('getEquipmentDimension have been called', () => {
    const data = [{
      heightQuantity: 123,
      lengthQuantity: 123,
      unitOfHeightMeasurementCode: 123,
      unitOfLengthMeasurementCode: 123,
      unitOfWidthMeasurementCode: 123,
      widthQuantity: 123,
    }];
    const obj = {
      hasSubscribe: true,
    };
    const changeDetector = {
      detectChanges: jasmine.createSpy(),
    };
    spyOn(service, 'getCurrentEquipmentCategory');
    spyOn(service, 'getEquipmentValues').and.returnValue(of(data));
    spyOn(service, 'frameEquipmentDimensionValues');
    service.getEquipmentDimension(obj, changeDetector, 'Length', 0, '0');
    expect(service.getCurrentEquipmentCategory).toHaveBeenCalled();
  });

});




