import { EquipmentGroupEditUtils } from './equipment-group-edit.utils';
import { EquipmentGroupUtility } from '../../services/equipment-group.utility';
import { FormBuilder } from '@angular/forms';


describe('EquipmentGroupEditUtils', () => {
    const formbuilder = new FormBuilder();
    it('should be created', () => {
        expect(EquipmentGroupEditUtils).toBeTruthy();
    });

    it('setEquipmentFormGroup return value should be empty', () => {
        const returnValue = EquipmentGroupEditUtils.setEquipmentFormGroup(formbuilder, 0);
        expect(returnValue.controls.equipmentCategory.value).toEqual('');
    });

    it('setStackEquipmentsForm return value should be empty', () => {
        const returnValue = EquipmentGroupEditUtils.setStackEquipmentsForm(formbuilder);
        expect(returnValue.controls.equipmentCategory.value).toEqual('');
    });

    it('prePopulateDetails should call frameStackedEquipments', () => {
        const test = {
            standardEquipmentGroupMemberId: 123,
            standardEquipmentGroupStackingId: 123,
            stackedStandardEquipmentGroupMemberId: null,
            equipmentGroupSequenceNumber: 123,
            equipmentClassificationCode: '',
            equipmentClassificationDescription: '',
            equipmentTypeCode: '',
            equipmentTypeDescription: '',
            lengthSpecificationCode: '',
            lengthSpecificationDescription: '',
            widthSpecificationCode: '',
            widthSpecificationDescription: '',
            heightSpecificationCode: '',
            heightSpecificationDescription: '',
        };
        spyOn(EquipmentGroupEditUtils, 'frameStackedEquipments');
        const call = EquipmentGroupEditUtils.prePopulateDetails(test);
        expect(EquipmentGroupEditUtils.frameStackedEquipments).toHaveBeenCalled();
    });

    it('frameStackedEquipments return vale should be defined', () => {
        const test = [{
            equipmentGroupSequenceNumber: 123,
            equipmentClassificationCode: '',
            equipmentClassificationDescription: '',
            equipmentTypeCode: '',
            equipmentTypeDescription: '',
            lengthSpecificationCode: '',
            lengthSpecificationDescription: '',
            widthSpecificationCode: '',
            widthSpecificationDescription: '',
            heightSpecificationCode: '',
            heightSpecificationDescription: '',
        }];

        const call = EquipmentGroupEditUtils.frameStackedEquipments(test);
        expect(call).toBeDefined();
    });

    it('checkDimensionEmpty return value should be 123', () => {
        const call = EquipmentGroupEditUtils.checkDimensionEmpty('123');
        expect(call).toEqual('123');
    });

    it('checkCumulativeValues should call getCumulativeValues', () => {
        spyOn(EquipmentGroupUtility, 'getCumulativeValues');
        const call = EquipmentGroupEditUtils.checkCumulativeValues('123', true);
        expect(EquipmentGroupUtility.getCumulativeValues).toHaveBeenCalled();
    });
    it('checkCumulativeValues should call false getCumulativeValues', () => {
        spyOn(EquipmentGroupUtility, 'getCumulativeValues');
        const call = EquipmentGroupEditUtils.checkCumulativeValues('123', false);
        expect(call).toEqual('123');
    });

    it('generateStackedEquipmentDetails return should equal to null', () => {
        const testdata = {
            controls: formbuilder.group({
                'equipmentCategory': [''],
                'equipmentType': [''],
                'equipmentLength': [''],
                'equipmentWidth': [''],
                'equipmentHeight': [''],
                'standardEquipmentGroupMemberId': [''],
                'standardEquipmentGroupStackingId': [''],
                'equipmentGroupSequenceNumber': [''],
                'equipmentTypeDescription': ['']
            })
        };
        spyOn(EquipmentGroupEditUtils, 'checkCumulativeValues');
        const call = EquipmentGroupEditUtils.generateStackedEquipmentDetails(testdata, 123, true);
        expect(call).toEqual(null);
    });

    it('getInchesValues return should equal to 1476', () => {
        const call = EquipmentGroupEditUtils.getInchesValues('123');
        expect(call).toEqual(1476);
    });

    it('getInchesValues return should equal to 0', () => {
        const call = EquipmentGroupEditUtils.getInchesValues('---');
        expect(call).toEqual(0);
    });

    it('getInchesValues return should equal to 0', () => {
        const call = EquipmentGroupEditUtils.getInchesValues('10 in ft');
        expect(call).toEqual(NaN);
    });

    it('getInchesValues return should equal to 0', () => {
        const call = EquipmentGroupEditUtils.getInchesValues('in');
        expect(call).toEqual(NaN);
    });

    it('getAdjustedLengthValues return should equal to test', () => {
        spyOn(EquipmentGroupEditUtils, 'getInchesValues');
        const call = EquipmentGroupEditUtils.getAdjustedLengthValues('test');
        expect(call.description).toEqual('test');
    });
    it('getAdjustedLengthValues return should equal to test', () => {
        spyOn(EquipmentGroupEditUtils, 'getInchesValues').and.returnValue(123);
        const call = EquipmentGroupEditUtils.getAdjustedLengthValues('test');
        expect(call.value).toEqual(123);
    });
    it('getAdjustedHeightValues return should equal to ---', () => {
        spyOn(EquipmentGroupEditUtils, 'getInchesValues');
        const call = EquipmentGroupEditUtils.getAdjustedHeightValues('');
        expect(call.description).toEqual('---');
    });

    it('calculationOverview return should equal to test', () => {
        spyOn(EquipmentGroupEditUtils, 'convertlengthSpecification');
        spyOn(EquipmentGroupUtility, 'maxWidthGroupOverview');
        spyOn(EquipmentGroupUtility, 'feetInchesGroupOverview');
        spyOn(EquipmentGroupUtility, 'systemAdjustedLength');
        spyOn(EquipmentGroupUtility, 'systemAdjustedHeight');
        spyOn(EquipmentGroupEditUtils, 'generateRequestObject');
        EquipmentGroupEditUtils.calculationOverview({}, 'default');
        expect(EquipmentGroupEditUtils.convertlengthSpecification).toHaveBeenCalled();
    });
    it('calculationOverview else courage', () => {
        const testdata = [{
            equipmentGroupSequenceNumber: 123,
            equipmentClassificationCode: '',
            equipmentClassificationDescription: '',
            equipmentTypeCode: '',
            equipmentTypeDescription: '',
            lengthSpecificationCode: '',
            lengthSpecificationDescription: '',
            widthSpecificationCode: '',
            widthSpecificationDescription: '',
            heightSpecificationCode: '',
            heightSpecificationDescription: '',
            stackedEquipments: [],
        }];
        spyOn(EquipmentGroupEditUtils, 'convertlengthSpecification');
        spyOn(EquipmentGroupUtility, 'maxWidthGroupOverview');
        spyOn(EquipmentGroupUtility, 'feetInchesGroupOverview');
        spyOn(EquipmentGroupUtility, 'systemAdjustedLength');
        spyOn(EquipmentGroupUtility, 'systemAdjustedHeight');
        spyOn(EquipmentGroupEditUtils, 'generateRequestObject').and.returnValue(testdata);
        EquipmentGroupEditUtils.calculationOverview({}, '');
        expect(EquipmentGroupEditUtils.generateRequestObject).toHaveBeenCalled();
    });

    it('convertlengthSpecification should call checkLengthSpecEmpty', () => {
        const eGroupMembers = [{
            equipmentGroupSequenceNumber: 123,
            equipmentClassificationCode: '',
            equipmentClassificationDescription: '',
            equipmentTypeCode: '',
            equipmentTypeDescription: '',
            lengthSpecificationCode: 'test',
            lengthSpecificationDescription: '',
            widthSpecificationCode: '',
            widthSpecificationDescription: '',
            heightSpecificationCode: '',
            heightSpecificationDescription: '',
        }];
        const testdata = [{
            equipmentGroupSequenceNumber: 123,
            equipmentClassificationCode: '',
            equipmentClassificationDescription: '',
            equipmentTypeCode: '',
            equipmentTypeDescription: '',
            lengthSpecificationCode: '',
            lengthSpecificationDescription: '',
            widthSpecificationCode: '',
            widthSpecificationDescription: '',
            heightSpecificationCode: '',
            heightSpecificationDescription: '',
            stackedEquipments: eGroupMembers,
        }];
        spyOn(EquipmentGroupEditUtils, 'checkLengthSpecEmpty');
        EquipmentGroupEditUtils.convertlengthSpecification(testdata);
        expect(EquipmentGroupEditUtils.checkLengthSpecEmpty).toHaveBeenCalled();
    });

    it('checkLengthSpecEmpty return should equal to 123 ft', () => {
        const call = EquipmentGroupEditUtils.checkLengthSpecEmpty('123');
        expect(call).toEqual('123 ft');
    });

    it('checkLengthSpecEmpty return should equal to null', () => {
        const call = EquipmentGroupEditUtils.checkLengthSpecEmpty('');
        expect(call).toEqual(null);
    });

    it('initializeEquipmentFormDetails return should equal to null', () => {
        const data = {
            equipmentDetailsForm: null
        };
        const call = EquipmentGroupEditUtils.initializeEquipmentFormDetails(data, formbuilder);
        expect(data.equipmentDetailsForm.controls.name.value).toEqual('');
    });
    it('setDetailValidator have been called', () => {
        const data = {
            equipmentDetailsForm: null,
            updateValueAndValidity: jasmine.createSpy(),
            setValidators: jasmine.createSpy()
        };
        EquipmentGroupEditUtils.setDetailValidator(data, true);
        expect(data.updateValueAndValidity).toHaveBeenCalled();
    });
    it('setDetailValidator have been called else', () => {
        const data = {
            equipmentDetailsForm: null,
            updateValueAndValidity: jasmine.createSpy(),
            setValidators: jasmine.createSpy(),
            clearValidators: jasmine.createSpy(),
        };
        EquipmentGroupEditUtils.setDetailValidator(data, false);
        expect(data.updateValueAndValidity).toHaveBeenCalled();
    });
    it('populateEquipmentDetailsForm have been called else', () => {
        const editModelData = {
            equipmentGroup: [{
                equipmentGroupSequenceNumber: 123,
                equipmentClassificationCode: '',
                equipmentClassificationDescription: '',
                equipmentTypeCode: '',
                equipmentTypeDescription: '',
                lengthSpecificationCode: 'test',
                lengthSpecificationDescription: '',
                widthSpecificationCode: '',
                widthSpecificationDescription: '',
                heightSpecificationCode: '',
                heightSpecificationDescription: '',
                stackedEquipments: [],
            }],
            equipmentDetailsForm: formbuilder.group({
                'name': [''],
                'description': [''],
                'country': [''],
                'comments': [''],
                'equipmentGroupForm': formbuilder.array([
                    formbuilder.group({
                        'equipmentCategory': [''],
                        'equipmentType': [''],
                        'equipmentLength': [''],
                        'equipmentWidth': [''],
                        'equipmentHeight': [''],
                        'standardEquipmentGroupMemberId': [''],
                        'standardEquipmentGroupStackingId': [''],
                        'equipmentGroupSequenceNumber': [1],
                        'equipmentTypeDescription': [''],
                        'stackedEquipments': formbuilder.array([formbuilder.group({
                            'equipmentCategory': [''],
                            'equipmentType': [''],
                            'equipmentLength': [''],
                            'equipmentWidth': [''],
                            'equipmentHeight': [''],
                            'standardEquipmentGroupMemberId': [''],
                            'standardEquipmentGroupStackingId': [''],
                            'equipmentGroupSequenceNumber': [1],
                            'equipmentTypeDescription': [''],
                        })])
                    })
                ])
            }),
        };
        spyOn(EquipmentGroupEditUtils, 'loadStackElements');
        spyOn(EquipmentGroupEditUtils, 'setStackedGroupFormValues');
        spyOn(EquipmentGroupUtility, 'setOverviewType');
        spyOn(EquipmentGroupEditUtils, 'getEquipmentGroupForm');
        EquipmentGroupEditUtils.populateEquipmentDetailsForm(editModelData, formbuilder);
        expect(EquipmentGroupEditUtils.setStackedGroupFormValues).toHaveBeenCalled();
    });

    it('setStackedGroupFormValues have been called', () => {
        const eGroupMembers = [{
            equipmentGroupSequenceNumber: 123,
            equipmentClassificationCode: '',
            equipmentClassificationDescription: '',
            equipmentTypeCode: '',
            equipmentTypeDescription: '',
            lengthSpecificationCode: 'test',
            lengthSpecificationDescription: '',
            widthSpecificationCode: '',
            widthSpecificationDescription: '',
            heightSpecificationCode: '',
            heightSpecificationDescription: '',
        }];
        const editModelData = {
            equipmentGroup: [{
                equipmentGroupSequenceNumber: 123,
                equipmentClassificationCode: '',
                equipmentClassificationDescription: '',
                equipmentTypeCode: '',
                equipmentTypeDescription: '',
                lengthSpecificationCode: 'test',
                lengthSpecificationDescription: '',
                widthSpecificationCode: '',
                widthSpecificationDescription: '',
                heightSpecificationCode: '',
                heightSpecificationDescription: '',
                stackedEquipments: eGroupMembers,
            }],
            equipmentDetailsForm: formbuilder.group({
                'name': [''],
                'description': [''],
                'country': [''],
                'comments': [''],
                'equipmentGroupForm': formbuilder.array([
                    formbuilder.group({
                        'equipmentCategory': [''],
                        'equipmentType': [''],
                        'equipmentLength': [''],
                        'equipmentWidth': [''],
                        'equipmentHeight': [''],
                        'standardEquipmentGroupMemberId': [''],
                        'standardEquipmentGroupStackingId': [''],
                        'equipmentGroupSequenceNumber': [1],
                        'equipmentTypeDescription': [''],
                        'stackedEquipments': formbuilder.array([formbuilder.group({
                            'equipmentCategory': [''],
                            'equipmentType': [''],
                            'equipmentLength': [''],
                            'equipmentWidth': [''],
                            'equipmentHeight': [''],
                            'standardEquipmentGroupMemberId': [''],
                            'standardEquipmentGroupStackingId': [''],
                            'equipmentGroupSequenceNumber': [1],
                            'equipmentTypeDescription': [''],
                        })])
                    })
                ])
            }),
        };
        EquipmentGroupEditUtils.setStackedGroupFormValues(0, editModelData);
        expect(editModelData).toBeDefined();
    });

    it('setValidator have been called', () => {
        const editModelData = {
            equipmentGroup: [{
                equipmentGroupSequenceNumber: 123,
                equipmentClassificationCode: '',
                equipmentClassificationDescription: '',
                equipmentTypeCode: '',
                equipmentTypeDescription: '',
                lengthSpecificationCode: 'test',
                lengthSpecificationDescription: '',
                widthSpecificationCode: '',
                widthSpecificationDescription: '',
                heightSpecificationCode: '',
                heightSpecificationDescription: '',
            }],
            equipmentDetailsForm: formbuilder.group({
                'name': [''],
                'description': [''],
                'country': [''],
                'comments': [''],
                'equipmentGroupForm': formbuilder.array([
                    formbuilder.group({
                        'equipmentCategory': [''],
                        'equipmentType': [''],
                        'equipmentLength': [''],
                        'equipmentWidth': [''],
                        'equipmentHeight': [''],
                        'standardEquipmentGroupMemberId': [''],
                        'standardEquipmentGroupStackingId': [''],
                        'equipmentGroupSequenceNumber': [1],
                        'equipmentTypeDescription': [''],
                        'stackedEquipments': formbuilder.array([formbuilder.group({
                            'equipmentCategory': [''],
                            'equipmentType': [''],
                            'equipmentLength': [''],
                            'equipmentWidth': [''],
                            'equipmentHeight': [''],
                            'standardEquipmentGroupMemberId': [''],
                            'standardEquipmentGroupStackingId': [''],
                            'equipmentGroupSequenceNumber': [1],
                            'equipmentTypeDescription': [''],
                        })])
                    })
                ])
            }),
        };
        spyOn(EquipmentGroupEditUtils, 'setDetailValidator');
        EquipmentGroupEditUtils.setValidator('test', 0, true, editModelData);
        expect(EquipmentGroupEditUtils.setDetailValidator).toHaveBeenCalled();
    });



});
