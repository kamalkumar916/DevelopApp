import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { EquipmentGroupEditService } from './services/equipment-group-edit.service';

import { EquipmentGroupEditComponent } from './equipment-group-edit.component';

import { configureTestSuite } from 'ng-bullet';

import { DropdownModule } from 'primeng/dropdown';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormArray, Validators } from '@angular/forms';
import { MenuModule } from 'primeng/menu';
import { DialogModule } from 'primeng/dialog';
import { OrderListModule } from 'primeng/orderlist';
import { TableModule } from 'primeng/table';

import { EquipmentGroupResequenceComponent } from '../equipment-group-resequence/equipment-group-resequence.component';
import { EquipmentGroupStackComponent } from '../equipment-group-stack/equipment-group-stack.component';

import { JbhLoaderModule } from './../../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { UnitMetricsImperialPipe } from '../pipes/unit-metrics-imperial.pipe';
import { ActivatedRoute } from '@angular/router';
import { EquipmentGroupUtility } from '../services/equipment-group.utility';
import { EquipmentGroupEditUtils } from './services/equipment-group-edit.utils';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { FormValidationUtils } from 'src/app/shared/jbh-app-services/form-validation-utils';

const getCountryDetailsData = {
  _links: {
    self: {
      href: '',
      title: ''
    }
  },
  _embedded: {
    countries: [{
      countryCallingCode: '+61',
      countryCode: 'AUS',
      countryID: 10,
      countryName: 'Australia'
    }]
  },
  page: {
    number: 0,
    size: 1,
    totalElements: 1,
    totalPages: 1
  }
};

const getEquipmentCategoryData = {
  _links: {
    profile: {
      href: ''
    },
    search: {
      href: ''
    },
    self: {
      href: ''
    }
  },
  _embedded: {
    equipmentClassifications: [{
      createTimestamp: '',
      effectiveTimestamp: '',
      equipmentClassificationCode: 'Air',
      equipmentClassificationDescription: 'AIR',
      equipmentFunctionalGroupCode: 'TrlngEquip',
      expirationTimestamp: ''
    }]
  }
};

const getEquipmentTypeData = {
  _embedded: {
    equipmentTypes: [{
      createTimestamp: '',
      effectiveTimestamp: '',
      equipmentTypeCode: 'Chassis',
      equipmentTypeDescription: 'CHASSIS',
      expirationTimestamp: '',
    },
    {
      createTimestamp: '',
      effectiveTimestamp: '',
      equipmentTypeCode: 'Chassis',
      equipmentTypeDescription: 'CHASSIS',
      expirationTimestamp: '',
    },
    ]
  },
  _links: {
    self: {
      href: '',
    },
  },
};

const getEquipmentDetailsData = {
  countryCode: 'USA',
  countryDescription: 'USA',
  equipmentGroupComment: 'manageEquipmentGroupingCreateSingle',
  equipmentGroupDescription: 'automation run',
  equipmentGroupName: 'AUTOMATION CHECK 274',
  equipmentGroupTypeCode: 'NonMoving',
  equipmentGroupTypeCodeDescription: 'Non Moving',
  expirationTimestamp: '',
  standardEquipmentGroupId: 711,
  standardEquipmentGroupMembers: [{
    equipmentClassificationCode: 'Container',
    equipmentClassificationDescription: 'CONTAINER',
    equipmentGroupSequenceNumber: 3,
    equipmentTypeCode: 'Intermodal',
    equipmentTypeDescription: 'INTERMODAL',
    heightSpecificationCode: '162',
    heightSpecificationDescription: '13 ft 6 in',
    lengthSpecificationCode: '45',
    lengthSpecificationDescription: '45 ft',
    stackedEquipments: null,
    stackedStandardEquipmentGroupMemberId: null,
    standardEquipmentGroupMemberId: 2614,
    standardEquipmentGroupStackingId: null,
    widthSpecificationCode: '102',
    widthSpecificationDescription: '8 ft 6 in',
  }],
  status: 'Inactive'
};

const getEquipmentTypeIdsData = {
  _embedded: {
    equipmentTypes: [{
      createTimestamp: '',
      equipmentTypeCode: 'Dry Van',
      effectiveTimestamp: '',
      equipmentTypeDescription: 'DRY VAN',
      expirationTimestamp: '',
      links: {
        self: {
          href: ''
        },
        equipmentType: {
          href: ''
        },
        equipmentClassificationTypeAssociations: {
          href: ''
        },
        equipments: {
          href: ''
        }
      }
    }]
  },
  links: {
    self: {
      href: ''
    }
  }
};
const loadEquipmentTypeData = [{
  standardEquipmentGroupMemberId: null,
  standardEquipmentGroupStackingId: null,
  stackedStandardEquipmentGroupMemberId: null,
  equipmentGroupSequenceNumber: null,
  equipmentClassificationCode: '',
  equipmentClassificationDescription: '',
  equipmentTypeCode: '',
  equipmentTypeDescription: '',
  lengthSpecificationCode: '',
  lengthSpecificationDescription: '',
  widthSpecificationCode: '',
  widthSpecificationDescription: '',
  heightSpecificationCode: '',
  heightSpecificationDescription: '',
  stackedEquipments: [{
    standardEquipmentGroupMemberId: null,
    standardEquipmentGroupStackingId: null,
    stackedStandardEquipmentGroupMemberId: null,
    equipmentGroupSequenceNumber: null,
    equipmentClassificationCode: '',
    equipmentClassificationDescription: '',
    equipmentTypeCode: '',
    equipmentTypeDescription: '',
    lengthSpecificationCode: '',
    lengthSpecificationDescription: '',
    widthSpecificationCode: '',
    widthSpecificationDescription: '',
    heightSpecificationCode: '',
    heightSpecificationDescription: '',
    lengthSpecificationsVal: '',
    widthSpecificationsVal: '',
    heightSpecificationsVal: ''
  }],
  lengthSpecificationsVal: '',
  widthSpecificationsVal: '',
  heightSpecificationsVal: ''
}];
const formvalueInvalid = {
  name: '',
  country: '',
  equipmentGroupForm: {
    equipmentCategory: '',
    equipmentType: '',
    stackedEquipments: {
      equipmentCategory: '',
      equipmentType: '',
    }
  }
};
const formvalueValid = {
  name: 'abc',
  country: { value: { countryCode: '' } },
  equipmentGroupForm: {
    equipmentCategory: 'test',
    equipmentType: 'test',
    stackedEquipments: {
      equipmentCategory: 'test',
      equipmentType: 'test',
    }
  }
};
function getMockForm(fb: FormBuilder, stacked: Boolean, formvalue: any) {
  if (stacked) {
    return fb.group({
      'name': [formvalue.name, Validators.required],
      'description': [''],
      'country': [formvalue.country, Validators.required],
      'comments': [''],
      'equipmentGroupForm': fb.array([
        fb.group({
          'equipmentCategory': [formvalue.equipmentGroupForm.equipmentCategory, Validators.required],
          'equipmentType': [formvalue.equipmentGroupForm.equipmentType, Validators.required],
          'equipmentLength': [''],
          'equipmentWidth': [''],
          'equipmentHeight': [''],
          'standardEquipmentGroupMemberId': [''],
          'standardEquipmentGroupStackingId': [''],
          'equipmentGroupSequenceNumber': [1],
          'equipmentTypeDescription': [''],
          'stackedEquipments': fb.array([fb.group({
            'equipmentCategory': [formvalue.equipmentGroupForm.stackedEquipments.equipmentCategory, Validators.required],
            'equipmentType': [formvalue.equipmentGroupForm.stackedEquipments.equipmentType, Validators.required],
            'equipmentLength': [''],
            'equipmentWidth': [''],
            'equipmentHeight': [''],
            'standardEquipmentGroupMemberId': [''],
            'standardEquipmentGroupStackingId': [''],
            'equipmentGroupSequenceNumber': [1],
            'equipmentTypeDescription': [''],
          })])
        })
      ])
    });
  } else {
    return fb.group({
      'name': [formvalue.name, Validators.required],
      'description': [''],
      'country': [formvalue.country, Validators.required],
      'comments': [''],
      'equipmentGroupForm': fb.array([
        fb.group({
          'equipmentCategory': [formvalue.equipmentGroupForm.equipmentCategory, Validators.required],
          'equipmentType': [formvalue.equipmentGroupForm.equipmentType, Validators.required],
          'equipmentLength': [''],
          'equipmentWidth': [''],
          'equipmentHeight': [''],
          'standardEquipmentGroupMemberId': [''],
          'standardEquipmentGroupStackingId': [''],
          'equipmentGroupSequenceNumber': [1],
          'equipmentTypeDescription': [''],
          'stackedEquipments': fb.array([])
        })
      ])
    });
  }
}
class MockequipmentGroupEditService {
  constructor() { }
  getCountryDetails() {
    return of(getCountryDetailsData);
  }
  getEquipmentCategory() {
    return of(getEquipmentCategoryData);
  }
  getEquipmentDetails() {
    return of(getEquipmentDetailsData);
  }
  getEquipmentType() {
    return of(getEquipmentTypeData);
  }
  getEquipmentTypeIds() {
    return of(getEquipmentTypeIdsData);
  }
  getEquipmentDimension() {
    return throwError(null);
  }
  getEquipmentStatus() {
    return of({});
  }
  onEditEquipmentGroup() {
    return null;
  }
}

describe('EquipmentGroupEditComponent', () => {
  let component: EquipmentGroupEditComponent;
  let fixture: ComponentFixture<EquipmentGroupEditComponent>;
  const fb: FormBuilder = new FormBuilder();

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule,
        HttpClientTestingModule, RouterTestingModule, DropdownModule, BreadcrumbModule, ConfirmDialogModule, MenuModule, FormsModule,
        ReactiveFormsModule, JbhLoaderModule, DirectivesModule, DialogModule, OrderListModule, TableModule],
      providers: [UserService, AppConfigService, MessageService, ConfirmationService,
        { provide: EquipmentGroupEditService, useClass: MockequipmentGroupEditService }],
      declarations: [EquipmentGroupEditComponent, EquipmentGroupResequenceComponent, EquipmentGroupStackComponent, UnitMetricsImperialPipe]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupEditComponent);
    component = fixture.componentInstance;
    TestBed.get(ActivatedRoute).queryParams = {
      value: {
        standardEquipmentGroupID: 1
      }
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onSelectCountry hasCountryChanged value should be true', () => {
    component.onSelectCountry('test');
    expect(component.equipmentGroupEditModel.hasCountryChanged).toBe(true);
  });

  it('onSelectEquipmentType should be call getEquipmentDimension', () => {
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'getEquipmentDimension');
    component.onSelectEquipmentType('test', 1, 'test1');
    expect(equipmentGroupEditService.getEquipmentDimension).toHaveBeenCalled();
  });

  it('loadEquipmentType should call', () => {
    spyOn(component, 'getEquipmentType');
    component.loadEquipmentType(loadEquipmentTypeData);
    expect(component.getEquipmentType).toHaveBeenCalled();
  });

  it('onSelectEquipmentLength should be call thresholdExceedwarning', () => {
    spyOn(EquipmentGroupUtility, 'feetInchesGroupOverview');
    spyOn(EquipmentGroupUtility, 'systemAdjustedLength');
    spyOn(component, 'thresholdExceedWarning');
    spyOn(component, 'groupOverviewLengthWidthHeight');
    component.equipmentGroupEditModel.systemAdjustedLength = '123';
    component.onSelectEquipmentLength('test', 1);
    expect(component.thresholdExceedWarning).toHaveBeenCalled();
  });

  it('onSelectEquipmentWidth should be call maxWidthGroupOverview', () => {
    spyOn(component, 'groupOverviewLengthWidthHeight');
    spyOn(EquipmentGroupUtility, 'maxWidthGroupOverview');
    component.onSelectEquipmentWidth('test', 1);
    expect(EquipmentGroupUtility.maxWidthGroupOverview).toHaveBeenCalled();
  });

  it('onSelectEquipmentHeight should be call thresholdexceedwarning', () => {
    spyOn(component, 'groupOverviewLengthWidthHeight');
    spyOn(EquipmentGroupUtility, 'maxWidthGroupOverview');
    spyOn(EquipmentGroupUtility, 'systemAdjustedHeight');
    spyOn(component, 'thresholdExceedWarning');
    component.onSelectEquipmentHeight('test', 1);
    expect(component.thresholdExceedWarning).toHaveBeenCalled();
  });

  it('generateStackOverflow stackOverFlowMenuItems length should be 2', () => {
    spyOn(component, 'onAddStackedEquipment');
    spyOn(component, 'onUnStackEquipment');
    spyOn(component, 'onRemoveStackedEquipment');
    component.generateStackOverflow(1, 1);
    expect(component.equipmentGroupEditModel.stackOverFlowMenuItems.length).toEqual(2);
  });

  it('onSelectUnitOfMeasure unitOfMeasure should be defined', () => {
    component.onSelectUnitOfMeasure('test');
    expect(component.equipmentGroupEditModel.unitOfMeasure).toBeDefined();
  });

  it('thresholdExceedWarning', () => {
    const val = component.equipmentGroupEditModel.equipmentDetailsForm.controls['equipmentGroupForm'] as FormArray;
    val.insert(0, fb.group({
      'equipmentCategory': [''],
      'equipmentType': [''],
      'equipmentLength': [''],
      'equipmentWidth': [''],
      'equipmentHeight': [''],
      'standardEquipmentGroupMemberId': [''],
      'standardEquipmentGroupStackingId': [''],
      'equipmentGroupSequenceNumber': [1, ''],
      'equipmentTypeDescription': [''],
      'stackedEquipments': fb.array([])
    }));
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.accept();
      confirmation.reject();
    });
    spyOn(component, 'onSelectEquipmentLength');
    spyOn(EquipmentGroupEditUtils, 'calculationOverview');
    component.thresholdExceedWarning(0, 'equipmentLength');
    expect(EquipmentGroupEditUtils.calculationOverview).toHaveBeenCalled();
  });

  it('onInactivate unitOfMeasure should be defined', () => {
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirmation) => {
      confirmation.accept();
    });
    spyOn(component, 'activeInactivate');
    component.onInactivate();
    expect(component.activeInactivate).toHaveBeenCalled();
  });


  it('getCountryDetails should set countryDetails to be an empty array', () => {
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'getCountryDetails').and.returnValue(throwError(null));
    component.getCountryDetails();
    expect(component.equipmentGroupEditModel.sectionLoading).toBeFalsy();
  });

  it('getEquipmentCategory should set countryDetails to be an empty array', () => {
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'getEquipmentCategory').and.returnValue(throwError(null));
    component.getEquipmentCategory();
    expect(component.equipmentGroupEditModel.sectionLoading).toBeFalsy();
  });

  it('onSelectCategory should call the spy calculationOverview', () => {
    spyOn(EquipmentGroupUtility, 'setOverviewType');
    spyOn(component, 'getEquipmentGroupForm');
    spyOn(component, 'getEquipmentType');
    spyOn(EquipmentGroupEditUtils, 'calculationOverview');
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueInvalid);
    component.onSelectCategory('test', 0, true, 0);
    expect(EquipmentGroupEditUtils.calculationOverview).toHaveBeenCalled();
  });

  it('onSelectCategory should call the spy getEquipmentType', () => {
    spyOn(EquipmentGroupUtility, 'setOverviewType');
    spyOn(component, 'getEquipmentGroupForm');
    spyOn(component, 'getEquipmentType');
    spyOn(EquipmentGroupEditUtils, 'calculationOverview');
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, false, formvalueInvalid);
    component.onSelectCategory('test', 0, true);
    expect(component.getEquipmentType).toHaveBeenCalled();
  });

  it('getEquipmentType sectionloading should be false', () => {
    spyOn(component, 'getEquipmentAssociations');
    component.getEquipmentType('test', 0, 1);
    expect(component.equipmentGroupEditModel.sectionLoading).toBeFalsy();
  });

  it('getEquipmentType sectionloading should be false', () => {
    spyOn(component, 'getEquipmentAssociations');
    component.getEquipmentType('test', 0, 0);
    expect(component.equipmentGroupEditModel.sectionLoading).toBeFalsy();
  });

  it('getEquipmentType sectionloading should be false', () => {
    spyOn(component, 'getEquipmentAssociations');
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'getEquipmentType').and.returnValue(throwError(null));
    component.getEquipmentType('test', 0, 0);
    expect(component.equipmentGroupEditModel.sectionLoading).toBeFalsy();
  });

  it('selectEquipmentType should call calculationOverview', () => {
    spyOn(component, 'onSelectEquipmentType');
    spyOn(EquipmentGroupEditUtils, 'calculationOverview');
    component.equipmentGroupEditModel.equipmentTypeList = [];
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueInvalid);
    component.selectEquipmentType('test', 0, true, 0);
    expect(EquipmentGroupEditUtils.calculationOverview).toHaveBeenCalled();
  });

  it('selectEquipmentType should call onSelectEquipmentType', () => {
    spyOn(component, 'onSelectEquipmentType');
    spyOn(EquipmentGroupEditUtils, 'calculationOverview');
    component.equipmentGroupEditModel.equipmentTypeList = [[{
      value: 'test',
      label: ''
    }]];
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueInvalid);
    component.selectEquipmentType('test', 0, true);
    expect(component.onSelectEquipmentType).toHaveBeenCalled();
  });

  it('getEquipmentType sectionloading should be false', () => {
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'getEquipmentDetails').and.returnValue(throwError(null));
    component.viewEquipmentDetails(711);
    expect(component.equipmentGroupEditModel.sectionLoading).toBeFalsy();
  });

  it('getEquipmentAssociations should call the spy onSelectEquipmentType', () => {
    spyOn(component, 'onSelectEquipmentType');
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueInvalid);
    component.getEquipmentAssociations('test', 0, '0.0');
    expect(component.onSelectEquipmentType).toHaveBeenCalled();
  });

  it('getEquipmentAssociations error block is called', () => {
    spyOn(component, 'onSelectEquipmentType');
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'getEquipmentTypeIds').and.returnValue(throwError(null));
    component.getEquipmentAssociations('test', 0, '0.0');
    expect(component.equipmentGroupEditModel.sectionLoading).toBeFalsy();
  });

  it('onRemoveStackedEquipment have been called', () => {
    spyOn(component, 'populateFormValues');
    spyOn(EquipmentGroupUtility, 'setOverviewType');
    spyOn(EquipmentGroupEditUtils, 'calculationOverview');
    component.equipmentGroupEditModel.unStackedEquipments = [];
    component.equipmentGroupEditModel.removedEquipments = [];
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueInvalid);
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirm) => {
      confirm.accept();
    });
    component.onRemoveStackedEquipment(0, 0);
    expect(component.populateFormValues).toHaveBeenCalled();
  });

  it('onRemoveEquipment have been called', () => {
    spyOn(component, 'removeStackedParent');
    spyOn(component, 'getEquipmentGroupForm');
    spyOn(EquipmentGroupUtility, 'setOverviewType');
    spyOn(EquipmentGroupEditUtils, 'calculationOverview');
    const confirmationService = TestBed.get(ConfirmationService);
    spyOn(confirmationService, 'confirm').and.callFake((confirm) => {
      confirm.accept();
    });
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueInvalid);
    component.equipmentGroupEditModel.removedEquipments = [];
    component.onRemoveEquipment(0);
    expect(component.removeStackedParent).toHaveBeenCalled();
  });

  it('validateStackFormFields should return false', () => {
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueInvalid);
    expect(component.validateStackFormFields('', 0, 0)).toBeFalsy();
  });

  it('validateFormFields should return false', () => {
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, false, formvalueInvalid);
    expect(component.validateFormFields('equipmentType', 0)).toBeFalsy();
  });

  it('onEditEquipment should call the spy onEditEquipmentGroup', () => {
    spyOn(FormValidationUtils, 'validateAllFormFields');
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'onEditEquipmentGroup');
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, true, formvalueValid);
    component.onEditEquipment();
    expect(equipmentGroupEditService.onEditEquipmentGroup).toHaveBeenCalled();
  });

  it('onEditEquipment should call the spy clear', () => {
    spyOn(FormValidationUtils, 'validateAllFormFields');
    const equipmentGroupEditService: EquipmentGroupEditService = TestBed.get(EquipmentGroupEditService);
    spyOn(equipmentGroupEditService, 'onEditEquipmentGroup');
    const toast = TestBed.get(MessageService);
    spyOn(toast, 'add');
    spyOn(toast, 'clear');
    component.equipmentGroupEditModel.equipmentDetailsForm = getMockForm(fb, false, formvalueValid);
    component.onEditEquipment();
    expect(toast.clear).toHaveBeenCalled();
  });
});
