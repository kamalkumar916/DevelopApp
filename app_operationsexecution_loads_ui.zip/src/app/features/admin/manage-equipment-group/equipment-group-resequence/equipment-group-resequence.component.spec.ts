import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';


import { EquipmentGroupResequenceComponent } from './equipment-group-resequence.component';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';


import { configureTestSuite } from 'ng-bullet';

import { DialogModule } from 'primeng/dialog';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { OrderListModule } from 'primeng/orderlist';
import { FormBuilder } from '@angular/forms';

describe('EquipmentGroupResequenceComponent', () => {
  let component: EquipmentGroupResequenceComponent;
  let fixture: ComponentFixture<EquipmentGroupResequenceComponent>;
  const fb: FormBuilder = new FormBuilder();
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, DialogModule, DirectivesModule, OrderListModule],
      providers: [UserService, AppConfigService, MessageService],
      declarations: [EquipmentGroupResequenceComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupResequenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('onCancel should have called', () => {
    component.onCancel();
    expect(component.equipmentGroupResequenceModel.isPopUpVisible).toBeFalsy();
  });
  it('onSave should have called', () => {
    spyOn(component.outputResequenceList, 'emit');
    component.onSave();
    expect(component.outputResequenceList.emit).toHaveBeenCalled();
  });
  it('afterReorder should have called', () => {
    component.afterReorder('test');
    expect(component.equipmentGroupResequenceModel.resequencedList).toBeUndefined();
  });
  it('inputResequenceList input set have been called', () => {
    const testdata = {
      inputOrderList: fb.array([]),
      dialogVisible: true,
      index: 123,
      stackOnCategory: 'test'
    };
    spyOn(component, 'resequenceOrder');
    component.inputResequenceList = testdata;
    expect(component.resequenceOrder).toHaveBeenCalled();
  });
  it('resequenceOrder should have called', () => {
    const inputListData = {
      inputOrderList: fb.array([]),
      dialogVisible: true,
      index: 123,
      stackOnCategory: 'test'
    };
    const inputFormListData = fb.array([]);
    component.resequenceOrder(inputListData, inputFormListData);
    expect(component.equipmentGroupResequenceModel.isPopUpVisible).toBeDefined();
  });
  it('formArrayList should have called', () => {
    component.equipmentGroupResequenceModel.acolumnOptions = fb.array([]);
    const call = component.formArrayList;
    expect(call).toBeDefined();
  });
});
