import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input,
  OnDestroy, OnInit, Output
} from '@angular/core';
import { FormArray } from '@angular/forms';
import * as lodashUtils from 'lodash';

import { ResequenceList } from './../model/equipment-group.interface';
import { EquipmentGroupResequence } from './model/equipment-group-resequence.model';

@Component({
  selector: 'app-equipment-group-resequence',
  templateUrl: './equipment-group-resequence.component.html',
  styleUrls: ['./equipment-group-resequence.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EquipmentGroupResequenceComponent implements OnInit {
  @Input() set inputResequenceList(inputList: ResequenceList) {
    if (inputList) {
      this.resequenceOrder(inputList, inputList.inputOrderList);
    }
  }
  @Output() readonly outputResequenceList: EventEmitter<any> = new EventEmitter();
  equipmentGroupResequenceModel: EquipmentGroupResequence;
  constructor() {
    this.equipmentGroupResequenceModel = new EquipmentGroupResequence();
  }

  ngOnInit() {
  }
  resequenceOrder(inputList: ResequenceList, inputFormList: FormArray) {
    this.equipmentGroupResequenceModel.isPopUpVisible = inputList.dialogVisible;
    this.equipmentGroupResequenceModel.acolumnOptions = lodashUtils.cloneDeep(inputList.inputOrderList);
    this.equipmentGroupResequenceModel.formList = inputFormList;
  }
  afterReorder(event) {
    this.equipmentGroupResequenceModel.resequencedList = this.equipmentGroupResequenceModel.acolumnOptions;
  }
  onSave() {
    this.equipmentGroupResequenceModel.resequencedList = this.equipmentGroupResequenceModel.acolumnOptions;
    this.equipmentGroupResequenceModel.isPopUpVisible = false;
    this.outputResequenceList.emit(this.equipmentGroupResequenceModel.resequencedList);
  }
  get formArrayList() {
    return this.equipmentGroupResequenceModel.acolumnOptions;
  }
  onCancel() {
    this.equipmentGroupResequenceModel.isPopUpVisible = false;
  }
}
