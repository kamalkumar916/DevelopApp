import { FormArray } from '@angular/forms';

export class EquipmentGroupResequence {
    acolumnOptions: FormArray;
    resequencedList: FormArray;
    formList: FormArray;
    isPopUpVisible: boolean;
    constructor() {

    }
}
