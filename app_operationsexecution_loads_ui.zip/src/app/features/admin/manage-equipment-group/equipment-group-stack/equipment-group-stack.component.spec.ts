import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/components/common/messageservice';

import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';

import { EquipmentGroupStackComponent } from './equipment-group-stack.component';

import { configureTestSuite } from 'ng-bullet';

import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { RadioButtonModule } from 'primeng/radiobutton';

describe('EquipmentGroupStackComponent', () => {
  let component: EquipmentGroupStackComponent;
  let fixture: ComponentFixture<EquipmentGroupStackComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule,
        RouterTestingModule, TableModule, RadioButtonModule, DialogModule],
      providers: [UserService, AppConfigService, MessageService],
      declarations: [EquipmentGroupStackComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentGroupStackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('onSave have been called', () => {
    component.onSave();
    expect(component.stackModel.displayValue).toBe(false);
  });
  it('onCancel have been called', () => {
    component.onCancel();
    expect(component.stackModel.displayValue).toBe(false);
  });
});








