import { FormArray, FormGroup } from '@angular/forms';
import { ColumnModel } from '../../model/equipment-group.interface';

export class EquipmentGroupStack {
    acolumnOptions: FormArray;
    stackedEquipmentList: FormGroup;
    formList: FormArray;
    displayValue: boolean;
    cols: Array<ColumnModel>;
    selectedRow: FormGroup;
    stackedCategory: string;
    constructor() {
    }
}
