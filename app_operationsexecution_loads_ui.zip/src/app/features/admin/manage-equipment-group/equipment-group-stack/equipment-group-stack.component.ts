import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, Input,
  OnDestroy, OnInit, AfterViewInit, Output, ViewChild
} from '@angular/core';
import * as lodashUtils from 'lodash';
import { FormArray, FormGroup } from '@angular/forms';

import { ResequenceList } from './../model/equipment-group.interface';
import { EquipmentGroupStack } from './model/equipment-group-stack.model';
@Component({
  selector: 'app-equipment-group-stack',
  templateUrl: './equipment-group-stack.component.html',
  styleUrls: ['./equipment-group-stack.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EquipmentGroupStackComponent implements OnInit {
  @Input() set inputStackList(inputList: ResequenceList) {
    if (inputList) {
      this.stackOrder(inputList, inputList.inputOrderList);
    }
  }
  @Output() readonly outputStackList: EventEmitter<any> = new EventEmitter();
  stackModel: EquipmentGroupStack;
  constructor() {
    this.stackModel = new EquipmentGroupStack();
  }

  ngOnInit() {
    this.stackModel.cols = [
      { field: 'number', header: 'Number' },
      { field: 'equipmentcategory', header: 'Equipment Category' },
      { field: 'equipmenttype', header: 'Equipment Type' },
      { field: 'length', header: 'Length' },
      { field: 'width', header: 'Width' },
      { field: 'height', header: 'Height' },
    ];
  }
  stackOrder(inputList: ResequenceList, inputFormList: FormArray) {
    this.stackModel.displayValue = inputList.dialogVisible;
    const index = inputList.index;
    const formList = lodashUtils.cloneDeep(inputList.inputOrderList);
    formList.splice(index, 1);
    this.stackModel.acolumnOptions = formList;
    this.stackModel.formList = inputFormList;
    this.stackModel.stackedCategory = inputList.stackOnCategory;
  }
  onSave() {
    this.stackModel.stackedEquipmentList = this.stackModel.selectedRow;
    this.stackModel.displayValue = false;
    this.outputStackList.emit(this.stackModel.stackedEquipmentList);
    this.stackModel.selectedRow = null;
  }
  onCancel() {
    this.stackModel.displayValue = false;
    this.stackModel.selectedRow = null;
  }

}
