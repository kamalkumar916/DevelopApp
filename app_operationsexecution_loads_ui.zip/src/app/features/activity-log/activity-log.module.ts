import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { CalendarModule } from 'primeng/calendar';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { DialogModule } from 'primeng/dialog';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ChipsModule } from 'primeng/chips';
import { CheckboxModule } from 'primeng/checkbox';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { KeyFilterModule } from 'primeng/keyfilter';

import { PipesModule } from './../../shared/pipes/pipes.module';
import { JbhLoaderModule } from './../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from './../../shared/directives/directives.module';
import { ActivityLogRoutingModule } from './activity-log-routing.module';
import { ActivityLogComponent } from './activity-log.component';
import { ActivityLogArrivalAddComponent } from './activity-log-arrival/activity-log-arrival-add/activity-log-arrival-add.component';
import { ActivityLogLoadedAddComponent } from './activity-log-loaded/activity-log-loaded-add/activity-log-loaded-add.component';
import { ActivityLogUnloadedAddComponent } from './activity-log-unloaded/activity-log-unloaded-add/activity-log-unloaded-add.component';
import { LoadOverviewModule } from './../../shared/load-overview/load-overview.module';
import { LoadContactsModule } from '../../shared/load-contacts/load-contacts.module';
import { EquipmentGroupPopupModule } from '../../shared/equipment-group-popup/equipment-group-popup.module';
import { AssetCommunicationModule } from '../sidebar/asset-communication/asset-communication.module';
import {
  ActivityLogErrorComponent
} from './activity-log-error/activity-log-error.component';
import { ActivityLogArrivalViewComponent } from './activity-log-arrival/activity-log-arrival-view/activity-log-arrival-view.component';
import { ActivityLogLoadedViewComponent } from './activity-log-loaded/activity-log-loaded-view/activity-log-loaded-view.component';
import { ActivityLogUnloadedViewComponent } from './activity-log-unloaded/activity-log-unloaded-view/activity-log-unloaded-view.component';
import { ActivityLogArrivalEditComponent } from './activity-log-arrival/activity-log-arrival-edit/activity-log-arrival-edit.component';
import { ActivityLogLocationDetailsComponent } from './activity-log-location-details/activity-log-location-details.component';
import { ActivityLogCommentsAddComponent } from './activity-log-comments/activity-log-comments-add/activity-log-comments-add.component';
import { ActivityLogCommentsViewComponent } from './activity-log-comments/activity-log-comments-view/activity-log-comments-view.component';
import { ActivityLogDispatchViewComponent } from './activity-log-dispatch/activity-log-dispatch-view/activity-log-dispatch-view.component';
import { LoadDetailsService } from '../../features/load-details/services/load-details.service';
import { AppSharedDataService } from '../../shared/jbh-app-services/app-shared-data.service';
import { ActivityLogLoadedEditComponent } from './activity-log-loaded/activity-log-loaded-edit/activity-log-loaded-edit.component';
import { ActivityLogResourceInformationComponent
 } from './activity-log-arrival/activity-log-resource-information/activity-log-resource-information.component';
import { ActivityLogUnloadedEditComponent } from './activity-log-unloaded/activity-log-unloaded-edit/activity-log-unloaded-edit.component';
import { ActivityLogResourceDetailsComponent } from './activity-log-resource-details/activity-log-resource-details.component';
import { GlobalPopupsModule } from './../../shared/global-popups/global-popups.module';
import { ManageEquipmentGroupModule } from '../../shared/manage-equipment-group/manage-equipment-group.module';

@NgModule({
  declarations: [
    ActivityLogComponent,
    ActivityLogArrivalAddComponent,
    ActivityLogLoadedAddComponent,
    ActivityLogUnloadedAddComponent,
    ActivityLogErrorComponent,
    ActivityLogArrivalViewComponent,
    ActivityLogLoadedViewComponent,
    ActivityLogUnloadedViewComponent,
    ActivityLogArrivalEditComponent,
    ActivityLogLocationDetailsComponent,
    ActivityLogCommentsAddComponent,
    ActivityLogCommentsViewComponent,
    ActivityLogDispatchViewComponent,
    ActivityLogLoadedEditComponent,
    ActivityLogResourceInformationComponent,
    ActivityLogUnloadedEditComponent,
    ActivityLogResourceDetailsComponent
  ],
  imports: [
    CommonModule,
    ButtonModule,
    InputTextModule,
    MenuModule,
    PanelModule,
    TooltipModule,
    BreadcrumbModule,
    CalendarModule,
    InputTextareaModule,
    AutoCompleteModule,
    FormsModule,
    ReactiveFormsModule,
    DropdownModule,
    DialogModule,
    ScrollPanelModule,
    InputSwitchModule,
    ChipsModule,
    CheckboxModule,
    PipesModule,
    JbhLoaderModule,
    DirectivesModule,
    ActivityLogRoutingModule,
    LoadOverviewModule,
    MessagesModule,
    MessageModule,
    KeyFilterModule,
    LoadContactsModule,
    AssetCommunicationModule,
    GlobalPopupsModule,
    EquipmentGroupPopupModule,
    ManageEquipmentGroupModule
  ],
  exports:  [ActivityLogErrorComponent],
  providers: [
    DatePipe, LoadDetailsService, AppSharedDataService
  ]
})
export class ActivityLogModule { }
