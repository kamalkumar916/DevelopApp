import { Component, OnInit, Input, ChangeDetectionStrategy, ChangeDetectorRef, Output, EventEmitter} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { takeWhile, finalize } from 'rxjs/operators';

import { AppointmentDateFormatterPipe } from '../../../../shared/pipes/appointment-date-formatter.pipe';

import { ActivityLogModel } from '../../models/activity-log.model';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ViewActivityLogDetails, FinalDestination, PickUpDetails, StopDetails } from '../../models/activity-log.interface';
import { ActivityLogService } from '../../services/activity-log.service';

@Component({
  selector: 'app-activity-log-loaded-view',
  templateUrl: './activity-log-loaded-view.component.html',
  styleUrls: ['./activity-log-loaded-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogLoadedViewComponent implements OnInit {
  @Output() readonly stopSequenceNumber: EventEmitter<StopDetails> = new EventEmitter();
  activityLogDetailsModel: ActivityLogModel;
  constructor(private readonly activityLogService: ActivityLogService,
    private readonly changeDetector: ChangeDetectorRef, private readonly activatedRoute: ActivatedRoute) {
    this.activityLogDetailsModel = new ActivityLogModel();
  }

  ngOnInit() {
    this.activityLogDetailsModel.activityType = this.activatedRoute.queryParams['_value']['activityType'];
    this.activityLogDetailsModel.checkCallId = this.activatedRoute.queryParams['_value']['checkCallId'];
    this.activityLogDetailsModel.loadNumber = this.activatedRoute.queryParams['_value']['loadNumber'];
    if (this.activityLogDetailsModel.checkCallId && this.activityLogDetailsModel.activityType) {
      this.getLoadedCallDetails(this.activityLogDetailsModel.checkCallId, this.activityLogDetailsModel.activityType);
    }
  }
  getLoadedCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    this.activityLogDetailsModel.loading = true;
    this.activityLogService.getCheckCallDetails(operationalPlanCheckCallId, activityType)
      .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
        finalize(() => {
          this.activityLogDetailsModel.loading = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((data: ViewActivityLogDetails) => {
        this.activityLogDetailsModel.loading = false;
        if (data) {
          this.activityLogDetailsModel.activityLogDetails = data;
          this.loadedData();
          this.getFinalDestination();
        }
      }, (error: Error) => {
        this.activityLogDetailsModel.loading = false;
        this.activityLogDetailsModel.finalDestination = null;
      });
  }
  loadedData() {
    const data = this.activityLogDetailsModel.activityLogDetails;
    let loadedAppointmentObject;
    if (data.operationalPlanStopDetails && data.operationalPlanStopDetails.locationDetails) {
      this.activityLogDetailsModel.splitViewDetailsData.location =
        ActivityLogUtils.getLocationDetails(data.operationalPlanStopDetails.locationDetails);
    }
    if (data.operationalPlanStopDetails) {
      loadedAppointmentObject = {
        appointmentStartTimestamp: data.operationalPlanStopDetails.appointmentStartTimestamp.toString(),
        appointmentEndTimestamp: data.operationalPlanStopDetails.appointmentEndTimestamp.toString(),
        timeZone: data.operationalPlanStopDetails.locationDetails.address.timeZone
      };
      this.activityLogDetailsModel.splitViewDetailsData.stopReasonCode =
        data.operationalPlanStopDetails.operationalPlanStopReasonCodeDescription;
      this.activityLogDetailsModel.splitViewDetailsData.stopSequenceDescription =
        data.operationalPlanStopDetails.stopSequenceDescription;
    }
    if (data.loadedTimestamp) {
      this.activityLogDetailsModel.splitViewDetailsData.arrivalTime =
        ActivityLogUtils.getArrivedDate(data.loadedTimestamp, data.operationalPlanStopDetails.locationDetails.address.timeZone);
    }
    if (loadedAppointmentObject && loadedAppointmentObject.appointmentStartTimestamp && loadedAppointmentObject.appointmentEndTimestamp) {
      this.activityLogDetailsModel.splitViewDetailsData.appointment =
        new AppointmentDateFormatterPipe().transform(loadedAppointmentObject);
    }
    this.activityLogDetailsModel.splitViewDetailsData.arrivalStatus =
      ActivityLogUtils.checkArrivalStatus(data);
    this.activityLogDetailsModel.departureTime = ActivityLogUtils.getArrivedDate(data.departureTimestamp,
      data.operationalPlanStopDetails.locationDetails.address.timeZone);
    this.activityLogDetailsModel.lastUpdatedOn = this.formatDeparture(data.lastUpdatedTimestamp);
  }
  formatDeparture(departureTime: string): string {
    if (departureTime) {
      return `${new AppointmentDateFormatterPipe().getFormattedDate(departureTime)}
        ${new AppointmentDateFormatterPipe().getFormattedTime(departureTime)} ${ActivityLogUtils.getZoneFormat()}`;
    } else {
      return null;
    }
  }
  getFinalDestination() {
    if (this.activityLogDetailsModel.loadNumber) {
      this.activityLogService.getFinalDestination(this.activityLogDetailsModel.loadNumber)
        .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data: FinalDestination) => {
          this.activityLogDetailsModel.finalDestination = data ? data : null;
        }, (error) => {
          this.activityLogDetailsModel.finalDestination = null;
        });
    }
  }

  getDropEquipmentValue(equipmentDetails: PickUpDetails[]) {
    let i = 0;
    equipmentDetails.forEach((equipmentData) => {
      if (equipmentData.equipmentType && equipmentData.equipmentPrefix && equipmentData.equipmentType) {
        ++i;
      }
    });
    if (i === 0) {
      return true;
    } else {
      return false;
    }
  }
  sequenceNumber(event) {
    if (event.stopSequenceNumber) {
      this.stopSequenceNumber.emit({
        'stopSequenceNumber': event.stopSequenceNumber,
        'stopId': event.stopId,
        'destinationHeader': event.destinationHeader
      });
    }
  }
}
