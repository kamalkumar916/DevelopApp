import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from 'ng-bullet';

import { TooltipModule } from 'primeng/tooltip';

import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { AppSharedDataService } from '../../../../shared/jbh-app-services/app-shared-data.service';
import { ActivityLogLoadedViewComponent } from './activity-log-loaded-view.component';
import { ActivityLogLocationDetailsComponent } from '../../activity-log-location-details/activity-log-location-details.component';
import { GlobalPopupsModule } from './../../../../shared/global-popups/global-popups.module';
import { ActivityLogService } from '../../services/activity-log.service';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { ActivityLogUtils } from '../../services/activity-log.utils';

const loadedDetails = {
  operationalPlanStopDetails: {
    locationDetails: {
      locationId: '',
      locationName: '',
      locationCode: '',
      address: {
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipcode: '',
        country: '',
        countryName: '',
        timeZone: 'America/Chicago'
      }
    }
  }
};
const pickupEquipmentDetails = [
  {
    equipmentId: 1,
    equipmentType: '',
    equipmentPrefix: '',
    equipmentNumber: ''
  }
];
const viewactiviytlogdetails = {
  operationalPlanStopId: 1,
  operationalPlanId: 1,
  loadedType: '',
  loadedBy: '',
  departureTimestamp: '',
  lastUpdatedTimestamp: '',
  operationalPlanStopDetails: {
    operationalPlanStopSequenceNumber: null,
    operationalPlanStopReasonCode: '',
    operationalPlanStopReasonCodeDescription: '',
    locationDetails: loadedDetails.operationalPlanStopDetails.locationDetails,
    appointmentStartTimestamp: '',
    appointmentEndTimestamp: '',
    stopSequenceDescription: ''
  },
  lastUpdateProgramName: '',
  lastUpdatedUserId: '',
  loadedTimestamp: 't',
  proNumber: null,
  weight: {
    weight: null,
    unitOfWeightMeasurement: ''
  },
  volume: {
    volume: null,
    unitOfVolumeMeasurement: ''
  },
  temperature: {
    temperature: null,
    unitOfTemperatureMeasurement: ''
  },
  count: null,
  countedBy: '',
  sealNumber: '',
  bolNumber: '',
  poNumbers: [],
  shipperIdentificationNumber: '',
  receiverStateId: null,
  receiverStateName: 'abc',
  hazmatIndicator: '',
  comments: '',
  pickupEquipmentDetails: pickupEquipmentDetails,
  dropEquipmentDetails: pickupEquipmentDetails,
  stopServicesTypeCodes: [],
  stopServices: []
};
const finalDestination = {
  stateID: null,
  stateCode: '',
  stateName: ''
};

class MockActivityLogService {
  constructor() { }
  getFinalDestination() {
    return of(finalDestination);
  }
  getCheckCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    return of(viewactiviytlogdetails);
  }
}

describe('ActivityLogLoadedViewComponent', () => {
  let component: ActivityLogLoadedViewComponent;
  let fixture: ComponentFixture<ActivityLogLoadedViewComponent>;
  let activityLogService: ActivityLogService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule, RouterTestingModule,
        JbhLoaderModule, PipesModule, TooltipModule, GlobalPopupsModule, DirectivesModule],
      providers: [UserService, AppConfigService, AppSharedDataService, { provide: ActivityLogService, useClass: MockActivityLogService }],
      declarations: [ActivityLogLoadedViewComponent, ActivityLogLocationDetailsComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogLoadedViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('sequenceNumber have been called', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.sequenceNumber({ stopSequenceNumber: '1', stopId: '', destinationHeader: '' });
    expect(component.stopSequenceNumber.emit).toHaveBeenCalled();
  });

  it('getDropEquipmentValue have been called', () => {
    const pickUpDetails = [];
    const rtnval = component.getDropEquipmentValue(pickUpDetails);
    expect(rtnval).toBeTruthy();
  });

  it('getDropEquipmentValue else case have been called', () => {
    const pickUpDetails = [{
      equipmentId: 1,
      equipmentType: 'truck',
      equipmentPrefix: 'T',
      equipmentNumber: ''
    }];
    const rtnval = component.getDropEquipmentValue(pickUpDetails);
    expect(rtnval).toBeFalsy();
  });

  it('formatDeparture have been called', () => {
    const rtnval = component.formatDeparture('');
    expect(rtnval).toBeNull();
  });

  it('formatDeparture else case have been called', () => {
    spyOn(ActivityLogUtils, 'getZoneFormat').and.returnValue('CDT');
    const rtnval = component.formatDeparture('a');
    expect(rtnval.trim()).toEqual('CDT');
  });
  it('loadedData have been called', () => {
    component.activityLogDetailsModel.activityLogDetails = viewactiviytlogdetails;
    component.loadedData();
    expect(component.activityLogDetailsModel.lastUpdatedOn).toBeNull();
  });

  it('getFinalDestination have been called', () => {
    component.activityLogDetailsModel.loadNumber = 1;
    component.activityLogDetailsModel.canSubscribe = true;
    component.getFinalDestination();
    expect(component.activityLogDetailsModel.finalDestination).toEqual(finalDestination);
  });

  it('getFinalDestination error block have been called', () => {
    component.activityLogDetailsModel.loadNumber = 1;
    component.activityLogDetailsModel.canSubscribe = true;
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getFinalDestination').and.returnValue(throwError(null));
    component.getFinalDestination();
    expect(component.activityLogDetailsModel.finalDestination).toEqual(null);
  });

  it('getLoadedCallDetails have been called', () => {
    spyOn(component, 'loadedData');
    spyOn(component, 'getFinalDestination');
    component.getLoadedCallDetails(123, 'loaded');
    expect(component.activityLogDetailsModel.loading).toBeFalsy();
  });

  it('getLoadedCallDetails error block have been called', () => {
    spyOn(component, 'loadedData');
    spyOn(component, 'getFinalDestination');
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getCheckCallDetails').and.returnValue(throwError(null));
    component.getLoadedCallDetails(123, 'loaded');
    expect(component.activityLogDetailsModel.finalDestination).toBeNull();
  });
});
