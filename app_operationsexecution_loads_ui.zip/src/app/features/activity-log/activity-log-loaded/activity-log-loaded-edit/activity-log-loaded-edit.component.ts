import { Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

import { timer } from 'rxjs';
import { takeWhile, finalize } from 'rxjs/operators';
import { find, isEmpty } from 'lodash';
import { MessageService } from 'primeng/components/common/messageservice';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';

import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';

import { ActivityLogLoadedAddService } from '../activity-log-loaded-add/services/activity-log-loaded-add.service';
import { ActivityLogLoadedAddModel } from '../activity-log-loaded-add/model/activity-log-loaded-add.model';
import { ListItem } from '../../../../features/model/common.interface';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ActivityLogService } from '../../services/activity-log.service';
import { ActivityLogLoadedAddUtils } from '../activity-log-loaded-add/services/activity-log-loaded-add.utils';
import { ErrorList, ViewActivityLogDetails, FinalDestination, StopDetails, ResourceOverview,
   TelematicsEquipment } from '../../models/activity-log.interface';
import { ActivityLogLoadedEditService } from './services/activity-log-loaded-edit.service';
import { ActivityLogModel } from '../../models/activity-log.model';
import { AssetDetailQuery } from '../../../query/asset-detail.query';
import { EquipmentGroupItem } from '../../../tracking-details/model/tracking-details.interface';

@Component({
  selector: 'app-activity-log-loaded-edit',
  templateUrl: './activity-log-loaded-edit.component.html',
  styleUrls: ['./activity-log-loaded-edit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogLoadedEditComponent implements OnInit, OnDestroy {
  @Input() set fromCheckCallPage(fromCheckCallPage) {
    if (fromCheckCallPage) {
      this.activityLogLoadedEditModel.isLoadedCheckCallDetails = fromCheckCallPage.isCheckCallTracking;
      this.activityLogLoadedEditModel.checkCallNavigation = fromCheckCallPage.checkCallNavigation;
      this.activityLogLoadedEditModel.isTracking = fromCheckCallPage.isTracking;
    }
  }
  @Input() set editFromTracking(editFromTracking) {
    if (editFromTracking) {
      this.activityLogLoadedEditModel.editFromTracking = editFromTracking;
    }
  }
  @Input() set trackingParam(trackingParam) {
    if (trackingParam) {
      this.activityLogLoadedEditModel.trackingDetailsParam = trackingParam;
    }
  }
  @Input() set reload(isReload: boolean) {
    if (isReload) {
      this.activityLogLoadedEditModel.isReload = isReload;
    }
  }
  @Input() set loadDetails(loadDetail) {
    if (loadDetail) {
      this.activityLogLoadedEditModel.loadOverviewDetails = loadDetail;
      this.activityLogLoadedEditModel.planNumber = loadDetail.operationalPlanNumber ? loadDetail.operationalPlanNumber : null;
      this.getStopId();
    }
  }
  @Input() set resourceDetails(resourceOverview: ResourceOverview) {
    this.activityLogLoadedEditModel.resourceOverview = resourceOverview;
    this.getDropEquipment(resourceOverview);
  }
  @Output() readonly stopSequenceNumber: EventEmitter<StopDetails> = new EventEmitter();
  @Output() readonly checkCallStopId: EventEmitter<any> = new EventEmitter();
  @Output() arrivalDeviationType: EventEmitter<ErrorList[]> = new EventEmitter<ErrorList[]>();
  @Output() readonly hasTelematicsPickup: EventEmitter<boolean> = new EventEmitter();
  @Output() readonly telematicsEquipDetails: EventEmitter<TelematicsEquipment> = new EventEmitter<TelematicsEquipment>();
  activityLogLoadedEditModel: ActivityLogLoadedAddModel;
  @Output() equipmentList: EventEmitter<EquipmentGroupItem[]> = new EventEmitter<EquipmentGroupItem[]>();
  @Input() set overrideAllWarning(event) {
    this.activityLogLoadedEditModel.isOverrideWarning = event;
    ActivityLogLoadedAddUtils.resolveWarning(this.activityLogLoadedEditModel);
  }
  constructor(private readonly fb: FormBuilder, private readonly activityLogLoadedAddService: ActivityLogLoadedAddService,
    private readonly localStorageService: LocalStorageService,
    private readonly changeDetector: ChangeDetectorRef, private readonly toastMessage: MessageService,
    private readonly activatedRoute: ActivatedRoute, private readonly router: Router,
    private readonly activityLogDetailsService: ActivityLogService,
    private readonly datePipe: DatePipe, private readonly activityLogLoadedEditService: ActivityLogLoadedEditService) {
    this.activityLogLoadedEditModel = new ActivityLogLoadedAddModel();
  }
  ngOnInit() {
    this.activityLogLoadedEditModel.addLoadedForm = ActivityLogUtils.getLoadedUnloadedFormGroup(this.fb);
    this.getloadedFormGroup();
    this.activityLogLoadedEditModel.checkCallId = this.activatedRoute.queryParams['_value']['checkCallId'];
    this.getArrivalCallDetails(this.activityLogLoadedEditModel.checkCallId,
      this.activatedRoute.queryParams['_value']['activityType']);
    this.getCountedByData();
    this.getLoadedByData();
    this.getUnitOfVolumeData();
    this.getUnitOfWeightData();
    this.getUnitOfTemperatureData();
    this.getLoadedTypeData();
    if (this.activityLogLoadedEditModel.isReload) {
      this.activityLogLoadedEditModel.isLoading = true;
      this.getDropEquipment(this.activityLogLoadedEditModel.resourceOverview);
    }
  }
  sequenceNumber(event) {
    if (event.stopSequenceNumber) {
      this.stopSequenceNumber.emit({
        'stopSequenceNumber': event.stopSequenceNumber,
        'stopId': event.stopId,
        'destinationHeader': event.destinationHeader
      });
    }
  }
  getloadedFormGroup() {
    this.activityLogLoadedEditModel.addLoadedForm.addControl('loadedDate', new FormControl('', Validators.required));
    this.activityLogLoadedEditModel.addLoadedForm.addControl('loadedTime', new FormControl('', Validators.required));
    this.activityLogLoadedEditModel.addLoadedForm.addControl('loadedBy', new FormControl('', Validators.required));
    if (this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
      this.activityLogLoadedEditModel.addLoadedForm.addControl('loadedType', new FormControl('', Validators.required));
    }
  }
  setFinalDestination() {
    if (this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.operationalPlanID) {
      this.activityLogDetailsService.getFinalDestination(this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.operationalPlanID)
        .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data: FinalDestination) => {
          this.activityLogLoadedEditModel.finalDestination = data ? data : null;
        }, (error) => {
          this.activityLogLoadedEditModel.finalDestination = null;
        });
    }
  }
  getArrivalCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    if (operationalPlanCheckCallId && activityType) {
      this.activityLogLoadedEditModel.isLoading = true;
      this.getCheckCallData(operationalPlanCheckCallId, activityType, this.activityLogLoadedEditModel.isLoadedCheckCallDetails);
    }
  }
  getCheckCallData(operationalPlanCheckCallId, activityType, showCheckCallDetails) {
    this.activityLogDetailsService.getCheckCallDetails(operationalPlanCheckCallId, activityType, showCheckCallDetails)
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => {
          this.loadedFinalizeMethod();
        }))
      .subscribe((data: ViewActivityLogDetails) => {
        this.activityLogLoadedEditModel.isLoading = false;
        if (data) {
          if (this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
            const loadedTypeValue = (data.loadedType && data.loadedType.toLowerCase() === 'live') ? 'Live' : 'DrpAndHook';
            this.activityLogLoadedEditModel.addLoadedForm.controls.loadedType.patchValue({
              'label': data.loadedType,
              'value': loadedTypeValue
            });
            this.getCommentsCount(data);
            this.onLoadedTypeSelected();
            this.onSelectLoadedType();
          }
          this.loadedResponse(data);
          this.telematicsPickupEquip();
          this.hasTelematicsPickupDetails();
        }
      }, (error: Error) => {
        this.activityLogLoadedEditModel.isLoading = false;
      });
  }
  telematicsPickupEquip() {
    if (this.activityLogLoadedEditModel.loadedDetails &&
      this.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails
      && this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
        const pickupEquipResponseValue = (this.activityLogLoadedEditModel.addLoadedForm.controls.trailerOrContainer.value);
        this.activityLogLoadedEditModel.isTelematicsPickup = true;
        if (pickupEquipResponseValue && pickupEquipResponseValue['value'] && this.activityLogLoadedEditModel.isTelematicsPickup) {
        const pickupDetails = pickupEquipResponseValue['value'];
          this.telematicsEquipDetails.emit({
            equipmentId: pickupDetails.equipmentId,
            equipmentNumber: pickupDetails.equipmentNumber,
            equipmentCategory: pickupDetails.equipmentCategory,
            equipmentPrefix: pickupDetails.equipmentPrefix
          });
        }
      }
  }
  loadedFinalizeMethod() {
    this.activityLogLoadedEditModel.isLoading = false;
    this.changeDetector.detectChanges();
  }
  loadedResponse(data: ViewActivityLogDetails) {
    this.activityLogLoadedEditModel.loadedDetails = data;
    this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.operationalPlanID = data.operationalPlanId;
    this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.operationalPlanStopID = data.operationalPlanStopId;
    this.activityLogLoadedEditModel.stopSequenceNumber = data.operationalPlanStopDetails &&
      data.operationalPlanStopDetails.operationalPlanStopSequenceNumber ?
      data.operationalPlanStopDetails.operationalPlanStopSequenceNumber : null;
    this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.isEdit = true;
    this.setLoadedValues(data);
    this.setFinalDestination();
    if (this.activityLogLoadedEditModel.isReload && this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
      this.getEquipmentInfo();
    }
  }
  getStopId() {
    if (this.activityLogLoadedEditModel.isLoadedCheckCallDetails && this.activityLogLoadedEditModel.loadedDetails
      && this.activityLogLoadedEditModel.loadOverviewDetails) {
      const stopDto = find(this.activityLogLoadedEditModel.loadOverviewDetails.operationalPlanStopDTOs,
        (item: any) => item.locationDetailsDTO.locationId ===
            this.activityLogLoadedEditModel.loadedDetails.operationalPlanStopDetails.locationDetails.locationId);
      if (stopDto.operationalPlanStopId) {
        this.checkCallStopId.emit({
          'checkCallStopId': stopDto.operationalPlanStopId
        });
      }
      if (this.activityLogLoadedEditModel.loadOverviewDetails.operationalPlanReferenceNumberDTOs &&
        this.activityLogLoadedEditModel.loadOverviewDetails.operationalPlanReferenceNumberDTOs.length > 0) {
          ActivityLogUtils.checkAllReferenceException(
            this.activityLogLoadedEditModel.loadOverviewDetails.operationalPlanReferenceNumberDTOs,
            stopDto, this.activityLogLoadedEditModel.addLoadedForm,  this.activityLogLoadedEditModel.loadedDetails);
          }
      }
      if (this.activityLogLoadedEditModel.isLoadedCheckCallDetails && this.activityLogLoadedEditModel.loadedDetails) {
        this.getHighLightedErrorFields();
      }
  }
  setLoadedValues(loadedDetails: ViewActivityLogDetails) {
   this.activityLogLoadedEditModel.timeZone = this.getTimeZone(loadedDetails);
    this.setLoadedAndDepartureDateTime(loadedDetails, 'loadedTimestamp', 'loadedDate', 'loadedTime');
    this.activityLogLoadedEditModel.loadedTimeSelected = this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.value;
    ActivityLogUtils.checkLoadedTime(this.activityLogLoadedEditModel, this.toastMessage, 'Loaded');
    this.setLoadedAndDepartureDateTime(loadedDetails, 'departureTimestamp', 'departureDate', 'departureTime');
    this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.loadedTimestamp = DateUtils.dateTimeZoneFormat(this.
      activityLogLoadedEditModel.loadedDate, this.activityLogLoadedEditModel.loadedTime,
      this.activityLogLoadedEditModel.timeZone);
    this.activityLogLoadedEditModel.departureTimestamp = DateUtils.dateTimeZoneFormat(
      this.activityLogLoadedEditModel.departureDate, this.activityLogLoadedEditModel.departureTime,
      this.activityLogLoadedEditModel.timeZone);
    this.setLoadedTypeByAndCounted(loadedDetails);
    if (loadedDetails.loadedType) {
      this.activityLogLoadedEditModel.isLoadedDropHook = loadedDetails.loadedType.toLowerCase() === 'drop and hook';
    }
    if (loadedDetails.stopServices && loadedDetails.stopServices.length > 0
      && loadedDetails.stopServicesTypeCodes && loadedDetails.stopServicesTypeCodes.length > 0) {
      ActivityLogUtils.setStopService(loadedDetails, this.activityLogLoadedEditModel.addLoadedForm);
    }
    if (this.activityLogLoadedEditModel.isLoadedCheckCallDetails &&
      isEmpty(loadedDetails.stopServices)) {
        this.getDefaultCheckCallStopServices(loadedDetails);
    }
    ActivityLogUtils.setReferenceAndCommentValues(loadedDetails, this.activityLogLoadedEditModel.addLoadedForm);
    this.setLoadedUnitFormValues(loadedDetails);
    this.getErrorList();
    if (this.activityLogLoadedEditModel.isLoadedCheckCallDetails && loadedDetails.receiverStateName) {
      this.activityLogLoadedEditModel.checkCallFinalDestination = loadedDetails.receiverStateName;
    }
  }
  getDefaultCheckCallStopServices(loadedDetails) {
    if (loadedDetails.loadedBy) {
      this.onLoadedBySelect({label: loadedDetails.loadedBy, value: loadedDetails.loadedBy});
    }
    if (loadedDetails.countedBy) {
      this.onCountedBySelect({label: loadedDetails.countedBy, value: loadedDetails.countedBy});
    }
  }
  getTimeZone(loadedDetails) {
    return loadedDetails && loadedDetails.operationalPlanStopDetails && loadedDetails.operationalPlanStopDetails.
      locationDetails && loadedDetails.operationalPlanStopDetails.
        locationDetails.address && loadedDetails.operationalPlanStopDetails.
          locationDetails.address.timeZone ? loadedDetails.operationalPlanStopDetails.
            locationDetails.address.timeZone : 'America/Chicago';
  }
  getErrorList() {
    this.activityLogDetailsService.getCheckCallErrors(this.activityLogLoadedEditModel.checkCallId)
      .pipe(
        takeWhile(() => this.activityLogLoadedEditModel.canSubscribe)).subscribe((data: any) => {
          if (data) {
            const exceptionErrorArray = data['checkCallErrorDTO'][0]['checkCallExceptions'];
            const exceptionList = [];
            exceptionErrorArray.forEach((exceptionObj) => {
              ActivityLogUtils.activityLogError(exceptionObj, exceptionList);
              if (exceptionObj.taskTypeName) {
                this.activityLogLoadedEditModel.fieldErrorList.push(exceptionObj.taskTypeName.toLowerCase());
              }
            });
            this.arrivalDeviationType.emit(exceptionList);
          }
        });
  }
  getHighLightedErrorFields() {
    ActivityLogUtils.getLoadedMandatory(this.activityLogLoadedEditModel,
      this.activityLogLoadedEditModel.addLoadedForm);
    ActivityLogUtils.getStopServicesError(this.activityLogLoadedEditModel,
      this.activityLogLoadedEditModel.addLoadedForm);
    this.activityLogLoadedEditModel.hasFinalDestinationError =
      ActivityLogUtils.getFinalDestError(this.activityLogLoadedEditModel);
    ActivityLogUtils.getEquipmentError(this.activityLogLoadedEditModel,
      this.activityLogLoadedEditModel.addLoadedForm);
    this.changeDetector.detectChanges();
  }
  setLoadedTypeByAndCounted(loadedDetails: ViewActivityLogDetails) {
    if (loadedDetails) {
      this.activityLogLoadedEditModel.addLoadedForm.patchValue({
        loadedBy: find(this.activityLogLoadedEditModel.loadedBy, ['label', loadedDetails['loadedBy']]),
        countedBy: find(this.activityLogLoadedEditModel.countedBy, ['label', loadedDetails['countedBy']])
      });
      this.dropEquipmentCheckbox();
    }
  }
  setLoadedAndDepartureDateTime(loadedDetails: ViewActivityLogDetails, timestamp: string, date: string, time: string) {
    if (loadedDetails[timestamp]) {
      const formatedDate = this.formatDateTime(loadedDetails[timestamp], 'MM/dd/yyyy');
      const formatedTime = momentTimezone.tz(loadedDetails[timestamp], this.activityLogLoadedEditModel.timeZone).format('hh:mm A');
      this.activityLogLoadedEditModel.addLoadedForm.controls[date].setValue(formatedDate);
      this.activityLogLoadedEditModel.addLoadedForm.controls[time].setValue(formatedTime);
      this.activityLogLoadedEditModel[date] = ActivityLogUtils.formatDateValue(this.
        activityLogLoadedEditModel.addLoadedForm.controls[date].value);
      this.activityLogLoadedEditModel[time] = momentTimezone.tz(loadedDetails[timestamp],
        this.activityLogLoadedEditModel.timeZone).format('HH:mm');
    }
  }
  setLoadedUnitFormValues(loadedDetails: ViewActivityLogDetails) {
    if (loadedDetails.weight && loadedDetails.weight.weight && loadedDetails.weight.unitOfWeightMeasurement) {
      ActivityLogUtils.setWeightValue(this.activityLogLoadedEditModel.addLoadedForm, loadedDetails.weight);
    }
    if (loadedDetails.volume && loadedDetails.volume.volume && loadedDetails.volume.unitOfVolumeMeasurement) {
      ActivityLogUtils.setVolumeValue(this.activityLogLoadedEditModel.addLoadedForm, loadedDetails.volume);
    }
    if (loadedDetails.temperature && loadedDetails.temperature.temperature &&
      loadedDetails.temperature.unitOfTemperatureMeasurement) {
      ActivityLogUtils.setTemperatureValue(this.activityLogLoadedEditModel.addLoadedForm, loadedDetails.temperature);
    }
    if (loadedDetails.hazmatIndicator) {
      ActivityLogUtils.setHazmatControl(this.activityLogLoadedEditModel.addLoadedForm, loadedDetails.hazmatIndicator);
    }
    this.changeDetector.detectChanges();
  }
  formatDateTime(event, format: string) {
    return ActivityLogUtils.formatBasedOnZone(this.datePipe, event, format);
  }
  getLoadedByData() {
    this.activityLogLoadedAddService.getLoadedBy()
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityPartyTypes)) {
          let stopdetails = null;
          if (this.activityLogLoadedEditModel.loadedDetails &&
            this.activityLogLoadedEditModel.loadedDetails.operationalPlanStopDetails) {
            stopdetails = this.activityLogLoadedEditModel.loadedDetails.operationalPlanStopDetails;
          }
          this.activityLogLoadedEditModel.loadedBy = stopdetails ?
            ActivityLogUtils.getFormatedLoadedByValue(data._embedded.operationalPlanStopActivityPartyTypes,
              stopdetails) : ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityPartyTypes,
                'operationalPlanStopActivityPartyTypeDescription', 'operationalPlanStopActivityPartyTypeCode');
        }
      }, (error) => {
        this.activityLogLoadedEditModel.loadedBy = [];
      });
  }
  getCountedByData() {
    this.activityLogLoadedAddService.getCountedBy()
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.countedByPartyTypes)) {
          let stopdetails = null;
          if (this.activityLogLoadedEditModel.loadedDetails &&
            this.activityLogLoadedEditModel.loadedDetails.operationalPlanStopDetails) {
            stopdetails = this.activityLogLoadedEditModel.loadedDetails.operationalPlanStopDetails;
          }
          this.activityLogLoadedEditModel.countedBy = stopdetails ?
            ActivityLogUtils.getFormatedCountedByValue(data._embedded.countedByPartyTypes,
              stopdetails) : ActivityLogUtils.getFormattedData(data._embedded.countedByPartyTypes,
                'countedByPartyTypeDescription', 'countedByPartyTypeCode');
        }
      }, (error) => {
        this.activityLogLoadedEditModel.countedBy = [];
      });
  }
  getUnitOfWeightData() {
    this.activityLogLoadedAddService.getUnitOfWeight()
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfWeightMeasurements)) {
          this.activityLogLoadedEditModel.unitOfWeight =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfWeightMeasurements, 'unitOfWeightMeasurementDescription',
              'unitOfWeightMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogLoadedEditModel.addLoadedForm, 'weightUnits', { weight: '', units: 'Pounds' });
        }
      }, (error) => {
        this.activityLogLoadedEditModel.unitOfWeight = [];
      });
  }
  getUnitOfVolumeData() {
    this.activityLogLoadedAddService.getUnitOfVolume()
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfVolumeMeasurements)) {
          this.activityLogLoadedEditModel.unitOfVolume =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfVolumeMeasurements, 'unitOfVolumeMeasurementDescription',
              'unitOfVolumeMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogLoadedEditModel.addLoadedForm,
            'volumeUnits', { volume: '', units: 'Gallons' });
        }
      }, (error) => {
        this.activityLogLoadedEditModel.unitOfVolume = [];
      });
  }
  getUnitOfTemperatureData() {
    this.activityLogLoadedAddService.getUnitOfTemperature()
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfTemperatureMeasurements)) {
          this.activityLogLoadedEditModel.unitOfTemperature =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfTemperatureMeasurements, 'unitOfTemperatureMeasurementDescription',
              'unitOfTemperatureMeasurementCode');
        }
      }, (error) => {
        this.activityLogLoadedEditModel.unitOfTemperature = [];
      });
  }
  getStopServicesData(stopService) {
    if (stopService && stopService.query) {
      this.activityLogLoadedAddService.getStopServices(stopService.query)
        .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data) => {
          if (data && data._embedded && !isEmpty(data._embedded.operationalPlanServiceTypes)) {
            this.activityLogLoadedEditModel.stopServices =
              ActivityLogUtils.getFormattedData(data._embedded.operationalPlanServiceTypes, 'operationalPlanServiceTypeDescription',
                'operationalPlanServiceTypeCode');
          }
        }, (error) => {
          this.activityLogLoadedEditModel.stopServices = [];
        });
    }
  }
  saveForm() {
      if (!this.activityLogLoadedEditModel.addLoadedForm.dirty && !this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
        ActivityLogUtils.onNoChangeMessage(this.toastMessage);
        return;
      }
      this.arrivalDeviationType.emit([]);
      ActivityLogLoadedAddUtils.mandatoryFieldsCheck(this.activityLogLoadedEditModel.addLoadedForm);
      FormValidationUtils.validateAllFormFields(this.activityLogLoadedEditModel.addLoadedForm);
      this.changeDetector.detectChanges();
      if (this.activityLogLoadedEditModel.addLoadedForm.valid) {
        this.changeDetector.detectChanges();
        const addLoadedRequestInput = {
          loadedTimestamp: this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.loadedTimestamp,
          departureTimestamp: this.activityLogLoadedEditModel.departureTimestamp,
          planNumber: this.activityLogLoadedEditModel.planNumber,
          stopSequenceNumber: this.activityLogLoadedEditModel.stopSequenceNumber,
          receiverStateId: this.activityLogLoadedEditModel.finalDestination,
          overrideWarning: this.activityLogLoadedEditModel.isOverrideWarning,
          pickupEquipmentValue: this.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails,
          dropEquipmentValue: this.activityLogLoadedEditModel.dropEquipment,
          timeZone: this.activityLogLoadedEditModel.timeZone
        };
        let addLoadedReq;
        if (this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
          addLoadedReq = this.getLoadedCheckCallSave(addLoadedRequestInput);
          if (addLoadedReq) {
            addLoadedReq = this.frameCheckCallRequest(addLoadedReq);
          }
        } else {
          addLoadedReq = ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedEditModel.addLoadedForm,
            addLoadedRequestInput, this.activityLogLoadedEditModel.resourceOverview,
            ActivityLogUtils.getLoadedUnloadedTypeValue(this.activityLogLoadedEditModel.loadedType,
              this.activityLogLoadedEditModel.loadedDetails.loadedType));
        }
        this.loadedSaveCall(addLoadedReq);
      } else {
        ActivityLogUtils.checkLoadedFormValidity(this.toastMessage, this.activityLogLoadedEditModel.addLoadedForm,
          this.activityLogLoadedEditModel, this.arrivalDeviationType, this.changeDetector);
      }
  }
  frameCheckCallRequest(addLoadedReq) {
    addLoadedReq.checkCallSource = this.activityLogLoadedEditModel.loadedDetails.checkCallSource;
    addLoadedReq.isWarningOverride = this.activityLogLoadedEditModel.isOverrideWarning;
    addLoadedReq.checkCallId = this.activityLogLoadedEditModel.checkCallId;
    addLoadedReq.checkCallDetails.pickupEquipmentDetails = (this.activityLogLoadedEditModel.onSelectTrailerOrContainer) ?
      ActivityLogUtils.getPickupEquipmentValue(this.activityLogLoadedEditModel.trailerOrContainerSelected,
        this.activityLogLoadedEditModel.equipmentPaired) : this.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails;
    addLoadedReq.checkCallDetails.dropEquipmentDetails =
      ActivityLogUtils.getDropEquipmentValues(this.activityLogLoadedEditModel.addLoadedForm);
    return addLoadedReq;
  }
  getLoadedCheckCallSave(addLoadedRequestInput) {
    if (addLoadedRequestInput.dropEquipmentValue && addLoadedRequestInput.dropEquipmentValue.length > 0) {
      if (addLoadedRequestInput.pickupEquipmentValue && addLoadedRequestInput.pickupEquipmentValue.length > 0) {
        return ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedEditModel.addLoadedForm,
            addLoadedRequestInput, this.activityLogLoadedEditModel.resourceOverview);
        } else {
          if (addLoadedRequestInput.pickupEquipmentValue.length === 0 &&
            isEmpty(this.activityLogLoadedEditModel.trailerOrContainerSelected)) {
             return this.checkSelectedDropEquipment(addLoadedRequestInput);
          } else {
            return ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedEditModel.addLoadedForm,
            addLoadedRequestInput, this.activityLogLoadedEditModel.resourceOverview);
          }
        }
      } else {
        return this.emptyDropEquipment(addLoadedRequestInput);
      }
  }
  checkSelectedDropEquipment(addLoadedRequestInput) {
    if (ActivityLogUtils.checkeddroppedOrUndropped(this.activityLogLoadedEditModel.addLoadedForm)) {
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').markAsTouched();
      this.pickupEquipmentError();
      return null;
    } else {
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors(null);
      return ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedEditModel.addLoadedForm,
        addLoadedRequestInput, this.activityLogLoadedEditModel.resourceOverview);
    }
  }
  emptyDropEquipment(addLoadedRequestInput) {
    if (this.activityLogLoadedEditModel.addLoadedForm.value.loadedType.value.toLowerCase() !== 'drpandhook') {
        if (this.activityLogLoadedEditModel.dropEquipment.length === 0 && (addLoadedRequestInput.pickupEquipmentValue.length === 0
          && isEmpty(this.activityLogLoadedEditModel.trailerOrContainerSelected))) {
            this.pickupEquipmentError();
            return null;
          }
        if (addLoadedRequestInput.pickupEquipmentValue.length > 0 &&
          isEmpty(this.activityLogLoadedEditModel.trailerOrContainerSelected)) {
          this.pickupEquipTypeError();
          return null;
        }
        return ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedEditModel.addLoadedForm,
          addLoadedRequestInput, this.activityLogLoadedEditModel.resourceOverview);
    } else {
      return ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedEditModel.addLoadedForm,
        addLoadedRequestInput, this.activityLogLoadedEditModel.resourceOverview);
    }
  }
  pickupEquipTypeError() {
    this.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails.forEach(ele => {
      if (ele.equipmentType.toLowerCase() !== 'container' || ele.equipmentType.toLowerCase() !== 'trailer') {
        this.pickupEquipmentError();
      }
    });
  }
  pickupEquipmentError() {
    this.toastMessage.add({
      severity: 'error',
      summary: 'Error',
      detail: 'Pickup any Equipment'
    });
    this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
    this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').markAsTouched();
    this.changeDetector.detectChanges();
  }
  handleError(error) {
    this.activityLogLoadedEditModel.isLoading = false;
    if (ActivityLogUtils.handleErrorAndNull(error, this.toastMessage)) {
      ActivityLogUtils.checkRuleValidationError(error.error.errors,
        this.activityLogLoadedEditModel.addLoadedForm, this.arrivalDeviationType,
        this.changeDetector);
      this.arrivalDeviationType.emit(error.error.errors);
    }
  }
  onLoadedDateOrTimeChange(event, isDate: boolean) {
    event.overlayVisible = false;
    const dateObj = DateUtils.getTimeValue(event);
    if (isDate) {
      this.activityLogLoadedEditModel.loadedDate = ActivityLogUtils.formatDateValue(event);
      ActivityLogUtils.checkLoadedTime(this.activityLogLoadedEditModel, this.toastMessage, 'Loaded');
    } else {
      if (!this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.value) {
        this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.setValue(moment(dateObj.withPm, ['hh:mm A']).toDate());
      }
      this.activityLogLoadedEditModel.loadedDate = ActivityLogUtils.formatDateValue(this.
        activityLogLoadedEditModel.addLoadedForm.controls.loadedDate.value);
      this.activityLogLoadedEditModel.loadedTime = dateObj.withoutPm;
      this.activityLogLoadedEditModel.loadedTimeSelected =
        ActivityLogUtils.formatTimeSelected(this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.value);
      ActivityLogUtils.checkLoadedTime(this.activityLogLoadedEditModel, this.toastMessage, 'Loaded');
    }
    if (this.activityLogLoadedEditModel.loadedDate && this.activityLogLoadedEditModel.loadedTime) {
      this.checkIsLoadedLate();
    }
  }
  onLoadedDateInputTyped(event) {
    this.activityLogLoadedEditModel.loadedDate =
      ActivityLogUtils.formatDateValue(this.activityLogLoadedEditModel.addLoadedForm.controls.loadedDate.value);
    if (this.activityLogLoadedEditModel.addLoadedForm.controls.loadedDate.value > new Date()) {
      ActivityLogUtils.dateValidation(this.activityLogLoadedEditModel.addLoadedForm, 'loadedDate',
        this.toastMessage, 'Loaded');
    }
    if (this.activityLogLoadedEditModel.loadedDate && this.activityLogLoadedEditModel.loadedTime) {
      ActivityLogUtils.checkLoadedTime(this.activityLogLoadedEditModel, this.toastMessage, 'Loaded');
    }
    this.checkIsLoadedLate();
  }
  onLoadedTimeInputTyped(event) {
    this.activityLogLoadedEditModel.loadedTime =
      ActivityLogUtils.formatTimeValue(this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.value);
  }
  checkIsLoadedLate() {
    if (this.activityLogLoadedEditModel.addLoadedForm.valid) {
      this.toastMessage.clear();
    }
    this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.loadedTimestamp = DateUtils.dateTimeZoneFormat(this.
      activityLogLoadedEditModel.loadedDate, this.activityLogLoadedEditModel.loadedTime,
      this.activityLogLoadedEditModel.timeZone);
    if (this.activityLogLoadedEditModel.addLoadedForm.controls.loadedDate.valid &&
      this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.valid) {
      this.activityLogLoadedAddService.getLoadedDateTime(this.activityLogLoadedEditModel.findIsLoadedEarlyRequest).
        pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
        }, (error) => {
          ActivityLogUtils.arrivalError(error.error, this.toastMessage);
        });
    }
  }
  onLoadedDateOrTimeClear(isDate: boolean, loadedTime = null) {
    if (isDate) {
      this.activityLogLoadedEditModel.addLoadedForm.controls.loadedDate.reset();
    } else {
      this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.reset();
      loadedTime.overlayVisible = false;
    }
  }
  onDepartureDateOrTimeChange(event, isDate: boolean) {
    event.overlayVisible = false;
    if (isDate) {
      this.activityLogLoadedEditModel.departureDate = ActivityLogUtils.formatDateValue(event);
    } else {
      if (!this.activityLogLoadedEditModel.addLoadedForm.controls.departureTime.value) {
        this.activityLogLoadedEditModel.addLoadedForm.controls.departureTime.setValue(DateUtils.getTimeValue(event).withPm);
      }
      this.activityLogLoadedEditModel.departureTime = DateUtils.getTimeValue(event).withoutPm;
    }
    if (this.activityLogLoadedEditModel.departureDate && this.activityLogLoadedEditModel.departureTime) {
      this.activityLogLoadedEditModel.departureTimestamp = ActivityLogUtils.frameTimeStampValues(this.
        activityLogLoadedEditModel.departureDate, this.activityLogLoadedEditModel.departureTime);
    }
  }
  onDepartureTimeInputTyped() {
    this.activityLogLoadedEditModel.departureTime =
      ActivityLogUtils.formatTimeValue(this.activityLogLoadedEditModel.addLoadedForm.controls.loadedTime.value);
    if (this.activityLogLoadedEditModel.departureDate && this.activityLogLoadedEditModel.departureTime) {
      this.activityLogLoadedEditModel.departureTimestamp = '';
    }
  }
  onDepartureDateInputTyped() {
    this.activityLogLoadedEditModel.departureDate =
      ActivityLogUtils.formatDateValue(this.activityLogLoadedEditModel.addLoadedForm.controls.departureDate.value);
    if (this.activityLogLoadedEditModel.departureDate && this.activityLogLoadedEditModel.departureTime) {
      this.activityLogLoadedEditModel.departureTimestamp = '';
    }
  }
  onDepartureDateOrTimeClear(isDate: boolean, departureTime = null) {
    if (isDate) {
      this.activityLogLoadedEditModel.addLoadedForm.controls.departureDate.reset();
    } else {
      this.activityLogLoadedEditModel.addLoadedForm.controls.departureTime.reset();
      departureTime.overlayVisible = false;
    }
    this.activityLogLoadedEditModel.departureTimestamp = '';
  }
  onTextAreaType() {
    this.activityLogLoadedEditModel.commentsCount = this.activityLogLoadedEditModel.addLoadedForm.controls.comments.value.length;
  }
  onLoadedBySelect(event: ListItem) {
    const driver = { value: 'DrvrLoad', label: 'Driver Loads Freight' };
    const lumper = { value: 'LumprLdFrg', label: 'Lumper Loads Freight' };
    const driverLumperValue = ['driver loads freight', 'lumper loads freight'];
    ActivityLogUtils.setStopServiceSelectedValue(event, driver, lumper, driverLumperValue,
      this.activityLogLoadedEditModel.addLoadedForm);
  }
  onCountedBySelect(event: ListItem) {
    const countsDriver = { label: 'Driver Counts Freight', value: 'DrvrCount' };
    const countsLumper = { label: 'Lumper Counts Freight', value: 'LumpCntFrg' };
    const driverLumperValue = ['driver counts freight', 'lumper counts freight'];
    ActivityLogUtils.setStopServiceSelectedValue(event, countsDriver, countsLumper, driverLumperValue,
      this.activityLogLoadedEditModel.addLoadedForm);
  }
  validateFormField(formControl) {
    return (this.activityLogLoadedEditModel.addLoadedForm.get(formControl).invalid &&
      this.activityLogLoadedEditModel.addLoadedForm.get(formControl).touched);
  }
  ngOnDestroy() {
    this.activityLogLoadedEditModel.canSubscribe = false;
    if (this.activityLogLoadedEditModel.addLoadedForm) {
      this.activityLogLoadedEditModel.addLoadedForm.reset();
    }
  }
  loadedSaveCall(addLoadedReq) {
    if (addLoadedReq && this.activityLogLoadedEditModel.checkCallId) {
      if (addLoadedReq.resourceDetails.value) {
        this.updateLoadedActivity(addLoadedReq);
      } else {
        this.toastMessage.clear();
        ActivityLogUtils.resourceFieldError(this.toastMessage);
      }
    }
  }
  updateLoadedActivity(addLoadedReq) {
    this.activityLogLoadedEditModel.isLoading = true;
    this.changeDetector.detectChanges();
    this.activityLogLoadedEditService.updateLoadedDetails(addLoadedReq, this.activityLogLoadedEditModel.checkCallId,
      this.activityLogLoadedEditModel.isLoadedCheckCallDetails)
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        this.activityLogLoadedEditModel.isLoading = false;
        if (data) {
          ActivityLogUtils.successMessage(this.toastMessage, 'Loaded', 'updated');
          timer(ActivityLogModel.editSaveTimer).subscribe(() => {
            if (this.activityLogLoadedEditModel.isTracking || this.activityLogLoadedEditModel.editFromTracking) {
              this.router.navigate(['/trackingdetails'],
                {
                  queryParams: this.activityLogLoadedEditModel.trackingDetailsParam
                });
            } else if (this.activityLogLoadedEditModel.checkCallNavigation) {
              this.router.navigate(['/tracking'],
                {
                  queryParams: {
                    fromCheckCall: 'true'
                  }
                });
            } else {
              this.router.navigate(['/loaddetails', this.activityLogLoadedEditModel.findIsLoadedEarlyRequest.operationalPlanID],
                {
                  queryParams: {
                    index: 2
                  }
                });
            }
          });
        }
      }, (error) => {
        this.handleError(error);
      });
  }
  getUpdatedEquipment(event) {
    this.activityLogLoadedEditModel.equipmentPaired = event;
  }
  dropEquipmentCheckbox() {
    const equipCategoryArray = [];
    if (this.activityLogLoadedEditModel.loadedDetails &&
      this.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails
      && this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
      this.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails.forEach(ele => {
        equipCategoryArray.push(ele.equipmentCategory);
        if (ele.equipmentCategory.toLowerCase() === 'container' || ele.equipmentCategory.toLowerCase() === 'trailer') {
          this.activityLogLoadedEditModel.addLoadedForm.controls.trailerOrContainer.patchValue({
            'label': ele.equipmentPrefix && ele.equipmentNumber ?
              `${ele.equipmentPrefix}${ele.equipmentNumber}` : `${ele.equipmentNumber}`,
            'value': {
              equipmentId: ele.equipmentId,
              equipmentNumber: ele.equipmentNumber,
              equipmentPrefix: ele.equipmentPrefix,
              equipmentType: ele.equipmentType
            }
          });
        }
      });
      this.getChassisEquip(equipCategoryArray);
    }
    this.changeDetector.detectChanges();
  }
  getChassisEquip(equipCategoryArray) {
    if (equipCategoryArray.indexOf('CONTAINER') > -1 || equipCategoryArray.indexOf('TRAILER') > -1) {
      this.activityLogLoadedEditModel.hasChassisEquip = true;
      this.activityLogLoadedEditModel.chassisEquip = find(this.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails,
        { 'equipmentCategory': 'CHASSIS' });
    }
  }
  hasTelematicsPickupDetails() {
    this.hasTelematicsPickup.emit(this.activityLogLoadedEditModel.isTelematicsPickup);
  }
  getDropEquipment(resourceOverview: ResourceOverview) {
    if (resourceOverview && resourceOverview.equipmentId &&
      this.activityLogLoadedEditModel.isLoadedCheckCallDetails) {
      this.activityLogDetailsService.getEquipmentDetails(resourceOverview.equipmentId)
        .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.length > 1) {
            this.activityLogLoadedEditModel.dropEquipment = ActivityLogUtils.getFormattedEquipment(data.slice(1));
            this.onLoadedTypeSelected();
            if (this.activityLogLoadedEditModel.isReload) {
              this.activityLogLoadedEditModel.isLoading = false;
              this.getEquipmentInfo();
            }
          }
        }, (error) => {
          this.activityLogLoadedEditModel.dropEquipment = [];
          this.onLoadedTypeSelected();
          if (this.activityLogLoadedEditModel.isReload) {
            this.activityLogLoadedEditModel.isLoading = false;
          }
        });
    }
  }
  getEquipmentInfo() {
    if (this.localStorageService.getItem('checkcallloadedForm', 'values') && this.activityLogLoadedEditModel.isReload) {
      const loadedFormValue = this.localStorageService.getItem('checkcallloadedForm', 'values');
      this.activityLogLoadedEditModel.addLoadedForm.patchValue(loadedFormValue.formDetails);
      this.activityLogLoadedEditModel.trailerOrContainerSelected = loadedFormValue.trailerSelected;
      this.activityLogLoadedEditModel.departureTimestamp = loadedFormValue.departureTime;
    } else {
      this.onSelectLoadedType();
    }
    if (this.localStorageService.getItem('checkcallpairedEquipment', 'values') && this.activityLogLoadedEditModel.isReload) {
      this.activityLogLoadedEditModel.equipmentPaired = this.localStorageService.getItem('checkcallpairedEquipment', 'values');
    }
  }
  onLoadedTypeSelected() {
    if (this.activityLogLoadedEditModel.dropEquipment.length > 0) {
      this.activityLogLoadedEditModel.dropEquipment.forEach(dropequipment => {
        if (dropequipment.equipmentType) {
          this.activityLogLoadedEditModel.addLoadedForm.controls.dropEquipmentDetails
          ['addControl'](dropequipment.equipmentType, new FormControl([]));
        }
      });
    }
    this.onSelectLoadedType();
    this.dropEquipmentCheckbox();
    this.changeDetector.detectChanges();
  }

  onSelectLoadedType() {
    if (this.activityLogLoadedEditModel.addLoadedForm.value.loadedType.value &&
      this.activityLogLoadedEditModel.addLoadedForm.value.loadedType.value.toLowerCase() === 'drpandhook') {
      ActivityLogLoadedAddUtils.trailerOrContainerError(this.activityLogLoadedEditModel.addLoadedForm);
      this.activityLogLoadedEditModel.equipmentPaired = [];
      this.changeDetector.detectChanges();
    } else {
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors(null);
    }
    Object.keys(this.activityLogLoadedEditModel.addLoadedForm.get('dropEquipmentDetails')['controls']).forEach((controlName) => {
      this.activityLogLoadedEditModel.addLoadedForm.get('dropEquipmentDetails')['controls'][controlName].reset();
    });
  }

  getLoadedTypeData() {
    this.activityLogLoadedAddService.getLoadedType()
      .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityTypes)) {
          this.activityLogLoadedEditModel.loadedType =
            ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityTypes,
              'operationalPlanStopActivityTypeDescription', 'operationalPlanStopActivityTypeCode');
        }
      }, (error) => {
        this.activityLogLoadedEditModel.loadedType = [];
      });
  }
  titleCase(dropEquipment) {
    return ActivityLogLoadedAddUtils.getTitleCase(dropEquipment);
  }
  onCheckAndUnCheck() {
    if (!ActivityLogUtils.droppedOrUndropped(this.activityLogLoadedEditModel.addLoadedForm) &&
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').invalid) {
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
      this.changeDetector.detectChanges();
    }
    if (!ActivityLogUtils.checkeddroppedOrUndropped(this.activityLogLoadedEditModel.addLoadedForm) &&
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').invalid &&
      this.activityLogLoadedEditModel.addLoadedForm.value.loadedType.value.toLowerCase() !== 'drpandhook') {
      this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors(null);
    }
  }
  getStringifyValue(dropEquipment) {
    return JSON.stringify(dropEquipment);
  }
  getTrailerOrContainerData(trailerOrContainer) {
    if (trailerOrContainer && trailerOrContainer.query) {
      const q = AssetDetailQuery.getContainerOrTrailer(trailerOrContainer.query);
      this.activityLogDetailsService.getTrailerOrContainer(q)
        .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.hits && data.hits.hits && data.hits.hits.length > 0) {
            this.activityLogLoadedEditModel.trailerOrContainer =
              ActivityLogUtils.getTrailerOrContainer(data.hits.hits);
          } else {
            this.activityLogLoadedEditModel.trailerOrContainer = [];
            this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
          }
        }, (error) => {
          this.activityLogLoadedEditModel.trailerOrContainer = [];
        });
    }
  }
  onRemoveTrailerOrContainer() {
    this.activityLogLoadedEditModel.chassis = null;
    this.activityLogLoadedEditModel.trailerOrContainerSelected = null;
    this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').reset();
    this.activityLogLoadedEditModel.equipmentPaired = [];
  }
  onTrailerOrContainerSelected(selectedTrailerOrContainer) {
    this.activityLogLoadedEditModel.onSelectTrailerOrContainer = true;
    this.activityLogLoadedEditModel.isTelematicsPickup = false;
    this.activityLogLoadedEditModel.hasChassisEquip = false;
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId) {
      if (!find(this.activityLogLoadedEditModel.dropEquipment,
        ['equipmentNumber', selectedTrailerOrContainer.value.equipmentNumber])) {
        this.activityLogLoadedEditModel.trailerOrContainerSelected = selectedTrailerOrContainer;
        this.getStackedEquipment(selectedTrailerOrContainer);
      } else {
        this.activityLogLoadedEditModel.trailerOrContainerSelected = null;
        this.toastMessage.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Select valid Equipment Details'
        });
        this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
        this.activityLogLoadedEditModel.addLoadedForm.get('trailerOrContainer').markAsTouched();
        this.changeDetector.detectChanges();
      }
    } else {
      this.activityLogLoadedEditModel.trailerOrContainerSelected = null;
    }
  }
  getStackedEquipment(selectedTrailerOrContainer) {
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId) {
      this.activityLogLoadedEditModel.isLoading = true;
      this.activityLogDetailsService.getEquipmentDetails(selectedTrailerOrContainer.value.equipmentId)
        .pipe(takeWhile(() => this.activityLogLoadedEditModel.canSubscribe),
          finalize(() => {
            this.activityLogLoadedEditModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: EquipmentGroupItem[]) => {
          if (data && data.length > 0) {
            this.onSelectingEquipmentDetails(data, selectedTrailerOrContainer.value.equipmentId);
            this.equipmentList.emit(data);
            this.hasTelematicsPickupDetails();
          }
        }, (error) => {
          this.activityLogLoadedEditModel.equipmentGroupValue = null;
          this.activityLogLoadedEditModel.status = [];
        });
    }
  }
  onSelectingEquipmentDetails(response, equipmentId) {
    if (response.length > 1) {
      this.activityLogLoadedEditModel.showEquipmentGroup = true;
      this.activityLogLoadedEditModel.trailingEquipmentGroup = response;
      let selectedEquipmentDetails;
      this.activityLogLoadedEditModel.trailingEquipmentGroup.forEach((equimentItem => {
        if (equimentItem.equipmentId === equipmentId) {
          selectedEquipmentDetails = equimentItem;
          this.activityLogLoadedEditModel.equipmentGroupValue.equipmentNumber = equimentItem.equipmentNumber;
          this.activityLogLoadedEditModel.equipmentGroupValue.equipmentType = equimentItem.equipmentType;
          this.activityLogLoadedEditModel.equipmentGroupValue.equipmentPrefix = equimentItem.equipmentPrefix;
          this.activityLogLoadedEditModel.equipmentGroupValue.equipmentId = equimentItem.equipmentId;
        } else {
          equimentItem.stackedEquipmentList.forEach(stackedItem => {
            if (stackedItem.equipmentId === equipmentId) {
              selectedEquipmentDetails = stackedItem;
              this.activityLogLoadedEditModel.equipmentGroupValue.equipmentNumber = stackedItem.equipmentNumber;
              this.activityLogLoadedEditModel.equipmentGroupValue.equipmentType = stackedItem.equipmentType;
              this.activityLogLoadedEditModel.equipmentGroupValue.equipmentPrefix = stackedItem.equipmentPrefix;
              this.activityLogLoadedEditModel.equipmentGroupValue.equipmentId = stackedItem.equipmentId;
            }
          });
        }
      }));
      this.activityLogLoadedEditModel.status = [{ label: 'Add this group to selected Equipment', value: 'Active' },
      {
        label: `Remove the ${selectedEquipmentDetails.equipmentType.charAt(0)
          + selectedEquipmentDetails.equipmentType.slice(1).toLowerCase()}
            ${selectedEquipmentDetails
            .equipmentPrefix}${selectedEquipmentDetails.equipmentNumber} from the Group and
          Add it to the selected Equipment`, value: 'Inactive'
      }];
    }
  }
  getCommentsCount(data: ViewActivityLogDetails) {
    if (data.comments) {
      this.activityLogLoadedEditModel.commentsCount = data.comments.length;
    }
  }
  getZoneFormat() {
    return ActivityLogUtils.getZoneFormat(this.activityLogLoadedEditModel.timeZone);
  }
}
