import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { DatePipe } from '@angular/common';
import { configureTestSuite } from 'ng-bullet';

import { MessageService } from 'primeng/components/common/messageservice';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { InputSwitchModule } from 'primeng/inputswitch';
import { TooltipModule } from 'primeng/tooltip';
import { KeyFilterModule } from 'primeng/keyfilter';

import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { AppSharedDataService } from '../../../../shared/jbh-app-services/app-shared-data.service';
import { ActivityLogLoadedEditComponent } from './activity-log-loaded-edit.component';
import { ActivityLogLocationDetailsComponent } from '../../activity-log-location-details/activity-log-location-details.component';
import { GlobalPopupsModule } from './../../../../shared/global-popups/global-popups.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { EquipmentGroupPopupModule } from '../../../../shared/equipment-group-popup/equipment-group-popup.module';

import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ActivityLogLoadedAddUtils } from '../activity-log-loaded-add/services/activity-log-loaded-add.utils';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { ActivityLogService } from '../../services/activity-log.service';

const finalDestination = {
  stateID: 0,
  stateCode: '',
  stateName: '',
};
const equipmentList = [
  {
    equipmentAssociationId: null,
    equipmentId: 191693,
    equipmentAssociationStackingId: null,
    equipmentNumber: '351810',
    equipmentPrefix: '',
    stack: null,
    isOldStack: null,
    sequenceNumber: null,
    equipmentCategory: 'TRACTOR',
    businessUnit: 'DCS',
    operationalGroupCode: 'DCS CUOR24',
    operationalGroupCodeType: 'Fleet',
    operationalGroupDescription: 'CHEP USA -INDIANAPOLIS',
    equipmentType: 'DAY CAB',
    equipmentTypeDesc: 'DayCab',
    equipmentStatus: 'Dispatched',
    trailingEquipmentStatus: '',
    length: '0 ft',
    width: '0 ft 0 in',
    height: '0 ft 0 in',
    lengthValue: 0,
    widthValue: 0,
    heightValue: 0,
    equipmentMaintenanceStatus: 'OPERATIONAL',
    equipmentMissing: null,
    equipmentAssociationGroupId: null,
    oldEquipmentAssociationGroupId: null,
    removeEquipment: null,
    isRemoveGroup: null,
    isUnstackRequired: null,
    isLegacyOnly: null,
    locationDetails: {
      equipmentId: '191693',
      locationId: null,
      marketingAreaCode: 'Kansas Area',
      locationCode: null,
      locationName: null,
      addressLine1: null,
      addressLine2: null,
      state: 'KS',
      city: 'Junction City',
      zipcode: '66441',
      country: 'USA',
      latitude: '40.719044',
      longitude: '-86.4308389',
      description: '55.1m N of Indianapolis, IN and 2.1m SW of Logansport, IN On State Rd 25',
      lastUpdatedCurrentLocation: null,
      lastUpdatedGpsLocation: '07/02/2019 05:26 PM GMT',
      timezone: 'America/Chicago',
      stateName: 'Kansas',
      cityId: '14499',
      countryCode: 'USA',
      gpsCurrentLocation: 'DUNKIRK,CA, IN',
      gpsCountryName: null,
      gpsCityName: 'DUNKIRK,CA',
      gpsStateName: 'IN',
      gpsStateCode: 'IN'
    },
    stackedEquipmentList: [],
    skipValidation: null,
    userId: null,
    oldTruckId: null,
    links: []
  },
  {
    equipmentAssociationId: null,
    equipmentId: 343349,
    equipmentAssociationStackingId: null,
    equipmentNumber: '094142',
    equipmentPrefix: 'JBHZ',
    stack: null,
    isOldStack: null,
    sequenceNumber: null,
    equipmentCategory: 'TRAILER',
    businessUnit: null,
    operationalGroupCode: null,
    operationalGroupCodeType: null,
    operationalGroupDescription: null,
    equipmentType: 'DRY VAN',
    equipmentTypeDesc: 'Dry Van',
    equipmentStatus: 'Available',
    trailingEquipmentStatus: 'Empty',
    length: '57 ft',
    width: '8 ft 6 in',
    height: '13 ft 6 in',
    lengthValue: 57,
    widthValue: 102,
    heightValue: 162,
    equipmentMaintenanceStatus: 'OPERATIONAL',
    equipmentMissing: null,
    equipmentAssociationGroupId: null,
    oldEquipmentAssociationGroupId: null,
    removeEquipment: null,
    isRemoveGroup: null,
    isUnstackRequired: null,
    isLegacyOnly: null,
    locationDetails: {
      equipmentId: '343349',
      locationId: 279648,
      marketingAreaCode: null,
      locationCode: 'HY',
      locationName: 'J B Hunt/Houston Yard',
      addressLine1: '350 Gellhorn Dr',
      addressLine2: '',
      state: 'TX',
      city: 'Houston',
      zipcode: '770136100',
      country: 'USA',
      latitude: null,
      longitude: null,
      description: null,
      lastUpdatedCurrentLocation: null,
      lastUpdatedGpsLocation: null,
      timezone: 'America/Chicago',
      stateName: 'TX',
      cityId: null,
      countryCode: 'USA',
      gpsCurrentLocation: null,
      gpsCountryName: null,
      gpsCityName: null,
      gpsStateName: null,
      gpsStateCode: null
    },
    stackedEquipmentList: [],
    skipValidation: null,
    userId: null,
    oldTruckId: null,
    links: []
  }
];

class MockActivityLogService {
  constructor() { }
  getFinalDestination(operationalPlanID) {
    return of(finalDestination);
  }
}
describe('ActivityLogLoadedEditComponent', () => {
  let component: ActivityLogLoadedEditComponent;
  let fixture: ComponentFixture<ActivityLogLoadedEditComponent>;
  let activityLogService: ActivityLogService;
  const fromCheckCallPage = {
    isCheckCallTracking: true,
    checkCallNavigation: true,
    isTracking: true
  };
  const trueValue = true;
  const trackingParam = {
    driverId: '1',
    equipmentId: 1,
    loadNumber: 1,
    equipmentNumber: 1
  };
  const loadedDetails = {
    operationalPlanStopDetails: {
      locationDetails: {
        locationId: '',
        locationName: '',
        locationCode: '',
        address: {
          addressLine1: '',
          addressLine2: '',
          city: '',
          state: '',
          zipcode: '',
          country: '',
          countryName: '',
          timeZone: 'abc'
        }
      }
    }
  };
  const pickupEquipmentDetails = [
    {
      equipmentId: 1,
      equipmentType: '',
      equipmentPrefix: '',
      equipmentNumber: '',
      equipmentCategory: 'container'
    }
  ];
  const pickupEquip = [{
    equipmentId: 1,
    equipmentType: 'container',
    equipmentPrefix: '',
    equipmentNumber: '1',
    equipmentCategory: 'container'
  }];
  const viewactiviytlogdetails = {
    operationalPlanStopId: 1,
    operationalPlanId: 1,
    loadedType: '',
    loadedBy: '',
    operationalPlanStopDetails: {
      operationalPlanStopSequenceNumber: null,
      operationalPlanStopReasonCode: '',
      operationalPlanStopReasonCodeDescription: '',
      locationDetails: loadedDetails.operationalPlanStopDetails.locationDetails,
      appointmentStartTimestamp: '',
      appointmentEndTimestamp: '',
      stopSequenceDescription: ''
    },
    lastUpdateProgramName: '',
    lastUpdatedUserId: '',
    loadedTimestamp: '',
    proNumber: null,
    weight: {
      weight: null,
      unitOfWeightMeasurement: ''
    },
    volume: {
      volume: null,
      unitOfVolumeMeasurement: ''
    },
    temperature: {
      temperature: null,
      unitOfTemperatureMeasurement: ''
    },
    count: null,
    countedBy: '',
    sealNumber: '',
    bolNumber: '',
    poNumbers: [],
    shipperIdentificationNumber: '',
    receiverStateId: null,
    receiverStateName: 'abc',
    hazmatIndicator: '',
    comments: '',
    pickupEquipmentDetails: pickupEquipmentDetails,
    dropEquipmentDetails: pickupEquipmentDetails,
    stopServicesTypeCodes: [],
    stopServices: [],
    checkCallSource: 'Telematics'
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule, CalendarModule, AutoCompleteModule,
        CheckboxModule, DropdownModule, InputSwitchModule, JbhLoaderModule, ReactiveFormsModule,
        PipesModule, TooltipModule, RouterTestingModule, GlobalPopupsModule, EquipmentGroupPopupModule,
        DirectivesModule, KeyFilterModule],
      providers: [UserService, AppConfigService, LocalStorageService, MessageService, DatePipe, AppSharedDataService,
        { provide: ActivityLogService, useClass: MockActivityLogService }],
      declarations: [ActivityLogLoadedEditComponent, ActivityLogLocationDetailsComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogLoadedEditComponent);
    component = fixture.componentInstance;
    component.fromCheckCallPage = fromCheckCallPage;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.editFromTracking = trueValue;
    component.overrideAllWarning = trueValue;
    component.reload = trueValue;
    component.trackingParam = trackingParam;
    component.loadDetails = viewactiviytlogdetails;
    expect(component).toBeTruthy();
  });

  it('ActivityLogLoadedEditComponent getloadedFormGroup have been called', () => {
    component.getloadedFormGroup();
    expect(component.activityLogLoadedEditModel.addLoadedForm.controls['loadedDate'].value).toEqual('');
  });

  it('ActivityLogLoadedEditComponent pickupEquipmentError have been called', () => {
    component.pickupEquipmentError();
    expect(component.activityLogLoadedEditModel.addLoadedForm.controls['trailerOrContainer'].touched).toBeTruthy();
  });

  it('ActivityLogLoadedEditComponent saveForm have been called', () => {
    spyOn(ActivityLogLoadedAddUtils, 'mandatoryFieldsCheck');
    spyOn(ActivityLogUtils, 'onNoChangeMessage');
    spyOn(ActivityLogUtils, 'checkLoadedFormValidity');
    spyOn(component.arrivalDeviationType, 'emit');
    component.saveForm();
    expect(component.arrivalDeviationType.emit).toHaveBeenCalledWith([]);
  });

  it('ActivityLogLoadedEditComponent dropEquipmentCheckbox have been called', () => {
    component.activityLogLoadedEditModel.isLoadedCheckCallDetails = true;
    component.activityLogLoadedEditModel.loadedDetails = viewactiviytlogdetails;
    component.activityLogLoadedEditModel.loadedDetails.pickupEquipmentDetails = pickupEquip;
    const result = {
      'label': '1',
      'value': {
        equipmentId: 1,
        equipmentType: 'container',
        equipmentPrefix: '',
        equipmentNumber: '1'
      }
    };
    component.dropEquipmentCheckbox();
    expect(component.activityLogLoadedEditModel.addLoadedForm.controls['trailerOrContainer'].value).toEqual(result);
  });

  it('ActivityLogLoadedEditComponent onSelectLoadedType have been called', () => {
    spyOn(component, 'onSelectLoadedType');
    component.onLoadedTypeSelected();
    expect(component.onSelectLoadedType).toHaveBeenCalled();
  });

  it('ActivityLogLoadedEditComponent loadedFinalizeMethod have been called', () => {
    component.loadedFinalizeMethod();
    expect(component.activityLogLoadedEditModel.isLoading).toBe(false);
  });

  it('ActivityLogLoadedEditComponent onRemoveTrailerOrContainer have been called', () => {
    component.onRemoveTrailerOrContainer();
    expect(component.activityLogLoadedEditModel.equipmentPaired.length).toBe(0);
  });

  it('ActivityLogLoadedEditComponent getStringifyValue have been called', () => {
    const obj = { value: '' };
    const rtnvalue = component.getStringifyValue(obj);
    expect(rtnvalue).toEqual(JSON.stringify(obj));
  });

  it('ActivityLogLoadedEditComponent frameCheckCallRequest have been called', () => {
    const obj = {
      checkCallSource: '',
      isWarningOverride: '',
      checkCallId: '',
      checkCallDetails: {
        pickupEquipmentDetails: [],
        dropEquipmentDetails: []
      }
    };
    component.activityLogLoadedEditModel.onSelectTrailerOrContainer = false;
    component.activityLogLoadedEditModel.loadedDetails = viewactiviytlogdetails;
    const rtnval = component.frameCheckCallRequest(obj);
    expect(rtnval.checkCallSource).toEqual('Telematics');
  });

  it('ActivityLogLoadedEditComponent getArrivalCallDetails have been called', () => {
    spyOn(component, 'getCheckCallData');
    component.getArrivalCallDetails(1, 'abc');
    expect(component.activityLogLoadedEditModel.isLoading).toEqual(true);
  });

  it('ActivityLogLoadedEditComponent telematicsPickupEquip have been called', () => {
    component.activityLogLoadedEditModel.loadedDetails = viewactiviytlogdetails;
    component.activityLogLoadedEditModel.isLoadedCheckCallDetails = true;
    component.activityLogLoadedEditModel.addLoadedForm.controls['trailerOrContainer'].patchValue({ value: 'trailer' });
    component.activityLogLoadedEditModel.isTelematicsPickup = true;
    component.telematicsPickupEquip();
    expect(component.activityLogLoadedEditModel.isTelematicsPickup).toBeTruthy();
  });

  it('ActivityLogLoadedEditComponent loadedResponse have been called', () => {
    spyOn(component, 'getErrorList');
    spyOn(component, 'setFinalDestination');
    const data = viewactiviytlogdetails;
    data.loadedType = 'drop and hook';
    data.stopServices = ['a', 'b'];
    data.stopServicesTypeCodes = ['a', 'b'];
    component.loadedResponse(data);
    expect(component.activityLogLoadedEditModel.findIsLoadedEarlyRequest.isEdit).toBeTruthy();
  });

  it('ActivityLogLoadedEditComponent loadedResponse have been called', () => {
    spyOn(component, 'onLoadedBySelect');
    spyOn(component, 'onCountedBySelect');
    spyOn(component, 'dropEquipmentCheckbox');
    spyOn(component, 'setLoadedUnitFormValues');
    spyOn(component, 'getErrorList');
    spyOn(component, 'getEquipmentInfo');
    spyOn(component, 'setFinalDestination');
    const data = viewactiviytlogdetails;
    data.loadedBy = 'a';
    data.countedBy = 'b';
    data.stopServices = [];
    component.activityLogLoadedEditModel.isLoadedCheckCallDetails = true;
    component.activityLogLoadedEditModel.isReload = true;
    component.loadedResponse(data);
    expect(component.activityLogLoadedEditModel.checkCallFinalDestination).toEqual('abc');
  });

  it('ActivityLogLoadedEditComponent sequenceNumber have been called', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.sequenceNumber({ stopSequenceNumber: '1', stopId: '', destinationHeader: '' });
    expect(component.stopSequenceNumber.emit).toHaveBeenCalled();
  });

  it('ActivityLogLoadedEditComponent getEquipmentInfo have been called', () => {
    component.activityLogLoadedEditModel.isReload = true;
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    const trailerSelected = {
      equipmentId: 1,
      equipmentType: '',
      equipmentPrefix: '',
      equipmentNumber: ''
    };
    spyOn(localStorageService, 'getItem').and.callFake(function (checkcallloadedForm, values) {
      if (checkcallloadedForm === 'checkcallloadedForm' && values === 'values') {
        return { departureTime: '', trailerSelected: trailerSelected, formDetails: {} };
      }
      return { departureTime: '' };
    });
    component.getEquipmentInfo();
    expect(component.activityLogLoadedEditModel.departureTimestamp).toEqual('');
  });

  it('ActivityLogLoadedEditComponent getEquipmentInfo else case have been called', () => {
    component.activityLogLoadedEditModel.isReload = false;
    spyOn(component, 'onSelectLoadedType');
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'getItem');
    component.getEquipmentInfo();
    expect(component.onSelectLoadedType).toHaveBeenCalled();
  });

  it('ActivityLogLoadedEditComponent handleError have been called', () => {
    spyOn(ActivityLogUtils, 'handleErrorAndNull');
    component.handleError({ error: { errors: '' } });
    expect(component.activityLogLoadedEditModel.isLoading).toBeFalsy();
  });

  it('ActivityLogLoadedEditComponent checkSelectedDropEquipment have been called', () => {
    spyOn(component, 'pickupEquipmentError');
    spyOn(ActivityLogLoadedAddUtils, 'createAddLoadedRequest');
    spyOn(ActivityLogUtils, 'checkeddroppedOrUndropped');
    component.checkSelectedDropEquipment({});
    expect(ActivityLogLoadedAddUtils.createAddLoadedRequest).toHaveBeenCalled();
  });

  it('ActivityLogLoadedEditComponent checkSelectedDropEquipment else case have been called', () => {
    spyOn(component, 'pickupEquipmentError');
    spyOn(ActivityLogLoadedAddUtils, 'createAddLoadedRequest');
    spyOn(ActivityLogUtils, 'checkeddroppedOrUndropped').and.returnValue('drop');
    component.checkSelectedDropEquipment({});
    expect(component.pickupEquipmentError).toHaveBeenCalled();
  });

  it('ActivityLogLoadedEditComponent onLoadedDateOrTimeClear have been called', () => {
    component.onLoadedDateOrTimeClear(true);
    expect(component.activityLogLoadedEditModel.addLoadedForm.controls.loadedDate.value).toBeNull();
  });

  it('ActivityLogLoadedEditComponent onLoadedDateOrTimeClear else case have been called', () => {
    const obj = { overlayVisible: true };
    component.onLoadedDateOrTimeClear(false, obj);
    expect(obj.overlayVisible).toBeFalsy();
  });
  it('ActivityLogLoadedEditComponent setFinalDestination have been called', () => {
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getFinalDestination').and.returnValue(of(finalDestination));
    component.activityLogLoadedEditModel.findIsLoadedEarlyRequest.operationalPlanID = 1234;
    component.setFinalDestination();
    expect(component.activityLogLoadedEditModel.finalDestination).toBe(finalDestination);
  });
  it('ActivityLogLoadedEditComponent setFinalDestination error block have been called', () => {
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getFinalDestination').and.returnValue(throwError(null));
    component.activityLogLoadedEditModel.findIsLoadedEarlyRequest.operationalPlanID = 1234;
    component.setFinalDestination();
    expect(component.activityLogLoadedEditModel.finalDestination).toBe(null);
  });
  it('ActivityLogLoadedEditComponent onLoadedBySelect have been called', () => {
    const loadedTypeValue = {
      label: 'Drop And Hook',
      value: 'DrpAndHook'
    };
    spyOn(ActivityLogUtils, 'setStopServiceSelectedValue').and.callThrough();
    component.onLoadedBySelect(loadedTypeValue);
    expect(ActivityLogUtils.setStopServiceSelectedValue).toHaveBeenCalled();
  });
  it('ActivityLogLoadedEditComponent onCountedBySelect have been called', () => {
    const countedByValue = {
      label: 'Lumper',
      value: 'Lumper'
    };
    spyOn(ActivityLogUtils, 'setStopServiceSelectedValue').and.callThrough();
    component.onCountedBySelect(countedByValue);
    expect(ActivityLogUtils.setStopServiceSelectedValue).toHaveBeenCalled();
  });
  it('ActivityLogLoadedEditComponent onTextAreaType have been called', () => {
    component.onTextAreaType();
    expect(component.activityLogLoadedEditModel.commentsCount).toEqual(0);
  });
  it('ActivityLogLoadedEditComponent getUpdatedEquipment have been called', () => {
    component.getUpdatedEquipment({});
    expect(component.activityLogLoadedEditModel.equipmentPaired).toEqual({});
  });
  it('ActivityLogLoadedEditComponent titleCase have been called', () => {
    spyOn(ActivityLogLoadedAddUtils, 'getTitleCase').and.callThrough();
    const dropEquipment = {
      equipmentType: 'DRY VAN'
    };
    component.titleCase(dropEquipment);
    expect(ActivityLogLoadedAddUtils.getTitleCase).toHaveBeenCalled();
  });
  it('ActivityLogLoadedEditComponent onSelectingEquipmentDetails have been called', () => {
    component.onSelectingEquipmentDetails(equipmentList, 191693);
    expect(component.activityLogLoadedEditModel.showEquipmentGroup).toBeTruthy();
  });
});
