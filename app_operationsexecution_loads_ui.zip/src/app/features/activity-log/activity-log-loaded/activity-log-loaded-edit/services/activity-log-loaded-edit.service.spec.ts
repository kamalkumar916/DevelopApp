import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogLoadedEditService } from './activity-log-loaded-edit.service';
import { configureTestSuite } from 'ng-bullet';

describe('ActivityLogLoadedEditService', () => {
  let service: ActivityLogLoadedEditService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogLoadedEditService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(ActivityLogLoadedEditService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('updateLoadedDetails should be called', () => {
    service.updateLoadedDetails({}, 0, true).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.addCheckCallLoaded}/0/monitoringtasks`);
    expect(req.request.method).toEqual('PATCH');
  });
  it('updateLoadedDetails should be called', () => {
    service.updateLoadedDetails({}, 0).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.addLoaded}/0`);
    expect(req.request.method).toEqual('PATCH');
  });
});
