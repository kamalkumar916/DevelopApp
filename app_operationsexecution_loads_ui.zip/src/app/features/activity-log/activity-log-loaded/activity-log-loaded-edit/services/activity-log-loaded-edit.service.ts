import { Injectable } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from './../../../../../shared/service/app-config.service';

@Injectable({
  providedIn: 'root'
})
export class ActivityLogLoadedEditService {

  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('activitylog');
  }
  updateLoadedDetails(editRequestObj, checkCallId: number, isLoadedCheckCallDetails = false): Observable<any> {
    if (isLoadedCheckCallDetails) {
      return this.http.patch<any>(`${this.endpoint.addCheckCallLoaded}/${checkCallId}/monitoringtasks`,
       editRequestObj);
    } else {
      return this.http.patch<any>(`${this.endpoint.addLoaded}/${checkCallId}`, editRequestObj);
    }
  }
}
