import { Injectable } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ElasticResponseModel } from '../../../../../features/model/elastic-response.interface';
import { AppConfigService } from './../../../../../shared/service/app-config.service';

import {
  CountedBy, UnitOfTemperature, UnitOfVolume, UnitOfWeight,
  OperationalPlanStopActivityPartyType, OperationalPlanStopActivityType, IsLoadedEarly, IsLoadedEarlyError, StopServices, AddLoadedRequest
} from '../model/activity-log-loaded-add.interface';

@Injectable({
  providedIn: 'root'
})
export class ActivityLogLoadedAddService {

  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('activitylog');
  }
  getLoadedType(): Observable<OperationalPlanStopActivityType> {
    return this.http.get<OperationalPlanStopActivityType>(this.endpoint.loadedType);
  }
  getLoadedBy(): Observable<OperationalPlanStopActivityPartyType> {
    return this.http.get<OperationalPlanStopActivityPartyType>(this.endpoint.loadedBy);
  }
  getCountedBy(): Observable<CountedBy> {
    return this.http.get<CountedBy>(this.endpoint.countedBy);
  }
  getUnitOfWeight(): Observable<UnitOfWeight> {
    return this.http.get<UnitOfWeight>(this.endpoint.unitOfWeight);
  }
  getUnitOfVolume(): Observable<UnitOfVolume> {
    return this.http.get<UnitOfVolume>(this.endpoint.unitOfVolume);
  }
  getUnitOfTemperature(): Observable<UnitOfTemperature> {
    return this.http.get<UnitOfTemperature>(this.endpoint.unitOfTemperature);
  }
  getLoadedDateTime(loadedDateTime: IsLoadedEarly): Observable<IsLoadedEarlyError> {
    return this.http.post<IsLoadedEarlyError>(this.endpoint.addLoadedDateTime, loadedDateTime);
  }
  getStopServices(stopService: string): Observable<StopServices> {
    return this.http.get<StopServices>(`${this.endpoint.stopServices}/stopservices?stopService=${stopService}`);
  }
  addLoadedDetails(addLoadedReq): Observable<any> {
    return this.http.post<any>(this.endpoint.addLoaded, addLoadedReq);
  }
}
