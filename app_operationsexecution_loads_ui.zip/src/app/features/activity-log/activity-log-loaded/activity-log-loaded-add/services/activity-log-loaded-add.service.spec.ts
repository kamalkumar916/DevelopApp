import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogLoadedAddService } from './activity-log-loaded-add.service';
import { configureTestSuite } from 'ng-bullet';

describe('ActivityLogLoadedAddService', () => {
  let service: ActivityLogLoadedAddService;
  let httpTestingController: HttpTestingController;
  const IsLoadedEarly  = {
      loadedTimestamp: '',
      unloadedTimestamp: '',
      operationalPlanID: 0,
      operationalPlanStopID: 0,
      isEdit: false
  };
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogLoadedAddService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(ActivityLogLoadedAddService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getLoadedType should be called', () => {
    service.getLoadedType().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.loadedType);
    expect(req.request.method).toEqual('GET');
  });
  it('getLoadedBy should be called', () => {
    service.getLoadedBy().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.loadedBy);
    expect(req.request.method).toEqual('GET');
  });
  it('getCountedBy should be called', () => {
    service.getCountedBy().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.countedBy);
    expect(req.request.method).toEqual('GET');
  });
  it('getUnitOfWeight should be called', () => {
    service.getUnitOfWeight().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.unitOfWeight);
    expect(req.request.method).toEqual('GET');
  });
  it('getUnitOfVolume should be called', () => {
    service.getUnitOfVolume().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.unitOfVolume);
    expect(req.request.method).toEqual('GET');
  });
  it('getUnitOfTemperature should be called', () => {
    service.getUnitOfTemperature().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.unitOfTemperature);
    expect(req.request.method).toEqual('GET');
  });
  it('getStopServices should be called', () => {
    service.getStopServices('').subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.stopServices}/stopservices?stopService=${''}`);
    expect(req.request.method).toEqual('GET');
  });
  it('addLoadedDetails should be called', () => {
    service.addLoadedDetails({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.addLoaded);
    expect(req.request.method).toEqual('POST');
  });
  it('getLoadedDateTime should be called', () => {
    service.getLoadedDateTime(IsLoadedEarly).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.addLoadedDateTime);
    expect(req.request.method).toEqual('POST');
  });
});
