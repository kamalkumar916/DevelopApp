import { FormGroup } from '@angular/forms';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';
import * as moment from 'moment';
import { AddLoadedResponseValues } from '../model/activity-log-loaded-add.interface';
import { ActivityLogLoadedAddModel } from '../model/activity-log-loaded-add.model';
import { ActivityLogUtils } from '../../../services/activity-log.utils';
import { ViewActivityLogDetails, ResourceOverview, DropEquipmentDetail } from '../../../models/activity-log.interface';
import { ListItem } from '../../../../model/common.interface';
import { LoadOverview } from '../../../../load-details/load-details-overview/model/load-overview.interface';
import { findIndex } from 'lodash';

export class ActivityLogLoadedAddUtils {
    static mandatoryFieldsCheck(addLoadedForm: FormGroup) {
        if (addLoadedForm.controls.weightUnits['controls'].weight.value && !addLoadedForm.controls.weightUnits['controls'].units.value) {
            addLoadedForm.controls.weightUnits['controls'].units.setErrors({ 'invalid': true });
        }
        if (addLoadedForm.controls.volumeUnits['controls'].volume.value &&
            !addLoadedForm.controls.volumeUnits['controls'].units.value) {
            addLoadedForm.controls.volumeUnits['controls'].units.setErrors({ 'invalid': true });
        }
        if (addLoadedForm.controls.temperatureReadingUnits['controls'].temperatureReading.value &&
            !addLoadedForm.controls.temperatureReadingUnits['controls'].units.value) {
            addLoadedForm.controls.temperatureReadingUnits['controls'].units.setErrors({ 'invalid': true });
        }
    }
    static createAddLoadedRequest(addLoadedForm: FormGroup, addLoadedInput: AddLoadedResponseValues, resourceOverview: ResourceOverview,
        loadedType?: string) {
        const stopServiceValue = addLoadedForm.value.stopServices && addLoadedForm.value.stopServices.length > 0
            ? addLoadedForm.value.stopServices.map(stopService => stopService.value) : [];
        return {
            operationalPlanNumber: addLoadedInput.planNumber,
            operationalPlanStopSequenceNumber: addLoadedInput.stopSequenceNumber,
            receiverStateId: addLoadedInput.receiverStateId && addLoadedInput.receiverStateId.stateID
                ? addLoadedInput.receiverStateId.stateID : null,
            stopServices: stopServiceValue,
            hazmatIndicator: addLoadedForm.value.hazmat,
            isWarningOverride: addLoadedInput.overrideWarning,
            checkCallDetails: {
                loadedTimestamp: addLoadedInput.loadedTimestamp,
                loadedBy: addLoadedForm.value.loadedBy.value,
                loadedType: loadedType ? loadedType : addLoadedForm.value && addLoadedForm.value.loadedType &&
                    addLoadedForm.value.loadedType.value ? addLoadedForm.value.loadedType.value : null,
                count: ActivityLogUtils.getValueOrNull(addLoadedForm.value.quantity),
                countedBy: addLoadedForm.value.countedBy.value,
                sealNumber: ActivityLogUtils.getValueOrNull(addLoadedForm.value.sealNumber),
                bolNumber: ActivityLogUtils.getValueOrNull(addLoadedForm.value.billOfLadingNumber),
                poNumbers: addLoadedForm.value.purchaseOrderNumber ? [addLoadedForm.value.purchaseOrderNumber] : [],
                shipperIdentificationNumber: ActivityLogUtils.getValueOrNull(addLoadedForm.value.shipmentIdentification),
                unloadedTimestamp: null,
                unloadedBy: null,
                unloadedType: null,
                hubReading: null,
                pickupEquipmentDetails: (addLoadedInput.pickupEquipmentValue
                    && addLoadedInput.pickupEquipmentValue.length > 0) ? addLoadedInput.pickupEquipmentValue : null,
                dropEquipmentDetails: addLoadedInput.dropEquipmentValue,
                comments: ActivityLogUtils.getValueOrNull(addLoadedForm.value.comments),
                departureTimestamp: addLoadedInput.departureTimestamp,
                proNumber: ActivityLogUtils.getValueOrNull(addLoadedForm.value.proNumber),
                weight: this.getWeightDetails(addLoadedForm),
                volume: this.getVolumeDetails(addLoadedForm),
                temperature: this.getTemperatureDetails(addLoadedForm)
            },
            resourceDetails: {
                type: 'Truck',
                value: ActivityLogUtils.getTruckValue(resourceOverview)
            },
            checkCallSourceTimestamp:
                DateUtils.dateTimeZoneFormat(moment(new Date()).format('YYYY-MM-DD'), moment(new Date()).format('H:mm'),
                    addLoadedInput.timeZone),
            checkCallMessage: null,
            isAutoCheckCall: false,
            checkCallSource: 'MnlChkCal',
            locationDetails: null
        };
    }
    static getWeightDetails(addLoadedForm: FormGroup) {
        if (addLoadedForm.value.weightUnits.weight && addLoadedForm.value.weightUnits.units) {
            return {
                weight: addLoadedForm.value.weightUnits.weight,
                unitOfWeightMeasurement: addLoadedForm.value.weightUnits.units
            };
        } else {
            return null;
        }
    }
    static getVolumeDetails(addLoadedForm: FormGroup) {
        if (addLoadedForm.value.volumeUnits.volume && addLoadedForm.value.volumeUnits.units) {
            return {
                volume: addLoadedForm.value.volumeUnits.volume,
                unitOfVolumeMeasurement: addLoadedForm.value.volumeUnits.units
            };
        } else {
            return null;
        }
    }
    static getTemperatureDetails(addLoadedForm: FormGroup) {
        if (addLoadedForm.value.temperatureReadingUnits.temperatureReading && addLoadedForm.value.temperatureReadingUnits.units) {
            return {
                temperature: addLoadedForm.value.temperatureReadingUnits.temperatureReading,
                unitOfTemperatureMeasurement: addLoadedForm.value.temperatureReadingUnits.units
            };
        } else {
            return null;
        }
    }
    static getDropEquipmentValue(addLoadedForm: FormGroup) {
        if (addLoadedForm.value.loadedType.value && addLoadedForm.value.loadedType.value === 'DrpAndHook') {
            const dropEquipment = addLoadedForm.get('dropEquipmentDetails').value;
            const dropEquipmentValue = [];
            Object.keys(dropEquipment).forEach((equipment) => {
                if (dropEquipment[equipment] && dropEquipment[equipment].length > 0) {
                    dropEquipmentValue.push(JSON.parse(dropEquipment[equipment][0]));
                }
            });
            return dropEquipmentValue;
        } else {
            return null;
        }
    }
    static isEquipmentsEqual(dropEquipment: DropEquipmentDetail[], pickEquipment) {
        const drpEquipment = [];
        let equal = true;
        dropEquipment.forEach((equip) => {
            if (equip.stackedEquipmentList.length > 0) {
                equip.stackedEquipmentList.forEach((sEquip) => {
                    drpEquipment.push(sEquip);
                });
            } else {
                drpEquipment.push(equip);
            }
        });
        pickEquipment.forEach((pEquipment) => {
            if (findIndex(drpEquipment, {
                'equipmentNumber': pEquipment.equipmentNumber,
                'equipmentId': pEquipment.equipmentId
            }) === -1) {
                equal = false;
            }
        });
        return equal;
    }
    static getTitleCase(dropEquipment) {
        let equipmentLabel = '';
        if (dropEquipment && dropEquipment.equipmentType) {
          equipmentLabel = `${dropEquipment.equipmentType.slice(0, 1).toUpperCase()}${dropEquipment.equipmentType.slice(1).toLowerCase()}`;
        }
        return equipmentLabel;
    }
    static resolveWarning(loadedEditModel: ActivityLogLoadedAddModel) {
        if (loadedEditModel.fieldErrorList.includes(loadedEditModel.loadedErrorTaskTypeName.weight)) {
            loadedEditModel.addLoadedForm.get('weightUnits').get('weight').setErrors(null);
        }
        if (loadedEditModel.fieldErrorList.includes(loadedEditModel.loadedErrorTaskTypeName.stopServices)) {
            loadedEditModel.addLoadedForm.get('stopServices').setErrors(null);
        }
        if (loadedEditModel.fieldErrorList.includes(loadedEditModel.loadedErrorTaskTypeName.loadedTime)) {
            loadedEditModel.addLoadedForm.get('loadedTime').setErrors(null);
        }
    }
    static trailerOrContainerError(loadedEditForm: FormGroup) {
        loadedEditForm.get('trailerOrContainer').reset();
        loadedEditForm.get('trailerOrContainer').setErrors({ invalid: true });
        loadedEditForm.get('trailerOrContainer').markAsTouched();
    }
}
