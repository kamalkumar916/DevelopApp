import {
  Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy, ChangeDetectorRef, Output, EventEmitter,
  ViewChild
} from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { takeWhile, finalize } from 'rxjs/operators';
import { timer } from 'rxjs';
import { isEmpty, find } from 'lodash';
import * as moment from 'moment';
import { MessageService } from 'primeng/components/common/messageservice';

import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';

import { ActivityLogLoadedAddService } from './services/activity-log-loaded-add.service';
import { ActivityLogLoadedAddModel } from './model/activity-log-loaded-add.model';
import { ListItem } from '../../../../features/model/common.interface';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ActivityLogLoadedAddUtils } from './services/activity-log-loaded-add.utils';
import { ErrorList, FinalDestination, ResourceOverview } from '../../models/activity-log.interface';
import { ArrivalDeviationRequest } from '../../activity-log-arrival/activity-log-arrival-add/model/activity-log-arrival-add.interface';
import { ActivityLogService } from '../../services/activity-log.service';
import { ActivityLogModel } from '../../models/activity-log.model';
import { AssetDetailQuery } from '../../../query/asset-detail.query';
import { EquipmentGroupItem } from '../../../tracking-details/model/tracking-details.interface';

@Component({
  selector: 'app-activity-log-loaded-add',
  templateUrl: './activity-log-loaded-add.component.html',
  styleUrls: ['./activity-log-loaded-add.component.scss', '../../activity-log.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogLoadedAddComponent implements OnInit, OnDestroy {

  @Input() set earlyLoadedRequest(data: ArrivalDeviationRequest) {
    if (data && data.operationalPlanID && data.operationalPlanStopID) {
      this.activityLogLoadedAddModel.findIsLoadedEarlyRequest.operationalPlanID = data.operationalPlanID;
      this.activityLogLoadedAddModel.findIsLoadedEarlyRequest.operationalPlanStopID = data.operationalPlanStopID;
      this.activityLogLoadedAddModel.stopSequenceNumber = data.operationalPlanStopSequenceNumber
        ? data.operationalPlanStopSequenceNumber : null;
      this.activityLogLoadedAddModel.planNumber = data.operationalPlanNumber ? data.operationalPlanNumber : null;
      this.setFinalDestination();
    }
  }

  @Input() set loadDetails(loadDetail) {
    if (loadDetail) {
      this.activityLogLoadedAddModel.loadOverviewDetails = loadDetail;
      this.activityLogLoadedAddModel.isHazmat = ActivityLogUtils.checkForHazmat(loadDetail);
      ActivityLogUtils.checkLocalStoreHazmat(this.activityLogLoadedAddModel.addLoadedForm, this.activityLogLoadedAddModel.isHazmat,
      this.activityLogLoadedAddModel.isReload);
    }
  }
  @Input() set stopInformation(stopInfo) {
    this.activityLogLoadedAddModel.stopDetails = stopInfo;
    if (stopInfo && stopInfo.locationDetailsDTO && stopInfo.locationDetailsDTO.timezone) {
      this.activityLogLoadedAddModel.timeZone = stopInfo.locationDetailsDTO.timezone;
    }
  }
  @Input() set resourceDetails(resourceOverview: ResourceOverview) {
    this.activityLogLoadedAddModel.resourceOverview = resourceOverview;
    this.getDropEquipment(resourceOverview);
  }
  @Input() set reload(isReload: boolean) {
    if (isReload) {
      this.activityLogLoadedAddModel.isReload = isReload;
    }
  }
  @Output() arrivalDeviationType: EventEmitter<ErrorList[]> = new EventEmitter<ErrorList[]>();
  @Output() equipmentList: EventEmitter<EquipmentGroupItem[]> = new EventEmitter<EquipmentGroupItem[]>();
  activityLogLoadedAddModel: ActivityLogLoadedAddModel;
  @Input() set overrideAllWarning(event) {
    this.activityLogLoadedAddModel.isOverrideWarning = event;
  }
  constructor(private readonly fb: FormBuilder, private readonly activityLogLoadedAddService: ActivityLogLoadedAddService,
    private readonly localStorageService: LocalStorageService,
    private readonly changeDetector: ChangeDetectorRef, private readonly toastMessage: MessageService, private readonly router: Router,
    private readonly activityLogService: ActivityLogService, private readonly activatedRoute: ActivatedRoute) {
    this.activityLogLoadedAddModel = new ActivityLogLoadedAddModel();
  }

  ngOnInit() {
    this.activityLogLoadedAddModel.activityType = this.activatedRoute.queryParams['_value']['activityType'];
    this.activityLogLoadedAddModel.addLoadedForm = ActivityLogUtils.getLoadedUnloadedFormGroup(this.fb);
    this.getloadedFormGroup();
    this.getUnitOfVolumeData();
    this.getUnitOfWeightData();
    this.getUnitOfTemperatureData();
    if (this.activityLogLoadedAddModel.isReload) {
      this.activityLogLoadedAddModel.isLoading = true;
      this.getDropEquipment(this.activityLogLoadedAddModel.resourceOverview);
    }
  }
  getStringifyValue(dropEquipment) {
    return JSON.stringify(dropEquipment);
  }
  setFinalDestination() {
    if (this.activityLogLoadedAddModel.findIsLoadedEarlyRequest.operationalPlanID) {
      this.activityLogService.getFinalDestination(this.activityLogLoadedAddModel.findIsLoadedEarlyRequest.operationalPlanID)
        .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data: FinalDestination) => {
          this.activityLogLoadedAddModel.finalDestination = data ? data : null;
        }, (error) => {
          this.activityLogLoadedAddModel.finalDestination = null;
        });
    }
  }
  getloadedFormGroup() {
    this.activityLogLoadedAddModel.addLoadedForm.addControl('loadedDate', new FormControl('', Validators.required));
    this.activityLogLoadedAddModel.addLoadedForm.addControl('loadedTime', new FormControl('', Validators.required));
    this.activityLogLoadedAddModel.addLoadedForm.addControl('loadedType', new FormControl('', Validators.required));
    this.activityLogLoadedAddModel.addLoadedForm.addControl('loadedBy', new FormControl('', Validators.required));
  }
  getLoadedTypeData() {
    this.activityLogLoadedAddService.getLoadedType()
      .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityTypes)) {
          this.activityLogLoadedAddModel.loadedType =
            ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityTypes,
              'operationalPlanStopActivityTypeDescription', 'operationalPlanStopActivityTypeCode');
        }
      }, (error) => {
        this.activityLogLoadedAddModel.loadedType = [];
      });
  }
  getLoadedByData() {
    this.activityLogLoadedAddService.getLoadedBy()
      .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityPartyTypes)) {
          this.activityLogLoadedAddModel.loadedBy = this.activityLogLoadedAddModel.stopDetails &&
            this.activityLogLoadedAddModel.stopDetails.operationalPlanStopReason ?
            ActivityLogUtils.getFormatedLoadedByValue(data._embedded.operationalPlanStopActivityPartyTypes,
              this.activityLogLoadedAddModel.stopDetails.operationalPlanStopReason) :
            ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityPartyTypes,
              'operationalPlanStopActivityPartyTypeDescription', 'operationalPlanStopActivityPartyTypeCode');
        }
      }, (error) => {
        this.activityLogLoadedAddModel.loadedBy = [];
      });
  }
  getCountedByData() {
    this.activityLogLoadedAddService.getCountedBy()
      .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.countedByPartyTypes)) {
          this.activityLogLoadedAddModel.countedBy = this.activityLogLoadedAddModel.stopDetails &&
            this.activityLogLoadedAddModel.stopDetails.operationalPlanStopReason ?
            ActivityLogUtils.getFormatedCountedByValue(data._embedded.countedByPartyTypes,
              this.activityLogLoadedAddModel.stopDetails.operationalPlanStopReason) :
            ActivityLogUtils.getFormattedData(data._embedded.countedByPartyTypes,
              'countedByPartyTypeDescription', 'countedByPartyTypeCode');
        }
      }, (error) => {
        this.activityLogLoadedAddModel.countedBy = [];
      });
  }
  getUnitOfWeightData() {
    this.activityLogLoadedAddService.getUnitOfWeight()
      .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfWeightMeasurements)) {
          this.activityLogLoadedAddModel.unitOfWeight =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfWeightMeasurements, 'unitOfWeightMeasurementDescription',
              'unitOfWeightMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogLoadedAddModel.addLoadedForm, 'weightUnits', { weight: '', units: 'Pounds' });
        }
      }, (error) => {
        this.activityLogLoadedAddModel.unitOfWeight = [];
      });
  }
  getUnitOfVolumeData() {
    this.activityLogLoadedAddService.getUnitOfVolume()
      .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfVolumeMeasurements)) {
          this.activityLogLoadedAddModel.unitOfVolume =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfVolumeMeasurements, 'unitOfVolumeMeasurementDescription',
              'unitOfVolumeMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogLoadedAddModel.addLoadedForm, 'volumeUnits', { volume: '', units: 'Gallons' });
        }
      }, (error) => {
        this.activityLogLoadedAddModel.unitOfVolume = [];
      });
  }
  getUnitOfTemperatureData() {
    this.activityLogLoadedAddService.getUnitOfTemperature()
      .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfTemperatureMeasurements)) {
          this.activityLogLoadedAddModel.unitOfTemperature =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfTemperatureMeasurements, 'unitOfTemperatureMeasurementDescription',
              'unitOfTemperatureMeasurementCode');
        }
      }, (error) => {
        this.activityLogLoadedAddModel.unitOfTemperature = [];
      });
  }
  getStopServicesData(stopService) {
    if (stopService && stopService.query) {
      this.activityLogLoadedAddService.getStopServices(stopService.query)
        .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data) => {
          if (data && data._embedded && !isEmpty(data._embedded.operationalPlanServiceTypes)) {
            this.activityLogLoadedAddModel.stopServices =
              ActivityLogUtils.getFormattedData(data._embedded.operationalPlanServiceTypes, 'operationalPlanServiceTypeDescription',
                'operationalPlanServiceTypeCode');
          }
        }, (error) => {
          this.activityLogLoadedAddModel.stopServices = [];
        });
    }
  }
  saveForm() {
    this.arrivalDeviationType.emit([]);
    this.toastMessage.clear();
    this.validateMandatoryFields();
    this.checkTrailerContainerValid();
    if (this.activityLogLoadedAddModel.addLoadedForm.valid && !this.activityLogLoadedAddModel.isLoading) {
      const addLoadedReq = this.frameLoadedAddRequest();
      if (addLoadedReq) {
        this.saveLoadedActivity(addLoadedReq);
      }
    }
  }
  checkTrailerContainerValid() {
    if (!this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').value &&
      this.activityLogLoadedAddModel.addLoadedForm.valid) {
      if (this.activityLogLoadedAddModel.dropEquipment.length === 0) {
        this.trailerMandatory();
      } else if (this.droppedOrUndroppedLength() === this.activityLogLoadedAddModel.dropEquipment.length) {
        this.pickupEquipmentError();
      } else {
        this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').reset();
        ActivityLogUtils.checkLoadedFormValidity(this.toastMessage, this.activityLogLoadedAddModel.addLoadedForm,
          this.activityLogLoadedAddModel, this.arrivalDeviationType, this.changeDetector);
      }
    } else {
      ActivityLogUtils.checkLoadedFormValidity(this.toastMessage, this.activityLogLoadedAddModel.addLoadedForm,
        this.activityLogLoadedAddModel, this.arrivalDeviationType, this.changeDetector);
    }
  }
  trailerMandatory() {
    if (this.activityLogLoadedAddModel.resourceOverview) {
      this.arrivalDeviationType.emit([{
        errorMessage:
          `Loaded check call failed. Truck ${this.activityLogLoadedAddModel.
            resourceOverview.truck}  must be assigned with trailing equipment to process the loaded check call`,
        errorType: this.activityLogLoadedAddModel.equipmentErrorType,
        errorSeverity: 'ERROR'
      }]);
      this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
      this.changeDetector.detectChanges();
    } else {
      this.toastMessage.clear();
      ActivityLogUtils.resourceFieldError(this.toastMessage);
    }
  }
  droppedOrUndroppedLength() {
    const selectedStatus = [];
    const dropEquipmentData = Object.entries(this.activityLogLoadedAddModel.addLoadedForm.get('dropEquipmentDetails').value);
    dropEquipmentData.forEach((entries) => {
      if (entries && entries[1] && entries[1]['length'] !== 0) {
        selectedStatus.push('checked');
      }
    });
    return selectedStatus.length;
  }
  saveLoadedActivity(addLoadedReq) {
    if (addLoadedReq.resourceDetails.value) {
      this.activityLogLoadedAddModel.isLoading = true;
      this.changeDetector.detectChanges();
      this.activityLogLoadedAddService.addLoadedDetails(addLoadedReq)
        .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
          finalize(() => {
            this.activityLogLoadedAddModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data) {
            this.clearLocalStoreItem();
            ActivityLogUtils.successMessage(this.toastMessage, 'Loaded', 'added');
            timer(ActivityLogModel.addSaveTimer).subscribe(() => {
              this.navigateToParent();
            });
          }
        }, (error) => {
          this.handleError(error);
        });
    } else {
      this.toastMessage.clear();
      ActivityLogUtils.resourceFieldError(this.toastMessage);
    }
  }
  handleError(error) {
    this.activityLogLoadedAddModel.isLoading = false;
    if (ActivityLogUtils.handleErrorAndNull(error, this.toastMessage)) {
      ActivityLogUtils.checkRuleValidationError(error.error.errors,
        this.activityLogLoadedAddModel.addLoadedForm, this.arrivalDeviationType,
        this.changeDetector);
      this.arrivalDeviationType.emit(error.error.errors);
    }
  }
  validateMandatoryFields() {
    ActivityLogLoadedAddUtils.mandatoryFieldsCheck(this.activityLogLoadedAddModel.addLoadedForm);
    FormValidationUtils.validateAllFormFields(this.activityLogLoadedAddModel.addLoadedForm);
    this.changeDetector.detectChanges();
  }
  frameLoadedAddRequest() {
    if (!this.activityLogLoadedAddModel.loadedDate && !this.activityLogLoadedAddModel.loadedTime) {
      this.activityLogLoadedAddModel.loadedDate =
        ActivityLogUtils.formatDateValue(this.activityLogLoadedAddModel.addLoadedForm.controls.loadedDate.value);
      this.activityLogLoadedAddModel.loadedTime =
        ActivityLogUtils.formatTimeSelected(this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.value);
      this.setLoadedTimeStampValue();
    }
    const addLoadedRequestInput = {
      loadedTimestamp: this.activityLogLoadedAddModel.findIsLoadedEarlyRequest.loadedTimestamp,
      departureTimestamp: this.activityLogLoadedAddModel.departureTimestamp,
      planNumber: this.activityLogLoadedAddModel.planNumber,
      stopSequenceNumber: this.activityLogLoadedAddModel.stopSequenceNumber,
      receiverStateId: this.activityLogLoadedAddModel.finalDestination,
      overrideWarning: this.activityLogLoadedAddModel.isOverrideWarning,
      pickupEquipmentValue: ActivityLogUtils.getPickupEquipmentValue(this.activityLogLoadedAddModel.trailerOrContainerSelected,
        this.activityLogLoadedAddModel.equipmentPaired),
      dropEquipmentValue: ActivityLogUtils.getDropEquipmentValues(this.activityLogLoadedAddModel.addLoadedForm),
      timeZone: this.activityLogLoadedAddModel.timeZone
    };
    if (!addLoadedRequestInput.dropEquipmentValue &&
      ActivityLogLoadedAddUtils.isEquipmentsEqual(this.activityLogLoadedAddModel.dropEquipment,
        addLoadedRequestInput.pickupEquipmentValue) &&
      this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value.toLowerCase() !== 'drpandhook') {
      addLoadedRequestInput.pickupEquipmentValue = null;
    }
    if (addLoadedRequestInput.dropEquipmentValue && addLoadedRequestInput.dropEquipmentValue.length > 0) {
      if (addLoadedRequestInput.pickupEquipmentValue && addLoadedRequestInput.pickupEquipmentValue.length > 0) {
        return ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedAddModel.addLoadedForm,
          addLoadedRequestInput, this.activityLogLoadedAddModel.resourceOverview);
      } else {
        this.pickupEquipmentError();
        return null;
      }
    } else {
      return this.emptyDropEquipment(addLoadedRequestInput);
    }
  }
  emptyDropEquipment(addLoadedRequestInput) {
    if (this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value.toLowerCase() !== 'drpandhook' &&
      this.activityLogLoadedAddModel.dropEquipment.length === 0 && !addLoadedRequestInput.pickupEquipmentValue) {
      this.pickupEquipmentError();
      return null;
    } else {
      return ActivityLogLoadedAddUtils.createAddLoadedRequest(this.activityLogLoadedAddModel.addLoadedForm,
        addLoadedRequestInput, this.activityLogLoadedAddModel.resourceOverview);
    }
  }
  pickupEquipmentError() {
    this.arrivalDeviationType.emit([{
      errorMessage: `Provide pickup equipment`,
      errorType: this.activityLogLoadedAddModel.equipmentErrorType,
      errorSeverity: 'ERROR'
    }]);
    this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
    this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').markAsTouched();
    this.changeDetector.detectChanges();
  }
  onLoadedDateOrTimeChange(event, isDate: any) {
    event.overlayVisible = false;
    const dateObj = DateUtils.getTimeValue(event);
    if (isDate) {
      this.activityLogLoadedAddModel.loadedDate = ActivityLogUtils.formatDateValue(event);
      ActivityLogUtils.checkLoadedTime(this.activityLogLoadedAddModel, this.toastMessage, 'Loaded');
    } else {
      if (!this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.value) {
        this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.setValue(moment(dateObj.withPm, ['hh:mm A']).toDate());
      }
      this.activityLogLoadedAddModel.loadedTime = dateObj.withoutPm;
      this.activityLogLoadedAddModel.loadedTimeSelected =
        ActivityLogUtils.formatTimeSelected(this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.value);
      ActivityLogUtils.checkLoadedTime(this.activityLogLoadedAddModel, this.toastMessage, 'Loaded');
    }
    if (this.activityLogLoadedAddModel.loadedDate && this.activityLogLoadedAddModel.loadedTime) {
      this.setLoadedTimeStampValue();
      if (this.activityLogLoadedAddModel.activityType === 'loaded') {
        this.checkIsLoadedLate();
      }
    }
  }
  onLoadedDateInputTyped(event) {
    this.activityLogLoadedAddModel.loadedDate =
      ActivityLogUtils.formatDateValue(this.activityLogLoadedAddModel.addLoadedForm.controls.loadedDate.value);
    if (this.activityLogLoadedAddModel.addLoadedForm.controls.loadedDate.value > new Date()) {
      ActivityLogUtils.dateValidation(this.activityLogLoadedAddModel.addLoadedForm, 'loadedDate',
        this.toastMessage, 'Loaded');
    }
    if (this.activityLogLoadedAddModel.loadedDate && this.activityLogLoadedAddModel.loadedTime) {
      ActivityLogUtils.checkLoadedTime(this.activityLogLoadedAddModel, this.toastMessage, 'Loaded');
    }
    this.checkIsLoadedLate();
  }
  onLoadedTimeInputTyped(event) {
    this.activityLogLoadedAddModel.loadedTime =
      ActivityLogUtils.formatTimeValue(this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.value);
  }
  checkIsLoadedLate() {
    if (this.activityLogLoadedAddModel.addLoadedForm.valid) {
      this.toastMessage.clear();
    }
    if (this.activityLogLoadedAddModel.addLoadedForm.controls.loadedDate.valid &&
      this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.valid) {
      this.activityLogLoadedAddService.getLoadedDateTime(this.activityLogLoadedAddModel.findIsLoadedEarlyRequest).
        pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
        }, (error) => {
          ActivityLogUtils.arrivalError(error.error, this.toastMessage);
        });
    }
  }
  setLoadedTimeStampValue() {
    this.activityLogLoadedAddModel.findIsLoadedEarlyRequest.loadedTimestamp = DateUtils.dateTimeZoneFormat(this.
      activityLogLoadedAddModel.loadedDate, this.activityLogLoadedAddModel.loadedTime, this.activityLogLoadedAddModel.timeZone);
  }
  onLoadedDateOrTimeClear(isDate: boolean, loadedTime = null) {
    if (isDate) {
      this.activityLogLoadedAddModel.addLoadedForm.controls.loadedDate.reset();
    } else {
      this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.reset();
      loadedTime.overlayVisible = false;
    }
  }
  onDepartureDateOrTimeChange(event, isDate: boolean) {
    event.overlayVisible = false;
    if (isDate) {
      this.activityLogLoadedAddModel.departureDate = ActivityLogUtils.formatDateValue(event);
    } else {
      if (!this.activityLogLoadedAddModel.addLoadedForm.controls.departureTime.value) {
        this.activityLogLoadedAddModel.addLoadedForm.controls.departureTime.setValue(DateUtils.getTimeValue(event).withPm);
      }
      this.activityLogLoadedAddModel.departureTime = DateUtils.getTimeValue(event).withoutPm;
    }
    if (this.activityLogLoadedAddModel.departureDate && this.activityLogLoadedAddModel.departureTime) {
      this.activityLogLoadedAddModel.departureTimestamp = DateUtils.dateTimeZoneFormat(this.
        activityLogLoadedAddModel.departureDate, this.activityLogLoadedAddModel.departureTime, this.activityLogLoadedAddModel.timeZone);
    }
  }
  onDepartureTimeInputTyped(event) {
    this.activityLogLoadedAddModel.departureTime =
      ActivityLogUtils.formatTimeValue(this.activityLogLoadedAddModel.addLoadedForm.controls.loadedTime.value);
  }
  onDepartureDateInputTyped(event) {
    this.activityLogLoadedAddModel.departureDate =
      ActivityLogUtils.formatDateValue(this.activityLogLoadedAddModel.addLoadedForm.controls.departureDate.value);
  }
  onDepartureDateOrTimeClear(isDate: boolean, departureTime = null) {
    if (isDate) {
      this.activityLogLoadedAddModel.addLoadedForm.controls.departureDate.reset();
    } else {
      this.activityLogLoadedAddModel.addLoadedForm.controls.departureTime.reset();
      departureTime.overlayVisible = false;
    }
    this.activityLogLoadedAddModel.departureTimestamp = '';
  }
  onTextAreaType() {
    this.activityLogLoadedAddModel.commentsCount = this.activityLogLoadedAddModel.addLoadedForm.controls.comments.value.length;
  }
  onLoadedBySelect(event: ListItem) {
    const driver = {
      value: 'DrvrLoad',
      label: 'Driver Loads Freight'
    };
    const lumper = {
      value: 'LumprLdFrg',
      label: 'Lumper Loads Freight'
    };
    const driverLumperValue = ['driver loads freight', 'lumper loads freight'];
    ActivityLogUtils.setStopServiceSelectedValue(event, driver, lumper, driverLumperValue, this.activityLogLoadedAddModel.addLoadedForm);
  }
  onCountedBySelect(event: ListItem) {
    const countsDriver = {
      label: 'Driver Counts Freight',
      value: 'DrvrCount'
    };
    const countsLumper = {
      label: 'Lumper Counts Freight',
      value: 'LumpCntFrg'
    };
    const driverLumperValue = ['driver counts freight', 'lumper counts freight'];
    ActivityLogUtils.setStopServiceSelectedValue(event, countsDriver, countsLumper, driverLumperValue,
      this.activityLogLoadedAddModel.addLoadedForm);
  }
  ngOnDestroy() {
    this.activityLogLoadedAddModel.canSubscribe = false;
    if (this.activityLogLoadedAddModel.addLoadedForm) {
      this.activityLogLoadedAddModel.addLoadedForm.reset();
    }
  }
  navigateToParent() {
    if (this.router.url && this.router.url.indexOf('/trackingdetails') !== -1) {
      this.router.navigate(['/trackingdetails'], { queryParams: this.localStorageService.getItem('TrackingDetails', 'param') });
    } else {
      this.router.navigate(['/loaddetails', this.activityLogLoadedAddModel.findIsLoadedEarlyRequest.operationalPlanID],
        { queryParams: { index: 2 } });
    }
  }
  showPickupEquipments() {
    this.setEquipmentValues();
    if (this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value &&
      this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value.toLowerCase() === 'drpandhook') {
      this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').reset();
      this.activityLogLoadedAddModel.equipmentPaired = [];
    }
    Object.keys(this.activityLogLoadedAddModel.addLoadedForm.get('dropEquipmentDetails')['controls']).forEach((controlName) => {
      this.activityLogLoadedAddModel.addLoadedForm.get('dropEquipmentDetails')['controls'][controlName].reset();
    });
  }
  setEquipmentValues() {
    if (this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value &&
      this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value.toLowerCase() !== 'drpandhook' &&
      this.activityLogLoadedAddModel.dropEquipment.length > 0) {
      this.activityLogLoadedAddModel.equipmentPaired = this.activityLogLoadedAddModel.dropEquipment;
      this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').setValue(
        {
          label: this.activityLogLoadedAddModel.equipmentPaired[0].equipmentPrefix +
            this.activityLogLoadedAddModel.equipmentPaired[0].equipmentNumber,
          value: this.activityLogLoadedAddModel.equipmentPaired
        });
      this.activityLogLoadedAddModel.trailerOrContainerSelected = this.activityLogLoadedAddModel.equipmentPaired[0];
    }
  }
  getDropEquipment(resourceOverview: ResourceOverview) {
    if (resourceOverview && resourceOverview.equipmentId) {
      this.activityLogService.getEquipmentDetails(resourceOverview.equipmentId)
        .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.length > 1) {
            this.activityLogLoadedAddModel.dropEquipment = ActivityLogUtils.getFormattedEquipment(data.slice(1));
            this.activityLogLoadedAddModel.dropEquipment.forEach((dropequipment, i) => {
              this.activityLogLoadedAddModel.addLoadedForm.controls.dropEquipmentDetails
              ['addControl'](i, new FormControl([[]]));
            });
            this.showPickupEquipments();
          }
          if (this.activityLogLoadedAddModel.isReload) {
            this.activityLogLoadedAddModel.isLoading = false;
            this.getEquipmentInfo();
          }
        }, (error) => {
          this.activityLogLoadedAddModel.dropEquipment = [];
        });
    }
  }
  getEquipmentInfo() {
    if (this.localStorageService.getItem('loadedForm', 'values') && this.activityLogLoadedAddModel.isReload) {
      const loadedFormValue = this.localStorageService.getItem('loadedForm', 'values');
      this.activityLogLoadedAddModel.addLoadedForm.patchValue(loadedFormValue.formDetails);
      this.activityLogLoadedAddModel.trailerOrContainerSelected = loadedFormValue.trailerSelected;
      this.activityLogLoadedAddModel.departureTimestamp = loadedFormValue.departureTime;
    } else {
      this.showPickupEquipments();
    }
    if (this.localStorageService.getItem('pairedEquipment', 'values') && this.activityLogLoadedAddModel.isReload) {
      this.activityLogLoadedAddModel.equipmentPaired = this.localStorageService.getItem('pairedEquipment', 'values');
    }
  }
  clearLocalStoreItem() {
    this.localStorageService.clearItem('loadedForm', 'values');
    this.localStorageService.clearItem('pairedEquipment', 'values');
  }
  getTrailerOrContainerData(trailerOrContainer) {
    if (trailerOrContainer && trailerOrContainer.query) {
      const q = AssetDetailQuery.getContainerOrTrailer(trailerOrContainer.query);
      this.activityLogService.getTrailerOrContainer(q)
        .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.hits && data.hits.hits && data.hits.hits.length > 0) {
            this.activityLogLoadedAddModel.trailerOrContainer =
              ActivityLogUtils.getTrailerOrContainer(data.hits.hits);
          } else {
            this.activityLogLoadedAddModel.trailerOrContainer = [];
            this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
          }
        }, (error) => {
          this.activityLogLoadedAddModel.trailerOrContainer = [];
        });
    }
  }
  onRemoveTrailerOrContainer() {
    this.activityLogLoadedAddModel.chassis = null;
    this.activityLogLoadedAddModel.trailerOrContainerSelected = null;
    this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').reset();
    this.activityLogLoadedAddModel.equipmentPaired = [];
  }
  onTrailerOrContainerSelected(selectedTrailerOrContainer) {
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId &&
      this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value.toLowerCase() === 'drpandhook') {
      if (!find(this.activityLogLoadedAddModel.dropEquipment,
        ['equipmentNumber', selectedTrailerOrContainer.value.equipmentNumber])) {
        this.activityLogLoadedAddModel.trailerOrContainerSelected = selectedTrailerOrContainer;
        this.getStackedEquipment(selectedTrailerOrContainer);
      } else {
        this.activityLogLoadedAddModel.trailerOrContainerSelected = null;
        this.arrivalDeviationType.emit([{
          errorMessage: `Select valid Equipment Details`,
          errorType: this.activityLogLoadedAddModel.equipmentErrorType,
          errorSeverity: 'ERROR'
        }]);
        this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
        this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').markAsTouched();
        this.changeDetector.detectChanges();
      }
    } else if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId &&
      this.activityLogLoadedAddModel.addLoadedForm.value.loadedType.value.toLowerCase() === 'live') {
      this.activityLogLoadedAddModel.trailerOrContainerSelected = selectedTrailerOrContainer;
      this.getStackedEquipment(selectedTrailerOrContainer);
    } else {
      this.activityLogLoadedAddModel.trailerOrContainerSelected = null;
    }
  }
  getStackedEquipment(selectedTrailerOrContainer) {
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId) {
      this.activityLogLoadedAddModel.isLoading = true;
      this.activityLogService.getEquipmentDetails(selectedTrailerOrContainer.value.equipmentId)
        .pipe(takeWhile(() => this.activityLogLoadedAddModel.canSubscribe),
          finalize(() => {
            this.activityLogLoadedAddModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: EquipmentGroupItem[]) => {
          if (data && data.length > 0) {
            this.onSelectingEquipmentDetails(data, selectedTrailerOrContainer.value.equipmentId);
            this.equipmentList.emit(data);
          }
        }, (error) => {
          this.activityLogLoadedAddModel.equipmentGroupValue = null;
          this.activityLogLoadedAddModel.status = [];
        });
    }
  }
  onSelectingEquipmentDetails(response, equipmentId) {
    if (response.length > 1) {
      this.activityLogLoadedAddModel.showEquipmentGroup = true;
      this.activityLogLoadedAddModel.trailingEquipmentGroup = response;
      const selectedEquipmentDetails = this.frameStackedEquipment(equipmentId);
      this.activityLogLoadedAddModel.status = [{ label: 'Add this group to selected Equipment', value: 'Active' },
      {
        label: `Remove the ${selectedEquipmentDetails.equipmentType.charAt(0)
          + selectedEquipmentDetails.equipmentType.slice(1).toLowerCase()}
            ${selectedEquipmentDetails
            .equipmentPrefix}${selectedEquipmentDetails.equipmentNumber} from the Group and
          Add it to the selected Equipment`, value: 'Inactive'
      }];
    }
  }
  getUpdatedEquipment(event) {
    this.activityLogLoadedAddModel.equipmentPaired = event;
  }
  validateFormField(formControl) {
    return (this.activityLogLoadedAddModel.addLoadedForm.get(formControl).invalid &&
      this.activityLogLoadedAddModel.addLoadedForm.get(formControl).touched);
  }
  titleCase(dropEquipment) {
    let equipmentLabel = '';
    if (dropEquipment && dropEquipment.equipmentType) {
      equipmentLabel = `${dropEquipment.equipmentType.slice(0, 1).toUpperCase()}${dropEquipment.equipmentType.slice(1).toLowerCase()}`;
    }
    return equipmentLabel;
  }
  onCheckAndUnCheck() {
    if (!ActivityLogUtils.droppedOrUndropped(this.activityLogLoadedAddModel.addLoadedForm) &&
      this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').invalid) {
      this.activityLogLoadedAddModel.addLoadedForm.get('trailerOrContainer').reset();
      this.changeDetector.detectChanges();
    }
  }
  getZoneFormat() {
    return ActivityLogUtils.getZoneFormat(this.activityLogLoadedAddModel.timeZone);
  }
  frameStackedEquipment(equipmentId) {
    let selectedEquipmentDetails;
    this.activityLogLoadedAddModel.trailingEquipmentGroup.forEach((equimentItem => {
      if (equimentItem.equipmentId === equipmentId) {
        selectedEquipmentDetails = equimentItem;
        this.activityLogLoadedAddModel.equipmentGroupValue.equipmentNumber = equimentItem.equipmentNumber;
        this.activityLogLoadedAddModel.equipmentGroupValue.equipmentPrefix = equimentItem.equipmentPrefix;
        this.activityLogLoadedAddModel.equipmentGroupValue.equipmentType = equimentItem.equipmentType;
        this.activityLogLoadedAddModel.equipmentGroupValue.equipmentId = equimentItem.equipmentId;
      } else {
        equimentItem.stackedEquipmentList.forEach(stackedItem => {
          if (stackedItem.equipmentId === equipmentId) {
            selectedEquipmentDetails = stackedItem;
            this.activityLogLoadedAddModel.equipmentGroupValue.equipmentNumber = stackedItem.equipmentNumber;
            this.activityLogLoadedAddModel.equipmentGroupValue.equipmentType = stackedItem.equipmentType;
            this.activityLogLoadedAddModel.equipmentGroupValue.equipmentPrefix = stackedItem.equipmentPrefix;
            this.activityLogLoadedAddModel.equipmentGroupValue.equipmentId = stackedItem.equipmentId;
          }
        });
      }
    }));
    return selectedEquipmentDetails;
  }
}
