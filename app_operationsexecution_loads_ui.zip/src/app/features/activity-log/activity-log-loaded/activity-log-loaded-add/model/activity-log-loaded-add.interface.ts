import { Self, Links2, Page, FinalDestination, DropEquipmentDetail, PickUpDetails } from '../../../models/activity-log.interface';

export interface CountedBy {
    _embedded: CountedByEmbedded;
    _links: Links2;
    page: Page;
}
export interface CountedByEmbedded {
    countedByPartyTypes: CountedByPartyType[];
}
export interface CountedByPartyType {
    createTimestamp: string;
    createProgramName: string;
    lastUpdateProgramName: string;
    createUserId: string;
    lastUpdateUserId: string;
    countedByPartyTypeDescription: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: CountedByLinks;
}
export interface CountedByLinks {
    self: Self;
    countedByPartyType: Self;
}
export interface UnitOfWeightEmbedded {
    unitOfWeightMeasurements: UnitOfWeightMeasurement[];
}
export interface UnitOfWeightMeasurement {
    unitOfWeightMeasurementCode: string;
    unitOfWeightMeasurementDescription: string;
    lastUpdateTimestampString: string;
    _links: UnitOfWeightLinks;
}
export interface UnitOfWeightLinks {
    self: Self;
    unitOfWeightMeasurement: Self;
}
export interface UnitOfWeight {
    _embedded: UnitOfWeightEmbedded;
    _links: Links2;
    page: Page;
}
export interface UnitOfVolumeEmbedded {
    unitOfVolumeMeasurements: UnitOfVolumeMeasurement[];
}
export interface UnitOfVolumeMeasurement {
    unitOfVolumeMeasurementCode: string;
    unitOfVolumeMeasurementDescription: string;
    lastUpdateTimestampString: string;
    _links: UnitOfVolumeLinks;
}
export interface UnitOfVolumeLinks {
    self: Self;
    unitOfVolumeMeasurement: Self;
}
export interface UnitOfVolume {
    _embedded: UnitOfVolumeEmbedded;
    _links: Links2;
    page: Page;
}
export interface UnitOfTemperatureEmbedded {
    unitOfTemperatureMeasurements: UnitOfTemperatureMeasurement[];
}
export interface UnitOfTemperatureMeasurement {
    unitOfTemperatureMeasurementCode: string;
    unitOfTemperatureMeasurementDescription: string;
    lastUpdateTimestampString: string;
    _links: UnitOfTemperatureLinks;
}
export interface UnitOfTemperatureLinks {
    self: Self;
    unitOfTemperatureMeasurement: Self;
}
export interface UnitOfTemperature {
    _embedded: UnitOfTemperatureEmbedded;
    _links: Links2;
    page: Page;
}
export interface OperationalPlanStopActivityPartyTypeEmbedded {
    operationalPlanStopActivityPartyTypes: OperationalPlanStopActivityPartyTypeData[];
}
export interface OperationalPlanStopActivityPartyTypeData {
    createTimestamp: string;
    createProgramName: string;
    lastUpdateProgramName: string;
    createUserId: string;
    lastUpdateUserId: string;
    operationalPlanStopActivityPartyTypeDescription: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: OperationalPlanStopActivityPartyTypeLinks;
}
export interface OperationalPlanStopActivityPartyTypeLinks {
    self: Self;
    operationalPlanStopActivityPartyType: Self;
}
export interface OperationalPlanStopActivityPartyType {
    _embedded: OperationalPlanStopActivityPartyTypeEmbedded;
    _links: Links2;
    page: Page;
}
export interface OperationalPlanStopActivityType {
    _embedded: OperationalPlanStopActivityTypeLinksEmbedded;
    _links: Links2;
    page: Page;
}
export interface OperationalPlanStopActivityTypeLinksEmbedded {
    operationalPlanStopActivityTypes: OperationalPlanStopActivityTypeData[];
}
export interface OperationalPlanStopActivityTypeData {
    createTimestamp: string;
    createProgramName: string;
    lastUpdateProgramName: string;
    createUserId: string;
    lastUpdateUserId: string;
    operationalPlanStopActivityTypeDescription: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: OperationalPlanStopActivityTypeLinks;
}
export interface OperationalPlanStopActivityTypeLinks {
    self: Self;
    operationalPlanStopActivityType: Self;
}
export interface IsLoadedEarly {
    loadedTimestamp?: string;
    unloadedTimestamp?: string;
    operationalPlanID: number;
    operationalPlanStopID: number;
    isEdit: boolean;
}
export interface IsLoadedEarlyError {
    timestamp: string;
    status: number;
    error: string;
    exception: string;
    message: string;
    path: string;
}
export interface StopServices {
    _embedded: Embedded;
    _links: StopServiceLinks2;
}
export interface StopServiceLinks2 {
    self: Self;
}

export interface Embedded {
    operationalPlanServiceTypes: OperationalPlanServiceType[];
}
export interface OperationalPlanServiceType {
    operationalPlanServiceTypeCode: string;
    operationalPlanServiceTypeDescription: string;
    operationalPlanServiceCategory: OperationalPlanServiceCategory;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: StopServiceLinks;
}
export interface StopServiceLinks {
    self: Self;
    operationalPlanServiceType: Self;
}
export interface OperationalPlanServiceCategory {
    operationalPlanServiceCategoryDescription: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
}
export interface AddLoadedRequest {
    operationalPlanNumber: string;
    operationalPlanStopSequenceNumber: number;
    resourceDetails: ResourceDetails;
    checkCallSourceTimestamp: number;
    checkCallMessage: string;
    isAutoCheckCall: boolean;
    checkCallSource: string;
    locationDetails: LocationDetails;
    checkCallDetails: CheckCallDetails;
    receiverStateId: number;
    stopServices: string[];
    hazmatIndicator?: boolean;
    isWarningOverride: boolean;
}

export interface CheckCallDetails {
    loadedTimestamp: string;
    loadedBy: string;
    loadedType: string;
    count: number;
    countedBy: string;
    sealNumber: string;
    bolNumber: string;
    poNumbers: string[];
    shipperIdentificationNumber: string;
    unloadedTimestamp?: any;
    unloadedBy?: any;
    unloadedType?: any;
    hubReading?: any;
    pickupEquipmentDetails: any;
    dropEquipmentDetails: DropEquipmentDetail[];
    comments?: any;
    departureTimestamp: number;
    proNumber: string;
    weight: Weight;
    volume: Volume;
    temperature: Temperature;
    equipmentHubReadingValue?: any;
}

export interface Temperature {
    temperature: number;
    unitOfTemperatureMeasurement: string;
}

export interface Volume {
    volume: number;
    unitOfVolumeMeasurement: string;
}

export interface Weight {
    weight: number;
    unitOfWeightMeasurement: string;
}

export interface LocationDetails {
    latitude: number;
    longitude: number;
}

export interface ResourceDetails {
    type: string;
    value: number;
}
export interface AddLoadedResponseValues {
    loadedTimestamp: string;
    departureTimestamp: string;
    planNumber: string;
    stopSequenceNumber: number;
    receiverStateId: FinalDestination;
    overrideWarning: boolean;
    pickupEquipmentValue: PickUpDetails[];
    dropEquipmentValue: PickUpDetails[];
    timeZone: string;
}
