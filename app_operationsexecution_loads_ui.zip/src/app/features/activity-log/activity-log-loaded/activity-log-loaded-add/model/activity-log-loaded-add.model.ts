import { ListItem } from '../../../../../features/model/common.interface';
import { FormGroup } from '@angular/forms';
import { IsLoadedEarly, AddLoadedRequest } from './activity-log-loaded-add.interface';
import {
    ViewActivityLogDetails, FinalDestination, DropEquipmentDetail,
    PickUpDetails, EquipmentGroup, ResourceOverview, TrackingDetailsParam
} from '../../../models/activity-log.interface';
import { OperationalPlanStopDTO } from '../../../../load-details/model/load-details.interface';
import { LoadOverview } from '../../../../load-details/load-details-overview/model/load-overview.interface';
import { RadioButtonValue } from '../../../../../shared/manage-equipment-group/models/manage-equipment-group.interface';

export class ActivityLogLoadedAddModel {
    addLoadedForm: FormGroup;
    canSubscribe: boolean;
    loadedType: ListItem[];
    loadedBy: ListItem[];
    countedBy: ListItem[];
    commentsCount: number;
    isLoadedDropHook: boolean;
    unitOfWeight: ListItem[];
    unitOfVolume: ListItem[];
    unitOfTemperature: ListItem[];
    loadedDate: string;
    loadedTime: string;
    departureDate: string;
    departureTime: string;
    departureTimestamp: string;
    findIsLoadedEarlyRequest: IsLoadedEarly;
    stopServices: ListItem[];
    addLoadedRequest: AddLoadedRequest;
    stopSequenceNumber: number;
    planNumber: string;
    isLoading: boolean;
    isOverrideWarning: boolean;
    loadedDetails: ViewActivityLogDetails;
    hazmat: boolean;
    checkCallId: number;
    isHazmat: boolean;
    dropEquipment: DropEquipmentDetail[];
    finalDestination: FinalDestination;
    activityType: string;
    todayDate: Date;
    stopDetails: OperationalPlanStopDTO;
    loadedTimeSelected: string;
    trailerOrContainer: any;
    chassis: PickUpDetails | any;
    loadOverviewDetails: LoadOverview;
    trailerOrContainerSelected: PickUpDetails;
    isLoadedCheckCallDetails: boolean;
    trailingEquipmentGroup: any;
    status: RadioButtonValue[];
    showEquipmentGroup: boolean;
    equipmentGroupValue: EquipmentGroup;
    selectedStatus: string;
    equipmentPaired: any;
    fieldErrorList: Array<string>;
    loadedErrorTaskTypeName: any;
    hasFinalDestinationError: boolean;
    fromCheckCallSource: string;
    onSelectTrailerOrContainer: boolean;
    timeZone: string;
    alphaNumericPattern: RegExp;
    inputNumberPattern: RegExp;
    checkCallNavigation: boolean;
    resourceOverview: ResourceOverview;
    isTracking: boolean;
    editFromTracking: boolean;
    trackingDetailsParam: TrackingDetailsParam;
    equipmentErrorType: string;
    checkCallFinalDestination: string;
    isReload: boolean;
    isTelematicsPickup: boolean;
    hasChassisEquip: boolean;
    chassisEquip: string;

    constructor() {
        this.canSubscribe = true;
        this.commentsCount = 0;
        this.isLoadedDropHook = false;
        this.loadedBy = [];
        this.loadedType = [];
        this.countedBy = [];
        this.unitOfWeight = [];
        this.unitOfVolume = [];
        this.unitOfTemperature = [];
        this.equipmentErrorType = 'Equipment Validation';
        this.findIsLoadedEarlyRequest = {
            loadedTimestamp: '',
            operationalPlanID: null,
            operationalPlanStopID: null,
            isEdit: false
        };
        this.inputNumberPattern = /^[0-9]*$/;
        this.alphaNumericPattern = /^[a-zA-Z0-9 ]*$/;
        this.isLoading = false;
        this.isOverrideWarning = false;
        this.hazmat = false;
        this.dropEquipment = [];
        this.finalDestination = null;
        this.activityType = '';
        this.todayDate = new Date();
        this.trailerOrContainer = [];
        this.chassis = null;
        this.trailerOrContainerSelected = null;
        this.equipmentGroupValue = {
            equipmentNumber: '',
            equipmentType: '',
            equipmentId: 0
        };
        this.selectedStatus = 'Active';
        this.fieldErrorList = [];
        this.loadedErrorTaskTypeName = {
            weight: 'loaded call - weight is greater than the specified loaded weight',
            finalDest: 'loaded call - final destination state check',
            stopServices: 'loaded call - stop service missing',
            loadedTime: 'loaded call - loaded time is outside the appointment window',
            loadedBy: 'loaded call - missing mandatory attribute',
            BOLPRONo: 'loaded call - reference number mismatch',
            equipmentNumber: 'loaded call - trailing equipment number mismatch',
            equipmentType: 'loaded call - equipment type mismatch',
            equipmentLength: 'loaded call - equipment length mismatch',
            trailingEquipNonOpr: 'loaded call - trailing equipment is non operational',
            trailingEquipNonAvailable: 'loaded call - trailing equipment is not available',
            trailingEquipLiveLoad: 'loaded call - tractor is not paired with trailing equipment',
            trailingEquipinWrongLocation: 'loaded call - trailing equipment is in the wrong location'
        };
        this.fromCheckCallSource = 'Telematics';
        this.onSelectTrailerOrContainer = false;
        this.timeZone = '';
        this.resourceOverview = null;
    }
}
