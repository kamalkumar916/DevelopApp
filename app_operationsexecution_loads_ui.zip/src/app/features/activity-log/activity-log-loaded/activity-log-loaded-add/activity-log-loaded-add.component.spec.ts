import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from 'ng-bullet';
import { ReactiveFormsModule } from '@angular/forms';

import { TooltipModule } from 'primeng/tooltip';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CheckboxModule } from 'primeng/checkbox';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DropdownModule } from 'primeng/dropdown';
import { KeyFilterModule } from 'primeng/keyfilter';

import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { ActivityLogLoadedAddComponent } from './activity-log-loaded-add.component';
import { ActivityLogLoadedAddService } from './services/activity-log-loaded-add.service';
import { ActivityLogService } from '../../services/activity-log.service';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { GlobalPopupsModule } from '../../../../shared/global-popups/global-popups.module';
import { EquipmentGroupPopupModule } from '../../../../shared/equipment-group-popup/equipment-group-popup.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { ActivityLogUtils } from '../../services/activity-log.utils';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { Router } from '@angular/router';

const finalDestination = {
  stateID: 0,
  stateCode: '',
  stateName: '',
};
const loadedTypeValue = [{
  label: 'Drop And Hook',
  value: 'DrpAndHook'
},
{
  label: 'Live',
  value: 'Live'
},
];
const countedByValue = [{
  label: 'Driver',
  value: 'Driver'
},
{
  label: 'Lumper',
  value: 'Lumper'
},
{
  label: 'Receiver',
  value: 'Receiver'
}, {
  label: 'Shipper',
  value: 'Shipper'
}];
const countedByData = {
  _embedded: {
    countedByPartyTypes: [
      {
        createTimestamp: '2019-09-28T00:25:29.5311613',
        createProgramName: 'SSIS',
        lastUpdateProgramName: 'SSIS',
        createUserId: 'PIDNEXT',
        lastUpdateUserId: 'PIDNEXT',
        countedByPartyTypeCode: 'Driver',
        countedByPartyTypeDescription: 'Driver',
        effectiveTimestamp: '2018-01-01T00:00:00Z',
        expirationTimestamp: '2199-12-31T23:59:59Z',
        lastUpdateTimestampString: '2019-09-28T00:25:29.5311613',
      },
      {
        createTimestamp: '2019-09-28T00:25:29.5467857',
        createProgramName: 'SSIS',
        lastUpdateProgramName: 'SSIS',
        createUserId: 'PIDNEXT',
        lastUpdateUserId: 'PIDNEXT',
        countedByPartyTypeCode: 'Lumper',
        countedByPartyTypeDescription: 'Lumper',
        effectiveTimestamp: '2018-01-01T00:00:00Z',
        expirationTimestamp: '2199-12-31T23:59:59Z',
        lastUpdateTimestampString: '2019-09-28T00:25:29.5467857',
      },
      {
        createTimestamp: '2019-09-28T00:25:29.5467857',
        createProgramName: 'SSIS',
        lastUpdateProgramName: 'SSIS',
        createUserId: 'PIDNEXT',
        lastUpdateUserId: 'PIDNEXT',
        countedByPartyTypeCode: 'Receiver',
        countedByPartyTypeDescription: 'Receiver',
        effectiveTimestamp: '2018-01-01T00:00:00Z',
        expirationTimestamp: '2199-12-31T23:59:59Z',
        lastUpdateTimestampString: '2019-09-28T00:25:29.5467857',
      },
      {
        createTimestamp: '2019-09-28T00:25:29.5467857',
        createProgramName: 'SSIS',
        lastUpdateProgramName: 'SSIS',
        createUserId: 'PIDNEXT',
        lastUpdateUserId: 'PIDNEXT',
        countedByPartyTypeCode: 'Shipper',
        countedByPartyTypeDescription: 'Shipper',
        effectiveTimestamp: '2018-01-01T00:00:00Z',
        expirationTimestamp: '2199-12-31T23:59:59Z',
        lastUpdateTimestampString: '2019-09-28T00:25:29.5467857',
      }
    ]
  }
};
const equipmentList = [
  {
    equipmentAssociationId: null,
    equipmentId: 191693,
    equipmentAssociationStackingId: null,
    equipmentNumber: '351810',
    equipmentPrefix: '',
    stack: null,
    isOldStack: null,
    sequenceNumber: null,
    equipmentCategory: 'TRACTOR',
    businessUnit: 'DCS',
    operationalGroupCode: 'DCS CUOR24',
    operationalGroupCodeType: 'Fleet',
    operationalGroupDescription: 'CHEP USA -INDIANAPOLIS',
    equipmentType: 'DAY CAB',
    equipmentTypeDesc: 'DayCab',
    equipmentStatus: 'Dispatched',
    trailingEquipmentStatus: '',
    length: '0 ft',
    width: '0 ft 0 in',
    height: '0 ft 0 in',
    lengthValue: 0,
    widthValue: 0,
    heightValue: 0,
    equipmentMaintenanceStatus: 'OPERATIONAL',
    equipmentMissing: null,
    equipmentAssociationGroupId: null,
    oldEquipmentAssociationGroupId: null,
    removeEquipment: null,
    isRemoveGroup: null,
    isUnstackRequired: null,
    isLegacyOnly: null,
    locationDetails: {
      equipmentId: '191693',
      locationId: null,
      marketingAreaCode: 'Kansas Area',
      locationCode: null,
      locationName: null,
      addressLine1: null,
      addressLine2: null,
      state: 'KS',
      city: 'Junction City',
      zipcode: '66441',
      country: 'USA',
      latitude: '40.719044',
      longitude: '-86.4308389',
      description: '55.1m N of Indianapolis, IN and 2.1m SW of Logansport, IN On State Rd 25',
      lastUpdatedCurrentLocation: null,
      lastUpdatedGpsLocation: '07/02/2019 05:26 PM GMT',
      timezone: 'America/Chicago',
      stateName: 'Kansas',
      cityId: '14499',
      countryCode: 'USA',
      gpsCurrentLocation: 'DUNKIRK,CA, IN',
      gpsCountryName: null,
      gpsCityName: 'DUNKIRK,CA',
      gpsStateName: 'IN',
      gpsStateCode: 'IN'
    },
    stackedEquipmentList: [],
    skipValidation: null,
    userId: null,
    oldTruckId: null,
    links: []
  },
  {
    equipmentAssociationId: null,
    equipmentId: 343349,
    equipmentAssociationStackingId: null,
    equipmentNumber: '094142',
    equipmentPrefix: 'JBHZ',
    stack: null,
    isOldStack: null,
    sequenceNumber: null,
    equipmentCategory: 'TRAILER',
    businessUnit: null,
    operationalGroupCode: null,
    operationalGroupCodeType: null,
    operationalGroupDescription: null,
    equipmentType: 'DRY VAN',
    equipmentTypeDesc: 'Dry Van',
    equipmentStatus: 'Available',
    trailingEquipmentStatus: 'Empty',
    length: '57 ft',
    width: '8 ft 6 in',
    height: '13 ft 6 in',
    lengthValue: 57,
    widthValue: 102,
    heightValue: 162,
    equipmentMaintenanceStatus: 'OPERATIONAL',
    equipmentMissing: null,
    equipmentAssociationGroupId: null,
    oldEquipmentAssociationGroupId: null,
    removeEquipment: null,
    isRemoveGroup: null,
    isUnstackRequired: null,
    isLegacyOnly: null,
    locationDetails: {
      equipmentId: '343349',
      locationId: 279648,
      marketingAreaCode: null,
      locationCode: 'HY',
      locationName: 'J B Hunt/Houston Yard',
      addressLine1: '350 Gellhorn Dr',
      addressLine2: '',
      state: 'TX',
      city: 'Houston',
      zipcode: '770136100',
      country: 'USA',
      latitude: null,
      longitude: null,
      description: null,
      lastUpdatedCurrentLocation: null,
      lastUpdatedGpsLocation: null,
      timezone: 'America/Chicago',
      stateName: 'TX',
      cityId: null,
      countryCode: 'USA',
      gpsCurrentLocation: null,
      gpsCountryName: null,
      gpsCityName: null,
      gpsStateName: null,
      gpsStateCode: null
    },
    stackedEquipmentList: [],
    skipValidation: null,
    userId: null,
    oldTruckId: null,
    links: []
  }
];
const numberPrefixTypeDTO = {
  prefix: '',
  number: '',
  typeRequired: ''
};
const trailer = {
  prefix: '',
  number: '',
  typeRequired: false,
  length: 0,
  isLengthRequired: false,
  isPreLoaded: false,
  category: '',
  type: ''
};
const loadInfo = {
  operationalPlanId: 0,
  operationalPlanNumber: '',
  operationalPlanStopSequenceNumber: 0,
  operationalPlanType: {
    operationalPlanTypeCode: '',
    operationalPlanTypeDescription: ''
  },
  operationalPlanSubtype: {
    operationalPlanSubtypeCode: '',
    operationalPlanSubtypeDescription: ''
  },
  operationalPlanStatus: {
    operationalPlanStatusCode: '',
    operationalPlanStatusDescription: ''
  },
  operationalPlanServiceOfferingCode: '',
  operationalPlanTransitModeCode: '',
  operationalPlanFinanceBusinessUnitCode: '',
  desirabilityIndexNumber: 0,
  resource: '',
  truck: '',
  requiredEquipment: '',
  trailer: '',
  container: '',
  chassis: '',
  classifications: [],
  loadedMilesWithUnit: '',
  loadedMiles: '',
  emptyMiles: '',
  estimatedTotalMiles: '',
  items: '',
  totalWeight: '',
  requestedService: [],
  estimatedTimeOfCompletion: '',
  routeSequenceNumber: '',
  totalRouteSequenceNumber: '',
  routePlanId: '',
  routeId: '',
  payRoute: [],
  utilization: null,
  totalPointsQuantity: '',
  networkOperationalPlanIndicator: '',
  externalOperationalPlanBoardIndicator: '',
  bulkProcessIndicator: '',
  operationalGroupCode: '',
  customerRate: [],
  tripPlanTransitValue: '',
  operationalPlanStopDTOs: null,
  billTo: [],
  operationalPlanOwnershipDTOs: [],
  equipmentDetails: {
    isPreLoaded: false,
    truck: numberPrefixTypeDTO,
    chassis: numberPrefixTypeDTO,
    container: numberPrefixTypeDTO,
    trailer: trailer,
    currentTrailer: trailer,
    driverId: 0,
    equipmentId: 0,
    alphaCode: '',
    firstName: '',
    lastName: '',
    middleName: '',
    resourceName: '',
    tanker: numberPrefixTypeDTO,
    hopper: numberPrefixTypeDTO
  },
  operationalPlanRouteGuideStatus: {
    operationalPlanRouteGuideStatusCode: '',
    operationalPlanRouteGuideStatusDescription: ''
  },
  servicePriorityCode: '',
  committedFreightIndicator: '',
  shipmentId: [],
  payRouteLists: [],
  jbhuntFailureCount: 0,
  operationalPlanOrderIds: {}
};
const loadedtype = {
  _embedded: {
    operationalPlanStopActivityTypes: [
      {
        operationalPlanStopActivityTypeCode: 'DrpAndHook',
        operationalPlanStopActivityTypeDescription: 'Drop And Hook',
      },
      {
        operationalPlanStopActivityTypeCode: 'Live',
        operationalPlanStopActivityTypeDescription: 'Live',
      }
    ]
  }
};
const loadedBy = {
  _embedded: {
    operationalPlanStopActivityPartyTypes: [{
      operationalPlanStopActivityPartyTypeCode: 'Driver',
      operationalPlanStopActivityPartyTypeDescription: 'Driver',
    }, {
      operationalPlanStopActivityPartyTypeCode: 'Lumper',
      operationalPlanStopActivityPartyTypeDescription: 'Lumper'
    }]
  }
};
const loadedByValue = [{
  label: 'Driver',
  value: 'Driver'
},
{
  label: 'Lumper',
  value: 'Lumper'
},
];
const weight = {
  _embedded: {
    unitOfWeightMeasurements: [
      {
        unitOfWeightMeasurementCode: 'Grams',
        unitOfWeightMeasurementDescription: 'Grams'
      },
      {
        unitOfWeightMeasurementCode: 'Ounces',
        unitOfWeightMeasurementDescription: 'Ounces'
      },
      {
        unitOfWeightMeasurementCode: 'Tons',
        unitOfWeightMeasurementDescription: 'Tons'
      }
    ]
  }
};
const weightValue = [{
  label: 'Grams',
  value: 'Grams'
},
{
  label: 'Tons',
  value: 'Tons'
},
];
const volume = {
  _embedded: {
    unitOfVolumeMeasurements: [ {
      unitOfVolumeMeasurementCode: 'Liters',
      unitOfVolumeMeasurementDescription: 'Liters'
    },
    {
      unitOfVolumeMeasurementCode: 'Pints',
      unitOfVolumeMeasurementDescription: 'Pints'
    }
  ]
}
};
const volumeValue = [{
  label: 'Liters',
  value: 'Liters'
},
{
  label: 'Pints',
  value: 'Pints'
},
];
const temperature = {
  _embedded : {
    unitOfTemperatureMeasurements : [ {
      unitOfTemperatureMeasurementCode : 'Celsius',
      unitOfTemperatureMeasurementDescription : 'Celsius Temperature'
    }, {
      unitOfTemperatureMeasurementCode : 'Fahrenheit',
      unitOfTemperatureMeasurementDescription : 'Fahrenheit Temperature'
    } ]
  }
};
const temperatureValue = [{
  label: 'Celsius',
  value: 'Celsius Temperature'
},
{
  label: 'Fahrenheit',
  value: 'Fahrenheit Temperature'
},
];
const stopServiceData = {
  _embedded: {
    operationalPlanServiceTypes: [
      {
        operationalPlanServiceTypeDescription: 'Chassis Balance',
        operationalPlanServiceTypeCode: 'ChassBalnc',
        operationalPlanServiceCategory: {
          operationalPlanServiceCategoryDescription: 'Stop Level Service'
        }
      },
      {
        operationalPlanServiceTypeDescription: 'Crosstown',
        operationalPlanServiceTypeCode: 'Crosstown',
        operationalPlanServiceCategory: {
          operationalPlanServiceCategoryDescription: 'Stop Level Service'
        }
      }]
    }
  };
  const stopServiceValue = [{
    label: 'Chassis Balance',
    value: 'ChassBalnc'
  },
  {
    label: 'Crosstown',
    value: 'Crosstown'
  },
  ];
class MockActivityLogService {
  constructor() { }
  getFinalDestination(operationalPlanID) {
    return of(finalDestination);
  }
}
describe('ActivityLogLoadedAddComponent', () => {
  let component: ActivityLogLoadedAddComponent;
  let fixture: ComponentFixture<ActivityLogLoadedAddComponent>;
  let activityLogService: ActivityLogService;
  let activityLogLoadedAddService: ActivityLogLoadedAddService;
  const arrivalDeviationRequest = {
    operationalPlanID: 123,
    operationalPlanStopSequenceNumber: 1,
    operationalPlanStopID: 1,
    arrivalTimestamp: '',
    operationalPlanNumber: '',
    truck: '',
    destinationHeader: ''
  };
  const stopInfo = {
    operationalPlanStopId: 1,
    operationalPlanStopSequenceNumber: 1,
    operationalPlanStopReason: {
      operationalPlanStopReasonCode: '',
      operationalPlanStopReasonDescription: ''
    },
    operationalPlanStopStatus: {
      operationalPlanStopStatusCode: '',
      operationalPlanStopStatusDescription: ''
    },
    locationDetailsDTO: {
      locationId: 1,
      locationName: '',
      locationCode: '',
      address: {
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipcode: '',
        country: ''
      },
      locationSubTypes: [{ code: '', description: '' }],
      timezone: 'America/Chicago'
    },
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, HttpClientTestingModule, JbhLoaderModule, CalendarModule,
        CheckboxModule, AutoCompleteModule, InputSwitchModule, DropdownModule, ReactiveFormsModule,
        TooltipModule, RouterTestingModule, PipesModule, GlobalPopupsModule, DirectivesModule, EquipmentGroupPopupModule,
        KeyFilterModule],
      providers: [UserService, AppConfigService, LocalStorageService, MessageService,
        { provide: ActivityLogService, useClass: MockActivityLogService }],
      declarations: [ActivityLogLoadedAddComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogLoadedAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.earlyLoadedRequest = arrivalDeviationRequest;
    component.stopInformation = stopInfo;
    component.reload = true;
    component.overrideAllWarning = true;
    expect(component).toBeTruthy();
  });

  it('ActivityLogLoadedAddComponent pickupEquipmentError have been called', () => {
    component.pickupEquipmentError();
    expect(component.activityLogLoadedAddModel.addLoadedForm.controls['trailerOrContainer'].touched).toBeTruthy();
  });

  it('ActivityLogLoadedAddComponent trailerMandatory have been called', () => {
    spyOn(ActivityLogUtils, 'resourceFieldError');
    component.trailerMandatory();
    expect(ActivityLogUtils.resourceFieldError).toHaveBeenCalled();
  });

  it('ActivityLogLoadedAddComponent showPickupEquipments have been called', () => {
    spyOn(component, 'setEquipmentValues');
    component.showPickupEquipments();
    expect(component.setEquipmentValues).toHaveBeenCalled();
  });

  it('ActivityLogLoadedAddComponent getEquipmentInfo else have been called', () => {
    spyOn(component, 'showPickupEquipments');
    component.activityLogLoadedAddModel.isReload = false;
    component.getEquipmentInfo();
    expect(component.showPickupEquipments).toHaveBeenCalled();
  });

  it('ActivityLogLoadedAddComponent saveForm have been called', () => {
    spyOn(component, 'checkTrailerContainerValid');
    component.saveForm();
    expect(component.checkTrailerContainerValid).toHaveBeenCalled();
  });

  it('ActivityLogLoadedAddComponent onRemoveTrailerOrContainer have been called', () => {
    component.onRemoveTrailerOrContainer();
    expect(component.activityLogLoadedAddModel.equipmentPaired.length).toBe(0);
  });

  it('ActivityLogLoadedAddComponent getUpdatedEquipment have been called', () => {
    const obj = { event: '' };
    component.getUpdatedEquipment(obj);
    expect(component.activityLogLoadedAddModel.equipmentPaired).toEqual(obj);
  });

  it('ActivityLogLoadedAddComponent titleCase have been called', () => {
    const rtnval = component.titleCase({ equipmentType: 'truck' });
    expect(rtnval).toEqual('Truck');
  });

  it('ActivityLogLoadedAddComponent getStringifyValue have been called', () => {
    const obj = { value: '' };
    const rtnvalue = component.getStringifyValue(obj);
    expect(rtnvalue).toEqual(JSON.stringify(obj));
  });

  it('ActivityLogLoadedAddComponent checkTrailerContainerValid have been called', () => {
    spyOn(ActivityLogUtils, 'checkLoadedFormValidity');
    component.checkTrailerContainerValid();
    expect(ActivityLogUtils.checkLoadedFormValidity).toHaveBeenCalled();
  });

  it('ActivityLogLoadedAddComponent droppedOrUndroppedLength have been called', () => {
    const rtnval = component.droppedOrUndroppedLength();
    expect(rtnval).toEqual(0);
  });

  it('ActivityLogLoadedAddComponent saveLoadedActivity have been called', () => {
    spyOn(ActivityLogUtils, 'resourceFieldError');
    component.saveLoadedActivity({ resourceDetails: { value: '' } });
    expect(ActivityLogUtils.resourceFieldError).toHaveBeenCalled();
  });

  it('ActivityLogLoadedAddComponent handleError have been called', () => {
    spyOn(ActivityLogUtils, 'handleErrorAndNull').and.returnValue('abc');
    spyOn(ActivityLogUtils, 'checkRuleValidationError');
    component.handleError({ error: { errors: '' } });
    expect(component.activityLogLoadedAddModel.isLoading).toBeFalsy();
  });

  it('ActivityLogLoadedAddComponent onLoadedDateInputTyped have been called', () => {
    spyOn(ActivityLogUtils, 'formatDateValue').and.returnValue('a');
    spyOn(ActivityLogUtils, 'checkLoadedTime');
    spyOn(component, 'checkIsLoadedLate');
    component.activityLogLoadedAddModel.loadedTime = 'b';
    component.onLoadedDateInputTyped({});
    expect(component.checkIsLoadedLate).toHaveBeenCalled();
  });

  it('ActivityLogLoadedAddComponent onLoadedDateOrTimeClear have been called', () => {
    component.onLoadedDateOrTimeClear(true);
    expect(component.activityLogLoadedAddModel.addLoadedForm.controls.loadedDate.value).toBeNull();
  });

  it('ActivityLogLoadedAddComponent onLoadedDateOrTimeClear else case have been called', () => {
    const obj = { overlayVisible: true };
    component.onLoadedDateOrTimeClear(false, obj);
    expect(obj.overlayVisible).toBeFalsy();
  });

  it('ActivityLogLoadedAddComponent onDepartureDateOrTimeClear have been called', () => {
    component.onDepartureDateOrTimeClear(true);
    expect(component.activityLogLoadedAddModel.departureTimestamp).toEqual('');
  });

  it('ActivityLogLoadedAddComponent onDepartureDateOrTimeClear else case have been called', () => {
    const obj = { overlayVisible: true };
    component.onDepartureDateOrTimeClear(false, obj);
    expect(obj.overlayVisible).toBeFalsy();
  });
  it('ActivityLogLoadedAddComponent setFinalDestination have been called', () => {
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getFinalDestination').and.returnValue(of(finalDestination));
    component.activityLogLoadedAddModel.findIsLoadedEarlyRequest.operationalPlanID = 1234;
    component.setFinalDestination();
    expect(component.activityLogLoadedAddModel.finalDestination).toBe(finalDestination);
  });
  it('ActivityLogLoadedAddComponent setFinalDestination error block have been called', () => {
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getFinalDestination').and.returnValue(throwError(null));
    component.activityLogLoadedAddModel.findIsLoadedEarlyRequest.operationalPlanID = 1234;
    component.setFinalDestination();
    expect(component.activityLogLoadedAddModel.finalDestination).toBe(null);
  });
  it('ActivityLogLoadedAddComponent getLoadedTypeData have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getLoadedType').and.returnValue(of(loadedtype));
    spyOn(ActivityLogUtils, 'getFormattedData');
    component.getLoadedTypeData();
    component.activityLogLoadedAddModel.loadedType = loadedTypeValue;
    expect(component.activityLogLoadedAddModel.loadedType).toBe(loadedTypeValue);
  });
  it('ActivityLogLoadedAddComponent getLoadedTypeData error block have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getLoadedType').and.returnValue(throwError(null));
    component.getLoadedTypeData();
    expect(component.activityLogLoadedAddModel.loadedType).toEqual([]);
  });
  it('ActivityLogLoadedAddComponent onTextAreaType have been called', () => {
    component.onTextAreaType();
    expect(component.activityLogLoadedAddModel.commentsCount).toEqual(0);
  });
  it('ActivityLogLoadedAddComponent getCountedByData have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getCountedBy').and.returnValue(of(countedByData));
    spyOn(ActivityLogUtils, 'getFormattedData').and.callFake(() => {
      return countedByValue;
    });
    component.getCountedByData();
    component.activityLogLoadedAddModel.countedBy = countedByValue;
    expect(component.activityLogLoadedAddModel.countedBy).toBe(countedByValue);
  });
  it('ActivityLogLoadedAddComponent getCountedByData error block have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getCountedBy').and.returnValue(throwError(null));
    component.getCountedByData();
    expect(component.activityLogLoadedAddModel.countedBy).toEqual([]);
  });
  it('ActivityLogLoadedAddComponent getUpdatedEquipment have been called', () => {
    component.getUpdatedEquipment({});
    expect(component.activityLogLoadedAddModel.equipmentPaired).toEqual({});
  });
  it('ActivityLogLoadedAddComponent titleCase have been called', () => {
    const dropEquipment = {
      equipmentType: 'DRY VAN'
    };
    const equipmentValue = component.titleCase(dropEquipment);
    expect(equipmentValue).toBeDefined();
  });
  it('ActivityLogLoadedAddComponent onSelectingEquipmentDetails have been called', () => {
    component.onSelectingEquipmentDetails(equipmentList, 191693);
    expect(component.activityLogLoadedAddModel.showEquipmentGroup).toBeTruthy();
  });
  it('ActivityLogLoadedAddComponent clearLocalStoreItem have been called', () => {
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'clearItem');
    component.clearLocalStoreItem();
    expect(localStorageService.clearItem).toHaveBeenCalled();
  });
  it('ActivityLogLoadedAddComponent checkTrailerContainerValid have been called', () => {
    spyOn(component, 'trailerMandatory').and.callThrough();
    component.activityLogLoadedAddModel.dropEquipment = [];
    component.checkTrailerContainerValid();
    expect(component.activityLogLoadedAddModel.dropEquipment.length).toBe(0);
  });
  it('ActivityLogLoadedAddComponent onLoadedBySelect have been called', () => {
    spyOn(ActivityLogUtils, 'setStopServiceSelectedValue').and.callThrough();
    component.onLoadedBySelect(loadedTypeValue[0]);
    expect(ActivityLogUtils.setStopServiceSelectedValue).toHaveBeenCalled();
  });
  it('ActivityLogLoadedAddComponent onCountedBySelect have been called', () => {
    spyOn(ActivityLogUtils, 'setStopServiceSelectedValue').and.callThrough();
    component.onCountedBySelect(countedByValue[0]);
    expect(ActivityLogUtils.setStopServiceSelectedValue).toHaveBeenCalled();
  });
  it('ActivityLogLoadedAddComponent earlyLoadedRequest has been set', () => {
    component.earlyLoadedRequest = arrivalDeviationRequest;
    expect(component.activityLogLoadedAddModel.stopSequenceNumber).toBe(arrivalDeviationRequest.operationalPlanStopSequenceNumber);
  });
  it('ActivityLogLoadedAddComponent navigateToParent have been called', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.navigateToParent();
    expect(router.navigate).toHaveBeenCalled();
  });
  it('ActivityLogLoadedAddComponent showPickupEquipments for dropandhook have been called', () => {
    component.activityLogLoadedAddModel.addLoadedForm.controls['loadedType'].setValue({
      label: 'Drop And Hook',
      value: 'DrpAndHook'
    });
    component.showPickupEquipments();
    expect(component.activityLogLoadedAddModel.equipmentPaired).toEqual([]);
  });
  it('ActivityLogLoadedAddComponent setEquipmentValues have been called', () => {
    component.activityLogLoadedAddModel.addLoadedForm.controls['loadedType'].setValue({
      label: 'Live',
      value: 'Live'
    });
    component.activityLogLoadedAddModel.dropEquipment = [{
      equipmentId: 477628,
      equipmentType: 'DRY VAN',
      equipmentPrefix: '0462',
      equipmentNumber: '00JBHZ',
      equipmentCategory: 'Trailer'
    }];
    component.setEquipmentValues();
    expect(component.activityLogLoadedAddModel.trailerOrContainerSelected).toBeDefined();
  });
  it('ActivityLogLoadedAddComponent getEquipmentInfo have been called', () => {
    component.activityLogLoadedAddModel.isReload = true;
    const trailerSelected = {
      equipmentId: 1,
      equipmentType: '',
      equipmentPrefix: '',
      equipmentNumber: ''
    };
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'getItem').and.callFake(() => {
      return { departureTime: '', trailerSelected: trailerSelected, formDetails: {} };
    });
    component.getEquipmentInfo();
    expect(localStorageService.getItem).toHaveBeenCalled();
  });
  it('ActivityLogLoadedAddComponent stopInformation has been set', () => {
    component.stopInformation = stopInfo;
    expect(component.activityLogLoadedAddModel.timeZone).toBeDefined();
  });
  it('ActivityLogLoadedAddComponent loadDetails has been set', () => {
    component.loadDetails = loadInfo;
    expect(component.activityLogLoadedAddModel.loadOverviewDetails).toBeDefined();
  });
  it('ActivityLogLoadedAddComponent getLoadedByData have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getLoadedBy').and.returnValue(of(loadedBy));
    spyOn(ActivityLogUtils, 'getFormattedData');
    component.getLoadedByData();
    component.activityLogLoadedAddModel.loadedBy = loadedByValue;
    expect(component.activityLogLoadedAddModel.loadedBy).toBe(loadedByValue);
  });
  it('ActivityLogLoadedAddComponent getLoadedByData error block have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getLoadedBy').and.returnValue(throwError(null));
    component.getLoadedByData();
    expect(component.activityLogLoadedAddModel.loadedBy).toEqual([]);
  });
  it('ActivityLogLoadedAddComponent getUnitOfWeightData have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getUnitOfWeight').and.returnValue(of(weight));
    spyOn(ActivityLogUtils, 'getFormattedData');
    component.getUnitOfWeightData();
    component.activityLogLoadedAddModel.unitOfWeight = weightValue;
    expect(component.activityLogLoadedAddModel.unitOfWeight).toBe(weightValue);
  });
  it('ActivityLogLoadedAddComponent getUnitOfWeightData error block have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getUnitOfWeight').and.returnValue(throwError(null));
    component.getUnitOfWeightData();
    expect(component.activityLogLoadedAddModel.unitOfWeight).toEqual([]);
  });
  it('ActivityLogLoadedAddComponent getUnitOfVolumeData have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getUnitOfVolume').and.returnValue(of(volume));
    spyOn(ActivityLogUtils, 'getFormattedData');
    component.getUnitOfVolumeData();
    component.activityLogLoadedAddModel.unitOfVolume = volumeValue;
    expect(component.activityLogLoadedAddModel.unitOfVolume).toBe(volumeValue);
  });
  it('ActivityLogLoadedAddComponent getUnitOfVolumeData error block have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getUnitOfVolume').and.returnValue(throwError(null));
    component.getUnitOfVolumeData();
    expect(component.activityLogLoadedAddModel.unitOfVolume).toEqual([]);
  });
  it('ActivityLogLoadedAddComponent getUnitOfTemperatureData have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getUnitOfTemperature').and.returnValue(of(temperature));
    spyOn(ActivityLogUtils, 'getFormattedData');
    component.getUnitOfTemperatureData();
    component.activityLogLoadedAddModel.unitOfTemperature = temperatureValue;
    expect(component.activityLogLoadedAddModel.unitOfTemperature).toBe(temperatureValue);
  });
  it('ActivityLogLoadedAddComponent getUnitOfTemperatureData error block have been called', () => {
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getUnitOfTemperature').and.returnValue(throwError(null));
    component.getUnitOfTemperatureData();
    expect(component.activityLogLoadedAddModel.unitOfTemperature).toEqual([]);
  });
  it('ActivityLogLoadedAddComponent getStopServicesData have been called', () => {
    const stopservice = {
      query: 's'
    };
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getStopServices').and.returnValue(of(stopServiceData));
    spyOn(ActivityLogUtils, 'getFormattedData');
    component.getStopServicesData(stopservice);
    component.activityLogLoadedAddModel.stopServices = stopServiceValue;
    expect(component.activityLogLoadedAddModel.stopServices).toBe(stopServiceValue);
  });
  it('ActivityLogLoadedAddComponent getStopServicesData error block have been called', () => {
    const stopservice = {
      query: 's'
    };
    activityLogLoadedAddService = TestBed.get(ActivityLogLoadedAddService);
    spyOn(activityLogLoadedAddService, 'getStopServices').and.returnValue(throwError(null));
    component.getStopServicesData(stopservice);
    expect(component.activityLogLoadedAddModel.stopServices).toEqual([]);
  });
});

