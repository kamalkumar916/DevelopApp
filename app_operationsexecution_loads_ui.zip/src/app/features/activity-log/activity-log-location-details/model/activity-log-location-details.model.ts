import { LoadOverview } from '../../../../features/load-details/load-details-overview/model/load-overview.interface';
import { LocationDetails } from '../../../../features/model/location-address.interface';
import { AppointmentDetails } from '../../../../features/model/common.interface';
import { ViewActivityLogDetails, CityDTO } from '../../models/activity-log.interface';

export class ActivityLogLocationDetailsModel {
    loadOverview: LoadOverview;
    stopSequenceNumber: number;
    stopReasonCode: string;
    locationDetailDto: LocationDetails;
    appointmentTime: AppointmentDetails;
    checkCallArrivalDetails: ViewActivityLogDetails;
    lastUpdatedOn: string;
    stopId: number;
    canSubscribe: boolean;
    activityType: string;
    checkCallId: string;
    destinationDescription: string;
    stopSequenceDescription: number;
    cityDetailsDto: CityDTO;
    constructor() {
        this.appointmentTime = {
            appointmentStartTimestamp: '',
            appointmentEndTimestamp: '',
            timeZone: 'America/Chicago'
        };
        this.canSubscribe = true;
        this.checkCallId = '';
        this.activityType = '';
        this.stopSequenceDescription = null;
        this.cityDetailsDto = null;
    }
}
