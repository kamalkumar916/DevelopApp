import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { find } from 'lodash';

import { AppSharedDataService } from '../../../shared/jbh-app-services/app-shared-data.service';
import { AppointmentDateFormatterPipe } from './../../../shared/pipes/appointment-date-formatter.pipe';
import { ActivityLogLocationDetailsModel } from './model/activity-log-location-details.model';
import { StopDetails, ViewActivityLogDetails, OperationalPlanStopDetails } from '../models/activity-log.interface';
import { OperationalPlanStopDTO } from '../../load-details/model/load-details.interface';
import { DateUtils } from '../../../shared/jbh-app-services/date-utils';

@Component({
  selector: 'app-activity-log-location-details',
  templateUrl: './activity-log-location-details.component.html',
  styleUrls: ['./activity-log-location-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogLocationDetailsComponent implements OnInit {

  loadArrivalDetailsModel: ActivityLogLocationDetailsModel;
  isErrorDetailsFocus: any;
  @Input() set data(data) {
    if (data) {
      this.loadArrivalDetailsModel.loadOverview = data;
      this.getStopInformation();
    }
  }
  @Input() set editArrivalDetails(data: ViewActivityLogDetails) {
    if (data) {
      this.loadArrivalDetailsModel.checkCallArrivalDetails = data;
      this.getArrivalDetails();
      this.stopInformation.emit(data.operationalPlanStopDetails);
    }
  }
  @Output() readonly stopSequenceNumber: EventEmitter<StopDetails> = new EventEmitter();
  @Output() readonly stopInformation: EventEmitter<OperationalPlanStopDTO | OperationalPlanStopDetails> = new EventEmitter();

  constructor(private readonly activatedRoute: ActivatedRoute,
    private readonly appSharedDataService: AppSharedDataService) {
    this.loadArrivalDetailsModel = new ActivityLogLocationDetailsModel();
  }
  ngOnInit() {
    this.loadArrivalDetailsModel.activityType = this.activatedRoute.queryParams['_value']['activityType'];
    this.loadArrivalDetailsModel.checkCallId = this.activatedRoute.queryParams['_value']['checkCallId'];
    this.checkErrorWarningDetails();
  }
  checkErrorWarningDetails() {
    this.isErrorDetailsFocus = '';
    this.appSharedDataService.getData().subscribe(data => {
      this.isErrorDetailsFocus = data;
    }, (error) => {
    });
  }
  getStopInformation() {
    let stopDto;
    switch (this.loadArrivalDetailsModel.activityType) {
      case 'arrival': case 'arrivalandloaded': case 'arrivalandunloaded':
        stopDto = find(this.loadArrivalDetailsModel.loadOverview.operationalPlanStopDTOs,
          (item: any) => item.operationalPlanStopStatus.operationalPlanStopStatusCode.toLowerCase() === 'arrived' ||
            item.operationalPlanStopStatus.operationalPlanStopStatusCode.toLowerCase() === 'pending');
        this.stopInformation.emit(stopDto);
        break;
      case 'loaded':
        stopDto = find(this.loadArrivalDetailsModel.loadOverview.operationalPlanStopDTOs,
          (item: any) => item.operationalPlanStopStatus.operationalPlanStopStatusCode.toLowerCase() === 'arrived' &&
            (item.operationalPlanStopReason.operationalPlanStopReasonCode.toLowerCase() === 'pickup' ||
            item.operationalPlanStopReason.operationalPlanStopReasonCode.toLowerCase() === 'pickupequi'));
        this.stopInformation.emit(stopDto);
        break;
      case 'unloaded':
        stopDto = find(this.loadArrivalDetailsModel.loadOverview.operationalPlanStopDTOs,
          (item: any) => item.operationalPlanStopStatus.operationalPlanStopStatusCode.toLowerCase() === 'arrived' &&
            (item.operationalPlanStopReason.operationalPlanStopReasonCode.toLowerCase() === 'delivery' ||
            item.operationalPlanStopReason.operationalPlanStopReasonCode.toLowerCase() === 'dropequi'));
        this.stopInformation.emit(stopDto);
        break;
      default:
        this.stopInformation.emit(null);
        break;
    }
    if (stopDto) {
      this.setStopDetails(stopDto);
    }
    this.setStopSequenceNumber();
  }
  setStopDetails(stopDto) {
    this.loadArrivalDetailsModel.locationDetailDto = stopDto.locationDetailsDTO ? stopDto.locationDetailsDTO : null;
    this.loadArrivalDetailsModel.cityDetailsDto = this.loadArrivalDetailsModel.locationDetailDto ?
      null : stopDto.cityDetailsDTO ? stopDto.cityDetailsDTO : null;
    this.loadArrivalDetailsModel.stopSequenceNumber = stopDto.operationalPlanStopSequenceNumber;
    this.loadArrivalDetailsModel.stopSequenceDescription = this.loadArrivalDetailsModel.loadOverview.operationalPlanStopDTOs.length;
    this.loadArrivalDetailsModel.stopId = stopDto.operationalPlanStopId;
    this.getDestinationDescription();
    this.setStopReasonAndAppoinmentDateTime(stopDto);
  }
  getDestinationDescription() {
    const stopSeqNo = this.loadArrivalDetailsModel.stopSequenceNumber;
    if (stopSeqNo === 1) {
      this.loadArrivalDetailsModel.destinationDescription = 'Origin';
    } else if (stopSeqNo === this.loadArrivalDetailsModel.stopSequenceDescription) {
      this.loadArrivalDetailsModel.destinationDescription = 'Destination';
    } else {
      this.loadArrivalDetailsModel.destinationDescription = '';
    }
  }
  setStopReasonAndAppoinmentDateTime(stopDto) {
    this.loadArrivalDetailsModel.stopReasonCode = stopDto.operationalPlanStopReason &&
      stopDto.operationalPlanStopReason.operationalPlanStopReasonCode ?
      stopDto.operationalPlanStopReason.operationalPlanStopReasonCode : null;
    if (stopDto.operationalPlanStopAppointment && stopDto.operationalPlanStopAppointment.appointmentStartTimestamp &&
      stopDto.operationalPlanStopAppointment.appointmentEndTimestamp) {
      this.loadArrivalDetailsModel.appointmentTime = {
        appointmentStartTimestamp: stopDto.operationalPlanStopAppointment.appointmentStartTimestamp,
        appointmentEndTimestamp: stopDto.operationalPlanStopAppointment.appointmentEndTimestamp,
        timeZone: stopDto.locationDetailsDTO && stopDto.locationDetailsDTO.timezone
          ? stopDto.locationDetailsDTO.timezone : 'America/Chicago'
      };
    }
  }
  setStopSequenceNumber() {
    if (this.loadArrivalDetailsModel.stopSequenceNumber) {
      this.stopSequenceNumber.emit({
        'stopSequenceNumber': this.loadArrivalDetailsModel.stopSequenceNumber,
        'stopId': this.loadArrivalDetailsModel.stopId,
        'destinationHeader': this.loadArrivalDetailsModel.destinationDescription
      });
    }
  }
  getArrivalDetails() {
    const checkCallDetails = this.loadArrivalDetailsModel.checkCallArrivalDetails;
    if (checkCallDetails && checkCallDetails.operationalPlanStopDetails) {
      this.loadArrivalDetailsModel.locationDetailDto = checkCallDetails.operationalPlanStopDetails.locationDetails;
      this.loadArrivalDetailsModel.stopSequenceNumber = checkCallDetails.operationalPlanStopDetails.operationalPlanStopSequenceNumber;
      this.loadArrivalDetailsModel.stopReasonCode = checkCallDetails.operationalPlanStopDetails.operationalPlanStopReasonCode;
      this.loadArrivalDetailsModel.stopSequenceDescription =
        checkCallDetails.operationalPlanStopDetails.stopSequenceDescription === 'Origin' ? 1 :
          checkCallDetails.operationalPlanStopDetails.stopSequenceDescription === 'Destination' ?
            checkCallDetails.operationalPlanStopDetails.operationalPlanStopSequenceNumber : null;
      this.loadArrivalDetailsModel.stopId = checkCallDetails.operationalPlanStopId;
      this.getDestinationDescription();
      this.loadArrivalDetailsModel.appointmentTime = {
        appointmentStartTimestamp: checkCallDetails.operationalPlanStopDetails.appointmentStartTimestamp.toString(),
        appointmentEndTimestamp: checkCallDetails.operationalPlanStopDetails.appointmentEndTimestamp.toString(),
        timeZone: checkCallDetails.operationalPlanStopDetails.locationDetails.address.timeZone ?
          checkCallDetails.operationalPlanStopDetails.locationDetails.address.timeZone : 'America/Chicago'
      };
    }
    if (checkCallDetails.lastUpdatedTimestamp) {
      this.getLastUpdatedTimeStamp(checkCallDetails.lastUpdatedTimestamp);
    }
    if (checkCallDetails.lastUpdatedOn) {
      this.getLastUpdatedTimeStamp(checkCallDetails.lastUpdatedOn);
    }
    this.setStopSequenceNumber();
  }
  formatLastUpdatedTime(departureTime: string): string {
    if (departureTime) {
      return `${new AppointmentDateFormatterPipe().getFormattedDate(departureTime)}
        ${new AppointmentDateFormatterPipe().getFormattedTime(departureTime)} CST`;
    } else {
      return null;
    }
  }
  getLastUpdatedTimeStamp(timestamp: string) {
    this.loadArrivalDetailsModel.lastUpdatedOn = DateUtils.convertOffsetDateByDefaultTimeZone(timestamp, 'MM/DD/YYYY hh:mm A z');
  }
}
