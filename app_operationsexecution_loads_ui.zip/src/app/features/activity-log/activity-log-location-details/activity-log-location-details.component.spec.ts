import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { configureTestSuite } from 'ng-bullet';
import { TooltipModule } from 'primeng/tooltip';

import { DirectivesModule } from './../../../shared/directives/directives.module';
import { AppSharedDataService } from '../../../shared/jbh-app-services/app-shared-data.service';
import { PipesModule } from '../../../shared/pipes/pipes.module';
import { ActivityLogLocationDetailsComponent } from './activity-log-location-details.component';
import { GlobalPopupsModule } from '../../../shared/global-popups/global-popups.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

const numberPrefixTypeDTO = {
  prefix: '',
  number: '',
  typeRequired: ''
};
const trailer = {
  prefix: '',
  number: '',
  typeRequired: false,
  length: 0,
  isLengthRequired: false,
  isPreLoaded: false,
  category: '',
  type: ''
};
const operationalPlanStopDtoValue = [{
  operationalPlanStopId: null,
  operationalPlanStopSequenceNumber: null,
  operationalPlanStopReason: {
    operationalPlanStopReasonCode: '',
    operationalPlanStopReasonDescription: ''
  },
  operationalPlanStopStatus: {
    operationalPlanStopStatusCode: '',
    operationalPlanStopStatusDescription: ''
  },
  locationDetailsDTO: {
    locationId: '',
    locationName: '',
    locationCode: '',
    address: {
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      zipcode: '',
      country: '',
      countryName: '',
      id: null
    },
    person: {
      firstName: '',
      lastName: '',
      contactExtension: '',
      telephoneNumber: '',
      telephoneAreaCode: '',
      primaryEmail: ''
    },
    timezone: ''
  },
  cityDetailsDTO: {
    cityId: null,
    cityName: '',
    stateCode: '',
    countryCode: '',
    timezone: ''
  },
  marketingArea: '',
  operationalPlanStopAppointment: {
    appointmentStartTimestamp: '',
    appointmentEndTimestamp: '',
    viewAppointmentDate: ''
  },
  handlingUnitSummaryDTO: {
    handlingType: '',
    handlingQuantity: null,
    weight: {
      value: null,
      unitOfMeasurementCode: ''
    },
    density: {
      value: null,
      unitOfMeasurementCode: ''
    },
    volume: {
      value: null,
      unitOfMeasurementCode: ''
    },
    length: {
      value: null,
      unitOfMeasurementCode: ''
    },
    itemHandlingUnitWidth: null,
    itemHandlingUnitHeight: null,
    itemDetailDTO: []
  },
  orderIds: [''],
  estimatedTimeofArrival: '',
  timeZone: ''
}];
const loadOverviewDetails = {
  operationalPlanId: 0,
  operationalPlanNumber: '',
  operationalPlanType: {
    operationalPlanTypeCode: '',
    operationalPlanTypeDescription: ''
  },
  operationalPlanSubtype: {
    operationalPlanSubtypeCode: '',
    operationalPlanSubtypeDescription: ''
  },
  operationalPlanStatus: {
    operationalPlanStatusCode: '',
    operationalPlanStatusDescription: ''
  },
  operationalPlanServiceOfferingCode: '',
  operationalPlanTransitModeCode: '',
  operationalPlanFinanceBusinessUnitCode: '',
  desirabilityIndexNumber: 0,
  resource: '',
  truck: '',
  requiredEquipment: '',
  trailer: '',
  container: '',
  chassis: '',
  classifications: [],
  loadedMilesWithUnit: '',
  loadedMiles: '',
  emptyMiles: '',
  estimatedTotalMiles: '',
  items: '',
  totalWeight: '',
  requestedService: [],
  estimatedTimeOfCompletion: '',
  routeSequenceNumber: '',
  totalRouteSequenceNumber: '',
  routePlanId: '',
  routeId: '',
  payRoute: [],
  utilization: null,
  totalPointsQuantity: '',
  networkOperationalPlanIndicator: '',
  externalOperationalPlanBoardIndicator: '',
  bulkProcessIndicator: '',
  operationalGroupCode: '',
  customerRate: [],
  tripPlanTransitValue: '',
  operationalPlanStopDTOs: null,
  billTo: [],
  operationalPlanOwnershipDTOs: [],
  equipmentDetails: {
    isPreLoaded: false,
    truck: numberPrefixTypeDTO,
    chassis: numberPrefixTypeDTO,
    container: numberPrefixTypeDTO,
    trailer: trailer,
    currentTrailer: trailer,
    driverId: 0,
    equipmentId: 0,
    alphaCode: '',
    firstName: '',
    lastName: '',
    middleName: '',
    resourceName: '',
    tanker: numberPrefixTypeDTO,
    hopper: numberPrefixTypeDTO
  },
  operationalPlanRouteGuideStatus: {
    operationalPlanRouteGuideStatusCode: '',
    operationalPlanRouteGuideStatusDescription: ''
  },
  servicePriorityCode: '',
  committedFreightIndicator: '',
  shipmentId: [],
  payRouteLists: [],
  jbhuntFailureCount: 0,
  operationalPlanOrderIds: {}
};
const editArrivalDetails = {
  operationalPlanCheckCallId: null,
  operationalPlanStopId: null,
  operationalPlanId: null,
  arrivalDateTime: '',
  operationalPlanStopDetails: {
    operationalPlanStopSequenceNumber: null,
    operationalPlanStopReasonCode: '',
    operationalPlanStopReasonCodeDescription: '',
    locationDetails: {
      locationId: null,
      locationName: '',
      locationCode: '',
      address: {
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipcode: '',
        country: '',
        countryName: '',
        timeZone: ''
      }
    },
    appointmentStartTimestamp: '',
    appointmentEndTimestamp: '',
    stopSequenceDescription: 'Destination',
    operationalPlanStopId: null
  },
  lastUpdateProgramName: '',
  lastUpdatedUserId: '',
  lastUpdatedOn: '',
  loadedTimestamp: '',
  proNumber: null,
  weight: { weight: null, unitOfWeightMeasurement: '' },
  volume: { volume: null, unitOfVolumeMeasurement: '' },
  temperature: { temperature: null, unitOfTemperatureMeasurement: '' },
  unloadedTimestamp: '',
  count: null,
  countedBy: '',
  sealNumber: '',
  bolNumber: '',
  poNumbers: [],
  shipperIdentificationNumber: '',
  receiverStateId: null,
  receiverStateName: '',
  hazmatIndicator: '',
  comments: '',
  lastUpdatedTimestamp: '',
  pickupEquipmentDetails: [],
  dropEquipmentDetails: [],
  stopServicesTypeCodes: [],
  stopServices: [],
  unitOfWeightMeasurement: '',
  poNumber: '',
  checkCallSource: ''
};

describe('ActivityLogLocationDetailsComponent', () => {
  let component: ActivityLogLocationDetailsComponent;
  let fixture: ComponentFixture<ActivityLogLocationDetailsComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [PipesModule, TooltipModule, RouterTestingModule, GlobalPopupsModule, NoopAnimationsModule, DirectivesModule],
      providers: [AppSharedDataService],
      declarations: [ActivityLogLocationDetailsComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogLocationDetailsComponent);
    component = fixture.componentInstance;
    component.data = loadOverviewDetails;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getStopInformation should call the spy emit with null', () => {
    spyOn(component, 'setStopSequenceNumber');
    spyOn(component.stopInformation, 'emit');
    component.getStopInformation();
    expect(component.stopInformation.emit).toHaveBeenCalledWith(null);
  });

  it('getStopInformation is called with activityType arrival', () => {
    spyOn(component.stopInformation, 'emit');
    spyOn(component, 'setStopDetails');
    spyOn(component, 'setStopSequenceNumber');
    component.loadArrivalDetailsModel.activityType = 'arrival';
    operationalPlanStopDtoValue[0].operationalPlanStopStatus.operationalPlanStopStatusCode = 'pending';
    component.loadArrivalDetailsModel.loadOverview.operationalPlanStopDTOs = operationalPlanStopDtoValue;
    component.getStopInformation();
    expect(component.stopInformation.emit).toHaveBeenCalled();
  });

  it('getStopInformation should call the spy setStopSequenceNumber', () => {
    spyOn(component.stopInformation, 'emit');
    spyOn(component, 'setStopDetails');
    spyOn(component, 'setStopSequenceNumber');
    component.loadArrivalDetailsModel.activityType = 'loaded';
    operationalPlanStopDtoValue[0].operationalPlanStopStatus.operationalPlanStopStatusCode = 'arrived';
    operationalPlanStopDtoValue[0].operationalPlanStopReason.operationalPlanStopReasonCode = 'pickupequi';
    component.loadArrivalDetailsModel.loadOverview.operationalPlanStopDTOs = operationalPlanStopDtoValue;
    component.getStopInformation();
    expect(component.setStopSequenceNumber).toHaveBeenCalled();
  });

  it('getStopInformation should call the spy setStopDetails', () => {
    spyOn(component.stopInformation, 'emit');
    spyOn(component, 'setStopDetails');
    spyOn(component, 'setStopSequenceNumber');
    component.loadArrivalDetailsModel.activityType = 'unloaded';
    operationalPlanStopDtoValue[0].operationalPlanStopStatus.operationalPlanStopStatusCode = 'arrived';
    operationalPlanStopDtoValue[0].operationalPlanStopReason.operationalPlanStopReasonCode = 'dropequi';
    component.getStopInformation();
    expect(component.setStopDetails).toHaveBeenCalled();
  });

  it('getDestinationDescription should set the value of destinationDescription as Origin', () => {
    component.loadArrivalDetailsModel.stopSequenceNumber = 1;
    component.getDestinationDescription();
    expect(component.loadArrivalDetailsModel.destinationDescription).toEqual('Origin');
  });

  it('getDestinationDescription should set the value of destinationDescription as Destination', () => {
    component.loadArrivalDetailsModel.stopSequenceNumber = 2;
    component.loadArrivalDetailsModel.stopSequenceDescription = 2;
    component.getDestinationDescription();
    expect(component.loadArrivalDetailsModel.destinationDescription).toEqual('Destination');
  });

  it('getDestinationDescription should clear the value of destinationDescription', () => {
    component.loadArrivalDetailsModel.stopSequenceNumber = 3;
    component.getDestinationDescription();
    expect(component.loadArrivalDetailsModel.destinationDescription).toEqual('');
  });

  it('setStopDetails', () => {
    spyOn(component, 'getDestinationDescription');
    spyOn(component, 'setStopReasonAndAppoinmentDateTime');
    component.setStopDetails(operationalPlanStopDtoValue[0]);
    expect(component.getDestinationDescription).toHaveBeenCalled();
  });

  it('setStopSequenceNumber should call the spy emit', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.loadArrivalDetailsModel.stopSequenceNumber = 1;
    component.setStopSequenceNumber();
    expect(component.stopSequenceNumber.emit).toHaveBeenCalled();
  });

  it('Input editArrivalDetails value is set', () => {
    spyOn(component.stopInformation, 'emit');
    component.editArrivalDetails = editArrivalDetails;
    expect(component.stopInformation.emit).toHaveBeenCalled();
  });

  it('getArrivalDetails', () => {
    spyOn(component, 'getLastUpdatedTimeStamp');
    editArrivalDetails.operationalPlanStopDetails.stopSequenceDescription = 'Origin';
    editArrivalDetails.operationalPlanStopDetails.locationDetails.address.timeZone = 'test';
    editArrivalDetails.lastUpdatedTimestamp = 'time';
    editArrivalDetails.lastUpdatedOn = 'test';
    component.loadArrivalDetailsModel.checkCallArrivalDetails = editArrivalDetails;
    component.getArrivalDetails();
    expect(component.getLastUpdatedTimeStamp).toHaveBeenCalled();
  });
});
