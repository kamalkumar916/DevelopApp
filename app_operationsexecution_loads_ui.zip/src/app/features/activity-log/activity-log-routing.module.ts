import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivityLogComponent } from './activity-log.component';
import { ActivityLogArrivalViewComponent } from './activity-log-arrival/activity-log-arrival-view/activity-log-arrival-view.component';
import { ActivityLogLoadedViewComponent } from './activity-log-loaded/activity-log-loaded-view/activity-log-loaded-view.component';
import { ActivityLogUnloadedViewComponent } from './activity-log-unloaded/activity-log-unloaded-view/activity-log-unloaded-view.component';

const routes: Routes =
 [{ path: '', component: ActivityLogComponent },
 { path: 'view/arrival', component: ActivityLogArrivalViewComponent },
 { path: 'view/loaded', component: ActivityLogLoadedViewComponent },
 { path: 'view/unloaded', component: ActivityLogUnloadedViewComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ActivityLogRoutingModule { }
