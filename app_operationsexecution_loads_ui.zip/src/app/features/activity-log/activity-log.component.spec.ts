import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { TooltipModule } from 'primeng/tooltip';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { DropdownModule } from 'primeng/dropdown';
import { DialogModule } from 'primeng/dialog';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ChipsModule } from 'primeng/chips';
import { CheckboxModule } from 'primeng/checkbox';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { KeyFilterModule } from 'primeng/keyfilter';

import { JbhLoaderModule } from './../../shared/jbh-loader/jbh-loader.module';
import { UserService } from '../../shared/jbh-esa/index';
import { AppConfigService } from '../../shared/service/app-config.service';
import { LocalStorageService } from '../../shared/jbh-app-services/local-storage.service';
import { ActivityLogComponent } from './activity-log.component';
import { ActivityLogErrorComponent } from './activity-log-error/activity-log-error.component';
import { ActivityLogResourceDetailsComponent } from './activity-log-resource-details/activity-log-resource-details.component';
import { ActivityLogArrivalViewComponent } from './activity-log-arrival/activity-log-arrival-view/activity-log-arrival-view.component';
import { ActivityLogLoadedViewComponent } from './activity-log-loaded/activity-log-loaded-view/activity-log-loaded-view.component';
import { ActivityLogUnloadedViewComponent } from './activity-log-unloaded/activity-log-unloaded-view/activity-log-unloaded-view.component';
import { ActivityLogArrivalEditComponent } from './activity-log-arrival/activity-log-arrival-edit/activity-log-arrival-edit.component';
import { ActivityLogLocationDetailsComponent } from './activity-log-location-details/activity-log-location-details.component';
import { ActivityLogCommentsAddComponent } from './activity-log-comments/activity-log-comments-add/activity-log-comments-add.component';
import { ActivityLogCommentsViewComponent } from './activity-log-comments/activity-log-comments-view/activity-log-comments-view.component';
import { ActivityLogDispatchViewComponent } from './activity-log-dispatch/activity-log-dispatch-view/activity-log-dispatch-view.component';
import { ActivityLogArrivalAddComponent } from './activity-log-arrival/activity-log-arrival-add/activity-log-arrival-add.component';
import { ActivityLogLoadedAddComponent } from './activity-log-loaded/activity-log-loaded-add/activity-log-loaded-add.component';
import { ActivityLogUnloadedAddComponent } from './activity-log-unloaded/activity-log-unloaded-add/activity-log-unloaded-add.component';
import { ActivityLogLoadedEditComponent } from './activity-log-loaded/activity-log-loaded-edit/activity-log-loaded-edit.component';
import {
  ActivityLogResourceInformationComponent
} from './activity-log-arrival/activity-log-resource-information/activity-log-resource-information.component';
import { ActivityLogUnloadedEditComponent } from './activity-log-unloaded/activity-log-unloaded-edit/activity-log-unloaded-edit.component';
import { LoadOverviewModule } from './../../shared/load-overview/load-overview.module';
import { PipesModule } from './../../shared/pipes/pipes.module';
import { LoadContactsModule } from '../../shared/load-contacts/load-contacts.module';
import { GlobalPopupsModule } from './../../shared/global-popups/global-popups.module';
import { AppSharedDataService } from './../../shared/jbh-app-services/app-shared-data.service';
import { AssetCommunicationModule } from './../sidebar/asset-communication/asset-communication.module';
import { EquipmentGroupPopupModule } from '../../shared/equipment-group-popup/equipment-group-popup.module';
import { DirectivesModule } from './../../shared/directives/directives.module';
import { EquipmentUnassignComponent } from '../../shared/manage-equipment-group/equipment-unassign/equipment-unassign.component';
import { ActivityLogService } from './services/activity-log.service';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { Router } from '@angular/router';
import { ErrorUtils } from 'src/app/shared/jbh-app-services/error-utils';

const getLoadOverviewData = {
  items: '',
  operationalGroupCode: '',
  bulkProcessIndicator: 'No',
  chassis: null,
  classifications: [],
  committedFreightIndicator: null,
  container: null,
  desirabilityIndexNumber: 0,
  emptyMiles: null,
  equipmentDetails: null,
  estimatedTimeOfCompletion: null,
  estimatedTotalMiles: '2898 Miles',
  externalOperationalPlanBoardIndicator: 'N',
  jbhuntFailureCount: null,
  loadedMiles: '',
  loadedMilesWithUnit: '2898 Miles',
  networkOperationalPlanIndicator: 'N',
  operationalPlanAdditionalInstructionDTOs: [],
  operationalPlanCommentDTOs: [],
  operationalPlanFinanceBusinessUnitCode: 'DCS',
  operationalPlanId: 456,
  operationalPlanNumber: 'L456',
  operationalPlanResourceAssignmentSequenceNumber: 1,
  operationalPlanRouteGuideStatus: null,
  operationalPlanServiceOfferingCode: 'Dedicated',
  operationalPlanTransitModeCode: 'Truck',
  payRoute: null,
  requestedService: [],
  requiredEquipment: null,
  resource: null,
  routeId: '182',
  routePlanId: '183',
  routeSequenceNumber: '1',
  servicePriorityCode: 'standard',
  splitLoadApplicable: false,
  totalPointsQuantity: '',
  totalRouteSequenceNumber: null,
  totalWeight: '0.00',
  trailer: null,
  tripPlanTransitValue: null,
  truck: null,
  unitOfWeightMeasurementCode: 'lbs',
  billTo: [],
  customerRate: [],
  operationalPlanGroupDTO: {
    operationalGroupTypeCode: 'Fleet',
    operationalPlanGroupCode: 'DC',
    operationalPlanGroupDescription: 'SIMMONS'
  },
  operationalPlanOrderIds: [1],
  operationalPlanOwnershipDTOs: [],
  operationalPlanReferenceNumberDTOs: [],
  operationalPlanStatus: {
    operationalPlanStatusCode: 'Completed',
    operationalPlanStatusDescription: 'Completed'
  },
  operationalPlanStopDTOs: [],
  operationalPlanSubtype: {
    operationalPlanSubtypeCode: 'FTL',
    operationalPlanSubtypeDescription: 'Full Truck Load'
  },
  operationalPlanType: {
    operationalPlanTypeCode: 'Freight',
    operationalPlanTypeDescription: 'Freight'
  },
  payRouteLists: [],
  resourceDetails: {
    alphaCode: null,
    aobrStatus: null,
    aobrStatusDurationHours: null,
    boardCode: null,
    boardName: null,
    certifications: null,
    currentLocation: null,
    driveHours: null,
    driverId: null,
    driverPlannedLoads: null,
    drivingHoursRemainingAtReadyTime: null,
    emptyMiles: null,
    endorsements: null,
    equipmentId: null,
    estimatedTimeOfCompletion: null,
    firstName: null,
    fleetCode: null,
    fleetManager: null,
    fleetName: null,
    lastLocation: null,
    lastName: null,
    liveEquipments: [],
    maintenanceTerminal: null,
    marketingArea: null,
    middleName: null,
    milesTillNextService: null,
    nextServiceDateandTime: null,
    nextServiceType: null,
    onDutyHours: null,
    operationalStatus: null,
    payType: null,
    plannedLoads: null,
    preferredName: null,
    previousSegmentStatus: null,
    readyLocation: null,
    readyTime: null,
    recapHours: null,
    resourceName: null,
    resourcePlanType: null,
    resourceStatus: null,
    serviceAppointmentStatus: null,
    serviceFailures: null,
    suggestedBreak: null,
    timeOfLocation: null,
    timeOff: null,
    totalLoadsHauledForTheWeek: null,
    totalMilesHauledForTheWeek: null,
    trailers: null,
    truck: '2925',
    truckPlannedLoads: null,
    type: null,
    utilization: null,
    workHours: null
  },
  shipmentId: [],
  taskReason: [],
  utilization: {
    utilizationStatusCode: 'OTR',
    utilizationStatusDescription: 'Over The Road',
  }
};
const getResourceOverviewDetailsData = {
  alphaCode: '',
  aobrLastUpdated: 1569,
  aobrStatus: '',
  aobrStatusDurationHours: 1,
  board: '',
  boardCode: '1',
  certifications: null,
  currentLoadNumber: null,
  currentLocation: null,
  destinationCityState: '',
  dotReviewDate: '',
  driveHours: 222,
  driverId: '',
  driverPlannedLoads: null,
  driverStatus: 'A',
  drivingHoursRemainingAtReadyTime: 650,
  emptyMiles: 1541,
  emptyMilesLimit: null,
  equipmentId: 285,
  estimatedTimeOfArrival: '',
  estimatedTimeOfArrivalTimezone: null,
  estimatedTimeOfCompletion: '',
  estimatedTimeOfCompletionTimezone: null,
  etaCityStateCode: '',
  etcCityStateCode: '',
  expirationDate: '',
  firstName: '',
  firstStopLattitude: null,
  firstStopLocationId: null,
  firstStopLongitude: null,
  fleet: '',
  fleetCode: 'JBP',
  fleetName: '',
  lastLocation: '',
  lastLocationUpdatedTimeStamp: '',
  lastName: '',
  lastStopLattitude: 36.266701,
  lastStopLocationId: null,
  lastStopLongitude: null,
  latitude: '',
  longitude: '-82.5975445',
  maintenanceTerminal: '',
  maintenanceTerminalDescription: '',
  marketingArea: null,
  middleName: '',
  milesTillNextService: 29,
  nextServiceDateandTime: '',
  nextServiceType: 'B',
  numberOfDays: null,
  onDutyHours: null,
  operationalPlanId: null,
  operationalStatus: 'Available',
  originCityState: '',
  physicalExpirationDate: '',
  plannedLoads: 0,
  preferredName: '',
  previousSegementStatus: null,
  readyTime: '',
  resourceName: '',
  resourceStatus: 'PLANNED',
  safetyTerminal: 'HY',
  scheduleStart: null,
  secondSeatDriverDetails: null,
  serviceAppointmentStatus: '',
  serviceFailures: null,
  stopCityStateCode: null,
  suggestedBreak: '',
  suggestedBreakTimezone: null,
  timeOfLocation: null,
  timeOff: null,
  timeOffDate: null,
  timeOffType: null,
  totalLoadsHauledForTheWeek: '1',
  totalMilesHauledForTheWeek: '',
  trailers: [],
  truck: '',
  truckPlannedLoads: 0,
  utilization: 'OTR',
  utilizationStatus: [],
  workHours: null,
  type: [],
  contactDetails: {
    email: '',
    homePhone: '',
    workPhone: null
  },
  endorsements: [],
  fleetManager: {
    businessUnit: '',
    costCenterID: '',
    departmentCode: '',
    email: '',
    emplId: '',
    extenstion: '',
    firstName: '',
    isDriver: 'N',
    jobCode: '',
    jobGroup: ' ',
    jobTitle: '',
    lastName: '',
    locationCode: '',
    locationDesc: '',
    managerEmplId: '',
    managerName: '',
    middleName: '',
    personSubType: '',
    personType: 'EMP',
    phone: '',
    positionDescr: '',
    positionNbr: '',
    prefName: '',
    status: 'A',
    userId: ''
  },
  payType: [],
  recapHours: [],
  readyLocation: {
    addressLine1: '',
    addressLine2: '',
    city: '',
    country: '',
    id: 14,
    latitude: 36.266701,
    locationCode: 'LO',
    locationName: '',
    longitude: -94.136496,
    state: '',
    zipcode: '',
    locationContacts: []
  },
};

class MockActivityLogService {
  constructor() { }
  getLoadOverview() {
    return of(getLoadOverviewData);
  }
  getResourceOverviewDetails() {
    return of(getResourceOverviewDetailsData);
  }
  getCheckCallErrors() {
    return throwError(null);
  }
  addArrivalAndUnloaded() {
    return throwError(null);
  }
  addArrivalLoaded() {
    return throwError(null);
  }
  getLoadRemove() {
    return throwError(null);
  }
}
describe('ActivityLogComponent', () => {
  let component: ActivityLogComponent;
  let fixture: ComponentFixture<ActivityLogComponent>;
  const fb: FormBuilder = new FormBuilder();

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, BreadcrumbModule,
        JbhLoaderModule, LoadOverviewModule, PipesModule, TooltipModule,
        FormsModule, ReactiveFormsModule, CalendarModule, AutoCompleteModule, DropdownModule, DialogModule, CheckboxModule,
        ScrollPanelModule, InputSwitchModule, ChipsModule, KeyFilterModule, MessageModule, MessagesModule, LoadContactsModule,
        BrowserAnimationsModule, GlobalPopupsModule, AssetCommunicationModule, DirectivesModule, EquipmentGroupPopupModule],
      providers: [UserService, AppConfigService, LocalStorageService, MessageService, AppSharedDataService,
        { provide: ActivityLogService, useClass: MockActivityLogService }],
      declarations: [ActivityLogComponent, ActivityLogErrorComponent, ActivityLogArrivalViewComponent, ActivityLogLoadedViewComponent,
        ActivityLogUnloadedViewComponent, ActivityLogArrivalEditComponent, ActivityLogLocationDetailsComponent,
        ActivityLogCommentsAddComponent, ActivityLogCommentsViewComponent, ActivityLogDispatchViewComponent, ActivityLogArrivalAddComponent,
        ActivityLogLoadedAddComponent, ActivityLogUnloadedAddComponent, ActivityLogLoadedEditComponent, ActivityLogUnloadedEditComponent,
        ActivityLogResourceInformationComponent, ActivityLogResourceDetailsComponent, EquipmentUnassignComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onSave have been called', () => {
    spyOn(component, 'saveAddActivityLog');
    component.onSave();
    expect(component.saveAddActivityLog).toHaveBeenCalled();
  });

  it('onCancel is called with isTracking truthy', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.activityLogDetailsModel.isTracking = true;
    component.onCancel();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('onCancel is called with checkCallNavigation truthy', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.activityLogDetailsModel.checkCallNavigation = true;
    component.onCancel();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('onCancel should call the navigate spy', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.onCancel();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('onEdit have been called', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.activityLogDetailsModel.checkCallId = null;
    component.activityLogDetailsModel.loadNumber = null;
    component.activityLogDetailsModel.activityType = '';
    component.activityLogDetailsModel.resourceIdVal = '';
    component.activityLogDetailsModel.resourceTypeVal = '';
    component.onEdit();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('setLocalStoreItems should call the spy loadedLocalStore', () => {
    spyOn(component, 'loadedLocalStore');
    component.activityLogDetailsModel.activityType = 'loaded';
    component.setLocalStoreItems();
    expect(component.loadedLocalStore).toHaveBeenCalled();
  });

  it('setLocalStoreItems is called with activityType arrivalandloaded', () => {
    spyOn(component, 'getArrivalFormValue');
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'setItem');
    spyOn(component, 'frameLoadedUnloadedValue');
    component.addLoaded = {
      activityLogLoadedAddModel: {
        addLoadedForm: fb.group({})
      },
      equipmentPaired: null
    };
    component.activityLogDetailsModel.activityType = 'arrivalandloaded';
    component.setLocalStoreItems();
    expect(component.getArrivalFormValue).toHaveBeenCalled();
  });

  it('setLocalStoreItems should call the spy unloadedLocalStore', () => {
    spyOn(component, 'unloadedLocalStore');
    component.activityLogDetailsModel.activityType = 'unloaded';
    component.setLocalStoreItems();
    expect(component.unloadedLocalStore).toHaveBeenCalled();
  });

  it('setLocalStoreItems is called with activityType arrivalandunloaded', () => {
    spyOn(component, 'unloadedLocalStore');
    spyOn(component, 'getArrivalFormValue');
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'setItem');
    spyOn(component, 'frameLoadedUnloadedValue');
    component.addUnloaded = {
      activityLogUnloadedAddModel: {
        addUnloadedForm: fb.group({}),
        equipmentPaired: null
      }
    };
    component.activityLogDetailsModel.activityType = 'arrivalandunloaded';
    component.setLocalStoreItems();
    expect(component.getArrivalFormValue).toHaveBeenCalled();
  });

  it('clearLocalStoreItem should call the spy localStorageService', () => {
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'clearItem');
    component.clearLocalStoreItem();
    expect(localStorageService.clearItem).toHaveBeenCalled();
  });

  it('unLoadedFinalizeMethod should set the activityLogHeader as COMMENTS', () => {
    component.activityLogDetailsModel.activityType = 'comment';
    spyOn(component, 'getBreadCrumbData');
    component.setHeader();
    expect(component.activityLogDetailsModel.activityLogHeader).toBe('COMMENTS');
  });

  it('unLoadedFinalizeMethod is called with activityType dispatch', () => {
    component.activityLogDetailsModel.activityType = 'dispatch';
    spyOn(component, 'getBreadCrumbData');
    component.setHeader();
    expect(component.getBreadCrumbData).toHaveBeenCalled();
  });

  it('unLoadedFinalizeMethod is called with activityType arrival', () => {
    component.activityLogDetailsModel.activityType = 'arrival';
    spyOn(component, 'setHeaderAndMenu');
    component.setHeader();
    expect(component.setHeaderAndMenu).toHaveBeenCalled();
  });

  it('unLoadedFinalizeMethod is called with activityType loaded', () => {
    component.activityLogDetailsModel.activityType = 'loaded';
    spyOn(component, 'setHeaderAndMenu');
    component.setHeader();
    expect(component.setHeaderAndMenu).toHaveBeenCalled();
  });

  it('unLoadedFinalizeMethod is called with activityType unloaded', () => {
    component.activityLogDetailsModel.activityType = 'unloaded';
    spyOn(component, 'setHeaderAndMenu');
    component.setHeader();
    expect(component.setHeaderAndMenu).toHaveBeenCalled();
  });

  it('unLoadedFinalizeMethod is called with activityType arrivalandloaded', () => {
    component.activityLogDetailsModel.activityType = 'arrivalandloaded';
    spyOn(component, 'setHeaderAndMenu');
    component.setHeader();
    expect(component.setHeaderAndMenu).toHaveBeenCalled();
  });

  it('unLoadedFinalizeMethod is called with activityType arrivalandunloaded', () => {
    component.activityLogDetailsModel.activityType = 'arrivalandunloaded';
    spyOn(component, 'setHeaderAndMenu');
    component.setHeader();
    expect(component.setHeaderAndMenu).toHaveBeenCalled();
  });

  it('setHeaderAndMenu should call the spy getBreadCrumbData', () => {
    spyOn(component, 'getBreadCrumbData');
    component.setHeaderAndMenu('');
    expect(component.getBreadCrumbData).toHaveBeenCalled();
  });

  it('frameActivityLogHeader is called with activityType arrival', () => {
    component.activityLogDetailsModel.arrivalRequestObj = {
      destinationHeader: 'ACTIVITY',
      operationalPlanID: null,
      operationalPlanStopSequenceNumber: 1
    };
    component.activityLogDetailsModel.activityType = 'arrival';
    component.frameActivityLogHeader();
    expect(component.activityLogDetailsModel.activityLogHeader).toEqual(`ACTIVITY ARRIVAL DETAILS`);
  });

  it('frameActivityLogHeader is called with activityType loaded', () => {
    component.activityLogDetailsModel.arrivalRequestObj = {
      destinationHeader: '',
      operationalPlanID: null,
      operationalPlanStopSequenceNumber: 1
    };
    component.activityLogDetailsModel.activityType = 'loaded';
    component.frameActivityLogHeader();
    expect(component.activityLogDetailsModel.activityLogHeader).toEqual(`Origin LOADED DETAILS`);
  });

  it('frameActivityLogHeader is called with activityType unloaded', () => {
    component.activityLogDetailsModel.arrivalRequestObj = {
      destinationHeader: '',
      operationalPlanID: null,
      operationalPlanStopSequenceNumber: 2
    };
    component.activityLogDetailsModel.activityType = 'unloaded';
    component.frameActivityLogHeader();
    expect(component.activityLogDetailsModel.activityLogHeader).toEqual(`Stop 2 UNLOADED DETAILS`);
  });

  it('frameActivityLogHeader is called with activityType arrivalandloaded', () => {
    component.activityLogDetailsModel.arrivalRequestObj = {
      destinationHeader: 'ACTIVITY',
      operationalPlanID: null,
      operationalPlanStopSequenceNumber: 1
    };
    component.activityLogDetailsModel.activityType = 'arrivalandloaded';
    component.frameActivityLogHeader();
    expect(component.activityLogDetailsModel.activityLogHeader).toEqual(`ACTIVITY ARRIVAL AND LOADED DETAILS`);
  });

  it('frameActivityLogHeader is called with activityType arrivalandunloaded', () => {
    component.activityLogDetailsModel.arrivalRequestObj = {
      destinationHeader: 'ACTIVITY',
      operationalPlanID: null,
      operationalPlanStopSequenceNumber: 1
    };
    component.activityLogDetailsModel.activityType = 'arrivalandunloaded';
    component.frameActivityLogHeader();
    expect(component.activityLogDetailsModel.activityLogHeader).toEqual(`ACTIVITY ARRIVAL AND UNLOADED DETAILS`);
  });

  it('getLoadOverView should set isLoading as false', () => {
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getLoadOverview').and.returnValue(throwError(null));
    component.activityLogDetailsModel.loadNumber = 1;
    component.getLoadOverView();
    expect(component.activityLogDetailsModel.isLoading).toBeFalsy();
  });

  it('getLoadOverView should set isLoading as isAddCheckCallLoaded ', () => {
    component.activityLogDetailsModel.loadNumber = 1;
    component.getLoadOverView();
    expect(component.activityLogDetailsModel.isAddCheckCallLoaded).toBeFalsy();
  });

  it('getResourceDetails should set resourceOverview  as null', () => {
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getResourceOverviewDetails').and.returnValue(throwError(null));
    component.activityLogDetailsModel.loadNumber = 1;
    component.getResourceDetails();
    expect(component.activityLogDetailsModel.resourceOverview).toBeNull();
  });

  it('getResourceDetails should set resourceOverview as null', () => {
    component.activityLogDetailsModel.loadNumber = 1;
    component.getResourceDetails();
    expect(component.activityLogDetailsModel.driverIdComments).toEqual('');
  });

  it('onEquipmentLocationAction should call the spy getLoadOverView', () => {
    spyOn(component, 'getLoadOverView');
    spyOn(component, 'getResourceDetails');
    spyOn(component, 'arrivalDevationType');
    spyOn(component, 'getCheckCallErrorWarningList');
    component.activityLogDetailsModel.breadCrumb = [];
    component.onEquipmentLocationAction();
    expect(component.getLoadOverView).toHaveBeenCalled();
  });

  it('sequenceNumber should set the operationalPlanStopSequenceNumber as null', () => {
    spyOn(component, 'frameActivityLogHeader');
    component.activityLogDetailsModel.loadNumber = 1;
    component.activityLogDetailsModel.loadOverviewDetails = getLoadOverviewData;
    component.sequenceNumber({
      stopSequenceNumber: null,
      stopId: null,
      destinationHeader: ''
    });
    expect(component.activityLogDetailsModel.arrivalRequestObj.operationalPlanStopSequenceNumber).toEqual(null);
  });

  it('sequenceNumber should call the spy frameActivityLogHeader', () => {
    spyOn(component, 'frameActivityLogHeader');
    component.activityLogDetailsModel.loadNumber = 1;
    component.sequenceNumber({
      stopSequenceNumber: null,
      stopId: null,
      destinationHeader: ''
    });
    expect(component.frameActivityLogHeader).toHaveBeenCalled();
  });

  it('checkCallStopId should set stopID equal to 1', () => {
    component.checkCallStopId({ checkCallStopId: 1 });
    expect(component.activityLogDetailsModel.stopID).toEqual(1);
  });

  it('checkErrorWarningMessageDisplay should call the spy saveData', () => {
    component.activityLogDetailsModel.errorMessage = [{
      errorMessage: '',
      errorType: '',
      errorSeverity: ''
    }];
    const appSharedDataService: AppSharedDataService = TestBed.get(AppSharedDataService);
    spyOn(appSharedDataService, 'saveData');
    component.checkErrorWarningMessageDisplay();
    expect(appSharedDataService.saveData).toHaveBeenCalled();
  });

  it('checkErrorWarningMessageDisplay should call the spy saveData with parameter false', () => {
    component.activityLogDetailsModel.errorMessage = [];
    const appSharedDataService: AppSharedDataService = TestBed.get(AppSharedDataService);
    spyOn(appSharedDataService, 'saveData');
    component.checkErrorWarningMessageDisplay();
    expect(appSharedDataService.saveData).toHaveBeenCalledWith(false);
  });

  it('onRemove should set the removeDisplayDialog as true', () => {
    component.onRemove();
    expect(component.activityLogDetailsModel.removeDisplayDialog).toBeTruthy();
  });

  it('onCancelPopup should set the removeDisplayDialog as false', () => {
    component.onCancelPopup();
    expect(component.activityLogDetailsModel.removeDisplayDialog).toBeFalsy();
  });

  it('updateLocation should call the spy setLocalStoreItems', () => {
    spyOn(component, 'setLocalStoreItems');
    component.activityLogDetailsModel.breadCrumb = [];
    component.updateLocation({
      equipmentCategory: '',
      equipmentNumber: '',
      equipmentId: null,
      hasLocation: true
    });
    expect(component.setLocalStoreItems).toHaveBeenCalled();
  });

  it('checkTelematicsPickup should set hasTelematicsPickup as true', () => {
    component.checkTelematicsPickup(true);
    expect(component.activityLogDetailsModel.hasTelematicsPickup).toBeTruthy();
  });

  it('loadedLocalStore should call the spy setItem', () => {
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'setItem');
    spyOn(component, 'frameLoadedUnloadedValue');
    component.addLoaded = {
      activityLogLoadedEditModel: {
        addLoadedForm: fb.group({}),
        equipmentPaired: null
      }
    };
    component.activityLogDetailsModel.isCheckCallTracking = true;
    component.loadedLocalStore();
    expect(localStorageService.setItem).toHaveBeenCalled();
  });

  it('loadedLocalStore should call the spy frameLoadedUnloadedValue', () => {
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'setItem');
    spyOn(component, 'frameLoadedUnloadedValue');
    component.addLoaded = {
      activityLogLoadedAddModel: {
        addLoadedForm: fb.group({}),
        equipmentPaired: null
      }
    };
    component.activityLogDetailsModel.isCheckCallTracking = false;
    component.loadedLocalStore();
    expect(component.frameLoadedUnloadedValue).toHaveBeenCalled();
  });

  it('unloadedLocalStore should call the spy setItem', () => {
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'setItem');
    spyOn(component, 'frameLoadedUnloadedValue');
    component.activityLogDetailsModel.isCheckCallTracking = true;
    component.addUnloaded = {
      activityLogUnloadedEditModel: {
        editUnloadedForm: fb.group({}),
        equipmentPaired: null
      }
    };
    component.unloadedLocalStore();
    expect(localStorageService.setItem).toHaveBeenCalled();
  });

  it('unloadedLocalStore should call the spy frameLoadedUnloadedValue', () => {
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'setItem');
    spyOn(component, 'frameLoadedUnloadedValue');
    component.activityLogDetailsModel.isCheckCallTracking = false;
    component.addUnloaded = {
      activityLogUnloadedAddModel: {
        addUnloadedForm: fb.group({}),
        equipmentPaired: null
      }
    };
    component.unloadedLocalStore();
    expect(component.frameLoadedUnloadedValue).toHaveBeenCalled();
  });

  it('frameLoadedUnloadedValue should return departureTimeStamp as empty string', () => {
    const data = { departureTimestamp: '', trailerOrContainerSelected: null };
    const returnValue = component.frameLoadedUnloadedValue(data, {});
    expect(returnValue.departureTime).toEqual('');
  });

  it('arrivalDevationType should call the spy checkErrorWarningMessageDisplay', () => {
    spyOn(component, 'checkErrorWarningMessageDisplay');
    const data = [{ errorSeverity: 'ERROR' }, { errorSeverity: 'WARNING' }];
    component.arrivalDevationType(data);
    expect(component.checkErrorWarningMessageDisplay).toHaveBeenCalled();
  });

  it('arrivalDevationType should set the errorMessage as empty array', () => {
    spyOn(component, 'checkErrorWarningMessageDisplay');
    component.arrivalDevationType([]);
    expect(component.activityLogDetailsModel.errorMessage.length).toEqual(0);
  });

  it('overrideWarning should set showError as false', () => {
    component.overrideWarning({});
    expect(component.activityLogDetailsModel.showError).toBeFalsy();
  });

  it('overrideWarning should set isOverrideWarning as false', () => {
    component.overrideWarning(null);
    expect(component.activityLogDetailsModel.isOverrideWarning).toBeFalsy();
  });

  it('saveAddActivityLog should call the spy addArrival.saveForm', () => {
    component.activityLogDetailsModel.activityType = 'arrival';
    component.addArrival = {
      saveForm: jasmine.createSpy('saveForm')
    };
    component.saveAddActivityLog();
    expect(component.addArrival.saveForm).toHaveBeenCalled();
  });

  it('saveAddActivityLog should call the spy addLoaded.saveForm', () => {
    component.activityLogDetailsModel.activityType = 'loaded';
    component.addLoaded = {
      saveForm: jasmine.createSpy('saveForm')
    };
    component.saveAddActivityLog();
    expect(component.addLoaded.saveForm).toHaveBeenCalled();
  });

  it('saveAddActivityLog should call the spy addUnloaded.saveForm', () => {
    component.activityLogDetailsModel.activityType = 'unloaded';
    component.addUnloaded = {
      saveForm: jasmine.createSpy('saveForm')
    };
    component.saveAddActivityLog();
    expect(component.addUnloaded.saveForm).toHaveBeenCalled();
  });

  it('saveAddActivityLog should call the spy saveArrivalAndUnloaded', () => {
    component.activityLogDetailsModel.activityType = 'arrivalandunloaded';
    spyOn(component, 'saveArrivalAndUnloaded');
    component.saveAddActivityLog();
    expect(component.saveArrivalAndUnloaded).toHaveBeenCalled();
  });

  it('saveAddActivityLog should call the spy saveArrivalAndLoaded', () => {
    component.activityLogDetailsModel.activityType = 'arrivalandloaded';
    spyOn(component, 'saveArrivalAndLoaded');
    component.saveAddActivityLog();
    expect(component.saveArrivalAndLoaded).toHaveBeenCalled();
  });

  it('handleError should call the spy toast.add', () => {
    const error = {
      status: 500
    };
    const toast: MessageService = TestBed.get(MessageService);
    spyOn(toast, 'add');
    spyOn(ErrorUtils, 'getErrorMessage');
    component.handleError(error);
    expect(toast.add).toHaveBeenCalled();
  });

  it('handleError should call the spy handleEmptyError', () => {
    const error = {
      status: 200,
      error: {
        errors: [{
          errorMessage: ''
        }]
      }
    };
    spyOn(component, 'handleEmptyError');
    spyOn(ErrorUtils, 'getErrorMessage');
    component.handleError(error);
    expect(component.handleEmptyError).toHaveBeenCalled();
  });

  it('handleEmptyError should call the spy toast.add', () => {
    const error = {
      status: 200,
      error: {
        errors: [{
          errorMessage: ''
        }]
      }
    };
    const toast: MessageService = TestBed.get(MessageService);
    spyOn(toast, 'add');
    spyOn(ErrorUtils, 'getErrorMessage');
    component.handleEmptyError(error);
    expect(toast.add).toHaveBeenCalled();
  });

  it('handleEmptyError should call the spy toast.add', () => {
    const error = {
      status: 200,
      error: {
        errors: [{
          errorMessage: null
        }]
      }
    };
    const toast: MessageService = TestBed.get(MessageService);
    spyOn(toast, 'add');
    spyOn(ErrorUtils, 'getErrorMessage');
    component.handleEmptyError(error);
    expect(toast.add).toHaveBeenCalled();
  });

  it('handleEmptyError should call the spy arrivalDevationType', () => {
    const error = {
      status: 200,
      error: {
        errors: [{
          errorMessage: 'error'
        }]
      }
    };
    spyOn(component, 'arrivalDevationType');
    spyOn(component, 'findFormGroup');
    component.handleEmptyError(error);
    expect(component.arrivalDevationType).toHaveBeenCalled();
  });

});
