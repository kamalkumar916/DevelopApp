import { Component, OnInit, Input, ChangeDetectionStrategy, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { takeWhile, finalize } from 'rxjs/operators';

import { AppointmentDateFormatterPipe } from '../../../../shared/pipes/appointment-date-formatter.pipe';

import { ActivityLogModel } from '../../models/activity-log.model';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ViewActivityLogDetails, PickUpDetails, StopDetails } from '../../models/activity-log.interface';
import { ActivityLogService } from '../../services/activity-log.service';

@Component({
  selector: 'app-activity-log-unloaded-view',
  templateUrl: './activity-log-unloaded-view.component.html',
  styleUrls: ['./activity-log-unloaded-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogUnloadedViewComponent implements OnInit {
  @Output() readonly stopSequenceNumber: EventEmitter<StopDetails> = new EventEmitter();
  activityLogDetailsModel: ActivityLogModel;
  @Input() set checkCallId(checkCallId: number) {
    if (checkCallId) {
      this.getUnloadedCallDetails(checkCallId, 'unloaded');
    }
  }
  constructor(private readonly activityLogService: ActivityLogService,
    private readonly changeDetector: ChangeDetectorRef, private readonly activatedRoute: ActivatedRoute) {
    this.activityLogDetailsModel = new ActivityLogModel();
  }

  ngOnInit() {
    this.activityLogDetailsModel.activityType = this.activatedRoute.queryParams['_value']['activityType'];
    this.activityLogDetailsModel.checkCallId = this.activatedRoute.queryParams['_value']['checkCallId'];
    if (this.activityLogDetailsModel.checkCallId && this.activityLogDetailsModel.activityType) {
      this.getUnloadedCallDetails(this.activityLogDetailsModel.checkCallId, this.activityLogDetailsModel.activityType);
    }
  }
  getUnloadedCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    this.activityLogDetailsModel.loading = true;
    this.activityLogService.getCheckCallDetails(operationalPlanCheckCallId, activityType)
      .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
        finalize(() => {
          this.activityLogDetailsModel.loading = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((data: ViewActivityLogDetails) => {
        this.activityLogDetailsModel.loading = false;
        if (data) {
          this.activityLogDetailsModel.activityLogDetails = data;
          this.unLoadedData();
        }
      }, (error: Error) => {
        this.activityLogDetailsModel.loading = false;
      });
  }
  unLoadedData() {
    const data = this.activityLogDetailsModel.activityLogDetails;
    if (data.operationalPlanStopDetails && data.operationalPlanStopDetails.locationDetails) {
      this.activityLogDetailsModel.splitViewDetailsData.location =
        ActivityLogUtils.getLocationDetails(data.operationalPlanStopDetails.locationDetails);
    }
    let unloadedAppointmentObject;
    if (data.operationalPlanStopDetails && data.operationalPlanStopDetails.appointmentStartTimestamp &&
      data.operationalPlanStopDetails.appointmentEndTimestamp) {
      unloadedAppointmentObject = {
        appointmentStartTimestamp: data.operationalPlanStopDetails.appointmentStartTimestamp.toString(),
        appointmentEndTimestamp: data.operationalPlanStopDetails.appointmentEndTimestamp.toString(),
        timeZone: data.operationalPlanStopDetails.locationDetails.address.timeZone
      };
    }
    this.activityLogDetailsModel.splitViewDetailsData.stopReasonCode =
      data.operationalPlanStopDetails && data.operationalPlanStopDetails.operationalPlanStopReasonCodeDescription;
    this.activityLogDetailsModel.timeZone = data.operationalPlanStopDetails && data.operationalPlanStopDetails.locationDetails
    && data.operationalPlanStopDetails.locationDetails.address && data.operationalPlanStopDetails.locationDetails.address.timeZone;
    if (data.unloadedTimestamp) {
      this.activityLogDetailsModel.splitViewDetailsData.arrivalTime =
        ActivityLogUtils.getArrivedDate(data.unloadedTimestamp, this.activityLogDetailsModel.timeZone);
    }
    this.activityLogDetailsModel.timeZone = data.operationalPlanStopDetails.locationDetails.address.timeZone;
    if (unloadedAppointmentObject && unloadedAppointmentObject.appointmentStartTimestamp &&
      unloadedAppointmentObject.appointmentEndTimestamp) {
      this.activityLogDetailsModel.splitViewDetailsData.appointment =
        new AppointmentDateFormatterPipe().transform(unloadedAppointmentObject);
    }
    this.activityLogDetailsModel.splitViewDetailsData.arrivalStatus =
      ActivityLogUtils.checkArrivalStatus(data);
    this.activityLogDetailsModel.departureTime = ActivityLogUtils.getArrivedDate(data.departureTimestamp,
      data.operationalPlanStopDetails.locationDetails.address.timeZone);
    this.activityLogDetailsModel.lastUpdatedOn = this.formatDeparture(data.lastUpdatedTimestamp);
  }
  getDropEquipmentValue(equipmentDetails: PickUpDetails[]) {
    let i = 0;
    equipmentDetails.forEach((equipmentData) => {
      if (equipmentData.equipmentType && equipmentData.equipmentPrefix && equipmentData.equipmentType) {
        ++i;
      }
    });
    if (i === 0) {
      return true;
    } else {
      return false;
    }
  }
  formatDeparture(departureTime: string): string {
    if (departureTime) {
      return `${new AppointmentDateFormatterPipe().getFormattedDate(departureTime)}
        ${new AppointmentDateFormatterPipe().getFormattedTime(departureTime)} ${ActivityLogUtils.getZoneFormat()}`;
    } else {
      return null;
    }
  }
  sequenceNumber(event) {
    if (event.stopSequenceNumber) {
      this.stopSequenceNumber.emit({
        'stopSequenceNumber': event.stopSequenceNumber,
        'stopId': event.stopId,
        'destinationHeader': event.destinationHeader
      });
    }
  }
}
