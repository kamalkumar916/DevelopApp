import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { configureTestSuite } from 'ng-bullet';
import { TooltipModule } from 'primeng/tooltip';

import { AppSharedDataService } from '../../../../shared/jbh-app-services/app-shared-data.service';
import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { ActivityLogUnloadedViewComponent } from './activity-log-unloaded-view.component';
import { ActivityLogLocationDetailsComponent } from '../../activity-log-location-details/activity-log-location-details.component';
import { GlobalPopupsModule } from './../../../../shared/global-popups/global-popups.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivityLogService } from '../../services/activity-log.service';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';

const stopLocationDetails = {
  operationalPlanStopDetails: {
    locationDetails: {
      locationId: '26551',
      locationName: 'VAN Buren Main',
      locationCode: 'VAVAC3',
      address: {
        addressLine1: '5 Main St',
        addressLine2: '',
        city: 'Van Buren',
        state: 'AR',
        zipcode: '729565706',
        country: 'USA',
        countryName: 'USA',
        timeZone: 'America/Chicago'
      }
    }
  }
};
const dropEquipmentDetails = [
  {
    equipmentId: 1,
    equipmentType: 'CONTAINER',
    equipmentPrefix: 'JBHU',
    equipmentNumber: '745632'
  }
];
const viewUnloadedDetails = {
  operationalPlanStopId: 1,
  operationalPlanId: 1,
  unloadedType: 'Live',
  unloadedBy: 'Driver',
  departureTimestamp: '2019-09-26T10:00:00-05:00',
  lastUpdatedTimestamp: '09/28/2019 01:47 PM GMT',
  operationalPlanStopDetails: {
    operationalPlanStopSequenceNumber: 1,
    operationalPlanStopReasonCode: 'Pickup',
    operationalPlanStopReasonCodeDescription: 'Pickup',
    locationDetails: stopLocationDetails.operationalPlanStopDetails.locationDetails,
    appointmentStartTimestamp: '2019-09-26T10:00:00-05:00',
    appointmentEndTimestamp: '2019-09-26T10:00:00-05:00',
    stopSequenceDescription: 'Origin'
  },
  lastUpdateProgramName: 'Process ID',
  lastUpdatedUserId: 'pidordm',
  lastUpdatedOn: '09/28/2019 01:47 PM GMT',
  comments: '',
  unloadedTimestamp: '2019-09-26T10:00:00-05:00',
  loadedTimestamp: null,
  proNumber: null,
  weight: {
    weight: 478,
    unitOfWeightMeasurement: 'Pounds'
  },
  volume: {
    volume: 4545,
    unitOfVolumeMeasurement: 'Gallons'
  },
  temperature: {
    temperature: 32,
    unitOfTemperatureMeasurement: 'Celsius'
  },
  count: 4356,
  countedBy: 'Driver',
  sealNumber: '453454',
  bolNumber: '76867',
  poNumbers: ['2324', '34343'],
  shipperIdentificationNumber: '3156',
  receiverStateId: 176,
  receiverStateName: 'abc',
  hazmatIndicator: 'N',
  pickupEquipmentDetails: [],
  dropEquipmentDetails: dropEquipmentDetails,
  stopServicesTypeCodes: [],
  stopServices: []
};
const finalDestination = {
  stateID: 766,
  stateCode: 'AR',
  stateName: 'Arcancas'
};

class MockActivityLogService {
  constructor() { }
  getCheckCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    return of(viewUnloadedDetails);
  }
}
describe('ActivityLogUnloadedViewComponent', () => {
  let component: ActivityLogUnloadedViewComponent;
  let fixture: ComponentFixture<ActivityLogUnloadedViewComponent>;
  let activityLogService: ActivityLogService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, JbhLoaderModule, TooltipModule, PipesModule,
        RouterTestingModule, GlobalPopupsModule, DirectivesModule, NoopAnimationsModule],
      providers: [AppConfigService, AppSharedDataService, { provide: ActivityLogService, useClass: MockActivityLogService }],
      declarations: [ActivityLogUnloadedViewComponent, ActivityLogLocationDetailsComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogUnloadedViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('ActivityLogUnloadedViewComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('getUnloadedCallDetails should be called when Input checkCallId is set', () => {
    spyOn(component, 'getUnloadedCallDetails');
    const checkCallId = 1;
    component.checkCallId = checkCallId;
    expect(component.getUnloadedCallDetails).toHaveBeenCalledWith(checkCallId, 'unloaded');
  });
  it('getUnloadedCallDetails should not be called when Input checkCallId not set', () => {
    spyOn(component, 'getUnloadedCallDetails');
    const checkCallId = null;
    component.checkCallId = checkCallId;
    expect(component.getUnloadedCallDetails).toHaveBeenCalledTimes(0);
  });

  it('getUnloadedCallDetails have been called when service call success', () => {
    spyOn(component, 'unLoadedData');
    component.getUnloadedCallDetails(123, 'unloaded');
    expect(component.activityLogDetailsModel.loading).toBeFalsy();
  });

  it('getUnloadedCallDetails error block have been called when service fails', () => {
    spyOn(component, 'unLoadedData');
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getCheckCallDetails').and.returnValue(throwError(null));
    component.getUnloadedCallDetails(123, 'unloaded');
    expect(component.activityLogDetailsModel.loading).toBeFalsy();
  });

  it('unLoadedData should be called when all activityLogDetails present', () => {
    component.activityLogDetailsModel.activityLogDetails = viewUnloadedDetails;
    spyOn(ActivityLogUtils, 'getLocationDetails');
    spyOn(ActivityLogUtils, 'getArrivedDate');
    component.unLoadedData();
    expect(component.activityLogDetailsModel.splitViewDetailsData.location)
      .toBe(ActivityLogUtils.getLocationDetails(viewUnloadedDetails.operationalPlanStopDetails.locationDetails));
    expect(component.activityLogDetailsModel.splitViewDetailsData.arrivalTime)
      .toBe(ActivityLogUtils.getArrivedDate(viewUnloadedDetails.unloadedTimestamp,
        viewUnloadedDetails.operationalPlanStopDetails.locationDetails.address.timeZone));
  });

  it('unLoadedData have been called when some fields null', () => {
    const locdetails = {
      locationId: null,
      locationName: null,
      locationCode: null,
      address: {
        addressLine1: null,
        addressLine2: null,
        city: null,
        state: null,
        zipcode: null,
        country: null,
        countryName: null,
        timeZone: 'America/Chicago'
      }
    };
    viewUnloadedDetails.operationalPlanStopDetails = {
      operationalPlanStopSequenceNumber: null,
      operationalPlanStopReasonCode: null,
      operationalPlanStopReasonCodeDescription: null,
      locationDetails: locdetails,
      appointmentStartTimestamp: null,
      appointmentEndTimestamp: null,
      stopSequenceDescription: null
    };
    viewUnloadedDetails.unloadedTimestamp = null;
    const unloadedAppointmentObject = null;
    component.activityLogDetailsModel.activityLogDetails = viewUnloadedDetails;
    spyOn(ActivityLogUtils, 'getLocationDetails');
    spyOn(ActivityLogUtils, 'checkArrivalStatus');
    spyOn(ActivityLogUtils, 'getArrivedDate');
    spyOn(component, 'formatDeparture');
    component.unLoadedData();
    expect(component.activityLogDetailsModel.splitViewDetailsData.location)
      .toBe(ActivityLogUtils.getLocationDetails(viewUnloadedDetails.operationalPlanStopDetails.locationDetails));
    expect(component.activityLogDetailsModel.splitViewDetailsData.arrivalStatus).
      toBe(ActivityLogUtils.checkArrivalStatus(viewUnloadedDetails));
    expect(component.activityLogDetailsModel.departureTime)
      .toBe(ActivityLogUtils.getArrivedDate(viewUnloadedDetails.departureTimestamp, 'America/Chicago'));
    expect(component.activityLogDetailsModel.lastUpdatedOn)
      .toBe(component.formatDeparture(viewUnloadedDetails.lastUpdatedTimestamp));
  });

  it('getDropEquipmentValue have been called with no DropEquipments', () => {
    const returnValue = component.getDropEquipmentValue([]);
    expect(returnValue).toBeTruthy();
  });

  it('getDropEquipmentValue have been called when equipmentDetails present', () => {
    const returnValue = component.getDropEquipmentValue(dropEquipmentDetails);
    expect(returnValue).toBeFalsy();
  });
  it('getDropEquipmentValue have been called when equipmentDetails null', () => {
    const dropEquipments = [
      {
        equipmentId: 1,
        equipmentType: null,
        equipmentPrefix: null,
        equipmentNumber: null
      }
    ];
    const returnValue = component.getDropEquipmentValue(dropEquipments);
    expect(returnValue).toBeTruthy();
  });

  it('formatDeparture called when departure time is null', () => {
    const returnValue = component.formatDeparture(null);
    expect(returnValue).toBeNull();
  });

  it('sequenceNumber have been called when stopSequenceNumber given', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.sequenceNumber({ stopSequenceNumber: '1', stopId: '', destinationHeader: '' });
    expect(component.stopSequenceNumber.emit).toHaveBeenCalled();
  });

  it('sequenceNumber have been called when stopSequenceNumber is null', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.sequenceNumber({ stopSequenceNumber: null, stopId: '', destinationHeader: '' });
    expect(component.stopSequenceNumber.emit).toHaveBeenCalledTimes(0);
  });
});
