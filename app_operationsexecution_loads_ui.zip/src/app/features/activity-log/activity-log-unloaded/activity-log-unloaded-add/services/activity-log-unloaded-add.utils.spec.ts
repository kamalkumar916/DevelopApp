import { ActivityLogUnloadedAddUtils } from './activity-log-unloaded-add.utils';
import { FormBuilder, Validators } from '@angular/forms';

describe('ActivityLogUnloadedAddUtils', () => {
    const fb: FormBuilder = new FormBuilder();
    const formGroupName = fb.group({
        departureDate: [''],
        departureTime: [''],
        countedBy: ['', Validators.required],
        hazmat: ['', Validators.required],
        dropEquipmentDetails: fb.group({}),
        trailerOrContainer: [''],
        stopServices: [[]],
        shipmentIdentification: [''],
        billOfLadingNumber: [''],
        purchaseOrderNumber: [''],
        sealNumber: [''],
        proNumber: [''],
        finalDestination: [''],
        quantity: [''],
        weightUnits: fb.group({
            weight: ['2'],
            units: ['']
        }),
        volumeUnits: fb.group({
            volume: ['2'],
            units: ['']
        }),
        temperatureReadingUnits: fb.group({
            temperatureReading: ['2'],
            units: ['']
        }),
        comments: ['']
    });

    it('mandatoryFieldsCheck should set errors for the units controls', () => {
        ActivityLogUnloadedAddUtils.mandatoryFieldsCheck(formGroupName);
        expect(formGroupName.get('weightUnits')['controls'].units.errors['invalid']).toBeTruthy();
    });

    it('getWeightDetails should return an object with weight value as 1', () => {
        formGroupName.get('weightUnits').patchValue({
            weight: '1',
            units: '1'
        });
        const returnValue = ActivityLogUnloadedAddUtils.getWeightDetails(formGroupName);
        expect(returnValue.weight).toEqual('1');
    });

    it('getWeightDetails should return null', () => {
        formGroupName.get('weightUnits').reset();
        const returnValue = ActivityLogUnloadedAddUtils.getWeightDetails(formGroupName);
        expect(returnValue).toEqual(null);
    });

    it('getVolumeDetails should return an object with volume value as 1', () => {
        formGroupName.get('volumeUnits').patchValue({
            volume: '1',
            units: '1'
        });
        const returnValue = ActivityLogUnloadedAddUtils.getVolumeDetails(formGroupName);
        expect(returnValue.volume).toEqual('1');
    });

    it('getVolumeDetails should return null', () => {
        formGroupName.get('volumeUnits').reset();
        const returnValue = ActivityLogUnloadedAddUtils.getVolumeDetails(formGroupName);
        expect(returnValue).toEqual(null);
    });

    it('getTemperatureDetails should return an object with temperature value as 1', () => {
        formGroupName.get('temperatureReadingUnits').patchValue({
            temperatureReading: '1',
            units: '1'
        });
        const returnValue = ActivityLogUnloadedAddUtils.getTemperatureDetails(formGroupName);
        expect(returnValue.temperature).toEqual('1');
    });

    it('getTemperatureDetails should return null', () => {
        formGroupName.get('temperatureReadingUnits').reset();
        const returnValue = ActivityLogUnloadedAddUtils.getTemperatureDetails(formGroupName);
        expect(returnValue).toEqual(null);
    });
});
