import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogUnloadedAddService } from './activity-log-unloaded-add.service';
import { configureTestSuite } from 'ng-bullet';

describe('ActivityLogUnloadedAddService', () => {
  let service: ActivityLogUnloadedAddService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogUnloadedAddService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(ActivityLogUnloadedAddService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('addUnloadedDetails should be called', () => {
    service.addUnloadedDetails({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.addUnloaded);
    expect(req.request.method).toEqual('POST');
  });
});
