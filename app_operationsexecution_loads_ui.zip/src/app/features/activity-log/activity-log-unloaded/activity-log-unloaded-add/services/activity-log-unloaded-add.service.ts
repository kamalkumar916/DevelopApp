import { Injectable } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from './../../../../../shared/service/app-config.service';

@Injectable({
  providedIn: 'root'
})
export class ActivityLogUnloadedAddService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('activitylog');
  }
  addUnloadedDetails(addUnloadedReq): Observable<any> {
    return this.http.post<any>(this.endpoint.addUnloaded, addUnloadedReq);
  }
}
