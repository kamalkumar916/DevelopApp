import { FormGroup } from '@angular/forms';
import { AddLoadedResponseValues } from '../../../activity-log-loaded/activity-log-loaded-add/model/activity-log-loaded-add.interface';
import { DateUtils } from '../../../../../shared/jbh-app-services/date-utils';
import * as moment from 'moment';
import { ActivityLogUtils } from '../../../services/activity-log.utils';
import { ListItem } from '../../../../model/common.interface';
import { LoadOverview } from '../../../../load-details/load-details-overview/model/load-overview.interface';
import { ResourceOverview } from '../../../models/activity-log.interface';

export class ActivityLogUnloadedAddUtils {
    static mandatoryFieldsCheck(formGroupName: FormGroup) {
        if (formGroupName.get('weightUnits')['controls'].weight.value && !formGroupName.get('weightUnits')['controls'].units.value) {
            formGroupName.get('weightUnits')['controls'].units.setErrors({ 'invalid': true });
        }
        if (formGroupName.get('volumeUnits')['controls'].volume.value &&
            !formGroupName.get('volumeUnits')['controls'].units.value) {
            formGroupName.get('volumeUnits')['controls'].units.setErrors({ 'invalid': true });
        }
        if (formGroupName.get('temperatureReadingUnits')['controls'].temperatureReading.value &&
            !formGroupName.get('temperatureReadingUnits')['controls'].units.value) {
            formGroupName.get('temperatureReadingUnits')['controls'].units.setErrors({ 'invalid': true });
        }
    }
    static getWeightDetails(formGroupName: FormGroup) {
        if (formGroupName.value.weightUnits.weight && formGroupName.value.weightUnits.units) {
            return {
                weight: formGroupName.value.weightUnits.weight,
                unitOfWeightMeasurement: formGroupName.value.weightUnits.units
            };
        } else {
            return null;
        }
    }
    static getVolumeDetails(formGroupName: FormGroup) {
        if (formGroupName.value.volumeUnits.volume && formGroupName.value.volumeUnits.units) {
            return {
                volume: formGroupName.value.volumeUnits.volume,
                unitOfVolumeMeasurement: formGroupName.value.volumeUnits.units
            };
        } else {
            return null;
        }
    }
    static getTemperatureDetails(formGroupName: FormGroup) {
        if (formGroupName.value.temperatureReadingUnits.temperatureReading && formGroupName.value.temperatureReadingUnits.units) {
            return {
                temperature: formGroupName.value.temperatureReadingUnits.temperatureReading,
                unitOfTemperatureMeasurement: formGroupName.value.temperatureReadingUnits.units
            };
        } else {
            return null;
        }
    }
    static createAddUnloadedRequest(addUnloadedForm: FormGroup, addUnloadedInput: AddLoadedResponseValues,
        resourceOverview: ResourceOverview, unloadedType?: string) {
        const stopServicesObject = addUnloadedForm.value.stopServices ?
            addUnloadedForm.value.stopServices.map(stopService => stopService.value) : [];
        return {
            operationalPlanNumber: addUnloadedInput.planNumber,
            operationalPlanStopSequenceNumber: addUnloadedInput.stopSequenceNumber,
            receiverStateId: null,
            stopServices: stopServicesObject,
            hazmatIndicator: addUnloadedForm.value.hazmat,
            isWarningOverride: addUnloadedInput.overrideWarning,
            checkCallDetails: {
                loadedTimestamp: null,
                loadedBy: null,
                loadedType: null,
                count: ActivityLogUtils.getValueOrNull(addUnloadedForm.value.quantity),
                countedBy: addUnloadedForm.value.countedBy.value,
                sealNumber: ActivityLogUtils.getValueOrNull(addUnloadedForm.value.sealNumber),
                bolNumber: ActivityLogUtils.getValueOrNull(addUnloadedForm.value.billOfLadingNumber),
                poNumbers: addUnloadedForm.value.purchaseOrderNumber ? [addUnloadedForm.value.purchaseOrderNumber] : [],
                shipperIdentificationNumber: ActivityLogUtils.getValueOrNull(addUnloadedForm.value.shipmentIdentification),
                unloadedTimestamp: addUnloadedInput.loadedTimestamp,
                unloadedBy: addUnloadedForm.value.unloadedBy.value,
                unloadedType: unloadedType ? unloadedType : addUnloadedForm.value && addUnloadedForm.value.unloadedType &&
                    addUnloadedForm.value.unloadedType.value ? addUnloadedForm.value.unloadedType.value : null,
                hubReading: null,
                pickupEquipmentDetails: (addUnloadedInput.pickupEquipmentValue &&
                    addUnloadedInput.pickupEquipmentValue.length > 0) ? addUnloadedInput.pickupEquipmentValue : null,
                dropEquipmentDetails: addUnloadedInput.dropEquipmentValue,
                comments: ActivityLogUtils.getValueOrNull(addUnloadedForm.value.comments),
                departureTimestamp: addUnloadedInput.departureTimestamp,
                proNumber: ActivityLogUtils.getValueOrNull(addUnloadedForm.value.proNumber),
                weight: this.getWeightDetails(addUnloadedForm),
                volume: this.getVolumeDetails(addUnloadedForm),
                temperature: this.getTemperatureDetails(addUnloadedForm)
            },
            resourceDetails: {
                type: 'Truck',
                value: ActivityLogUtils.getTruckValue(resourceOverview)
            },
            checkCallSourceTimestamp:
                DateUtils.dateTimeZoneFormat(moment(new Date()).format('YYYY-MM-DD'), moment(new Date()).format('H:mm'),
                    addUnloadedInput.timeZone),
            checkCallMessage: null,
            isAutoCheckCall: false,
            checkCallSource: 'MnlChkCal',
            locationDetails: null
        };
    }
}
