import { FormGroup } from '@angular/forms';
import { ListItem } from '../../../../model/common.interface';
import { IsLoadedEarly } from '../../../activity-log-loaded/activity-log-loaded-add/model/activity-log-loaded-add.interface';
import {
    ViewActivityLogDetails, FinalDestination, DropEquipmentDetail,
    PickUpDetails, EquipmentGroup, ResourceOverview, TrackingDetailsParam
} from '../../../models/activity-log.interface';
import { OperationalPlanStopDTO } from '../../../../load-details/model/load-details.interface';
import { LoadOverview } from '../../../../load-details/load-details-overview/model/load-overview.interface';
import { RadioButtonValue } from '../../../../../shared/manage-equipment-group/models/manage-equipment-group.interface';


export class ActivityLogUnloadedAddModel {
    addUnloadedForm: FormGroup;
    isLoading: boolean;
    commentsCount: number;
    canSubscribe: boolean;
    unloadedType: ListItem[];
    unloadedBy: ListItem[];
    countedBy: ListItem[];
    stopServices: ListItem[];
    unitOfWeight: ListItem[];
    unitOfVolume: ListItem[];
    unitOfTemperature: ListItem[];
    isLoadedDropHook: boolean;
    departureDate: string;
    departureTime: string;
    departureTimestamp: string;
    unloadedDate: string;
    unloadedTime: string;
    inputNumberPattern: RegExp;
    findUnloadedEarlyRequest: IsLoadedEarly;
    isWarningOverride: boolean;
    stopSequenceNumber: number;
    operationalPlanNumber: string;
    editUnloadedForm: FormGroup;
    checkCallId: number;
    unloadedDetails: ViewActivityLogDetails;
    isHazmat: boolean;
    finalDestination: FinalDestination;
    dropEquipment: DropEquipmentDetail[];
    activityType: string;
    todayDate: Date;
    stopDetails: OperationalPlanStopDTO;
    unloadedTimeSelected: string;
    trailerOrContainer: ListItem[];
    chassis: PickUpDetails | any;
    loadOverviewDetails: LoadOverview;
    trailerOrContainerSelected: PickUpDetails;
    isUnloadedCheckCallDetails: boolean;
    trailingEquipmentGroup: any;
    status: RadioButtonValue[];
    showEquipmentGroup: boolean;
    equipmentGroupValue: EquipmentGroup;
    selectedStatus: string;
    equipmentPaired: any;
    fieldErrorList: Array<string>;
    unLoadedErrorTaskTypeName: any;
    onSelectTrailerOrContainer: boolean;
    timeZone: string;
    alphaNumericPattern: RegExp;
    checkCallNavigation: boolean;
    resourceOverview: ResourceOverview;
    isTracking: boolean;
    editFromTracking: boolean;
    trackingDetailsParam: TrackingDetailsParam;
    isReload: boolean;
    isTelematicsPickup: boolean;
    hasChassisEquip: boolean;
    chassisEquip: string;

    constructor() {
        this.isLoading = false;
        this.canSubscribe = true;
        this.unloadedType = [];
        this.unloadedBy = [];
        this.countedBy = [];
        this.stopServices = [];
        this.unitOfWeight = [];
        this.unitOfVolume = [];
        this.unitOfTemperature = [];
        this.isLoadedDropHook = false;
        this.commentsCount = 0;
        this.inputNumberPattern = /^[0-9]*$/;
        this.alphaNumericPattern = /^[a-zA-Z0-9 ]*$/;
        this.findUnloadedEarlyRequest = {
            unloadedTimestamp: '',
            operationalPlanID: null,
            operationalPlanStopID: null,
            isEdit: false
        };
        this.isWarningOverride = false;
        this.dropEquipment = [];
        this.activityType = '';
        this.todayDate = new Date();
        this.trailerOrContainer = [];
        this.chassis = null;
        this.trailerOrContainerSelected = null;
        this.equipmentGroupValue = {
            equipmentNumber: '',
            equipmentType: '',
            equipmentId: 0
        };
        this.selectedStatus = 'Active';
        this.fieldErrorList = [];
        this.unLoadedErrorTaskTypeName = {
            weight: 'unloaded call - weight is not equal to the specified unloaded weight',
            stopServices: 'unloaded call - stop service missing',
            unLoadedTime: 'unloaded call - unloaded time is outside the appointment window',
            unLoadedBy: 'unloaded call - missing mandatory attribute',
            BOLPRONo: 'unloaded call - reference number mismatch',
            trailingEquipment: 'unloaded call - trailing equipment is non-operational',
            trailingEquipNotAvailable: 'unloaded call - trailing equipment is not available',
            trailingEquipinWrongLocation: 'unloaded call - trailing equipment is in the wrong location'
        };
        this.onSelectTrailerOrContainer = false;
        this.timeZone = '';
        this.resourceOverview = null;
    }
}
