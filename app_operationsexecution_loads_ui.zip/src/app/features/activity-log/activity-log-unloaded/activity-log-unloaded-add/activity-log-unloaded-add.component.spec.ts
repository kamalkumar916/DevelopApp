import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { KeyFilterModule } from 'primeng/keyfilter';
import { TooltipModule } from 'primeng/tooltip';

import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { ActivityLogUnloadedAddComponent } from './activity-log-unloaded-add.component';
import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { GlobalPopupsModule } from '../../../../shared/global-popups/global-popups.module';
import { EquipmentGroupPopupModule } from '../../../../shared/equipment-group-popup/equipment-group-popup.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ActivityLogService } from '../../services/activity-log.service';
import { of } from 'rxjs/internal/observable/of';
import * as lodashUtils from 'lodash';
import { throwError } from 'rxjs';

describe('ActivityLogUnloadedAddComponent', () => {
  let component: ActivityLogUnloadedAddComponent;
  let fixture: ComponentFixture<ActivityLogUnloadedAddComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        JbhLoaderModule,
        CalendarModule,
        AutoCompleteModule,
        InputSwitchModule,
        DropdownModule,
        CheckboxModule,
        KeyFilterModule,
        ReactiveFormsModule,
        RouterTestingModule,
        TooltipModule,
        PipesModule,
        GlobalPopupsModule,
        DirectivesModule,
        EquipmentGroupPopupModule
      ],
      providers: [
        UserService,
        AppConfigService,
        MessageService,
        LocalStorageService
      ],
      declarations: [ActivityLogUnloadedAddComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogUnloadedAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('saveForm have been called', () => {
    spyOn(component, 'validateUnloadedCall');
    component.activityLogUnloadedAddModel.isLoading = false;
    component.saveForm();
    expect(component.validateUnloadedCall).toHaveBeenCalled();
  });

  it('onRemoveTrailerOrContainer have been called', () => {
    component.onRemoveTrailerOrContainer();
    expect(component.activityLogUnloadedAddModel.equipmentPaired.length).toBe(0);
  });

  it('onDepartureDateOrTimeClear have been called', () => {
    component.onDepartureDateOrTimeClear(true);
    expect(component.activityLogUnloadedAddModel.departureTimestamp).toBe('');
  });

  it('handleError have been called', () => {
    component.handleError(null);
    expect(component.activityLogUnloadedAddModel.isLoading).toBe(false);
  });

  it('getStringifyValue have been called', () => {
    const returnValue = component.getStringifyValue({ key: 'value' });
    expect(returnValue).toBe('{"key":"value"}');
  });

  it('titleCase have been called', () => {
    const returnValue = component.titleCase({ equipmentType: 'test' });
    expect(returnValue).toBe('Test');
  });

  it('getUpdatedEquipment have been called', () => {
    component.getUpdatedEquipment('test');
    expect(component.activityLogUnloadedAddModel.equipmentPaired).toBe('test');
  });


  it('onUnloadedDateOrTimeClear have been called', () => {
    component.onUnloadedDateOrTimeClear(true);
    expect(component.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedDate.value).toBe(null);
  });

  it('onUnloadedTypeSelected have been called', () => {
    component.activityLogUnloadedAddModel.isLoadedDropHook = false;
    component.onUnloadedTypeSelected({ 'label': 'abc', 'value': 'abc' });
    expect(component.activityLogUnloadedAddModel.trailerOrContainerSelected).toBe(null);
  });

  it('onTrailerOrContainerSelected have been called', () => {
    component.onTrailerOrContainerSelected(false);
    expect(component.activityLogUnloadedAddModel.trailerOrContainerSelected).toBe(null);
  });

  it('getUpdatedEquipment have been called', () => {
    component.getUpdatedEquipment(true);
    expect(component.activityLogUnloadedAddModel.equipmentPaired).toBe(true);
  });

  it('ActivityLogUnloadedAddComponent ngOnInit for isReload', () => {
    const reload = true;
    component.reload = reload;
    component.ngOnInit();
    expect(component.activityLogUnloadedAddModel.isLoading).toBe(true);
  });

  it('ActivityLogUnloadedAddComponent onUnloadedDateInputTyped should be called', () => {
    spyOn(component, 'checkIsLoadedLate').and.callThrough();
    spyOn(ActivityLogUtils, 'dateValidation').and.callThrough();
    const today = new Date();
    const tomorrow = new Date(today.setDate(today.getDate() + 1));
    component.activityLogUnloadedAddModel.addUnloadedForm.controls['unloadedDate'].setValue(tomorrow);
    component.onUnloadedDateInputTyped();
    expect(ActivityLogUtils.dateValidation).toHaveBeenCalled();
    expect(component.checkIsLoadedLate).toHaveBeenCalled();
  });

  it('ActivityLogUnloadedAddComponent checkIsLoadedLate should be called', () => {
    const isLoadedError = {
      timestamp: '',
      status: 0,
      error: '',
      exception: '',
      message: '',
      path: '',
    };
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getUnloadedDateTime').and.returnValue(of(isLoadedError));
    component.activityLogUnloadedAddModel.addUnloadedForm.controls['unloadedDate'].setValue(new Date());
    component.activityLogUnloadedAddModel.addUnloadedForm.controls['unloadedTime'].setValue('10:00 AM');
    component.checkIsLoadedLate();
    expect(activityLogService.getUnloadedDateTime).toHaveBeenCalled();

  });

  it('ActivityLogUnloadedAddComponent getCountedByData should be called', () => {
    const countedBy = {
      _embedded: {
        countedByPartyTypes: [{
          createTimestamp: '',
          createProgramName: '',
          lastUpdateProgramName: '',
          createUserId: '',
          lastUpdateUserId: '',
          countedByPartyTypeDescription: '',
          effectiveTimestamp: '',
          expirationTimestamp: '',
          lastUpdateTimestampString: '',
          _links: {
            self: { href: '' },
            countedByPartyType: { href: '' }
          }
        }]
      },
      _links: {
        self: {
          href: '',
          templated: false
        },
        profile: { href: '' }
      },
      page: {
        size: 0,
        totalElements: 0,
        totalPages: 0,
        number: 0,
      }
    };
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getCountedBy').and.returnValue(of(countedBy));
    component.getCountedByData();
    expect(activityLogService.getCountedBy).toHaveBeenCalled();
  });

  it('ActivityLogUnloadedAddComponent getUnitOfVolumeData should have been called', () => {
    const unitOfVolume = {
      _embedded: [{
        unitOfVolumeMeasurementCode: '',
        unitOfVolumeMeasurementDescription: '',
        lastUpdateTimestampString: '',
        _links: {
          self: { href: '' },
          unitOfVolumeMeasurement: { href: '' }
        }
      }],
      _links: {
        self: {
          href: '',
          templated: false
        },
        profile: { href: '' }
      },
      page: {
        size: 0,
        totalElements: 0,
        totalPages: 0,
        number: 0,
      }
    };
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getUnitOfVolume').and.returnValue(of(unitOfVolume));
    component.getUnitOfVolumeData();
    expect(activityLogService.getUnitOfVolume).toHaveBeenCalled();
  });

  it('ActivityLogUnloadedAddComponent getEquipmentInfo should be called', () => {
    const isReload = true;
    const trailerSelected = {
      equipmentId: 1,
      equipmentType: '',
      equipmentPrefix: '',
      equipmentNumber: ''
    };
    component.activityLogUnloadedAddModel.isReload = isReload;
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'getItem').and.callFake(function (unloadedForm, values) {
      if (unloadedForm === 'unloadedForm' && values === 'values') {
        return { departureTime: '', trailerSelected: trailerSelected, formDetails: {} };
      }
      return { departureTime: '' };
    });
    component.getEquipmentInfo();
    expect(localStorageService.getItem).toHaveBeenCalled();
  });

  it('ActivityLogUnloadedAddComponent onTrailerOrContainerSelected should be called', () => {
    const trailerOrContainer = {
      label: '',
      value: {
        equipmentId: 12345
      }
    };
    const dropEquipments = [{
      equipmentId: 12345,
      equipmentType: '',
      equipmentPrefix: '',
      equipmentNumber: '',
      stackedEquipmentList: {},
      equipmentCategory: '',
    }];
    component.activityLogUnloadedAddModel.dropEquipment = dropEquipments;
    spyOn(lodashUtils, 'find').and.returnValue(false);
    spyOn(component, 'getStackedEquipment').and.callThrough();
    component.onTrailerOrContainerSelected(trailerOrContainer);
    expect(component.activityLogUnloadedAddModel.trailerOrContainerSelected).toBeTruthy();
    expect(component.getStackedEquipment).toHaveBeenCalled();
  });

  it('ActivityLogUnloadedAddComponent onTrailerOrContainerSelected should be called for loadashUtils dind failed', () => {
    const trailerOrContainer = {
      label: '',
      value: {
        equipmentId: 12345
      }
    };
    const dropEquipments = [{
      equipmentId: 12345,
      equipmentType: '',
      equipmentPrefix: '',
      equipmentNumber: '',
      stackedEquipmentList: {},
      equipmentCategory: '',
    }];
    component.activityLogUnloadedAddModel.dropEquipment = dropEquipments;
    spyOn(lodashUtils, 'find').and.returnValue(true);
    spyOn(component, 'getStackedEquipment').and.callThrough();
    component.onTrailerOrContainerSelected(trailerOrContainer);
    expect(component.activityLogUnloadedAddModel.trailerOrContainerSelected).toBeNull();
  });

  it('ActivityLogUnloadedAddComponent getUnitOfTemperatureData should have been called', () => {
    const UnitOfTemperature = {
      _embedded: {
        unitOfTemperatureMeasurements: [{
          unitOfTemperatureMeasurementCode: '',
          unitOfTemperatureMeasurementDescription: '',
          lastUpdateTimestampString: '',
          _links: {
            self: { href: '' },
            unitOfTemperatureMeasurement: { href: '' }
          }
        }]
      },
      _links: {
        self: {
          href: '',
          templated: false
        },
        profile: { href: '' }
      },
      page: {
        size: 0,
        totalElements: 0,
        totalPages: 0,
        number: 0,
      }
    };
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getUnitOfTemperature').and.returnValue(of(UnitOfTemperature));
    spyOn(lodashUtils, 'isEmpty').and.returnValue(false);
    component.getUnitOfTemperatureData();
    expect(activityLogService.getUnitOfTemperature).toHaveBeenCalled();
  });

  it('ActivityLogUnloadedAddComponent getDropEquipment should be called', () => {
    component.reload = true;
    const resourceOverview = {
      driverId: '',
      equipmentId: 123,
      resourceStatus: '',
      truck: '',
      trailers: {},
      plannedLoads: 0,
      fleet: '',
      board: '',
      operationalStatus: '',
      emptyMiles: 0,
      drivingHoursRemainingAtReadyTime: 0,
      readyTime: '',
      readyLocation: {
        id: 0,
        locationName: '',
        locationCode: '',
        addressLine1: '',
        addressLine2: '',
        state: '',
        city: '',
        zipcode: '',
        country: '',
        latitude: 0,
        longitude: 0,
        locationContacts: [{}]
      },
      estimatedTimeOfCompletion: '',
      estimatedTimeOfArrival: '',
      timeOff: {},
      timeOfLocation: {},
      timeOffType: {},
      timeOffDate: {},
      numberOfDays: {},
      marketingArea: {},
      utilization: '',
      serviceFailures: {},
      type: [''],
      payType: [''],
      certifications: [{}],
      aobrStatusDurationHours: 0,
      aobrStatus: {},
      driveHours: 0,
      workHours: 0,
      onDutyHours: 0,
      aobrLastUpdated: 0,
      scheduleStart: {},
      previousSegementStatus: {},
      alphaCode: '',
      firstName: '',
      middleName: '',
      lastName: '',
      resourceName: '',
      preferredName: '',
      expirationDate: '',
      physicalExpirationDate: '',
      dotReviewDate: '',
      driverStatus: '',
      emptyMilesLimit: {},
      firstStopLocationId: 0,
      lastStopLocationId: 0,
      firstStopLattitude: 0,
      firstStopLongitude: 0,
      lastStopLattitude: 0,
      lastStopLongitude: 0,
      operationalPlanId: 0,
      endorsements: [{
        qualifierClass: '',
        qualifierType: '',
        expirationDate: ''
      }],
      originCityState: '',
      destinationCityState: '',
      suggestedBreak: '',
      fleetManager: {
        emplId: '',
        userId: '',
        firstName: '',
        middleName: '',
        lastName: '',
        prefName: '',
        personType: '',
        personSubType: '',
        isDriver: '',
        status: '',
        positionNbr: '',
        positionDescr: '',
        managerEmplId: '',
        managerName: '',
        departmentCode: '',
        costCenterID: '',
        businessUnit: '',
        jobCode: '',
        jobTitle: '',
        jobGroup: '',
        locationCode: '',
        locationDesc: '',
        phone: '',
        extenstion: '',
        email: ''
      },
      fleetCode: '',
      fleetName: '',
      safetyTerminal: '',
      totalLoadsHauledForTheWeek: '',
      totalMilesHauledForTheWeek: '',
      boardCode: '',
      recapHours: [0],
      lastLocation: '',
      currentLocation: '',
      lastLocationUpdatedTimeStamp: '',
      latitude: '',
      longitude: '',
      driverPlannedLoad: {},
      truckPlannedLoads: 0,
      maintenanceTerminal: '',
      maintenanceTerminalDescription: '',
      nextServiceDateandTime: '',
      nextServiceType: '',
      serviceAppointmentStatus: '',
      milesTillNextService: 0,
      secondSeatDriverDetails: {},
      currentLoadNumber: '',
      utilizationStatus: [{}],
      contactDetails: {
        homePhone: '',
        workPhone: {},
        email: {}
      }
    };
    component.resourceDetails = resourceOverview;
    const dropEquipments = [{
      equipmentAssociationId: {},
      equipmentId: 2,
      equipmentNumber: '',
      equipmentPrefix: '',
      stack: false,
      sequenceNumber: {},
      equipmentCategory: '',
      businessUnit: {},
      operationalGroupCode: {},
      operationalGroupDescription: {},
      equipmentType: '',
      equipmentStatus: '',
      trailingEquipmentStatus: '',
      length: '',
      width: '',
      height: '',
      equipmentMaintenanceStatus: '',
      equipmentMissing: {},
      equipmentAssociationGroupId: {},
      oldEquipmentAssociationGroupId: {},
      removeEquipment: {},
      locationDetails: {},
      stackedEquipmentList: {},
      links: [{}]
    }, {
      equipmentAssociationId: {},
      equipmentId: 3,
      equipmentNumber: '',
      equipmentPrefix: '',
      stack: false,
      sequenceNumber: {},
      equipmentCategory: '',
      businessUnit: {},
      operationalGroupCode: {},
      operationalGroupDescription: {},
      equipmentType: '',
      equipmentStatus: '',
      trailingEquipmentStatus: '',
      length: '',
      width: '',
      height: '',
      equipmentMaintenanceStatus: '',
      equipmentMissing: {},
      equipmentAssociationGroupId: {},
      oldEquipmentAssociationGroupId: {},
      removeEquipment: {},
      locationDetails: {},
      stackedEquipmentList: {},
      links: [{}]
    }
    ];
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getEquipmentDetails').and.callFake(function (equipmentId) {
      if (equipmentId === 123) {
        return of(dropEquipments);
      }
    });
    spyOn(component, 'getEquipmentInfo').and.callThrough();
    spyOn(ActivityLogUtils, 'getFormattedEquipment').and.callThrough();
    component.getDropEquipment(resourceOverview);
    expect(component.activityLogUnloadedAddModel.dropEquipment).toBeTruthy();
  });



  it('ActivityLogUnloadedAddComponent getDropEquipment should be called with service error', () => {
    const resourceOverview = {
      driverId: '',
      equipmentId: 123,
      resourceStatus: '',
      truck: '',
      trailers: {},
      plannedLoads: 0,
      fleet: '',
      board: '',
      operationalStatus: '',
      emptyMiles: 0,
      drivingHoursRemainingAtReadyTime: 0,
      readyTime: '',
      readyLocation: {
        id: 0,
        locationName: '',
        locationCode: '',
        addressLine1: '',
        addressLine2: '',
        state: '',
        city: '',
        zipcode: '',
        country: '',
        latitude: 0,
        longitude: 0,
        locationContacts: [{}]
      },
      estimatedTimeOfCompletion: '',
      estimatedTimeOfArrival: '',
      timeOff: {},
      timeOfLocation: {},
      timeOffType: {},
      timeOffDate: {},
      numberOfDays: {},
      marketingArea: {},
      utilization: '',
      serviceFailures: {},
      type: [''],
      payType: [''],
      certifications: [{}],
      aobrStatusDurationHours: 0,
      aobrStatus: {},
      driveHours: 0,
      workHours: 0,
      onDutyHours: 0,
      aobrLastUpdated: 0,
      scheduleStart: {},
      previousSegementStatus: {},
      alphaCode: '',
      firstName: '',
      middleName: '',
      lastName: '',
      resourceName: '',
      preferredName: '',
      expirationDate: '',
      physicalExpirationDate: '',
      dotReviewDate: '',
      driverStatus: '',
      emptyMilesLimit: {},
      firstStopLocationId: 0,
      lastStopLocationId: 0,
      firstStopLattitude: 0,
      firstStopLongitude: 0,
      lastStopLattitude: 0,
      lastStopLongitude: 0,
      operationalPlanId: 0,
      endorsements: [{
        qualifierClass: '',
        qualifierType: '',
        expirationDate: ''
      }],
      originCityState: '',
      destinationCityState: '',
      suggestedBreak: '',
      fleetManager: {
        emplId: '',
        userId: '',
        firstName: '',
        middleName: '',
        lastName: '',
        prefName: '',
        personType: '',
        personSubType: '',
        isDriver: '',
        status: '',
        positionNbr: '',
        positionDescr: '',
        managerEmplId: '',
        managerName: '',
        departmentCode: '',
        costCenterID: '',
        businessUnit: '',
        jobCode: '',
        jobTitle: '',
        jobGroup: '',
        locationCode: '',
        locationDesc: '',
        phone: '',
        extenstion: '',
        email: ''
      },
      fleetCode: '',
      fleetName: '',
      safetyTerminal: '',
      totalLoadsHauledForTheWeek: '',
      totalMilesHauledForTheWeek: '',
      boardCode: '',
      recapHours: [0],
      lastLocation: '',
      currentLocation: '',
      lastLocationUpdatedTimeStamp: '',
      latitude: '',
      longitude: '',
      driverPlannedLoad: {},
      truckPlannedLoads: 0,
      maintenanceTerminal: '',
      maintenanceTerminalDescription: '',
      nextServiceDateandTime: '',
      nextServiceType: '',
      serviceAppointmentStatus: '',
      milesTillNextService: 0,
      secondSeatDriverDetails: {},
      currentLoadNumber: '',
      utilizationStatus: [{}],
      contactDetails: {
        homePhone: '',
        workPhone: {},
        email: {}
      }
    };
    component.resourceDetails = resourceOverview;
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getEquipmentDetails').and.callFake(() => {
      return throwError(new Error('Fake error'));
    });
    // spyOn(component, 'getEquipmentInfo').and.callThrough();
    // spyOn(ActivityLogUtils, 'getFormattedEquipment').and.callThrough();
    component.getDropEquipment(resourceOverview);
    expect(component.activityLogUnloadedAddModel.dropEquipment).toEqual([]);
  });

});

