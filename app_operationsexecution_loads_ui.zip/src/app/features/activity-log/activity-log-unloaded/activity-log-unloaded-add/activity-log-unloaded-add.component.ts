import {
  Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef,
  Input, EventEmitter, Output, ViewChild
} from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { takeWhile, finalize } from 'rxjs/operators';
import { isEmpty, find } from 'lodash';
import { MessageService } from 'primeng/components/common/messageservice';
import { timer } from 'rxjs';
import * as moment from 'moment';

import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';

import { ActivityLogUnloadedAddService } from './services/activity-log-unloaded-add.service';
import { ActivityLogUnloadedAddUtils } from './services/activity-log-unloaded-add.utils';
import { ActivityLogUnloadedAddModel } from './model/activity-log-unloaded-add.model';
import {
  StopServices, CountedBy,
  OperationalPlanStopActivityPartyType,
  OperationalPlanStopActivityType
} from '../../activity-log-loaded/activity-log-loaded-add/model/activity-log-loaded-add.interface';
import { ListItem } from '../../../model/common.interface';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ActivityLogService } from '../../services/activity-log.service';
import { ErrorList, FinalDestination, ResourceOverview } from '../../models/activity-log.interface';
import { ArrivalDeviationRequest } from '../../activity-log-arrival/activity-log-arrival-add/model/activity-log-arrival-add.interface';
import { LoadOverview } from '../../../load-details/load-details-overview/model/load-overview.interface';
import { ActivityLogModel } from '../../models/activity-log.model';
import { AssetDetailQuery } from '../../../query/asset-detail.query';
import { EquipmentGroupItem } from '../../../tracking-details/model/tracking-details.interface';
@Component({
  selector: 'app-activity-log-unloaded-add',
  templateUrl: './activity-log-unloaded-add.component.html',
  styleUrls: ['./activity-log-unloaded-add.component.scss', '../../activity-log.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogUnloadedAddComponent implements OnInit, OnDestroy {
  activityLogUnloadedAddModel: ActivityLogUnloadedAddModel;
  constructor(private readonly fb: FormBuilder, private readonly activityLogService: ActivityLogService,
    private readonly changeDetector: ChangeDetectorRef, private readonly toastMessage: MessageService,
    private readonly activityLogUnloadedAddService: ActivityLogUnloadedAddService, private readonly router: Router,
    private readonly localStorageService: LocalStorageService, private readonly activatedRoute: ActivatedRoute) {
    this.activityLogUnloadedAddModel = new ActivityLogUnloadedAddModel();
  }
  @Input() set earlyLoadedRequest(data: ArrivalDeviationRequest) {
    if (data && data.operationalPlanID && data.operationalPlanStopID) {
      this.activityLogUnloadedAddModel.findUnloadedEarlyRequest.operationalPlanID = data.operationalPlanID;
      this.activityLogUnloadedAddModel.findUnloadedEarlyRequest.operationalPlanStopID = data.operationalPlanStopID;
      this.activityLogUnloadedAddModel.stopSequenceNumber = data.operationalPlanStopSequenceNumber ?
        data.operationalPlanStopSequenceNumber : null;
      this.activityLogUnloadedAddModel.operationalPlanNumber = data.operationalPlanNumber
        ? data.operationalPlanNumber : null;
      this.setFinalDestination();
    }
  }
  @Input() set overrideAllWarning(event: boolean) {
    this.activityLogUnloadedAddModel.isWarningOverride = event;
  }
  @Input() set loadDetails(loadOverviewDetails: LoadOverview) {
    if (loadOverviewDetails) {
      this.activityLogUnloadedAddModel.loadOverviewDetails = loadOverviewDetails;
      this.activityLogUnloadedAddModel.isHazmat = ActivityLogUtils.checkForHazmat(loadOverviewDetails);
      ActivityLogUtils.checkLocalStoreHazmat(this.activityLogUnloadedAddModel.addUnloadedForm, this.activityLogUnloadedAddModel.isHazmat,
      this.activityLogUnloadedAddModel.isReload);
    }
  }
  @Input() set stopInformation(stopInfo) {
    this.activityLogUnloadedAddModel.stopDetails = stopInfo;
    if (stopInfo && stopInfo.locationDetailsDTO && stopInfo.locationDetailsDTO.timezone) {
      this.activityLogUnloadedAddModel.timeZone = stopInfo.locationDetailsDTO.timezone;
    }
  }
  @Input() set resourceDetails(resourceOverview: ResourceOverview) {
    this.activityLogUnloadedAddModel.resourceOverview = resourceOverview;
    this.getDropEquipment(resourceOverview);
  }
  @Input() set reload(isReload: boolean) {
    if (isReload) {
      this.activityLogUnloadedAddModel.isReload = isReload;
    }
  }
  @Output() arrivalDeviationType: EventEmitter<ErrorList[]> = new EventEmitter<ErrorList[]>();
  @Output() equipmentList: EventEmitter<EquipmentGroupItem[]> = new EventEmitter<EquipmentGroupItem[]>();
  @ViewChild('volumeUnit') volumeUnit: any;
  @ViewChild('weightUnit') weightUnit: any;
  ngOnInit() {
    this.activityLogUnloadedAddModel.activityType = this.activatedRoute.queryParams['_value']['activityType'];
    this.activityLogUnloadedAddModel.addUnloadedForm = ActivityLogUtils.getLoadedUnloadedFormGroup(this.fb);
    this.getUnloadedFormGroup();
    this.getUnitOfVolumeData();
    this.getUnitOfWeightData();
    this.getUnitOfTemperatureData();
    if (this.activityLogUnloadedAddModel.isReload) {
      this.activityLogUnloadedAddModel.isLoading = true;
      this.getDropEquipment(this.activityLogUnloadedAddModel.resourceOverview);
    }
  }
  ngOnDestroy() {
    this.activityLogUnloadedAddModel.canSubscribe = false;
    if (this.activityLogUnloadedAddModel.addUnloadedForm) {
      this.activityLogUnloadedAddModel.addUnloadedForm.reset();
    }
  }
  validateFormFields(fieldName: string) {
    return (this.activityLogUnloadedAddModel.addUnloadedForm.controls[fieldName].invalid
      && this.activityLogUnloadedAddModel.addUnloadedForm.controls[fieldName].touched);
  }
  getUnloadedFormGroup() {
    this.activityLogUnloadedAddModel.addUnloadedForm.addControl('unloadedDate', new FormControl('', Validators.required));
    this.activityLogUnloadedAddModel.addUnloadedForm.addControl('unloadedTime', new FormControl('', Validators.required));
    this.activityLogUnloadedAddModel.addUnloadedForm.addControl('unloadedType', new FormControl('', Validators.required));
    this.activityLogUnloadedAddModel.addUnloadedForm.addControl('unloadedBy', new FormControl('', Validators.required));
  }
  onTextAreaType() {
    this.activityLogUnloadedAddModel.commentsCount = this.activityLogUnloadedAddModel.addUnloadedForm.controls.comments.value.length;
  }
  onUnloadedDateOrTimeClear(isDate: boolean, unloadedTime = null) {
    if (isDate) {
      this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedDate.reset();
    } else {
      this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedTime.reset();
      unloadedTime.overlayVisible = false;
    }
  }
  onUnloadedDateInputTyped() {
    this.activityLogUnloadedAddModel.unloadedDate =
      ActivityLogUtils.formatDateValue
        (this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedDate.value);
    if (this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedDate.value > new Date()) {
      ActivityLogUtils.dateValidation(this.activityLogUnloadedAddModel.addUnloadedForm, 'unloadedDate',
        this.toastMessage, 'Unloaded');
    }
    if (this.activityLogUnloadedAddModel.unloadedDate && this.activityLogUnloadedAddModel.unloadedTime) {
      ActivityLogUtils.checkUnloadedTime(this.activityLogUnloadedAddModel, false, this.toastMessage, 'Unloaded');
    }
    this.checkIsLoadedLate();
  }
  onUnloadedTimeInputTyped() {
    this.activityLogUnloadedAddModel.unloadedTime =
      ActivityLogUtils.formatTimeValue(this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedTime.value);
  }
  onUnloadedDateOrTimeChange(event, isDate: boolean) {
    event.overlayVisible = false;
    const dateObj = DateUtils.getTimeValue(event);
    if (isDate) {
      this.activityLogUnloadedAddModel.unloadedDate = ActivityLogUtils.formatDateValue(event);
      ActivityLogUtils.checkUnloadedTime(this.activityLogUnloadedAddModel, false,
        this.toastMessage, 'Unloaded');
    } else {
      if (!this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedTime.value) {
        this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedTime.setValue(moment(dateObj.withPm, ['hh:mm A']).toDate());
      }
      this.activityLogUnloadedAddModel.unloadedTime = dateObj.withoutPm;
      this.activityLogUnloadedAddModel.unloadedTimeSelected =
        ActivityLogUtils.formatTimeSelected(this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedTime.value);
      ActivityLogUtils.checkUnloadedTime(this.activityLogUnloadedAddModel, false,
        this.toastMessage, 'Unloaded');
    }
    if (this.activityLogUnloadedAddModel.unloadedDate && this.activityLogUnloadedAddModel.unloadedTime) {
      this.activityLogUnloadedAddModel.findUnloadedEarlyRequest.unloadedTimestamp = DateUtils.dateTimeZoneFormat(this.
        activityLogUnloadedAddModel.unloadedDate, this.activityLogUnloadedAddModel.unloadedTime, this.activityLogUnloadedAddModel.timeZone);
      if (this.activityLogUnloadedAddModel.activityType === 'unloaded') {
        this.checkIsLoadedLate();
      }

    }
  }
  checkIsLoadedLate() {
    if (this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedDate.valid &&
      this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedTime.valid) {
      this.activityLogService.getUnloadedDateTime(this.activityLogUnloadedAddModel.findUnloadedEarlyRequest).
        pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
        }, (error) => {
          ActivityLogUtils.arrivalError(error.error, this.toastMessage);
        });
    }
  }
  onDepartureDateOrTimeClear(isDate: boolean, departureTime = null) {
    if (isDate) {
      this.activityLogUnloadedAddModel.addUnloadedForm.controls.departureDate.reset();
    } else {
      this.activityLogUnloadedAddModel.addUnloadedForm.controls.departureTime.reset();
      departureTime.overlayVisible = false;
    }
    this.activityLogUnloadedAddModel.departureTimestamp = '';
  }
  onDepartureTimeInputTyped() {
    this.activityLogUnloadedAddModel.departureTime =
      ActivityLogUtils.formatTimeValue(this.activityLogUnloadedAddModel.addUnloadedForm.controls.unloadedTime.value);
  }
  onDepartureDateInputTyped() {
    this.activityLogUnloadedAddModel.departureDate =
      ActivityLogUtils.formatDateValue(this.activityLogUnloadedAddModel.addUnloadedForm.controls.departureDate.value);
  }
  onDepartureDateOrTimeChange(event, isDate: boolean) {
    event.overlayVisible = false;
    if (isDate) {
      this.activityLogUnloadedAddModel.departureDate = ActivityLogUtils.formatDateValue(event);
    } else {
      if (!this.activityLogUnloadedAddModel.addUnloadedForm.controls.departureTime.value) {
        this.activityLogUnloadedAddModel.addUnloadedForm.controls.departureTime.setValue(DateUtils.getTimeValue(event).withPm);
      }
      this.activityLogUnloadedAddModel.departureTime = DateUtils.getTimeValue(event).withoutPm;
    }
    if (this.activityLogUnloadedAddModel.departureDate && this.activityLogUnloadedAddModel.departureTime) {
      this.activityLogUnloadedAddModel.departureTimestamp = DateUtils.dateTimeZoneFormat(this.activityLogUnloadedAddModel.departureDate,
        this.activityLogUnloadedAddModel.departureTime, this.activityLogUnloadedAddModel.timeZone);
    }
  }
  getStopServicesData(stopService) {
    if (stopService && stopService.query) {
      this.activityLogService.getStopServices(stopService.query)
        .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data: StopServices) => {
          if (data && data._embedded && !isEmpty(data._embedded.operationalPlanServiceTypes)) {
            this.activityLogUnloadedAddModel.stopServices =
              ActivityLogUtils.getFormattedData(data._embedded.operationalPlanServiceTypes, 'operationalPlanServiceTypeDescription',
                'operationalPlanServiceTypeCode');
          }
        }, (error) => {
          this.activityLogUnloadedAddModel.stopServices = [];
        });
    }
  }
  getCountedByData() {
    this.activityLogService.getCountedBy()
      .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data: CountedBy) => {
        if (data && data._embedded && !isEmpty(data._embedded.countedByPartyTypes)) {
          this.activityLogUnloadedAddModel.countedBy = this.activityLogUnloadedAddModel.stopDetails &&
            this.activityLogUnloadedAddModel.stopDetails.operationalPlanStopReason ?
            ActivityLogUtils.getFormatedCountedByValue(data._embedded.countedByPartyTypes,
              this.activityLogUnloadedAddModel.stopDetails.operationalPlanStopReason) :
            ActivityLogUtils.getFormattedData(data._embedded.countedByPartyTypes,
              'countedByPartyTypeDescription', 'countedByPartyTypeCode');
        }
      }, (error) => {
        this.activityLogUnloadedAddModel.countedBy = [];
      });
  }
  getUnloadedByData() {
    this.activityLogService.getLoadedBy()
      .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data: OperationalPlanStopActivityPartyType) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityPartyTypes)) {
          this.activityLogUnloadedAddModel.unloadedBy = this.activityLogUnloadedAddModel.stopDetails &&
            this.activityLogUnloadedAddModel.stopDetails.operationalPlanStopReason ?
            ActivityLogUtils.getFormatedLoadedByValue(data._embedded.operationalPlanStopActivityPartyTypes,
              this.activityLogUnloadedAddModel.stopDetails.operationalPlanStopReason) :
            ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityPartyTypes,
              'operationalPlanStopActivityPartyTypeDescription', 'operationalPlanStopActivityPartyTypeCode');
        }
      }, (error) => {
        this.activityLogUnloadedAddModel.unloadedBy = [];
      });
  }
  getUnloadedTypeData() {
    this.activityLogService.getLoadedType()
      .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data: OperationalPlanStopActivityType) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityTypes)) {
          this.activityLogUnloadedAddModel.unloadedType =
            ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityTypes,
              'operationalPlanStopActivityTypeDescription', 'operationalPlanStopActivityTypeCode');
        }
      }, (error) => {
        this.activityLogUnloadedAddModel.unloadedType = [];
      });
  }
  onUnloadedTypeSelected(event: ListItem) {
    this.activityLogUnloadedAddModel.isLoadedDropHook = event.value.toLowerCase() === 'drpandhook';
    if (!this.activityLogUnloadedAddModel.isLoadedDropHook) {
      if (this.activityLogUnloadedAddModel.addUnloadedForm.get('dropEquipmentDetails')) {
        this.activityLogUnloadedAddModel.addUnloadedForm.removeControl('dropEquipmentDetails');
      }
      if (this.activityLogUnloadedAddModel.addUnloadedForm.get('trailerOrContainer')) {
        this.activityLogUnloadedAddModel.addUnloadedForm.removeControl('trailerOrContainer');
      }
      this.activityLogUnloadedAddModel.trailerOrContainerSelected = null;
      this.activityLogUnloadedAddModel.equipmentPaired = [];
    } else {
      this.activityLogUnloadedAddModel.addUnloadedForm.addControl('dropEquipmentDetails', new FormGroup({}));
      this.activityLogUnloadedAddModel.dropEquipment.forEach((dropequipment, i) => {
        this.activityLogUnloadedAddModel.addUnloadedForm.controls.dropEquipmentDetails
        ['addControl'](i, new FormControl([]));
      });
      this.activityLogUnloadedAddModel.addUnloadedForm.addControl('trailerOrContainer', new FormControl(''));
    }
  }
  getUnitOfVolumeData() {
    this.activityLogService.getUnitOfVolume()
      .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfVolumeMeasurements)) {
          this.activityLogUnloadedAddModel.unitOfVolume =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfVolumeMeasurements, 'unitOfVolumeMeasurementDescription',
              'unitOfVolumeMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogUnloadedAddModel.addUnloadedForm,
            'volumeUnits', { volume: '', units: 'Gallons' });
          this.volumeUnit.filled = true;
        }
      }, (error) => {
        this.activityLogUnloadedAddModel.unitOfVolume = [];
      });
  }
  getUnitOfWeightData() {
    this.activityLogService.getUnitOfWeight()
      .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfWeightMeasurements)) {
          this.activityLogUnloadedAddModel.unitOfWeight =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfWeightMeasurements, 'unitOfWeightMeasurementDescription',
              'unitOfWeightMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogUnloadedAddModel.addUnloadedForm,
            'weightUnits', { weight: '', units: 'Pounds' });
          this.weightUnit.filled = true;
        }
      }, (error) => {
        this.activityLogUnloadedAddModel.unitOfWeight = [];
      });
  }
  getUnitOfTemperatureData() {
    this.activityLogService.getUnitOfTemperature()
      .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfTemperatureMeasurements)) {
          this.activityLogUnloadedAddModel.unitOfTemperature =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfTemperatureMeasurements, 'unitOfTemperatureMeasurementDescription',
              'unitOfTemperatureMeasurementCode');
        }
      }, (error) => {
        this.activityLogUnloadedAddModel.unitOfTemperature = [];
      });
  }
  saveForm() {
    if (!this.activityLogUnloadedAddModel.isLoading) {
      this.validateUnloadedCall();
      if (this.activityLogUnloadedAddModel.addUnloadedForm.valid) {
        this.changeDetector.detectChanges();
        const addUnloadedRequestInput = ActivityLogUtils.frameUnloadedRequest(this.activityLogUnloadedAddModel);
        const addUnloadedReq = this.isValidRequest(addUnloadedRequestInput);
        if (addUnloadedReq) {
          this.addUnloadedActivity(addUnloadedReq);
        }
      } else {
        ActivityLogUtils.checkUnloadedFormValidity(this.toastMessage, this.activityLogUnloadedAddModel.addUnloadedForm,
          this.activityLogUnloadedAddModel, false, this.arrivalDeviationType, this.changeDetector);
      }
    }
  }
  addUnloadedActivity(addUnloadedReq) {
    if (addUnloadedReq.resourceDetails.value) {
      this.activityLogUnloadedAddModel.isLoading = true;
      this.changeDetector.detectChanges();
      this.activityLogUnloadedAddService.addUnloadedDetails(addUnloadedReq)
        .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
          finalize(() => {
            this.activityLogUnloadedAddModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data) {
            ActivityLogUtils.successMessage(this.toastMessage, 'Unloaded', 'added');
            timer(ActivityLogModel.addSaveTimer).subscribe(() => {
              this.navigateToParent();
            });
          }
        }, (error) => {
          this.handleError(error);
        });
    } else {
      this.toastMessage.clear();
      ActivityLogUtils.resourceFieldError(this.toastMessage);
    }
  }
  handleError(error) {
    this.activityLogUnloadedAddModel.isLoading = false;
    if (ActivityLogUtils.handleErrorAndNull(error, this.toastMessage)) {
      ActivityLogUtils.checkRuleValidationError(error.error.errors,
         this.activityLogUnloadedAddModel.addUnloadedForm,
         this.arrivalDeviationType, this.changeDetector);
      this.arrivalDeviationType.emit(error.error.errors);
    }
  }
  isValidRequest(addUnloadedRequestInput) {
      return ActivityLogUnloadedAddUtils.createAddUnloadedRequest(this.activityLogUnloadedAddModel.addUnloadedForm,
        addUnloadedRequestInput, this.activityLogUnloadedAddModel.resourceOverview);
  }
  validateUnloadedCall() {
    ActivityLogUnloadedAddUtils.mandatoryFieldsCheck(this.activityLogUnloadedAddModel.addUnloadedForm);
    FormValidationUtils.validateAllFormFields(this.activityLogUnloadedAddModel.addUnloadedForm);
    this.changeDetector.detectChanges();
  }
  onUnloadedBySelect(selectedUnloadedBy: ListItem) {
    const driver = { value: 'DrvrUnLd', label: 'Driver Unloads Freight' };
    const lumper = { value: 'LmpUnldFrg', label: 'Lumper Unloads Freight' };
    const driverLumperValue = ['driver unloads freight', 'lumper unloads freight'];
    ActivityLogUtils.setStopServiceSelectedValue(selectedUnloadedBy, driver, lumper,
      driverLumperValue, this.activityLogUnloadedAddModel.addUnloadedForm);
  }
  onCountedBySelect(selectedCountedBy: ListItem) {
    const countsDriver = { label: 'Driver Counts Freight', value: 'DrvrCount' };
    const countsLumper = { label: 'Lumper Counts Freight', value: 'LumpCntFrg' };
    const driverLumperValue = ['driver counts freight', 'lumper counts freight'];
    ActivityLogUtils.setStopServiceSelectedValue(selectedCountedBy, countsDriver, countsLumper,
      driverLumperValue, this.activityLogUnloadedAddModel.addUnloadedForm);
  }
  navigateToParent() {
    if (this.router.url && this.router.url.indexOf('/trackingdetails') !== -1) {
      this.router.navigate(['/trackingdetails'], { queryParams: this.localStorageService.getItem('TrackingDetails', 'param') });
    } else {
      this.router.navigate(['/loaddetails', this.activityLogUnloadedAddModel.findUnloadedEarlyRequest.operationalPlanID],
        { queryParams: { index: 2 } });
    }
  }
  setFinalDestination() {
    if (this.activityLogUnloadedAddModel.findUnloadedEarlyRequest.operationalPlanID) {
      this.activityLogService.getFinalDestination(this.activityLogUnloadedAddModel.findUnloadedEarlyRequest.operationalPlanID)
        .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data: FinalDestination) => {
          this.activityLogUnloadedAddModel.finalDestination = data ? data : null;
        }, (error) => {
          this.activityLogUnloadedAddModel.finalDestination = null;
        });
    }
  }
  getDropEquipment(resourceOverview: ResourceOverview) {
    if (resourceOverview && resourceOverview.equipmentId) {
      this.activityLogService.getEquipmentDetails(resourceOverview.equipmentId)
        .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.length > 1) {
            this.activityLogUnloadedAddModel.dropEquipment = ActivityLogUtils.getFormattedEquipment(data.slice(1));
            if (this.activityLogUnloadedAddModel.isReload) {
              this.activityLogUnloadedAddModel.isLoading = false;
              this.getEquipmentInfo();
            }
          }
        }, (error) => {
          this.activityLogUnloadedAddModel.dropEquipment = [];
        });
    }
  }
  getEquipmentInfo() {
    if (this.localStorageService.getItem('unloadedForm', 'values') && this.activityLogUnloadedAddModel.isReload) {
      const loadedFormValue = this.localStorageService.getItem('unloadedForm', 'values');
      this.activityLogUnloadedAddModel.addUnloadedForm.patchValue(loadedFormValue.formDetails);
      this.activityLogUnloadedAddModel.trailerOrContainerSelected = loadedFormValue.trailerSelected;
      this.activityLogUnloadedAddModel.departureTimestamp = loadedFormValue.departureTime;
    }
    if (this.localStorageService.getItem('unloadedpairedEquipment', 'values') && this.activityLogUnloadedAddModel.isReload) {
      this.activityLogUnloadedAddModel.equipmentPaired = this.localStorageService.getItem('unloadedpairedEquipment', 'values');
    }
  }
  getStringifyValue(dropEquipment) {
    return JSON.stringify(dropEquipment);
  }
  getTrailerOrContainerData(trailerOrContainer) {
    if (trailerOrContainer && trailerOrContainer.query) {
      const q = AssetDetailQuery.getContainerOrTrailer(trailerOrContainer.query);
      this.activityLogService.getTrailerOrContainer(q)
        .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.hits && data.hits.hits && data.hits.hits.length > 0) {
            this.activityLogUnloadedAddModel.trailerOrContainer =
              ActivityLogUtils.getTrailerOrContainer(data.hits.hits);
          } else {
            this.activityLogUnloadedAddModel.trailerOrContainer = [];
            this.activityLogUnloadedAddModel.addUnloadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
          }
        }, (error) => {
          this.activityLogUnloadedAddModel.trailerOrContainer = [];
        });
    }
  }
  onRemoveTrailerOrContainer() {
    this.activityLogUnloadedAddModel.chassis = null;
    this.activityLogUnloadedAddModel.trailerOrContainerSelected = null;
    this.activityLogUnloadedAddModel.addUnloadedForm.get('trailerOrContainer').reset();
    this.activityLogUnloadedAddModel.equipmentPaired = [];
  }
  onTrailerOrContainerSelected(selectedTrailerOrContainer) {
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId) {
      if (!find(this.activityLogUnloadedAddModel.dropEquipment,
        ['equipmentNumber', selectedTrailerOrContainer.value.equipmentNumber])) {
        this.activityLogUnloadedAddModel.trailerOrContainerSelected = selectedTrailerOrContainer;
        this.getStackedEquipment(selectedTrailerOrContainer);
      } else {
        this.activityLogUnloadedAddModel.trailerOrContainerSelected = null;
        this.toastMessage.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Select valid Equipment Details'
        });
        this.activityLogUnloadedAddModel.addUnloadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
        this.activityLogUnloadedAddModel.addUnloadedForm.get('trailerOrContainer').markAsTouched();
        this.changeDetector.detectChanges();
      }
    } else {
      this.activityLogUnloadedAddModel.trailerOrContainerSelected = null;
    }
  }
  getStackedEquipment(selectedTrailerOrContainer) {
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId) {
      this.activityLogUnloadedAddModel.isLoading = true;
      this.activityLogService.getEquipmentDetails(selectedTrailerOrContainer.value.equipmentId)
        .pipe(takeWhile(() => this.activityLogUnloadedAddModel.canSubscribe),
          finalize(() => {
            this.activityLogUnloadedAddModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: EquipmentGroupItem[]) => {
          if (data && data.length > 0) {
            this.onSelectingEquipmentDetails(data, selectedTrailerOrContainer.value.equipmentId);
            this.equipmentList.emit(data);
          }
        }, (error) => {
          this.activityLogUnloadedAddModel.equipmentGroupValue = null;
          this.activityLogUnloadedAddModel.status = [];
        });
    }
  }
  titleCase(dropEquipment) {
    let equipmentLabel = '';
    if (dropEquipment && dropEquipment.equipmentType) {
      equipmentLabel = `${dropEquipment.equipmentType.slice(0, 1).toUpperCase()}${dropEquipment.equipmentType.slice(1).toLowerCase()}`;
    }
    return equipmentLabel;
  }
  onSelectingEquipmentDetails(response, equipmentId) {
    if (response.length > 1) {
      this.activityLogUnloadedAddModel.showEquipmentGroup = true;
      this.activityLogUnloadedAddModel.trailingEquipmentGroup = response;
      const selectedEquipmentDetails = this.frameStackedEquipment(equipmentId);
      this.activityLogUnloadedAddModel.status = [{ label: 'Add this group to selected Equipment', value: 'Active' },
      {
        label: `Remove the ${selectedEquipmentDetails.equipmentType.charAt(0)
          + selectedEquipmentDetails.equipmentType.slice(1).toLowerCase()}
            ${selectedEquipmentDetails
            .equipmentPrefix}${selectedEquipmentDetails.equipmentNumber} from the Group and
          Add it to the selected Equipment`, value: 'Inactive'
      }];
    }
  }
  getUpdatedEquipment(event) {
    this.activityLogUnloadedAddModel.equipmentPaired = event;
  }
  getZoneFormat() {
    return ActivityLogUtils.getZoneFormat(this.activityLogUnloadedAddModel.timeZone);
  }
  frameStackedEquipment(equipmentId) {
    let selectedEquipmentDetails;
    this.activityLogUnloadedAddModel.trailingEquipmentGroup.forEach((equimentItem => {
      if (equimentItem.equipmentId === equipmentId) {
        selectedEquipmentDetails = equimentItem;
        this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentNumber = equimentItem.equipmentNumber;
        this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentType = equimentItem.equipmentType;
        this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentPrefix = equimentItem.equipmentPrefix;
        this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentId = equimentItem.equipmentId;
      } else {
        equimentItem.stackedEquipmentList.forEach(stackedItem => {
          if (stackedItem.equipmentId === equipmentId) {
            selectedEquipmentDetails = stackedItem;
            this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentNumber = stackedItem.equipmentNumber;
            this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentType = stackedItem.equipmentType;
            this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentPrefix = stackedItem.equipmentPrefix;
            this.activityLogUnloadedAddModel.equipmentGroupValue.equipmentId = stackedItem.equipmentId;
          }
        });
      }
    }));
    return selectedEquipmentDetails;
  }
}
