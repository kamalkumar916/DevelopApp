import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { configureTestSuite } from 'ng-bullet';
import { MessageService } from 'primeng/components/common/messageservice';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DropdownModule } from 'primeng/dropdown';
import { KeyFilterModule } from 'primeng/keyfilter';
import { CheckboxModule } from 'primeng/checkbox';
import { TooltipModule } from 'primeng/tooltip';

import { AppSharedDataService } from '../../../../shared/jbh-app-services/app-shared-data.service';
import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { ActivityLogUnloadedEditComponent } from './activity-log-unloaded-edit.component';
import { ActivityLogLocationDetailsComponent } from '../../activity-log-location-details/activity-log-location-details.component';
import { GlobalPopupsModule } from './../../../../shared/global-popups/global-popups.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { EquipmentGroupPopupModule } from '../../../../shared/equipment-group-popup/equipment-group-popup.module';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { ActivityLogUnloadedAddUtils } from '../activity-log-unloaded-add/services/activity-log-unloaded-add.utils';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { ActivityLogService } from '../../services/activity-log.service';

const getStopServicesData = {
  _embedded: {
    operationalPlanServiceTypes: [{
      effectiveTimestamp: '2018-01-01T00:00:00Z',
      expirationTimestamp: '2199-12-31T23:59:59Z',
      operationalPlanServiceCategory: {
        effectiveTimestamp: '2018-01-01T00:00:00Z',
        expirationTimestamp: '2199-12-31T23:59:59Z',
        lastUpdateTimestampString: '2019-09-28T00:25:28.4374182',
        operationalPlanServiceCategoryDescription: 'Stop Level Service',
      },
      operationalPlanServiceTypeCode: 'BlockBrace',
      operationalPlanServiceTypeDescription: 'Block and Brace',
      links: {
        operationalPlanServiceType: {
          href: '',
          templated: true,
        },
        self: {
          href: '',
        },
      },
    }],
  },
  _links: {
    self: {
      href: '',
    },
  },
};

class MockactivityLogService {
  constructor() { }
  getStopServices() {
    return of(getStopServicesData);
  }
  getCountedBy() {
    return throwError(null);
  }
  getLoadedBy() {
    return throwError(null);
  }
  getCheckCallDetails() {
    return throwError(null);
  }
  getCheckCallErrors() {
    return throwError(null);
  }
  getUnitOfVolume() {
    return throwError(null);
  }
  getUnitOfWeight() {
    return throwError(null);
  }
  getUnitOfTemperature() {
    return throwError(null);
  }
  getLoadedType() {
    return throwError(null);
  }
  getTrailerOrContainer() {
    return throwError(null);
  }
  getEquipmentDetails() {
    return throwError(null);
  }
  getUnloadedDateTime() {
    return throwError(null);
  }
}
const addressData = {
  addressLine1: '',
  addressLine2: '',
  city: '',
  state: '',
  zipcode: '',
  country: '',
  countryName: '',
  id: 123,
  timeZone: '',
};
const locationalDetaildata = {
  locationId: 123,
  locationName: '',
  locationCode: '',
  address: addressData,
};
const OperationalPlanStopDetailsdata = {
  operationalPlanStopSequenceNumber: 123,
  operationalPlanStopReasonCode: '',
  operationalPlanStopReasonCodeDescription: '',
  locationDetails: locationalDetaildata,
  appointmentStartTimestamp: '',
  appointmentEndTimestamp: '',
  stopSequenceDescription: '',
  operationalPlanStopId: 123,
};
const WeightDetaildata = {
  weight: 123,
  unitOfWeightMeasurement: 'test',
};
const VolumeDetailData = {
  volume: 123,
  unitOfVolumeMeasurement: 'test',
};
const TemperatureDetailData = {
  temperature: 123,
  unitOfTemperatureMeasurement: 'test',
};
const PickUpDetailsData = [{
  equipmentId: 123,
  equipmentType: '',
  equipmentPrefix: '',
  equipmentNumber: '',
  oldTruckId: 123,
  equipmentCategory: '',
}];
const testData = {
  operationalPlanCheckCallId: 123,
  operationalPlanStopId: 123,
  operationalPlanId: 123,
  arrivalDateTime: '',
  operationalPlanStopDetails: OperationalPlanStopDetailsdata,
  lastUpdateProgramName: '',
  lastUpdatedUserId: '',
  lastUpdatedOn: '',
  loadedTimestamp: '',
  proNumber: 123,
  weight: WeightDetaildata,
  volume: VolumeDetailData,
  temperature: TemperatureDetailData,
  loadedBy: '',
  loadedType: '',
  unloadedBy: '',
  unloadedType: '',
  unloadedTimestamp: '2019-10-21T15:00:00-05:00',
  count: 123,
  countedBy: '',
  sealNumber: '',
  bolNumber: '',
  poNumbers: [],
  shipperIdentificationNumber: '',
  receiverStateId: 123,
  receiverStateName: '',
  hazmatIndicator: 'test',
  comments: '',
  lastUpdatedTimestamp: '',
  departureTimestamp: '',
  pickupEquipmentDetails: PickUpDetailsData,
  dropEquipmentDetails: PickUpDetailsData,
  stopServicesTypeCodes: [],
  stopServices: [],
};

const getLoadOverviewData = {
  items: '',
  operationalGroupCode: '',
  bulkProcessIndicator: 'No',
  chassis: null,
  classifications: [],
  committedFreightIndicator: null,
  container: null,
  desirabilityIndexNumber: 0,
  emptyMiles: null,
  equipmentDetails: null,
  estimatedTimeOfCompletion: null,
  estimatedTotalMiles: '2898 Miles',
  externalOperationalPlanBoardIndicator: 'N',
  jbhuntFailureCount: null,
  loadedMiles: '',
  loadedMilesWithUnit: '2898 Miles',
  networkOperationalPlanIndicator: 'N',
  operationalPlanAdditionalInstructionDTOs: [],
  operationalPlanCommentDTOs: [],
  operationalPlanFinanceBusinessUnitCode: 'DCS',
  operationalPlanId: 456,
  operationalPlanNumber: 'L456',
  operationalPlanResourceAssignmentSequenceNumber: 1,
  operationalPlanRouteGuideStatus: null,
  operationalPlanServiceOfferingCode: 'Dedicated',
  operationalPlanTransitModeCode: 'Truck',
  payRoute: null,
  requestedService: [],
  requiredEquipment: null,
  resource: null,
  routeId: '182',
  routePlanId: '183',
  routeSequenceNumber: '1',
  servicePriorityCode: 'standard',
  splitLoadApplicable: false,
  totalPointsQuantity: '',
  totalRouteSequenceNumber: null,
  totalWeight: '0.00',
  trailer: null,
  tripPlanTransitValue: null,
  truck: null,
  unitOfWeightMeasurementCode: 'lbs',
  billTo: [],
  customerRate: [],
  operationalPlanGroupDTO: {
    operationalGroupTypeCode: 'Fleet',
    operationalPlanGroupCode: 'DC',
    operationalPlanGroupDescription: 'SIMMONS'
  },
  operationalPlanOrderIds: [1],
  operationalPlanOwnershipDTOs: [],
  operationalPlanReferenceNumberDTOs: [],
  operationalPlanStatus: {
    operationalPlanStatusCode: 'Completed',
    operationalPlanStatusDescription: 'Completed'
  },
  operationalPlanStopDTOs: [],
  operationalPlanSubtype: {
    operationalPlanSubtypeCode: 'FTL',
    operationalPlanSubtypeDescription: 'Full Truck Load'
  },
  operationalPlanType: {
    operationalPlanTypeCode: 'Freight',
    operationalPlanTypeDescription: 'Freight'
  },
  payRouteLists: [],
  resourceDetails: {
    alphaCode: null,
    aobrStatus: null,
    aobrStatusDurationHours: null,
    boardCode: null,
    boardName: null,
    certifications: null,
    currentLocation: null,
    driveHours: null,
    driverId: null,
    driverPlannedLoads: null,
    drivingHoursRemainingAtReadyTime: null,
    emptyMiles: null,
    endorsements: null,
    equipmentId: null,
    estimatedTimeOfCompletion: null,
    firstName: null,
    fleetCode: null,
    fleetManager: null,
    fleetName: null,
    lastLocation: null,
    lastName: null,
    liveEquipments: [],
    maintenanceTerminal: null,
    marketingArea: null,
    middleName: null,
    milesTillNextService: null,
    nextServiceDateandTime: null,
    nextServiceType: null,
    onDutyHours: null,
    operationalStatus: null,
    payType: null,
    plannedLoads: null,
    preferredName: null,
    previousSegmentStatus: null,
    readyLocation: null,
    readyTime: null,
    recapHours: null,
    resourceName: null,
    resourcePlanType: null,
    resourceStatus: null,
    serviceAppointmentStatus: null,
    serviceFailures: null,
    suggestedBreak: null,
    timeOfLocation: null,
    timeOff: null,
    totalLoadsHauledForTheWeek: null,
    totalMilesHauledForTheWeek: null,
    trailers: null,
    truck: '2925',
    truckPlannedLoads: null,
    type: null,
    utilization: null,
    workHours: null
  },
  shipmentId: [],
  taskReason: [],
  utilization: {
    utilizationStatusCode: 'OTR',
    utilizationStatusDescription: 'Over The Road',
  }
};

describe('ActivityLogUnloadedEditComponent', () => {
  let component: ActivityLogUnloadedEditComponent;
  let fixture: ComponentFixture<ActivityLogUnloadedEditComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        CalendarModule,
        AutoCompleteModule,
        InputSwitchModule,
        DropdownModule,
        JbhLoaderModule,
        KeyFilterModule,
        ReactiveFormsModule,
        CheckboxModule,
        PipesModule,
        TooltipModule,
        GlobalPopupsModule,
        EquipmentGroupPopupModule,
        DirectivesModule],
      providers: [
        MessageService,
        AppConfigService,
        DatePipe,
        AppSharedDataService,
        LocalStorageService,
        {
          provide: ActivityLogService,
          useClass: MockactivityLogService
        },
      ],
      declarations: [
        ActivityLogUnloadedEditComponent,
        ActivityLogLocationDetailsComponent
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogUnloadedEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onRemoveTrailerOrContainer have been called', () => {
    component.onRemoveTrailerOrContainer();
    expect(component.activityLogUnloadedEditModel.equipmentPaired.length).toBe(0);
  });

  it('unLoadedFinalizeMethod have been called', () => {
    component.unLoadedFinalizeMethod();
    expect(component.activityLogUnloadedEditModel.isLoading).toBe(false);
  });

  it('onUnloadedDateOrTimeClear have been called', () => {
    component.onUnloadedDateOrTimeClear(true);
    expect(component.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedDate.value).toBe(null);
  });

  it('onUnloadedDateOrTimeClear have been called', () => {
    component.onUnloadedDateOrTimeClear(false, { overlayVisible: true });
    expect(component.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.value).toBe(null);
  });

  it('onDepartureDateOrTimeClear have been called', () => {
    component.onDepartureDateOrTimeClear(true);
    expect(component.activityLogUnloadedEditModel.editUnloadedForm.controls.departureDate.value).toBe(null);
  });

  it('onDepartureDateOrTimeClear have been called', () => {
    component.onDepartureDateOrTimeClear(false, { overlayVisible: true });
    expect(component.activityLogUnloadedEditModel.editUnloadedForm.controls.departureTime.value).toBe(null);
  });

  it('getUnloadedCheckcallDetails have been called', () => {
    spyOn(component, 'getCheckCallData');
    component.getUnloadedCheckcallDetails(123, 'abc');
    expect(component.activityLogUnloadedEditModel.isLoading).toBe(true);
  });

  it('hasTelematicsPickupDetails have been called', () => {
    spyOn(component.hasTelematicsPickup, 'emit');
    component.hasTelematicsPickupDetails();
    expect(component.hasTelematicsPickup.emit).toHaveBeenCalled();
  });

  it('onDepartureDateInputTyped have been called', () => {
    spyOn(ActivityLogUtils, 'formatDateValue').and.returnValue('abc');
    component.activityLogUnloadedEditModel.departureTime = 'abcd';
    component.onDepartureDateInputTyped();
    expect(component.activityLogUnloadedEditModel.departureTimestamp).toBe('');
  });

  it('onDepartureTimeInputTyped have been called', () => {
    spyOn(ActivityLogUtils, 'formatDateValue').and.returnValue('abc');
    component.activityLogUnloadedEditModel.departureDate = 'abcd';
    component.onDepartureTimeInputTyped();
    expect(component.activityLogUnloadedEditModel.departureTimestamp).toBe('');
  });

  it('sequenceNumber have been called', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.sequenceNumber({ stopSequenceNumber: '1', stopId: '', destinationHeader: '' });
    expect(component.stopSequenceNumber.emit).toHaveBeenCalled();
  });

  it('getDefaultCheckCallStopServices have been called', () => {
    spyOn(component, 'onUnloadedBySelect');
    spyOn(component, 'onCountedBySelect');
    component.getDefaultCheckCallStopServices({ unloadedBy: '1' });
    expect(component.onUnloadedBySelect).toHaveBeenCalled();
  });

  it('getDefaultCheckCallStopServices have been called', () => {
    spyOn(component, 'onCountedBySelect');
    spyOn(component, 'onUnloadedBySelect');
    component.getDefaultCheckCallStopServices({ countedBy: '1' });
    expect(component.onCountedBySelect).toHaveBeenCalled();
  });

  it('handleError have been called', () => {
    component.handleError('abc');
    expect(component.activityLogUnloadedEditModel.isLoading).toBe(false);
  });

  it('onTrailerOrContainerSelected have been called', () => {
    spyOn(component, 'getStackedEquipment');
    component.onTrailerOrContainerSelected('abc');
    expect(component.activityLogUnloadedEditModel.isTelematicsPickup).toBe(false);
  });

  it('getEquipmentInfo have been called', () => {
    spyOn(component, 'onSelectUnLoadedType');
    component.getEquipmentInfo();
    expect(component.onSelectUnLoadedType).toHaveBeenCalled();
  });

  it('getUpdatedEquipment have been called', () => {
    component.getUpdatedEquipment('abc');
    expect(component.activityLogUnloadedEditModel.equipmentPaired).toBe('abc');
  });

  it('fromCheckCallPage have been set true ', () => {
    const test = {
      isCheckCallTracking: true,
      checkCallNavigation: true,
      isTracking: true,
    };
    component.fromCheckCallPage = test;
    expect(component.activityLogUnloadedEditModel.isTracking).toBeTruthy();
  });

  it('isReload have been set true ', () => {
    component.reload = true;
    expect(component.activityLogUnloadedEditModel.isReload).toBe(true);
  });

  it('editFromTracking have been set true ', () => {
    component.editFromTracking = true;
    expect(component.activityLogUnloadedEditModel.editFromTracking).toBe(true);
  });

  it('trackingParam have been set param', () => {
    const param = {
      equipmentId: 0
    };
    component.trackingParam = param;
    expect(component.activityLogUnloadedEditModel.trackingDetailsParam).toBe(param);
  });

  it('overrideAllWarning have been set true', () => {
    component.overrideAllWarning = true;
    expect(component.activityLogUnloadedEditModel.isWarningOverride).toBe(true);
  });

  it('onUnloadedDateOrTimeChange have been set', () => {
    spyOn(DateUtils, 'getTimeValue');
    spyOn(ActivityLogUtils, 'formatDateValue');
    spyOn(ActivityLogUtils, 'checkUnloadedTime');
    spyOn(ActivityLogUtils, 'formatTimeSelected');
    spyOn(component, 'checkIsLoadedLate');
    component.onUnloadedDateOrTimeChange({}, true);
    expect(DateUtils.getTimeValue).toHaveBeenCalled();
  });

  it('onUnloadedDateInputTyped have been set', () => {
    spyOn(ActivityLogUtils, 'formatDateValue');
    spyOn(ActivityLogUtils, 'dateValidation');
    spyOn(ActivityLogUtils, 'checkUnloadedTime');
    spyOn(component, 'checkIsLoadedLate');
    component.onUnloadedDateInputTyped();
    expect(component.checkIsLoadedLate).toHaveBeenCalled();
  });

  it('onUnloadedTimeInputTyped have been set', () => {
    spyOn(ActivityLogUtils, 'formatTimeValue');
    component.onUnloadedTimeInputTyped();
    expect(ActivityLogUtils.formatTimeValue).toHaveBeenCalled();
  });

  it('unloadedResponse have been called', () => {
    spyOn(component, 'setUnloadedValues');
    spyOn(component, 'getEquipmentInfo');
    component.unloadedResponse(testData);
    expect(component.setUnloadedValues).toHaveBeenCalled();
  });

  it('onDepartureDateOrTimeChange have been called', () => {
    spyOn(ActivityLogUtils, 'formatDateValue');
    spyOn(DateUtils, 'getTimeValue');
    spyOn(ActivityLogUtils, 'frameTimeStampValues');
    component.onDepartureDateOrTimeChange({}, true);
    expect(ActivityLogUtils.formatDateValue).toHaveBeenCalled();
  });

  it('onTextAreaType have been called', () => {
    component.onTextAreaType();
    expect(component.activityLogUnloadedEditModel.commentsCount).toBe(0);
  });

  it('telematicsPickupEquip have been called', () => {
    component.activityLogUnloadedEditModel.unloadedDetails = testData;
    component.activityLogUnloadedEditModel.isUnloadedCheckCallDetails = true;
    component.activityLogUnloadedEditModel.unloadedDetails.pickupEquipmentDetails = PickUpDetailsData;
    spyOn(component.telematicsEquipDetails, 'emit');
    component.telematicsPickupEquip();
    expect(component.activityLogUnloadedEditModel.isTelematicsPickup).toBe(true);
  });

  it('setUnloadedValues have been called', () => {
    spyOn(component, 'getTimeZone');
    spyOn(component, 'setLoadedAndDepartureDateTime');
    spyOn(ActivityLogUtils, 'checkUnloadedTime');
    spyOn(DateUtils, 'dateTimeZoneFormat');
    spyOn(component, 'setUnloadedTypeByAndCounted');
    spyOn(ActivityLogUtils, 'setStopService');
    spyOn(component, 'getDefaultCheckCallStopServices');
    spyOn(ActivityLogUtils, 'setReferenceAndCommentValues');
    spyOn(component, 'getUnloadedCheckCallErrorList');
    spyOn(component, 'setUnloadedUnitFormValues');
    component.setUnloadedValues(testData);
    expect(component.setLoadedAndDepartureDateTime).toHaveBeenCalled();
  });

  it('getTimeZone have been called', () => {
    const call = component.getTimeZone(testData);
    expect(call).toBeDefined();
  });

  it('getHighLightedErrorFields have been called', () => {
    spyOn(ActivityLogUtils, 'getUnLoadedMandatory');
    spyOn(ActivityLogUtils, 'getUnLoadedStopServicesError');
    spyOn(ActivityLogUtils, 'getUnloadedEquipError');
    component.getHighLightedErrorFields();
    expect(ActivityLogUtils.getUnLoadedMandatory).toHaveBeenCalled();
  });

  it('setLoadedAndDepartureDateTime have been called', () => {
    spyOn(component, 'formatDateTime');
    spyOn(ActivityLogUtils, 'formatDateValue');
    component.setLoadedAndDepartureDateTime(testData, 'unloadedTimestamp', 'unloadedDate', 'unloadedTime');
    expect(component.formatDateTime).toHaveBeenCalled();
  });

  it('setUnloadedUnitFormValues have been called', () => {
    spyOn(ActivityLogUtils, 'setWeightValue');
    spyOn(ActivityLogUtils, 'setVolumeValue');
    spyOn(ActivityLogUtils, 'setTemperatureValue');
    spyOn(ActivityLogUtils, 'setHazmatControl');
    component.setUnloadedUnitFormValues(testData);
    expect(ActivityLogUtils.setWeightValue).toHaveBeenCalled();
  });

  it('formatDateTime have been called', () => {
    spyOn(ActivityLogUtils, 'formatBasedOnZone');
    const call = component.formatDateTime('test', 'test1');
    expect(ActivityLogUtils.formatBasedOnZone).toHaveBeenCalled();
  });

  it('onUnloadedBySelect have been called', () => {
    const listItemdata = {
      label: 'test',
      value: 'test',
    };
    spyOn(ActivityLogUtils, 'setStopServiceSelectedValue');
    component.onUnloadedBySelect(listItemdata);
    expect(ActivityLogUtils.setStopServiceSelectedValue).toHaveBeenCalled();
  });

  it('onUnloadedBySelect have been called', () => {
    const listItemdata = {
      label: 'test',
      value: 'test',
    };
    spyOn(ActivityLogUtils, 'setStopServiceSelectedValue');
    component.onCountedBySelect(listItemdata);
    expect(ActivityLogUtils.setStopServiceSelectedValue).toHaveBeenCalled();
  });

  it('saveForm have been called', () => {
    spyOn(ActivityLogUtils, 'onNoChangeMessage');
    component.saveForm();
    expect(ActivityLogUtils.onNoChangeMessage).toHaveBeenCalled();
  });

  it('unloadedSaveCall have been called', () => {
    spyOn(component, 'updateUnloadedActivity');
    component.activityLogUnloadedEditModel.checkCallId = 123;
    component.unloadedSaveCall(testData);
    expect(component.updateUnloadedActivity).toHaveBeenCalled();
  });

  it('titleCase have been called', () => {
    const data = { equipmentType: 'test' };
    const call = component.titleCase(data);
    expect(call).toBeDefined();
  });

  it('getStringifyValue have been called', () => {
    const call = component.getStringifyValue('test');
    expect(call).toBeDefined();
  });

  it('getCommentsCount have been called', () => {
    testData.comments = 'test';
    component.getCommentsCount(testData);
    expect(component.activityLogUnloadedEditModel.commentsCount).toBe(4);
  });

  it('getCommentsCount have been called', () => {
    spyOn(component, 'getStopId');
    component.loadDetails = getLoadOverviewData;
    expect(component.getStopId).toHaveBeenCalled();
  });

  it('getStopServicesData have been called', () => {
    spyOn(ActivityLogUtils, 'getFormattedData');
    component.getStopServicesData({ query: {} });
    expect(ActivityLogUtils.getFormattedData).toHaveBeenCalled();
  });

  it('getStopServicesData Error senario', () => {
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(ActivityLogUtils, 'getFormattedData');
    spyOn(activityLogService, 'getStopServices').and.returnValue(throwError(null));
    component.getStopServicesData({ query: {} });
    expect(component.activityLogUnloadedEditModel.stopServices).toEqual([]);
  });

});
