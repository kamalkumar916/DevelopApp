import {
  Component, OnInit, OnDestroy, ChangeDetectionStrategy,
  ChangeDetectorRef, Input, Output, EventEmitter, ViewChild
} from '@angular/core';
import { FormBuilder, FormControl, FormArray, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

import { takeWhile, finalize } from 'rxjs/operators';
import { MessageService } from 'primeng/components/common/messageservice';
import { timer } from 'rxjs';
import { isEmpty, find } from 'lodash';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';

import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';

import { LoadOverview } from '../../../load-details/load-details-overview/model/load-overview.interface';
import { ErrorList, ViewActivityLogDetails, StopDetails, ResourceOverview,
  TelematicsEquipment } from '../../models/activity-log.interface';
import { ActivityLogUnloadedAddModel } from '../activity-log-unloaded-add/model/activity-log-unloaded-add.model';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ActivityLogService } from '../../services/activity-log.service';
import {
  StopServices,
  OperationalPlanStopActivityPartyType,
  OperationalPlanStopActivityType
} from '../../activity-log-loaded/activity-log-loaded-add/model/activity-log-loaded-add.interface';
import { ListItem } from '../../../model/common.interface';
import { ActivityLogUnloadedAddUtils } from '../activity-log-unloaded-add/services/activity-log-unloaded-add.utils';
import { ActivityLogUnloadedEditService } from './services/activity-log-unloaded-edit.service';
import { ActivityLogModel } from '../../models/activity-log.model';
import { AssetDetailQuery } from '../../../query/asset-detail.query';
import { EquipmentGroupItem } from '../../../tracking-details/model/tracking-details.interface';

@Component({
  selector: 'app-activity-log-unloaded-edit',
  templateUrl: './activity-log-unloaded-edit.component.html',
  styleUrls: ['./activity-log-unloaded-edit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogUnloadedEditComponent implements OnInit, OnDestroy {
  activityLogUnloadedEditModel: ActivityLogUnloadedAddModel;
  constructor(private readonly fb: FormBuilder, private readonly changeDetector: ChangeDetectorRef,
    private readonly localStorageService: LocalStorageService,
    private readonly toastMessage: MessageService, private readonly activityLogService: ActivityLogService,
    private readonly router: Router, private readonly activatedRoute: ActivatedRoute,
    private readonly datePipe: DatePipe, private readonly activityLogUnloadedEditService: ActivityLogUnloadedEditService) {
    this.activityLogUnloadedEditModel = new ActivityLogUnloadedAddModel();
  }
  @Input() set fromCheckCallPage(fromCheckCallPage) {
    if (fromCheckCallPage) {
      this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails = fromCheckCallPage.isCheckCallTracking;
      this.activityLogUnloadedEditModel.checkCallNavigation = fromCheckCallPage.checkCallNavigation;
      this.activityLogUnloadedEditModel.isTracking = fromCheckCallPage.isTracking;
    }
  }
  @Input() set reload(isReload: boolean) {
    if (isReload) {
      this.activityLogUnloadedEditModel.isReload = isReload;
    }
  }
  @Input() set editFromTracking(editFromTracking) {
    if (editFromTracking) {
      this.activityLogUnloadedEditModel.editFromTracking = editFromTracking;
    }
  }
  @Input() set trackingParam(trackingParam) {
    if (trackingParam) {
      this.activityLogUnloadedEditModel.trackingDetailsParam = trackingParam;
    }
  }
  @Input() set overrideAllWarning(event: boolean) {
    this.activityLogUnloadedEditModel.isWarningOverride = event;
    if (this.activityLogUnloadedEditModel.fieldErrorList.includes(this.activityLogUnloadedEditModel.unLoadedErrorTaskTypeName.weight)) {
      this.activityLogUnloadedEditModel.editUnloadedForm.get('weightUnits').get('weight').setErrors(null);
    }
    if (this.activityLogUnloadedEditModel.fieldErrorList.includes(
      this.activityLogUnloadedEditModel.unLoadedErrorTaskTypeName.stopServices)) {
      this.activityLogUnloadedEditModel.editUnloadedForm.get('stopServices').setErrors(null);
    }
    if (this.activityLogUnloadedEditModel.fieldErrorList.includes(
      this.activityLogUnloadedEditModel.unLoadedErrorTaskTypeName.unLoadedTime)) {
      this.activityLogUnloadedEditModel.editUnloadedForm.get('unloadedTime').setErrors(null);
    }
  }
  @Input() set loadDetails(loadOverviewDetails: LoadOverview) {
    if (loadOverviewDetails) {
      this.activityLogUnloadedEditModel.loadOverviewDetails = loadOverviewDetails;
      this.activityLogUnloadedEditModel.operationalPlanNumber = loadOverviewDetails.operationalPlanNumber ?
        loadOverviewDetails.operationalPlanNumber : null;
      this.getStopId();
    }
  }
  @Input() set resourceDetails(resourceOverview: ResourceOverview) {
    this.activityLogUnloadedEditModel.resourceOverview = resourceOverview;
    this.getDropEquipment(resourceOverview);
  }
  @Output() readonly stopSequenceNumber: EventEmitter<StopDetails> = new EventEmitter();
  @Output() readonly checkCallStopId: EventEmitter<any> = new EventEmitter();
  @Output() arrivalDeviationType: EventEmitter<ErrorList[]> = new EventEmitter<ErrorList[]>();
  @Output() readonly hasTelematicsPickup: EventEmitter<boolean> = new EventEmitter();
  @Output() readonly telematicsEquipDetails: EventEmitter<TelematicsEquipment> = new EventEmitter<TelematicsEquipment>();
  @Output() equipmentList: EventEmitter<EquipmentGroupItem[]> = new EventEmitter<EquipmentGroupItem[]>();
  @ViewChild('volumeUnit') volumeUnit: any;
  @ViewChild('weightUnit') weightUnit: any;

  ngOnInit() {
    this.activityLogUnloadedEditModel.editUnloadedForm = ActivityLogUtils.getLoadedUnloadedFormGroup(this.fb);
    this.getUnloadedFormGroup();
    this.activityLogUnloadedEditModel.checkCallId = this.activatedRoute.queryParams['_value']['checkCallId'];
    this.getUnloadedCheckcallDetails(this.activityLogUnloadedEditModel.checkCallId,
      this.activatedRoute.queryParams['_value']['activityType']);
    this.getCountedByData();
    this.getUnloadedByData();
    this.getUnitOfVolumeData();
    this.getUnitOfWeightData();
    this.getUnitOfTemperatureData();
    this.getUnloadedTypeData();
    if (this.activityLogUnloadedEditModel.isReload) {
      this.activityLogUnloadedEditModel.isLoading = true;
      this.getDropEquipment(this.activityLogUnloadedEditModel.resourceOverview);
    }
  }
  ngOnDestroy() {
    this.activityLogUnloadedEditModel.canSubscribe = false;
    if (this.activityLogUnloadedEditModel.editUnloadedForm) {
      this.activityLogUnloadedEditModel.editUnloadedForm.reset();
    }
  }
  sequenceNumber(event) {
    if (event.stopSequenceNumber) {
      this.stopSequenceNumber.emit({
        'stopSequenceNumber': event.stopSequenceNumber,
        'stopId': event.stopId,
        'destinationHeader': event.destinationHeader
      });
    }
  }
  getUnloadedFormGroup() {
    this.activityLogUnloadedEditModel.editUnloadedForm.addControl('unloadedDate', new FormControl('', Validators.required));
    this.activityLogUnloadedEditModel.editUnloadedForm.addControl('unloadedTime', new FormControl('', Validators.required));
    this.activityLogUnloadedEditModel.editUnloadedForm.addControl('unloadedBy', new FormControl('', Validators.required));
    if (this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
      this.activityLogUnloadedEditModel.editUnloadedForm.addControl('unloadedType', new FormControl('', Validators.required));
    }
  }
  validateFormFields(fieldName: string) {
    return (this.activityLogUnloadedEditModel.editUnloadedForm.controls[fieldName].invalid
      && this.activityLogUnloadedEditModel.editUnloadedForm.controls[fieldName].touched);
  }
  onUnloadedDateOrTimeChange(event, isDate: boolean) {
    event.overlayVisible = false;
    const dateObj = DateUtils.getTimeValue(event);
    if (isDate) {
      this.activityLogUnloadedEditModel.unloadedDate = ActivityLogUtils.formatDateValue(event);
      ActivityLogUtils.checkUnloadedTime(this.activityLogUnloadedEditModel, true,
        this.toastMessage, 'Unloaded');
    } else {
      if (!this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.value) {
        this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.setValue(moment(dateObj.withPm, ['hh:mm A']).toDate());
      }
      this.activityLogUnloadedEditModel.unloadedTime = dateObj.withoutPm;
      this.activityLogUnloadedEditModel.unloadedDate = ActivityLogUtils.formatDateValue(this.
        activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedDate.value);
      this.activityLogUnloadedEditModel.unloadedTimeSelected =
        ActivityLogUtils.formatTimeSelected(this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.value);
      ActivityLogUtils.checkUnloadedTime(this.activityLogUnloadedEditModel, true,
        this.toastMessage, 'Unloaded');
    }
    if (this.activityLogUnloadedEditModel.unloadedDate && this.activityLogUnloadedEditModel.unloadedTime) {
      this.checkIsLoadedLate();
    }
  }
  checkIsLoadedLate() {
    if (this.activityLogUnloadedEditModel.unloadedDate && this.activityLogUnloadedEditModel.unloadedTime &&
      this.activityLogUnloadedEditModel.editUnloadedForm.valid) {
      this.activityLogUnloadedEditModel.findUnloadedEarlyRequest.unloadedTimestamp = DateUtils.dateTimeZoneFormat(
        this.activityLogUnloadedEditModel.unloadedDate,
        this.activityLogUnloadedEditModel.unloadedTime, this.activityLogUnloadedEditModel.timeZone);
    }
    if (this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedDate.valid &&
      this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.valid) {
      this.activityLogService.getUnloadedDateTime(this.activityLogUnloadedEditModel.findUnloadedEarlyRequest).
        pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
        }, (error) => {
          ActivityLogUtils.arrivalError(error.error, this.toastMessage);
        });
    }
  }
  onUnloadedDateOrTimeClear(isDate: boolean, unloadedTime = null) {
    if (isDate) {
      this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedDate.reset();
    } else {
      this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.reset();
      unloadedTime.overlayVisible = false;
    }
  }
  onUnloadedDateInputTyped() {
    this.activityLogUnloadedEditModel.unloadedDate =
      ActivityLogUtils.formatDateValue(this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedDate.value);
    if (this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedDate.value > new Date()) {
      ActivityLogUtils.dateValidation(this.activityLogUnloadedEditModel.editUnloadedForm, 'unloadedDate',
        this.toastMessage, 'Unloaded');
    }
    if (this.activityLogUnloadedEditModel.unloadedDate && this.activityLogUnloadedEditModel.unloadedTime) {
      ActivityLogUtils.checkUnloadedTime(this.activityLogUnloadedEditModel, true, this.toastMessage, 'Unloaded');
    }
    this.checkIsLoadedLate();
  }
  onUnloadedTimeInputTyped() {
    this.activityLogUnloadedEditModel.unloadedTime =
      ActivityLogUtils.formatTimeValue(this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.value);
  }
  onDepartureDateOrTimeChange(event, isDate: boolean) {
    event.overlayVisible = false;
    if (isDate) {
      this.activityLogUnloadedEditModel.departureDate = ActivityLogUtils.formatDateValue(event);
    } else {
      if (!this.activityLogUnloadedEditModel.editUnloadedForm.controls.departureTime.value) {
        this.activityLogUnloadedEditModel.editUnloadedForm.controls.departureTime.setValue(DateUtils.getTimeValue(event).withPm);
      }
      this.activityLogUnloadedEditModel.departureTime = DateUtils.getTimeValue(event).withoutPm;
    }
    if (this.activityLogUnloadedEditModel.departureDate && this.activityLogUnloadedEditModel.departureTime) {
      this.activityLogUnloadedEditModel.departureTimestamp = ActivityLogUtils.frameTimeStampValues(this.activityLogUnloadedEditModel.
        departureDate, this.activityLogUnloadedEditModel.departureTime);
    }
  }
  onDepartureDateOrTimeClear(isDate: boolean, departureTime = null) {
    if (isDate) {
      this.activityLogUnloadedEditModel.editUnloadedForm.controls.departureDate.reset();
    } else {
      this.activityLogUnloadedEditModel.editUnloadedForm.controls.departureTime.reset();
      departureTime.overlayVisible = false;
    }
    this.activityLogUnloadedEditModel.departureTimestamp = '';
  }
  onDepartureDateInputTyped() {
    this.activityLogUnloadedEditModel.departureDate =
      ActivityLogUtils.formatDateValue(this.activityLogUnloadedEditModel.editUnloadedForm.controls.departureDate.value);
    if (this.activityLogUnloadedEditModel.departureDate && this.activityLogUnloadedEditModel.departureTime) {
      this.activityLogUnloadedEditModel.departureTimestamp = '';
    }
  }
  onDepartureTimeInputTyped() {
    this.activityLogUnloadedEditModel.departureTime =
      ActivityLogUtils.formatTimeValue(this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.value);
    if (this.activityLogUnloadedEditModel.departureDate && this.activityLogUnloadedEditModel.departureTime) {
      this.activityLogUnloadedEditModel.departureTimestamp = '';
    }
  }
  onTextAreaType() {
    this.activityLogUnloadedEditModel.commentsCount = this.activityLogUnloadedEditModel.editUnloadedForm.controls.comments.value.length;
  }
  getStopServicesData(stopService) {
    if (stopService && stopService.query) {
      this.activityLogService.getStopServices(stopService.query).pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data: StopServices) => {
          if (data && data._embedded && !isEmpty(data._embedded.operationalPlanServiceTypes)) {
            this.activityLogUnloadedEditModel.stopServices =
              ActivityLogUtils.getFormattedData(data._embedded.operationalPlanServiceTypes, 'operationalPlanServiceTypeDescription',
                'operationalPlanServiceTypeCode');
          }
        }, (error) => {
          this.activityLogUnloadedEditModel.stopServices = [];
        });
    }
  }
  getCountedByData() {
    this.activityLogService.getCountedBy().pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
      finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.countedByPartyTypes)) {
          let stopdetails = null;
          if (this.activityLogUnloadedEditModel.unloadedDetails &&
            this.activityLogUnloadedEditModel.unloadedDetails.operationalPlanStopDetails) {
            stopdetails = this.activityLogUnloadedEditModel.unloadedDetails.operationalPlanStopDetails;
          }
          this.activityLogUnloadedEditModel.countedBy = stopdetails ?
            ActivityLogUtils.getFormatedCountedByValue(data._embedded.countedByPartyTypes,
              stopdetails) : ActivityLogUtils.getFormattedData(data._embedded.countedByPartyTypes,
                'countedByPartyTypeDescription', 'countedByPartyTypeCode');
        }
      }, (error) => {
        this.activityLogUnloadedEditModel.countedBy = [];
      });
  }
  getUnloadedByData() {
    this.activityLogService.getLoadedBy().pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
      finalize(() => this.changeDetector.detectChanges())).subscribe((data: OperationalPlanStopActivityPartyType) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityPartyTypes)) {
          let stopdetails = null;
          if (this.activityLogUnloadedEditModel.unloadedDetails &&
            this.activityLogUnloadedEditModel.unloadedDetails.operationalPlanStopDetails) {
            stopdetails = this.activityLogUnloadedEditModel.unloadedDetails.operationalPlanStopDetails;
          }
          this.activityLogUnloadedEditModel.unloadedBy = stopdetails ?
            ActivityLogUtils.getFormatedLoadedByValue(data._embedded.operationalPlanStopActivityPartyTypes,
              stopdetails) : ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityPartyTypes,
                'operationalPlanStopActivityPartyTypeDescription', 'operationalPlanStopActivityPartyTypeCode');
        }
      }, (error) => {
        this.activityLogUnloadedEditModel.unloadedBy = [];
      });
  }
  getUnloadedCheckcallDetails(operationalPlanCheckCallId: number, activityType: string) {
    if (operationalPlanCheckCallId && activityType) {
      this.activityLogUnloadedEditModel.isLoading = true;
      this.getCheckCallData(operationalPlanCheckCallId, activityType, this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails);
    }
  }
  getCheckCallData(operationalPlanCheckCallId, activityType, showCheckCallDetails) {
    this.activityLogService.getCheckCallDetails(operationalPlanCheckCallId, activityType, showCheckCallDetails)
      .pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
        finalize(() => {
          this.unLoadedFinalizeMethod();
          this.activityLogUnloadedEditModel.isLoading = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((data: ViewActivityLogDetails) => {
        this.activityLogUnloadedEditModel.isLoading = false;
        if (data) {
          if (this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
            const unloadedTypeValue = (data.unloadedType && data.unloadedType.toLowerCase() === 'live') ? 'Live' : 'DrpAndHook';
            this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedType.patchValue({
              'label': data.unloadedType,
              'value': unloadedTypeValue
            });
            this.getCommentsCount(data);
            this.onUnloadedTypeSelected(this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedType.value);
          }
          this.unloadedResponse(data);
          this.telematicsPickupEquip();
          this.hasTelematicsPickupDetails();
        }
      }, (error: Error) => {
        this.activityLogUnloadedEditModel.isLoading = false;
      });
  }
  telematicsPickupEquip() {
    if (this.activityLogUnloadedEditModel.unloadedDetails && this.activityLogUnloadedEditModel.unloadedDetails.pickupEquipmentDetails
      && this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
      const pickupEquipResponseValue = (this.activityLogUnloadedEditModel.editUnloadedForm.controls.trailerOrContainer &&
      this.activityLogUnloadedEditModel.editUnloadedForm.controls.trailerOrContainer.value);
      this.activityLogUnloadedEditModel.isTelematicsPickup = true;
      if (pickupEquipResponseValue && pickupEquipResponseValue['value'] && this.activityLogUnloadedEditModel.isTelematicsPickup) {
      const pickupDetails = pickupEquipResponseValue['value'];
        this.telematicsEquipDetails.emit({
          equipmentId: pickupDetails.equipmentId,
          equipmentNumber: pickupDetails.equipmentNumber,
          equipmentCategory: pickupDetails.equipmentCategory,
          equipmentPrefix: pickupDetails.equipmentPrefix
        });
      }
    }
  }
  hasTelematicsPickupDetails() {
    this.hasTelematicsPickup.emit(this.activityLogUnloadedEditModel.isTelematicsPickup);
  }
  unLoadedFinalizeMethod() {
    this.activityLogUnloadedEditModel.isLoading = false;
    this.changeDetector.detectChanges();
  }
  unloadedResponse(data: ViewActivityLogDetails) {
    this.activityLogUnloadedEditModel.unloadedDetails = data;
    this.activityLogUnloadedEditModel.unloadedDetails = data;
    this.activityLogUnloadedEditModel.findUnloadedEarlyRequest.operationalPlanID = data.operationalPlanId;
    this.activityLogUnloadedEditModel.findUnloadedEarlyRequest.operationalPlanStopID = data.operationalPlanStopId;
    this.activityLogUnloadedEditModel.stopSequenceNumber = data.operationalPlanStopDetails &&
      data.operationalPlanStopDetails.operationalPlanStopSequenceNumber ?
      data.operationalPlanStopDetails.operationalPlanStopSequenceNumber : null;
    this.activityLogUnloadedEditModel.findUnloadedEarlyRequest.isEdit = true;
    this.setUnloadedValues(data);
    if (this.activityLogUnloadedEditModel.isReload && this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
      this.getEquipmentInfo();
    }
  }
  getStopId() {
    if (this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails && this.activityLogUnloadedEditModel.unloadedDetails
      && this.activityLogUnloadedEditModel.loadOverviewDetails &&
      this.activityLogUnloadedEditModel.unloadedDetails.operationalPlanStopDetails) {
      const stopDto = find(this.activityLogUnloadedEditModel.loadOverviewDetails.operationalPlanStopDTOs,
        (item: any) => item.locationDetailsDTO.locationId ===
          this.activityLogUnloadedEditModel.unloadedDetails.operationalPlanStopDetails.locationDetails.locationId);

      if (stopDto && stopDto.operationalPlanStopId) {
        this.checkCallStopId.emit({
          'checkCallStopId': stopDto.operationalPlanStopId
        });
      }

      if (this.activityLogUnloadedEditModel.loadOverviewDetails.operationalPlanReferenceNumberDTOs &&
        this.activityLogUnloadedEditModel.loadOverviewDetails.operationalPlanReferenceNumberDTOs.length > 0) {
          ActivityLogUtils.checkAllReferenceException(
            this.activityLogUnloadedEditModel.loadOverviewDetails.operationalPlanReferenceNumberDTOs,
            stopDto, this.activityLogUnloadedEditModel.editUnloadedForm,  this.activityLogUnloadedEditModel.unloadedDetails);
          }
      }
      if (this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails && this.activityLogUnloadedEditModel.unloadedDetails) {
        this.getHighLightedErrorFields();
      }
    }

  setUnloadedValues(unloadedDetails: ViewActivityLogDetails) {
    this.activityLogUnloadedEditModel.timeZone = this.getTimeZone(unloadedDetails);
    this.setLoadedAndDepartureDateTime(unloadedDetails, 'unloadedTimestamp', 'unloadedDate', 'unloadedTime');
    this.activityLogUnloadedEditModel.unloadedTimeSelected = this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedTime.value;
    ActivityLogUtils.checkUnloadedTime(this.activityLogUnloadedEditModel, true,
      this.toastMessage, 'Unloaded');
    this.setLoadedAndDepartureDateTime(unloadedDetails, 'departureTimestamp', 'departureDate', 'departureTime');
    this.activityLogUnloadedEditModel.findUnloadedEarlyRequest.unloadedTimestamp = DateUtils.dateTimeZoneFormat(this.
      activityLogUnloadedEditModel.unloadedDate, this.activityLogUnloadedEditModel.unloadedTime,
      this.activityLogUnloadedEditModel.timeZone);
    this.activityLogUnloadedEditModel.departureTimestamp = DateUtils.dateTimeZoneFormat(this.activityLogUnloadedEditModel.departureDate,
      this.activityLogUnloadedEditModel.departureTime, this.activityLogUnloadedEditModel.timeZone);
    (this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) ? this.setUnloadedTypeByAndCounted(unloadedDetails,
      this.activityLogUnloadedEditModel.editUnloadedForm, this.activityLogUnloadedEditModel) :
      ActivityLogUtils.setUnloadedTypeByAndCounted(unloadedDetails,
        this.activityLogUnloadedEditModel.editUnloadedForm, this.activityLogUnloadedEditModel);
    if (unloadedDetails.unloadedType) {
      this.activityLogUnloadedEditModel.isLoadedDropHook = unloadedDetails.unloadedType.toLowerCase() === 'drop and hook';
    }
    if (unloadedDetails.stopServices && unloadedDetails.stopServices.length > 0
      && unloadedDetails.stopServicesTypeCodes && unloadedDetails.stopServicesTypeCodes.length > 0) {
      ActivityLogUtils.setStopService(unloadedDetails, this.activityLogUnloadedEditModel.editUnloadedForm);
    }
    if (this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails &&
      isEmpty(unloadedDetails.stopServices)) {
        this.getDefaultCheckCallStopServices(unloadedDetails);
    }
    ActivityLogUtils.setReferenceAndCommentValues(unloadedDetails, this.activityLogUnloadedEditModel.editUnloadedForm);
    this.setUnloadedUnitFormValues(unloadedDetails);
    this.getUnloadedCheckCallErrorList();
  }
  getDefaultCheckCallStopServices(unloadedDetails) {
    if (unloadedDetails.unloadedBy) {
      this.onUnloadedBySelect({label: unloadedDetails.unloadedBy, value: unloadedDetails.unloadedBy});
    }
    if (unloadedDetails.countedBy) {
      this.onCountedBySelect({label: unloadedDetails.countedBy, value: unloadedDetails.countedBy});
    }
  }
  getTimeZone(unloadedDetails) {
    return unloadedDetails && unloadedDetails.operationalPlanStopDetails && unloadedDetails.operationalPlanStopDetails.
      locationDetails && unloadedDetails.operationalPlanStopDetails.
        locationDetails.address && unloadedDetails.operationalPlanStopDetails.
          locationDetails.address.timeZone ? unloadedDetails.operationalPlanStopDetails.
            locationDetails.address.timeZone : 'America/Chicago';
  }
  getUnloadedCheckCallErrorList() {
    this.activityLogService.getCheckCallErrors(this.activityLogUnloadedEditModel.checkCallId)
      .pipe(
        takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe)).subscribe((data: any) => {
          if (data) {
            const exceptionErrorArray = data['checkCallErrorDTO'][0]['checkCallExceptions'];
            const exceptionList = [];
            exceptionErrorArray.forEach((exceptionObj) => {
              ActivityLogUtils.activityLogError(exceptionObj, exceptionList);
              if (exceptionObj.taskTypeName) {
                this.activityLogUnloadedEditModel.fieldErrorList.push(exceptionObj.taskTypeName.toLowerCase());
              }
            });
            this.arrivalDeviationType.emit(exceptionList);
          }
        });
  }
  getHighLightedErrorFields() {
    ActivityLogUtils.getUnLoadedMandatory(this.activityLogUnloadedEditModel,
      this.activityLogUnloadedEditModel.editUnloadedForm);
    ActivityLogUtils.getUnLoadedStopServicesError(this.activityLogUnloadedEditModel,
      this.activityLogUnloadedEditModel.editUnloadedForm);
    ActivityLogUtils.getUnloadedEquipError(this.activityLogUnloadedEditModel,
      this.activityLogUnloadedEditModel.editUnloadedForm);
    this.changeDetector.detectChanges();
  }
  setLoadedAndDepartureDateTime(unloadedDetails: ViewActivityLogDetails, timestamp: string, date: string, time: string) {
    if (unloadedDetails[timestamp]) {
      const formatedDate = this.formatDateTime(unloadedDetails[timestamp], 'MM/dd/yyyy');
      const formatedTime = momentTimezone.tz(unloadedDetails[timestamp], this.activityLogUnloadedEditModel.timeZone).format('hh:mm A');
      this.activityLogUnloadedEditModel.editUnloadedForm.controls[date].setValue(formatedDate);
      this.activityLogUnloadedEditModel.editUnloadedForm.controls[time].setValue(formatedTime);
      this.activityLogUnloadedEditModel[date] = ActivityLogUtils.formatDateValue(this.
        activityLogUnloadedEditModel.editUnloadedForm.controls[date].value);
      this.activityLogUnloadedEditModel[time] = momentTimezone.tz(unloadedDetails[timestamp],
        this.activityLogUnloadedEditModel.timeZone).format('HH:mm');
    }
  }
  setUnloadedUnitFormValues(unloadedDetails: ViewActivityLogDetails) {
    if (unloadedDetails.weight && unloadedDetails.weight.weight && unloadedDetails.weight.unitOfWeightMeasurement) {
      ActivityLogUtils.setWeightValue(this.activityLogUnloadedEditModel.editUnloadedForm, unloadedDetails.weight);
    }
    if (unloadedDetails.volume && unloadedDetails.volume.volume && unloadedDetails.volume.unitOfVolumeMeasurement) {
      ActivityLogUtils.setVolumeValue(this.activityLogUnloadedEditModel.editUnloadedForm, unloadedDetails.volume);
    }
    if (unloadedDetails.temperature && unloadedDetails.temperature.temperature &&
      unloadedDetails.temperature.unitOfTemperatureMeasurement) {
      ActivityLogUtils.setTemperatureValue(this.activityLogUnloadedEditModel.editUnloadedForm, unloadedDetails.temperature);
    }
    if (unloadedDetails.hazmatIndicator) {
      ActivityLogUtils.setHazmatControl(this.activityLogUnloadedEditModel.editUnloadedForm, unloadedDetails.hazmatIndicator);
    }
    this.changeDetector.detectChanges();
  }
  formatDateTime(event, format) {
    return ActivityLogUtils.formatBasedOnZone(this.datePipe, event, format);
  }
  getUnitOfVolumeData() {
    this.activityLogService.getUnitOfVolume().pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
      finalize(() => this.changeDetector.detectChanges())).subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfVolumeMeasurements)) {
          this.activityLogUnloadedEditModel.unitOfVolume =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfVolumeMeasurements, 'unitOfVolumeMeasurementDescription',
              'unitOfVolumeMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogUnloadedEditModel.editUnloadedForm,
            'volumeUnits', { volume: '', units: 'Gallons' });
          this.volumeUnit.filled = true;
        }
      }, (error) => {
        this.activityLogUnloadedEditModel.unitOfVolume = [];
      });
  }
  getUnitOfWeightData() {
    this.activityLogService.getUnitOfWeight().pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
      finalize(() => this.changeDetector.detectChanges())).subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfWeightMeasurements)) {
          this.activityLogUnloadedEditModel.unitOfWeight =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfWeightMeasurements, 'unitOfWeightMeasurementDescription',
              'unitOfWeightMeasurementCode');
          ActivityLogUtils.setDefaultUnits(this.activityLogUnloadedEditModel.editUnloadedForm,
            'weightUnits', { weight: '', units: 'Pounds' });
          this.weightUnit.filled = true;
        }
      }, (error) => {
        this.activityLogUnloadedEditModel.unitOfWeight = [];
      });
  }
  getUnitOfTemperatureData() {
    this.activityLogService.getUnitOfTemperature().pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
      finalize(() => this.changeDetector.detectChanges())).subscribe((data) => {
        if (data && data._embedded && !isEmpty(data._embedded.unitOfTemperatureMeasurements)) {
          this.activityLogUnloadedEditModel.unitOfTemperature =
            ActivityLogUtils.getFormattedData(data._embedded.unitOfTemperatureMeasurements, 'unitOfTemperatureMeasurementDescription',
              'unitOfTemperatureMeasurementCode');
        }
      }, (error) => {
        this.activityLogUnloadedEditModel.unitOfTemperature = [];
      });
  }
  onUnloadedBySelect(selectedUnloadedBy: ListItem) {
    const driver = { value: 'DrvrUnLd', label: 'Driver Unloads Freight' };
    const lumper = { value: 'LmpUnldFrg', label: 'Lumper Unloads Freight' };
    const driverLumperValue = ['driver unloads freight', 'lumper unloads freight'];
    ActivityLogUtils.setStopServiceSelectedValue(selectedUnloadedBy, driver, lumper,
      driverLumperValue, this.activityLogUnloadedEditModel.editUnloadedForm);
  }
  onCountedBySelect(selectedCountedBy: ListItem) {
    const countsDriver = { label: 'Driver Counts Freight', value: 'DrvrCount' };
    const countsLumper = { label: 'Lumper Counts Freight', value: 'LumpCntFrg' };
    const driverLumperValue = ['driver counts freight', 'lumper counts freight'];
    ActivityLogUtils.setStopServiceSelectedValue(selectedCountedBy, countsDriver, countsLumper,
      driverLumperValue, this.activityLogUnloadedEditModel.editUnloadedForm);
  }
  saveForm() {
      if (!this.activityLogUnloadedEditModel.editUnloadedForm.dirty && !this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
        ActivityLogUtils.onNoChangeMessage(this.toastMessage);
        return;
      }
      ActivityLogUnloadedAddUtils.mandatoryFieldsCheck(this.activityLogUnloadedEditModel.editUnloadedForm);
      FormValidationUtils.validateAllFormFields(this.activityLogUnloadedEditModel.editUnloadedForm);
      this.changeDetector.detectChanges();
      if (this.activityLogUnloadedEditModel.editUnloadedForm.valid) {
        this.changeDetector.detectChanges();
        let addUnloadedReq;
        if (this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
          const addUnloadedRequestInput = this.checkCallFrameUnloadedRequest(this.activityLogUnloadedEditModel);
          addUnloadedReq = this.isValidRequest(addUnloadedRequestInput);
          if (addUnloadedReq) {
            addUnloadedReq = this.frameUnloadedCheckCallRequest(addUnloadedReq);
          }
        } else {
          const addUnloadedRequestInput = this.frameUnloadedRequest();
          addUnloadedReq = ActivityLogUnloadedAddUtils.createAddUnloadedRequest(this.activityLogUnloadedEditModel.editUnloadedForm,
            addUnloadedRequestInput, this.activityLogUnloadedEditModel.resourceOverview,
            ActivityLogUtils.getLoadedUnloadedTypeValue(this.activityLogUnloadedEditModel.unloadedType,
              this.activityLogUnloadedEditModel.unloadedDetails.unloadedType));
        }
        this.unloadedSaveCall(addUnloadedReq);
      } else {
        ActivityLogUtils.checkUnloadedFormValidity(this.toastMessage, this.activityLogUnloadedEditModel.editUnloadedForm,
          this.activityLogUnloadedEditModel, true, this.arrivalDeviationType, this.changeDetector);
      }
  }
  frameUnloadedCheckCallRequest(addUnloadedReq) {
    addUnloadedReq.checkCallSource = this.activityLogUnloadedEditModel.unloadedDetails.checkCallSource;
    addUnloadedReq.isWarningOverride = this.activityLogUnloadedEditModel.isWarningOverride;
    addUnloadedReq.checkCallId = this.activityLogUnloadedEditModel.checkCallId;
    addUnloadedReq.checkCallDetails.pickupEquipmentDetails = (this.activityLogUnloadedEditModel.onSelectTrailerOrContainer) ?
    ActivityLogUtils.getPickupEquipmentValue(this.activityLogUnloadedEditModel.trailerOrContainerSelected,
    this.activityLogUnloadedEditModel.equipmentPaired) : this.activityLogUnloadedEditModel.unloadedDetails.pickupEquipmentDetails;
    addUnloadedReq.checkCallDetails.dropEquipmentDetails = (this.activityLogUnloadedEditModel.unloadedDetails &&
    this.activityLogUnloadedEditModel.unloadedDetails.dropEquipmentDetails) ?
    this.activityLogUnloadedEditModel.unloadedDetails.dropEquipmentDetails :
    ActivityLogUtils.getDropEquipmentValues(this.activityLogUnloadedEditModel.editUnloadedForm);
    return addUnloadedReq;
  }
  isValidRequest(addUnloadedRequestInput) {
    if (addUnloadedRequestInput.dropEquipmentValue && addUnloadedRequestInput.dropEquipmentValue.length > 0) {
      if (addUnloadedRequestInput.pickupEquipmentValue && addUnloadedRequestInput.pickupEquipmentValue.length > 0) {
        return ActivityLogUnloadedAddUtils.createAddUnloadedRequest(this.activityLogUnloadedEditModel.editUnloadedForm,
          addUnloadedRequestInput, this.activityLogUnloadedEditModel.resourceOverview);
      } else {
        this.toastMessage.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Pickup any Equipment'
        });
        this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
        this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').markAsTouched();
        this.changeDetector.detectChanges();
        return null;
      }
    } else {
      return ActivityLogUnloadedAddUtils.createAddUnloadedRequest(this.activityLogUnloadedEditModel.editUnloadedForm,
        addUnloadedRequestInput, this.activityLogUnloadedEditModel.resourceOverview);
    }
  }
  frameUnloadedRequest() {
    return {
      loadedTimestamp: this.activityLogUnloadedEditModel.findUnloadedEarlyRequest.unloadedTimestamp,
      departureTimestamp: this.activityLogUnloadedEditModel.departureTimestamp ?
        this.activityLogUnloadedEditModel.departureTimestamp : null,
      planNumber: this.activityLogUnloadedEditModel.operationalPlanNumber,
      stopSequenceNumber: this.activityLogUnloadedEditModel.stopSequenceNumber,
      receiverStateId: this.activityLogUnloadedEditModel.finalDestination,
      overrideWarning: this.activityLogUnloadedEditModel.isWarningOverride,
      pickupEquipmentValue: this.activityLogUnloadedEditModel.unloadedDetails.pickupEquipmentDetails,
      dropEquipmentValue: this.activityLogUnloadedEditModel.unloadedDetails.dropEquipmentDetails,
      timeZone: this.activityLogUnloadedEditModel.timeZone
    };
  }
  unloadedSaveCall(addUnloadedReq) {
    if (addUnloadedReq && this.activityLogUnloadedEditModel.checkCallId) {
      this.updateUnloadedActivity(addUnloadedReq);
    }
  }
  updateUnloadedActivity(addUnloadedReq) {
    if (addUnloadedReq.resourceDetails.value) {
      this.activityLogUnloadedEditModel.isLoading = true;
      this.changeDetector.detectChanges();
      this.activityLogUnloadedEditService.updateUnloadedDetails(addUnloadedReq, this.activityLogUnloadedEditModel.checkCallId,
        this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails)
        .pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((data) => {
          this.activityLogUnloadedEditModel.isLoading = false;
          if (data) {
            ActivityLogUtils.successMessage(this.toastMessage, 'Unloaded', 'updated');
            timer(ActivityLogModel.editSaveTimer).subscribe(() => {
              if (this.activityLogUnloadedEditModel.isTracking || this.activityLogUnloadedEditModel.editFromTracking) {
                this.router.navigate(['/trackingdetails'],
                  {
                    queryParams: this.activityLogUnloadedEditModel.trackingDetailsParam
                  });
              } else if (this.activityLogUnloadedEditModel.checkCallNavigation) {
                this.router.navigate(['/tracking'],
                  {
                    queryParams: {
                      fromCheckCall: 'true'
                    }
                  });
              } else {
                this.router.navigate(['/loaddetails', this.activityLogUnloadedEditModel.findUnloadedEarlyRequest.operationalPlanID],
                  {
                    queryParams: {
                      index: 2
                    }
                  });
              }
            });
          }
        }, (error) => {
          this.handleError(error);
        });
    } else {
      this.toastMessage.clear();
      ActivityLogUtils.resourceFieldError(this.toastMessage);
    }
  }
  handleError(error) {
    this.activityLogUnloadedEditModel.isLoading = false;
    if (ActivityLogUtils.handleErrorAndNull(error, this.toastMessage)) {
      ActivityLogUtils.checkRuleValidationError(error.error.errors,
        this.activityLogUnloadedEditModel.editUnloadedForm,
        this.arrivalDeviationType, this.changeDetector);
      this.arrivalDeviationType.emit(error.error.errors);
    }
  }
  setUnloadedTypeByAndCounted(unloadedDetails: ViewActivityLogDetails, formGroup: FormGroup, unloadedModel) {
    formGroup.patchValue({
      unloadedBy: find(unloadedModel.unloadedBy, ['label', unloadedDetails['unloadedBy']]),
      countedBy: find(unloadedModel.countedBy, ['label', unloadedDetails['countedBy']])
    });
    this.dropEquipmentCheckbox();
  }
  dropEquipmentCheckbox() {
    const equipCategoryArray = [];
    if (this.activityLogUnloadedEditModel.unloadedDetails && this.activityLogUnloadedEditModel.unloadedDetails.pickupEquipmentDetails
      && this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
      this.activityLogUnloadedEditModel.unloadedDetails.pickupEquipmentDetails.forEach(ele => {
        equipCategoryArray.push(ele.equipmentCategory);
        if (ele.equipmentCategory.toLowerCase() === 'container' || ele.equipmentCategory.toLowerCase() === 'trailer') {
          this.activityLogUnloadedEditModel.editUnloadedForm.controls.trailerOrContainer.patchValue({
            'label': ele.equipmentPrefix && ele.equipmentNumber ?
              `${ele.equipmentPrefix}${ele.equipmentNumber}` : `${ele.equipmentNumber}`,
            'value': {
              equipmentId: ele.equipmentId,
              equipmentNumber: ele.equipmentNumber,
              equipmentPrefix: ele.equipmentPrefix,
              equipmentType: ele.equipmentType
            }
          });
        }
      });
      this.getChassisEquip(equipCategoryArray);
    }
    this.changeDetector.detectChanges();
  }
  getChassisEquip(equipCategoryArray) {
    if (equipCategoryArray.indexOf('CONTAINER') > -1 || equipCategoryArray.indexOf('TRAILER') > -1) {
      this.activityLogUnloadedEditModel.hasChassisEquip = true;
      this.activityLogUnloadedEditModel.chassisEquip = find(this.activityLogUnloadedEditModel.unloadedDetails.pickupEquipmentDetails,
        { 'equipmentCategory': 'CHASSIS' });
    }
  }
  getUnloadedTypeData() {
    this.activityLogService.getLoadedType()
      .pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
        finalize(() => this.changeDetector.detectChanges()))
      .subscribe((data: OperationalPlanStopActivityType) => {
        if (data && data._embedded && !isEmpty(data._embedded.operationalPlanStopActivityTypes)) {
          this.activityLogUnloadedEditModel.unloadedType =
            ActivityLogUtils.getFormattedData(data._embedded.operationalPlanStopActivityTypes,
              'operationalPlanStopActivityTypeDescription', 'operationalPlanStopActivityTypeCode');
        }
      }, (error) => {
        this.activityLogUnloadedEditModel.unloadedType = [];
      });
  }
  onUnloadedTypeSelected(event: any) {
    this.activityLogUnloadedEditModel.isLoadedDropHook = event.value.toLowerCase() === 'drpandhook';
    if (this.activityLogUnloadedEditModel.isLoadedDropHook) {
      this.activityLogUnloadedEditModel.editUnloadedForm.addControl('dropEquipmentDetails', new FormGroup({}));
      this.activityLogUnloadedEditModel.dropEquipment.forEach(dropequipment => {
        this.activityLogUnloadedEditModel.editUnloadedForm.controls.dropEquipmentDetails
        ['addControl'](dropequipment.equipmentType, new FormControl([]));
      });
      this.activityLogUnloadedEditModel.editUnloadedForm.addControl('trailerOrContainer', new FormControl(''));
    } else {
      if (this.activityLogUnloadedEditModel.editUnloadedForm.get('dropEquipmentDetails')) {
        this.activityLogUnloadedEditModel.editUnloadedForm.removeControl('dropEquipmentDetails');
      }
      if (this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer')) {
        this.activityLogUnloadedEditModel.editUnloadedForm.removeControl('trailerOrContainer');
      }
    }
    this.dropEquipmentCheckbox();
  }
  titleCase(dropEquipment) {
    let equipmentLabel = '';
    if (dropEquipment && dropEquipment.equipmentType) {
      equipmentLabel = `${dropEquipment.equipmentType.slice(0, 1).toUpperCase()}${dropEquipment.equipmentType.slice(1).toLowerCase()}`;
    }
    return equipmentLabel;
  }
  onCheckAndUnCheck() {
    if (!ActivityLogUtils.droppedOrUndropped(this.activityLogUnloadedEditModel.editUnloadedForm) &&
      this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').invalid) {
      this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').reset();
      this.changeDetector.detectChanges();
    }
  }
  getStringifyValue(dropEquipment) {
    return JSON.stringify(dropEquipment);
  }
  getTrailerOrContainerData(trailerOrContainer) {
    if (trailerOrContainer && trailerOrContainer.query) {
      const q = AssetDetailQuery.getContainerOrTrailer(trailerOrContainer.query);
      this.activityLogService.getTrailerOrContainer(q)
        .pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.hits && data.hits.hits && data.hits.hits.length > 0) {
            this.activityLogUnloadedEditModel.trailerOrContainer =
              ActivityLogUtils.getTrailerOrContainer(data.hits.hits);
          } else {
            this.activityLogUnloadedEditModel.trailerOrContainer = [];
            this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
          }
        }, (error) => {
          this.activityLogUnloadedEditModel.trailerOrContainer = [];
        });
    }
  }
  onRemoveTrailerOrContainer() {
    this.activityLogUnloadedEditModel.chassis = null;
    this.activityLogUnloadedEditModel.trailerOrContainerSelected = null;
    this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').reset();
    this.activityLogUnloadedEditModel.equipmentPaired = [];
  }
  onTrailerOrContainerSelected(selectedTrailerOrContainer) {
    this.activityLogUnloadedEditModel.onSelectTrailerOrContainer = true;
    this.activityLogUnloadedEditModel.isTelematicsPickup = false;
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId) {
      if (!find(this.activityLogUnloadedEditModel.dropEquipment,
        ['equipmentNumber', selectedTrailerOrContainer.value.equipmentNumber])) {
        this.activityLogUnloadedEditModel.trailerOrContainerSelected = selectedTrailerOrContainer;
        this.getStackedEquipment(selectedTrailerOrContainer);
      } else {
        this.activityLogUnloadedEditModel.trailerOrContainerSelected = null;
        this.toastMessage.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Select valid Equipment Details'
        });
        this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').setErrors({ 'invalid': true });
        this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').markAsTouched();
        this.changeDetector.detectChanges();
      }
    } else {
      this.activityLogUnloadedEditModel.trailerOrContainerSelected = null;
    }
  }
  getDropEquipment(resourceOverview: ResourceOverview) {
    if (resourceOverview && resourceOverview.equipmentId
      && this.activityLogUnloadedEditModel.isUnloadedCheckCallDetails) {
      this.activityLogService.getEquipmentDetails(resourceOverview.equipmentId)
        .pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data) => {
          if (data && data.length > 1) {
            this.activityLogUnloadedEditModel.dropEquipment = ActivityLogUtils.getFormattedEquipment(data.slice(1));
            this.onUnloadedTypeSelected(this.activityLogUnloadedEditModel.editUnloadedForm.controls.unloadedType.value);
            if (this.activityLogUnloadedEditModel.isReload) {
              this.activityLogUnloadedEditModel.isLoading = false;
              this.getEquipmentInfo();
            }
          }
        }, (error) => {
          this.activityLogUnloadedEditModel.dropEquipment = [];
        });
    }
  }
  getEquipmentInfo() {
    if (this.localStorageService.getItem('unloadedForm', 'values') && this.activityLogUnloadedEditModel.isReload) {
      const unLoadedFormValue = this.localStorageService.getItem('unloadedForm', 'values');
      this.activityLogUnloadedEditModel.editUnloadedForm.patchValue(unLoadedFormValue.formDetails);
      this.activityLogUnloadedEditModel.trailerOrContainerSelected = unLoadedFormValue.trailerSelected;
      this.activityLogUnloadedEditModel.departureTimestamp = unLoadedFormValue.departureTime;
    } else {
      this.onSelectUnLoadedType();
    }
    if (this.localStorageService.getItem('unloadedpairedEquipment', 'values') && this.activityLogUnloadedEditModel.isReload) {
      this.activityLogUnloadedEditModel.equipmentPaired = this.localStorageService.getItem('unloadedpairedEquipment', 'values');
    }
  }
  onSelectUnLoadedType() {
    if (this.activityLogUnloadedEditModel.editUnloadedForm.value.unloadedType.value &&
      this.activityLogUnloadedEditModel.editUnloadedForm.value.unloadedType.value.toLowerCase() === 'drpandhook') {
      this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').reset();
      this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').setErrors({ invalid: true });
      this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').markAsTouched();
      this.activityLogUnloadedEditModel.equipmentPaired = [];
      this.changeDetector.detectChanges();
    } else {
      this.activityLogUnloadedEditModel.editUnloadedForm.get('trailerOrContainer').setErrors(null);
    }
    Object.keys(this.activityLogUnloadedEditModel.editUnloadedForm.get('dropEquipmentDetails')['controls']).forEach((controlName) => {
      this.activityLogUnloadedEditModel.editUnloadedForm.get('dropEquipmentDetails')['controls'][controlName].reset();
    });
  }
  getStackedEquipment(selectedTrailerOrContainer) {
    if (selectedTrailerOrContainer && selectedTrailerOrContainer.value && selectedTrailerOrContainer.value.equipmentId) {
      this.activityLogUnloadedEditModel.isLoading = true;
      this.activityLogService.getEquipmentDetails(selectedTrailerOrContainer.value.equipmentId)
        .pipe(takeWhile(() => this.activityLogUnloadedEditModel.canSubscribe),
          finalize(() => {
            this.activityLogUnloadedEditModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: EquipmentGroupItem[]) => {
          if (data && data.length > 0) {
            this.onSelectingEquipmentDetails(data, selectedTrailerOrContainer.value.equipmentId);
            this.equipmentList.emit(data);
            this.hasTelematicsPickupDetails();
          }
        }, (error) => {
          this.activityLogUnloadedEditModel.equipmentGroupValue = null;
          this.activityLogUnloadedEditModel.status = [];
        });
    }
  }
  onSelectingEquipmentDetails(response, equipmentId) {
    if (response.length > 1) {
      this.activityLogUnloadedEditModel.showEquipmentGroup = true;
      this.activityLogUnloadedEditModel.trailingEquipmentGroup = response;
      let selectedEquipmentDetails;
      this.activityLogUnloadedEditModel.trailingEquipmentGroup.forEach((equimentItem => {
        if (equimentItem.equipmentId === equipmentId) {
          selectedEquipmentDetails = equimentItem;
          this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentNumber = equimentItem.equipmentNumber;
          this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentType = equimentItem.equipmentType;
          this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentPrefix = equimentItem.equipmentPrefix;
          this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentId = equimentItem.equipmentId;
        } else {
          equimentItem.stackedEquipmentList.forEach(stackedItem => {
            if (stackedItem.equipmentId === equipmentId) {
              selectedEquipmentDetails = stackedItem;
              this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentNumber = stackedItem.equipmentNumber;
              this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentType = stackedItem.equipmentType;
              this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentPrefix = stackedItem.equipmentPrefix;
              this.activityLogUnloadedEditModel.equipmentGroupValue.equipmentId = stackedItem.equipmentId;
            }
          });
        }
      }));
      this.activityLogUnloadedEditModel.status = [{ label: 'Add this group to selected Equipment', value: 'Active' },
      {
        label: `Remove the ${selectedEquipmentDetails.equipmentType.charAt(0)
          + selectedEquipmentDetails.equipmentType.slice(1).toLowerCase()}
            ${selectedEquipmentDetails
            .equipmentPrefix}${selectedEquipmentDetails.equipmentNumber} from the Group and
          Add it to the selected Equipment`, value: 'Inactive'
      }];
    }
  }
  getUpdatedEquipment(event) {
    this.activityLogUnloadedEditModel.equipmentPaired = event;
  }
  getCommentsCount(data: ViewActivityLogDetails) {
    if (data.comments) {
      this.activityLogUnloadedEditModel.commentsCount = data.comments.length;
    }
  }
  checkCallFrameUnloadedRequest(unloadedModel) {
    return {
      loadedTimestamp: unloadedModel.findUnloadedEarlyRequest.unloadedTimestamp,
      departureTimestamp: unloadedModel.departureTimestamp ? unloadedModel.departureTimestamp : null,
      planNumber: unloadedModel.operationalPlanNumber,
      stopSequenceNumber: unloadedModel.stopSequenceNumber,
      receiverStateId: unloadedModel.finalDestination,
      overrideWarning: unloadedModel.isWarningOverride,
      pickupEquipmentValue: (unloadedModel.unloadedDetails && unloadedModel.unloadedDetails.pickupEquipmentDetails) ?
        unloadedModel.unloadedDetails.pickupEquipmentDetails :
        ActivityLogUtils.getPickupEquipmentValue(unloadedModel.trailerOrContainerSelected, unloadedModel.equipmentPaired),
      dropEquipmentValue: (unloadedModel.unloadedDetails && unloadedModel.unloadedDetails.dropEquipmentDetails) ?
        unloadedModel.unloadedDetails.dropEquipmentDetails : ActivityLogUtils.getDropEquipmentValues(unloadedModel.editUnloadedForm)
    };
  }
  getZoneFormat() {
    return ActivityLogUtils.getZoneFormat(this.activityLogUnloadedEditModel.timeZone);
  }
}
