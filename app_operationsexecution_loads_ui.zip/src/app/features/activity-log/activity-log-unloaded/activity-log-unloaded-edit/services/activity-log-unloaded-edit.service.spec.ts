import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogUnloadedEditService } from './activity-log-unloaded-edit.service';
import { configureTestSuite } from 'ng-bullet';

describe('ActivityLogUnloadedEditService', () => {
  let service: ActivityLogUnloadedEditService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogUnloadedEditService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(ActivityLogUnloadedEditService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('updateUnloadedDetails should be called', () => {
    service.updateUnloadedDetails({}, 0, true).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.addCheckCallUnloaded}/0/monitoringtasks`);
    expect(req.request.method).toEqual('PATCH');
  });
  it('updateUnloadedDetails should be called', () => {
    service.updateUnloadedDetails({}, 0).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.addUnloaded}/0`);
    expect(req.request.method).toEqual('PATCH');
  });
});
