import { Injectable } from '@angular/core';

import { HttpClient, } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from './../../../../../shared/service/app-config.service';
@Injectable({
  providedIn: 'root'
})
export class ActivityLogUnloadedEditService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('activitylog');
  }
  updateUnloadedDetails(addUnloadedReq, checkCallId: number, isUnloadedCheckCallDetails = false): Observable<any> {
    if (isUnloadedCheckCallDetails) {
      return this.http.patch<any>(`${this.endpoint.addCheckCallUnloaded}/${checkCallId}/monitoringtasks`,
      addUnloadedReq);
    } else {
      return this.http.patch<any>(`${this.endpoint.addUnloaded}/${checkCallId}`, addUnloadedReq);
    }
  }
}
