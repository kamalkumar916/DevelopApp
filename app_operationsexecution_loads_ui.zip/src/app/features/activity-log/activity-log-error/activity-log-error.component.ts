import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';

import { uniqBy, find, isEmpty} from 'lodash';

import { ActivityLogErrorModel } from './models/activity-log-error.model';
import { ErrorList, UpdateLocationHeader, TelematicsEquipment } from '../models/activity-log.interface';

@Component({
  selector: 'app-activity-log-error',
  templateUrl: './activity-log-error.component.html',
  styleUrls: ['./activity-log-error.component.scss']
})
export class ActivityLogErrorComponent implements OnInit {
  activityLogErrorModel: ActivityLogErrorModel;
  @Input() set errorType(error: ErrorList[]) {
    if (error) {
      this.activityLogErrorModel.errorList = uniqBy(error, 'errorMessage');
    }
  }
  @Input() set fromTrackingDetails(fromTrackingDetails: boolean) {
    if (fromTrackingDetails) {
      this.activityLogErrorModel.fromTrackingPage = fromTrackingDetails;
    }
  }
  @Input() set hastelematicsEquip(data: boolean) {
    if (data) {
      this.activityLogErrorModel.hastelematicsEquip = data;
    }
  }
  @Input() set telematicsEquipDetails(equip: TelematicsEquipment) {
    if (equip) {
      this.activityLogErrorModel.telematicsEquipValues = equip;
    }
  }
  @Input() equipmentList;
  @Output() overideWarning: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() locationUpdate: EventEmitter<UpdateLocationHeader> = new EventEmitter<UpdateLocationHeader>();
  constructor() {
    this.activityLogErrorModel = new ActivityLogErrorModel();
  }

  ngOnInit() {
  }

  isWarningOrError(warningOrError: string) {
    let showWarningorError = false;
    this.activityLogErrorModel.errorList.forEach((error) => {
      if (error.errorSeverity && error.errorSeverity.toLowerCase() === warningOrError) {
        showWarningorError = true;
      }
    });
    return showWarningorError;
  }

  overideAllWarnings() {
    this.overideWarning.emit(true);
  }
  onLocationUpdate(errorMsg) {
    const equipmentValue = this.activityLogErrorModel.telematicsEquipValues;
    if (this.activityLogErrorModel.hastelematicsEquip && !isEmpty(equipmentValue)) {
      this.locationUpdate.emit({
        equipmentId: equipmentValue.equipmentId,
        equipmentNumber: equipmentValue.equipmentNumber,
        equipmentCategory: equipmentValue.equipmentCategory,
        equipmentPrefix: equipmentValue.equipmentPrefix,
        hasLocation: true
      });
    } else {
      this.findCurrentTrailer(errorMsg);
    }
  }
  findCurrentTrailer(errorMessage) {
      const currentEquipment = find(this.equipmentList, (items) => {
        let equipment = items.equipmentCategory !== 'POWER' && items.equipmentNumber &&
        errorMessage.indexOf(`${items.equipmentPrefix}${items.equipmentNumber}`) !== -1;
        if (items.equipmentCategory !== 'POWER' && !equipment) {
          equipment = find(items.stackedEquipmentList, (stackedItem) => {
            return stackedItem.equipmentNumber && errorMessage
            .indexOf(`${stackedItem.equipmentPrefix}${stackedItem.equipmentNumber}`) !== -1;
          });
        }
        return equipment;
      });
      this.locationUpdate.emit({
        equipmentId: currentEquipment.equipmentId,
        equipmentNumber: currentEquipment.equipmentNumber,
        equipmentCategory: currentEquipment.equipmentCategory,
        equipmentPrefix: currentEquipment.equipmentPrefix,
        hasLocation: true
      });
  }

}
