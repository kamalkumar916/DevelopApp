import { ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';

import { ActivityLogErrorComponent } from './activity-log-error.component';

const errorListData = [{
  fieldErrorFlag: true,
  errorMessage: '',
  errorType: '',
  fieldName: null,
  code: '',
  errorSeverity: 'error',
}];
const equipmentValues = {
  equipmentId: null,
  equipmentNumber: '',
  equipmentCategory: '',
  equipmentPrefix: ''
};
const equipmentListData = [{
  equipmentPrefix: 'a',
  equipmentAssociationId: null,
  equipmentId: null,
  equipmentNumber: '',
  stack: true,
  sequenceNumber: null,
  equipmentCategory: '',
  businessUnit: '',
  equipmentType: '',
  equipmentStatus: '',
  trailingEquipmentStatus: '',
  length: '',
  width: '',
  height: '',
  equipmentMaintenanceStatus: '',
  equipmentMissing: true,
  equipmentAssociationGroupId: null,
  locationDetails: {
    equipmentId: '',
    locationId: null,
    locationCode: '',
    locationName: '',
    addressLine1: '',
    addressLine2: '',
    state: '',
    city: '',
    zipcode: '',
    country: '',
    latitude: null,
    longitude: null,
    description: null,
    lastUpdatedCurrentLocation: '',
    lastUpdatedGpsLocation: null,
    timezone: null,
    stateName: null,
    cityId: null,
    countryCode: null
  },
  stackedEquipmentList: [{
    equipmentNumber: '1',
    equipmentPrefix: 'a'
  }],
  links: null,
  oldEquipmentAssociationGroupId: null,
  isUnstackRequired: true,
  isOldStack: true,
  equipmentAssociationStackingId: true,
  isRemoveGroup: true,
  userId: '',
  isLegacyOnly: true,
  isRemoveLegacy: true,
}];
describe('ActivityLogErrorComponent', () => {
  let component: ActivityLogErrorComponent;
  let fixture: ComponentFixture<ActivityLogErrorComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [ActivityLogErrorComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Input errorType should set value to errorList', () => {
    component.errorType = errorListData;
    expect(component.activityLogErrorModel.errorList).toBeDefined();
  });

  it('onLocationUpdate have been called', () => {
    spyOn(component, 'findCurrentTrailer');
    component.activityLogErrorModel.hastelematicsEquip = false;
    component.onLocationUpdate('error');
    expect(component.findCurrentTrailer).toHaveBeenCalledWith('error');
  });

  it('onLocationUpdate have been called', () => {
    spyOn(component, 'findCurrentTrailer');
    component.activityLogErrorModel.hastelematicsEquip = true;
    component.activityLogErrorModel.telematicsEquipValues = equipmentValues;
    spyOn(component.locationUpdate, 'emit');
    component.onLocationUpdate('error');
    expect(component.locationUpdate.emit).toHaveBeenCalled();
  });

  it('isWarningOrError should return true', () => {
    component.activityLogErrorModel.errorList = errorListData;
    expect(component.isWarningOrError('error')).toBeTruthy();
  });
  it('trackingPage has been set', () => {
    component.fromTrackingDetails = true;
    expect(component.activityLogErrorModel.fromTrackingPage).toBeTruthy();
  });
  it('hastelematicsEquip has been set', () => {
    component.hastelematicsEquip = true;
    expect(component.activityLogErrorModel.hastelematicsEquip).toBeTruthy();
  });
  it('telematicsEquipValues has been set', () => {
    const telematicsEquip = {
      equipmentId: 0,
      equipmentNumber: '',
      equipmentCategory: '',
      equipmentPrefix: ''
    };
    component.telematicsEquipDetails = telematicsEquip;
    expect(component.activityLogErrorModel.telematicsEquipValues).toBe(telematicsEquip);
  });
  it('overideWarning have been emitted', () => {
    spyOn(component.overideWarning, 'emit');
    component.overideAllWarnings();
    expect(component.overideWarning.emit).toHaveBeenCalledWith(true);
  });
  it('findCurrentTrailer', () => {
    component.equipmentList = equipmentListData;
    spyOn(component.locationUpdate, 'emit');
    component.findCurrentTrailer('a1');
    expect(component.locationUpdate.emit).toHaveBeenCalled();
  });
});
