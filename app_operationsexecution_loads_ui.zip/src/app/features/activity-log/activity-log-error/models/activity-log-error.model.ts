import { ErrorList , TelematicsEquipment} from '../../models/activity-log.interface';


export class ActivityLogErrorModel {
    errorList: ErrorList[];
    errorType: string;
    viewMore: boolean;
    fromTrackingPage: boolean;
    hastelematicsEquip: boolean;
    telematicsEquipValues: TelematicsEquipment;
    trailingEquipmentLocationMismatch: Array<string>;
    constructor() {
        this.errorType = '';
        this.errorList = [];
        this.viewMore = false;
        this.trailingEquipmentLocationMismatch = [
            'EX_EQUIPMENT_LOCATION_NOTMATCHED',
            'unloaded call - trailing equipment is in the wrong location',
            'loaded call - trailing equipment is in the wrong location'
        ];
    }
}
