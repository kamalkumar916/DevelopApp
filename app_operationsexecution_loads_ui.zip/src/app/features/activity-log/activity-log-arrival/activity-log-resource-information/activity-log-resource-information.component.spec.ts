import { ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';

import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { ActivityLogResourceInformationComponent } from './activity-log-resource-information.component';

describe('ActivityLogResourceInformationComponent', () => {
  let component: ActivityLogResourceInformationComponent;
  let fixture: ComponentFixture<ActivityLogResourceInformationComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [PipesModule],
      declarations: [ActivityLogResourceInformationComponent]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogResourceInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});




