import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-activity-log-resource-information',
  templateUrl: './activity-log-resource-information.component.html',
  styleUrls: ['./activity-log-resource-information.component.scss']
})
export class ActivityLogResourceInformationComponent implements OnInit {
  constructor() { }
  @Input() contactInfo: any;
  ngOnInit() {
  }

}
