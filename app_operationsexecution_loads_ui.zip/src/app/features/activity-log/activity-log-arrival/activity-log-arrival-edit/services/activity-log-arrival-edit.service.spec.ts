import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { configureTestSuite } from 'ng-bullet';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogArrivalEditService } from './activity-log-arrival-edit.service';

describe('ActivityLogArrivalEditService', () => {
  let service: ActivityLogArrivalEditService;
  let httpTestingController: HttpTestingController;

  const arrivalDeviationRequest = {
    operationalPlanID: 1,
    operationalPlanStopSequenceNumber: 12,
    operationalPlanStopID: 0,
    arrivalTimestamp: '',
    operationalPlanNumber: '',
    truck: null,
    destinationHeader: ''
  };
  const editRequestObj = {
    checkCallId: null,
    operationalPlanNumber: '',
    operationalPlanStopSequenceNumber: null,
    arrivalType: '',
    checkCallSourceTimestamp: '',
    hubReading: '',
    arrivalCheckCallType: '',
    resourceDetails: {
      type: '',
      value: null
    },
    isAutoCheckCall: true,
    checkCallSource: '',
    comments: '',
    isWarningOverride: true,
    arrivalTimestamp: '',
    arrivalTimeDeviationDetails: {
      arrivalTimeDeviationType: '',
      arrivalTimeDeviationReason: '',
      arrivalTimeDeviationReasonCategory: '',
      arrivalDeviationResponsibilityPartyType: '',
      contactID: '',
      contactText: '',
    }
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogArrivalEditService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(ActivityLogArrivalEditService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('getReasonCategory have been called', () => {
    service.getReasonCategory().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.reasonCategory);
    expect(req.request.method).toEqual('GET');
  });

  it('getReason have been called', () => {
    const reasonCode = '';
    service.getReason(reasonCode).subscribe();
    const url = `${service.endpoint.reason}/category?category=${reasonCode}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getReasonResponsibilityTypes have been called', () => {
    service.getReasonResponsibilityTypes().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.responsibilityTypes);
    expect(req.request.method).toEqual('GET');
  });

  it('getResourceDetails have been called', () => {
    service.getResourceDetails({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getResourceDetails);
    expect(req.request.method).toEqual('POST');
  });

  it('getResourceImage have been called', () => {
    const queryParam = [''];
    service.getResourceImage(queryParam).subscribe();
    const url = `${service.endpoint.getResourceImage}?personIds=&userIds=${queryParam}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getArrivalType have been called', () => {
    service.getArrivalType(arrivalDeviationRequest).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getArrivalType);
    expect(req.request.method).toEqual('POST');
  });

  it('updateArrivalDetails else case have been called', () => {
    const checkCallId = 1;
    service.updateArrivalDetails(editRequestObj, checkCallId).subscribe();
    const url = `${service.endpoint.addArrival}/${checkCallId}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PATCH');
  });

  it('updateArrivalDetails if case have been called', () => {
    const checkCallId = 1;
    service.updateArrivalDetails(editRequestObj, checkCallId, true).subscribe();
    const url = `${service.endpoint.addCheckCallArrival}/${checkCallId}/monitoringtasks`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('PATCH');
  });

});


