import {
  Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy, ChangeDetectorRef, Output, EventEmitter,
  AfterViewChecked, ViewChild
} from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { takeWhile, finalize } from 'rxjs/operators';
import { findIndex, find } from 'lodash';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import { timer } from 'rxjs';
import { MessageService } from 'primeng/components/common/messageservice';

import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';
import { DriverDetailQuery } from '../../../../shared/query/driver-detail.query';
import { ErrorUtils } from '../../../../shared/jbh-app-services/error-utils';
import { AddressDetailsPipe } from '../../../../shared/pipes/address-details.pipe';

import { ActivityLogArrivalAddModel } from '../activity-log-arrival-add/model/activity-log-arrival-add.model';
import { ActivityLogArrivalEditService } from './services/activity-log-arrival-edit.service';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import {
  ArrivalDeviationResponse, LateReasonCategory,
  ReasonResponsibility, LateReason, OperationalPlanStopAppointmentChangeReasonCategory,
  OperationalPlanStopAppointmentChangeReason
} from '../activity-log-arrival-add/model/activity-log-arrival-add.interface';
import { ActivityLogService } from '../../services/activity-log.service';
import {
  ViewActivityLogDetails, ArrivalTimeDeviationDetails, ErrorList, StopDetails,
  ResourceOverview
} from '../../models/activity-log.interface';
import { ElasticResponseModel } from '../../../../features/model/elastic-response.interface';
import { DriverDetailsUtils } from '../../../service/driver-details.utils';
import { DriverImageDetails, FetchDetails } from '../../../model/driver-details.interface';
import { ActivityLogModel } from '../../models/activity-log.model';
import { Calendar } from 'primeng/calendar';

@Component({
  selector: 'app-activity-log-arrival-edit',
  templateUrl: './activity-log-arrival-edit.component.html',
  styleUrls: ['./activity-log-arrival-edit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogArrivalEditComponent implements OnInit, OnDestroy, AfterViewChecked {
  arrivalDetailsEditModel: ActivityLogArrivalAddModel;
  zoneId: any;
  @Input() set fromCheckCallPage(fromCheckCallPage) {
    if (fromCheckCallPage) {
      this.arrivalDetailsEditModel.showCheckCallDetails = fromCheckCallPage.isCheckCallTracking;
      this.arrivalDetailsEditModel.checkCallNavigation = fromCheckCallPage.checkCallNavigation;
      this.arrivalDetailsEditModel.isTracking = fromCheckCallPage.isTracking;
    }
  }
  @Input() set editFromTracking(editFromTracking) {
    if (editFromTracking) {
      this.arrivalDetailsEditModel.editFromTracking = editFromTracking;
    }
  }
  @Input() set trackingParam(trackingParam) {
    if (trackingParam) {
      this.arrivalDetailsEditModel.trackingDetailsParam = trackingParam;
    }
  }
  @Input() set overrideAllWarning(event: boolean) {
    this.arrivalDetailsEditModel.isWarningOverride = event;
  }
  @Input() set fieldErrorList(fieldErrorList: string[]) {
    if (fieldErrorList) {
      this.arrivalDetailsEditModel.checkCallErrorFieldList = fieldErrorList;
    }
  }
  @Input() set loadDetails(loadInfo) {
    if (loadInfo) {
      this.arrivalDetailsEditModel.loadDetails = loadInfo;
      if (loadInfo.operationalPlanID && loadInfo.operationalPlanStopSequenceNumber) {
        this.arrivalDetailsEditModel.findArrivalRequest.operationalPlanID = loadInfo.operationalPlanId;
        this.arrivalDetailsEditModel.findArrivalRequest.operationalPlanNumber = loadInfo.operationalPlanNumber;
      }
      this.getStopId();
    }
  }
  @Input() set resourceDetails(resourceOverview: ResourceOverview) {
    this.arrivalDetailsEditModel.resourceOverview = resourceOverview;
  }
  @Output() readonly stopSequenceNumber: EventEmitter<StopDetails> = new EventEmitter();
  @Output() readonly checkCallStopId: EventEmitter<any> = new EventEmitter();
  @ViewChild('arrivalDate') arrivalDate: Calendar;
  @Output() arrivalDeviationType: EventEmitter<ErrorList[]> = new EventEmitter<ErrorList[]>();
  constructor(private readonly changeDetector: ChangeDetectorRef,
    private readonly arrivalDetailsEditService: ActivityLogArrivalEditService,
    private readonly fb: FormBuilder, private readonly datePipe: DatePipe,
    private readonly toastMessage: MessageService, private readonly activatedRoute: ActivatedRoute,
    private readonly router: Router, private readonly activityLogDetailsService: ActivityLogService) {
    this.arrivalDetailsEditModel = new ActivityLogArrivalAddModel();
  }

  ngOnInit() {
    this.arrivalDetailsEditModel.editArrivalForm = this.initializeFormGroup();
    this.arrivalDetailsEditModel.activityType = this.activatedRoute.queryParams['_value']['activityType'];
    this.getArrivalCallDetails(this.activatedRoute.queryParams['_value']['checkCallId'],
      this.arrivalDetailsEditModel.activityType);
    this.addCommentsControl();
  }
  loadStopInformation(stopInfo) {
    this.arrivalDetailsEditModel.stopLocationEdit = stopInfo ? stopInfo : null;
  }
  sequenceNumber(event) {
    if (event.stopSequenceNumber) {
      this.stopSequenceNumber.emit({
        'stopSequenceNumber': event.stopSequenceNumber,
        'stopId': event.stopId,
        'destinationHeader': event.destinationHeader
      });
    }
  }
  ngAfterViewChecked() {
    if (this.arrivalDetailsEditModel.showCheckCallDetails &&
      this.arrivalDetailsEditModel.arrivalDeviationType !== this.arrivalDetailsEditModel.noDeviationType) {
      const hasDeviationError =
        ActivityLogUtils.getArrivalMandatory(this.arrivalDetailsEditModel.checkCallErrorFieldList);
      if (hasDeviationError) {
        ActivityLogUtils.checkMandatoryFields(this.arrivalDetailsEditModel.editArrivalForm);
        this.validateActivityLogForm();
      }
    }
  }
  ngOnDestroy() {
    this.arrivalDetailsEditModel.canSubscribe = false;
    if (this.arrivalDetailsEditModel.editArrivalForm) {
      this.arrivalDetailsEditModel.editArrivalForm.removeControl('arrivalLate');
      this.arrivalDetailsEditModel.editArrivalForm.removeControl('arrivalEarly');
    }
  }
  getArrivalCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    if (operationalPlanCheckCallId && activityType) {
      this.arrivalDetailsEditModel.isLoading = true;
      this.getCheckCallData(operationalPlanCheckCallId, activityType, this.arrivalDetailsEditModel.showCheckCallDetails);
    }
  }
  getCheckCallData(operationalPlanCheckCallId, activityType, showCheckCallDetails) {
    this.activityLogDetailsService.getCheckCallDetails(operationalPlanCheckCallId, activityType, showCheckCallDetails)
      .pipe(takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
        finalize(() => {
          this.arrivalFinalizeMethod();
        }))
      .subscribe((data: ViewActivityLogDetails) => {
        this.arrivalDetailsEditModel.isLoading = false;
        if (data) {
          this.arrivalResponse(data);
        }
      }, (error: Error) => {
        this.arrivalDetailsEditModel.isLoading = false;
      });
  }
  arrivalResponse(data: ViewActivityLogDetails) {
    this.arrivalDetailsEditModel.activityLogDetails = data;
    if (this.arrivalDetailsEditModel.showCheckCallDetails) {
      this.arrivalDetailsEditModel.arrivalDeviationType = (data['arrivalTimeDeviationDetails']) ?
        data['arrivalTimeDeviationDetails']['arrivalTimeDeviationType'] : 'Late';
      this.getCommentsCount(data);
    }
    this.formatData(data);
  }
  getStopId() {
    if (this.arrivalDetailsEditModel.showCheckCallDetails && this.arrivalDetailsEditModel.activityLogDetails
      && this.arrivalDetailsEditModel.loadDetails) {
      const stopDto = find(this.arrivalDetailsEditModel.loadDetails.operationalPlanStopDTOs,
        (item: any) => item.locationDetailsDTO.locationId ===
          this.arrivalDetailsEditModel.activityLogDetails.operationalPlanStopDetails.locationDetails.locationId);

      if (stopDto && stopDto.operationalPlanStopId) {
        this.checkCallStopId.emit({
          'checkCallStopId': stopDto.operationalPlanStopId
        });
      }
    }
  }
  arrivalFinalizeMethod() {
    this.arrivalDetailsEditModel.isLoading = false;
    this.changeDetector.detectChanges();
  }
  formatData(arrivalDetails: ViewActivityLogDetails) {
    this.arrivalDetailsEditModel.isLoading = true;
    this.getReasonCategoryDetails(true);
    this.loadReasonResponsibility(true);
    if (arrivalDetails.arrivalTimeDeviationDetails) {
      this.getArrivalDeviationDetails(arrivalDetails.arrivalTimeDeviationDetails);
    }
    this.arrivalDetailsEditModel.timeZone = arrivalDetails.operationalPlanStopDetails.locationDetails.address.timeZone;
    this.arrivalDetailsEditModel.arrivalDate = this.formatDateTime(arrivalDetails.arrivalDateTime, 'MM/dd/yyyy');
    this.arrivalDetailsEditModel.arrivalTime = momentTimezone.tz(arrivalDetails.arrivalDateTime,
      this.arrivalDetailsEditModel.timeZone).format('hh:mm A');
    this.arrivalDetailsEditModel.arrivalTimeSelected = this.arrivalDetailsEditModel.arrivalTime;
    ActivityLogUtils.formatTimeSelected(this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalTime.value);
    this.arrivalDetailsEditModel.editArrivalRequest.arrivalTimestamp = arrivalDetails.arrivalDateTime;
    this.arrivalDetailsEditModel.checkCallID = arrivalDetails.operationalPlanCheckCallId;
    this.arrivalDetailsEditModel.findArrivalRequest.operationalPlanStopSequenceNumber =
      arrivalDetails.operationalPlanStopDetails.operationalPlanStopSequenceNumber;
    this.arrivalDetailsEditModel.findArrivalRequest.operationalPlanID = this.activatedRoute.queryParams['_value']['loadNumber'];
    this.arrivalDetailsEditModel.comments = arrivalDetails.comments;
    this.arrivalDetailsEditModel.defaultArrivalDate = new Date(this.arrivalDetailsEditModel.arrivalDate);
    this.frameArrivalDeviationFormDetails();
    ActivityLogUtils.checkArrivalTime(this.arrivalDetailsEditModel, true, this.toastMessage, 'Arrival');
    this.addCommentsControl();
    this.arrivalDate.ngOnInit();
  }
  initializeFormGroup(): FormGroup {
    return this.fb.group({
      arrivalDate: [''],
      arrivalTime: [''],
      arrivalLate: this.fb.group({
        lateReasonCategory: [],
        lateReason: [],
        lateReasonResponsibility: [''],
        lateReasonContact: ['']
      }),
      arrivalEarly: this.fb.group({
        earlyReasonCategory: [],
        earlyReason: [],
        earlyReasonResponsibility: [''],
        earlyReasonContact: ['']
      })
    });
  }
  getArrivalDeviationDetails(arrivalTimeDeviationDetails: ArrivalTimeDeviationDetails) {
    this.arrivalDetailsEditModel.arrivalDeviationType = arrivalTimeDeviationDetails.arrivalTimeDeviationType;
    this.arrivalDetailsEditModel.arrivalTimeDeviationReason = arrivalTimeDeviationDetails.arrivalTimeDeviationReason;
    this.arrivalDetailsEditModel.arrivalTimeDeviationReasonCategory = arrivalTimeDeviationDetails.arrivalTimeDeviationReasonCategory;
    this.arrivalDetailsEditModel.arrivalDeviationResponsibilityPartyType =
      arrivalTimeDeviationDetails.arrivalDeviationResponsibilityPartyType;
    this.arrivalDetailsEditModel.contactID = arrivalTimeDeviationDetails.contactID;
    this.arrivalDetailsEditModel.contactName = arrivalTimeDeviationDetails.contactName;
    this.arrivalDetailsEditModel.contactText = arrivalTimeDeviationDetails.contactText;
  }
  getReasonCategoryDetails(isEdit = false) {
    this.arrivalDetailsEditService.getReasonCategory().pipe(
      takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
      finalize(() => {
        this.changeDetector.detectChanges();
      })
    ).subscribe((data: LateReasonCategory) => {
      this.arrivalDetailsEditModel.reasonCategory = this.getFormattedReasonCategory(data);
      const categoryValue = find(this.arrivalDetailsEditModel.reasonCategory,
        ['label', this.arrivalDetailsEditModel.arrivalTimeDeviationReasonCategory]);
      if (isEdit) {
        this.frameArrivalDeviationFormDetails();
        if (categoryValue) {
          this.onReasonCategorySelected(categoryValue.value, isEdit);
        }
      }
    }, (error) => {
      this.arrivalDetailsEditModel.reasonCategory = [];
    });
  }
  getFormattedReasonCategory(data: LateReasonCategory) {
    let reasonCategoryData = [];
    if (data) {
      reasonCategoryData = data._embedded.operationalPlanStopAppointmentChangeReasonCategories.
        map((reasonCategory: OperationalPlanStopAppointmentChangeReasonCategory) => {
          return {
            'label': reasonCategory.operationalPlanAppointmentChangeCategoryDescription,
            'value': reasonCategory.operationalPlanAppointmentChangeCategoryCode
          };
        });
    }
    return reasonCategoryData;
  }
  formatDateTime(event, format) {
    return ActivityLogUtils.formatBasedOnZone(this.datePipe, event, format);
  }
  onReasonCategorySelected(selectedReasonCategory: string, isEdit = false) {
    if (selectedReasonCategory) {
      this.arrivalDetailsEditModel.categorySelected = selectedReasonCategory;
      this.arrivalDetailsEditModel.reason = [];
      ActivityLogUtils.resetFormControls(this.arrivalDetailsEditModel, 'editArrivalForm', true);
      if (isEdit) {
        this.loadReason(isEdit);
      }
    }
  }
  loadReason(isEdit = false) {
    if (this.arrivalDetailsEditModel.categorySelected) {
      this.arrivalDetailsEditService.getReason(this.arrivalDetailsEditModel.categorySelected).pipe(
        takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      ).subscribe((data: LateReason) => {
        this.arrivalDetailsEditModel.reason = this.getFormattedReason(data);
        if (isEdit) {
          this.frameArrivalDeviationFormDetails();
        }
      });
    }
  }
  onSelectDriver(selectedDriverId: string) {
    this.arrivalDetailsEditModel.contactID = selectedDriverId;
  }
  onDateChange(dateValue, isDate: boolean) {
    dateValue.overlayVisible = false;
    const dateObj = DateUtils.getTimeValue(dateValue);
    if (isDate) {
      this.formatDateValue(dateValue);
      ActivityLogUtils.checkArrivalTime(this.arrivalDetailsEditModel, true, this.toastMessage, 'Arrival');
    } else {
      this.formatDateValue(this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalDate.value);
      this.arrivalDetailsEditModel.arrivalTime = dateObj.withoutPm;
      this.arrivalDetailsEditModel.arrivalTimeSelected =
        ActivityLogUtils.formatTimeSelected(this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalTime.value);
      ActivityLogUtils.checkArrivalTime(this.arrivalDetailsEditModel, true, this.toastMessage, 'Arrival');
    }
    ActivityLogUtils.checkMandatoryFields(this.arrivalDetailsEditModel.editArrivalForm);
    if (this.arrivalDetailsEditModel.arrivalDate && this.arrivalDetailsEditModel.arrivalTime) {
      this.getEarlyOrLateArrival();
    }
  }
  getEarlyOrLateArrival() {
    this.arrivalDetailsEditModel.editArrivalForm.get(`arrivalLate`).reset();
    this.arrivalDetailsEditModel.editArrivalForm.get(`arrivalEarly`).reset();
    if (this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalDate.value &&
      this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalTime.value && this.arrivalDetailsEditModel.editArrivalForm.valid) {
      this.arrivalDetailsEditModel.arrivalDeviationType = 'No deviation type';
      this.arrivalDetailsEditModel.findArrivalRequest.arrivalTimestamp = DateUtils.dateTimeZoneFormat(this.
        arrivalDetailsEditModel.arrivalDate, this.arrivalDetailsEditModel.arrivalTime, this.arrivalDetailsEditModel.timeZone);
      this.arrivalDetailsEditModel.isLoading = true;
      this.arrivalDetailsEditService.getArrivalType(this.arrivalDetailsEditModel.findArrivalRequest).
        pipe(takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
          finalize(() => {
            this.arrivalDetailsEditModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: ArrivalDeviationResponse) => {
          if (data && data.arrivalDeviationType) {
            this.arrivalDetailsEditModel.arrivalDeviationType = data.arrivalDeviationType;
            this.arrivalDetailsEditModel.isLoading = false;
            this.handleLateOrEarlyArrival(data);
          }
        }, (error: Error) => {
          this.arrivalDetailsEditModel.isLoading = false;
          ActivityLogUtils.arrivalError(error['error'], this.toastMessage);
          this.arrivalDeviationType.emit([]);
        });
    } else {
      ActivityLogUtils.checkMandatoryFields(this.arrivalDetailsEditModel.editArrivalForm);
      FormValidationUtils.validateAllFormFields(this.arrivalDetailsEditModel.editArrivalForm);
      this.arrivalDeviationType.emit([]);
    }
  }
  handleLateOrEarlyArrival(data) {
    if (this.arrivalDetailsEditModel.arrivalDeviationType.toLowerCase() !== 'ontime') {
      if (this.arrivalDetailsEditModel.loadDetails && this.arrivalDetailsEditModel.loadDetails.operationalPlanStopDTOs &&
        this.arrivalDetailsEditModel.stopLocationEdit &&
        this.arrivalDetailsEditModel.stopLocationEdit.operationalPlanStopSequenceNumber) {
        const stopSequence = findIndex(this.arrivalDetailsEditModel.loadDetails.operationalPlanStopDTOs,
          ['operationalPlanStopSequenceNumber', this.arrivalDetailsEditModel.stopLocationEdit.operationalPlanStopSequenceNumber]);
        const stopInfo = stopSequence === 0 ?
          'Origin' : stopSequence === this.arrivalDetailsEditModel.loadDetails.operationalPlanStopDTOs.length - 1 ? 'Destination' :
            `Stop${stopSequence + 1}`;
        const locationName = `${this.getLocationCode()}
          ${new AddressDetailsPipe().transform(this.arrivalDetailsEditModel.stopLocationEdit.locationDetails.address,
          ['locationAddress'])}
          ${new AddressDetailsPipe().transform(this.arrivalDetailsEditModel.stopLocationEdit.locationDetails,
            ['addressZipDetails'])}`;
        this.arrivalDeviationType.emit([{
          errorMessage: `${data.arrivalDeviationType} Arrival at the ${stopInfo} - ${locationName}`,
          errorType: 'Arrival Deviation',
          errorSeverity: 'ERROR'
        }]);
      }
    } else {
      this.arrivalDeviationType.emit([]);
    }
  }
  getLocationCode() {
    const locationNameCode = new AddressDetailsPipe().transform(this.arrivalDetailsEditModel.stopLocationEdit.locationDetails,
      ['locationNameCode']);
    return locationNameCode ? `${locationNameCode},` : '';
  }
  onDateTyped() {
    this.formatDateValue(this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalDate.value);
    if (this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalDate.value > new Date()) {
      ActivityLogUtils.dateValidation(this.arrivalDetailsEditModel.editArrivalForm, 'arrivalDate',
        this.toastMessage, 'Arrival');
    }
    ActivityLogUtils.checkArrivalTime(this.arrivalDetailsEditModel, true, this.toastMessage, 'Arrival');
    if (this.arrivalDetailsEditModel.arrivalDate && this.arrivalDetailsEditModel.arrivalTime) {
      this.getEarlyOrLateArrival();
    }
  }
  onTimeTyped() {
    this.formatTimeValue(this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalTime.value);
  }
  clearDateTime(isDate: boolean, calObj?: any) {
    if (isDate) {
      this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalDate.reset();
    } else {
      this.arrivalDetailsEditModel.editArrivalForm.controls.arrivalTime.reset();
      calObj.overlayVisible = false;
    }
  }
  formatDateValue(arrivalDate: Date) {
    this.arrivalDetailsEditModel.arrivalDate = moment(new Date(arrivalDate)).format('YYYY-MM-DD');
  }
  formatTimeValue(arrivalTime: Date) {
    this.arrivalDetailsEditModel.arrivalTime = moment(new Date(arrivalTime)).format('H:mm');
  }
  getFormattedReason(data: LateReason) {
    let lateReasonData = [];
    if (data) {
      lateReasonData = data._embedded.operationalPlanStopAppointmentChangeReasons.
        map((lateReason: OperationalPlanStopAppointmentChangeReason) => {
          return {
            'label': lateReason.operationalPlanAppointmentChangeDescription,
            'value': lateReason.operationalPlanAppointmentChangeCode
          };
        });
    }
    return lateReasonData;
  }
  loadReasonResponsibility(isEdit = false) {
    this.arrivalDetailsEditService.getReasonResponsibilityTypes().pipe(
      takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
      finalize(() => {
        this.arrivalDetailsEditModel.isLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe((data: ReasonResponsibility) => {
      this.arrivalDetailsEditModel.reasonResponsibility = [];
      if (data && data._embedded && data._embedded.arrivalDeviationResponsibilityPartyTypes.length > 0) {
        this.arrivalDetailsEditModel.reasonResponsibility = data._embedded.arrivalDeviationResponsibilityPartyTypes.map(reasonTypes => {
          return {
            label: reasonTypes.arrivalDeviationResponsibilityPartyTypeDescription,
            value: reasonTypes.arrivalDeviationResponsibilityPartyTypeCode
          };
        });
        const partyType = find(this.arrivalDetailsEditModel.reasonResponsibility,
          ['label', this.arrivalDetailsEditModel.arrivalDeviationResponsibilityPartyType]);
        if (partyType && isEdit) {
          this.onSelectReasonResponsibility(partyType.value, isEdit);
        }
      }
    });
  }
  frameArrivalDeviationFormDetails() {
    ActivityLogUtils.setFormValue(this.arrivalDetailsEditModel);
    const categoryValue = find(this.arrivalDetailsEditModel.reasonCategory,
      ['label', this.arrivalDetailsEditModel.arrivalTimeDeviationReasonCategory]);
    const reasonValue = find(this.arrivalDetailsEditModel.reason,
      ['label', this.arrivalDetailsEditModel.arrivalTimeDeviationReason]);
    const partyType = find(this.arrivalDetailsEditModel.reasonResponsibility,
      ['value', this.arrivalDetailsEditModel.arrivalDeviationResponsibilityPartyType]);
    if (this.arrivalDetailsEditModel.arrivalDeviationType === 'Late') {
      ActivityLogUtils.setLateFormValue(this.arrivalDetailsEditModel, categoryValue, reasonValue, partyType);
    } else if (this.arrivalDetailsEditModel.arrivalDeviationType === 'Early') {
      ActivityLogUtils.setEarlyFormValue(this.arrivalDetailsEditModel, categoryValue, reasonValue, partyType);
    }
    this.arrivalDetailsEditModel.isLoading = false;
    this.changeDetector.detectChanges();
  }
  onSelectReasonResponsibility(selectedReasonResp: string, isEdit = false) {
    this.arrivalDetailsEditModel.arrivalDeviationResponsibilityPartyType = selectedReasonResp;
    this.arrivalDetailsEditModel.resourcesWithImages = [];
    this.arrivalDetailsEditModel.results = [];
    ActivityLogUtils.resetFormControls(this.arrivalDetailsEditModel, 'editArrivalForm');
    if (selectedReasonResp === 'Other') {
      this.arrivalDetailsEditModel.isFreeText = true;
    } else {
      this.arrivalDetailsEditModel.isFreeText = false;
      if (this.arrivalDetailsEditModel.contactName && isEdit) {
        const userId = this.arrivalDetailsEditModel.regex.exec(this.arrivalDetailsEditModel.contactName);
        this.loadReasonContact(userId[1], isEdit);
      }
    }
    if (isEdit) {
      this.frameArrivalDeviationFormDetails();
    }
  }
  onsearchReasonText(searchText: string, isText: boolean) {
    if (isText) {
      this.arrivalDetailsEditModel.results = [];
    } else {
      this.loadReasonContact(searchText);
    }
  }
  loadReasonContact(search: string, isEdit = false) {
    if (this.arrivalDetailsEditModel.arrivalDeviationResponsibilityPartyType &&
      this.arrivalDetailsEditModel.arrivalDeviationResponsibilityPartyType.toLowerCase() !== 'carrier' &&
      this.arrivalDetailsEditModel.arrivalDeviationResponsibilityPartyType.toLowerCase() !== 'other') {
      this.arrivalDetailsEditService.getResourceDetails(DriverDetailQuery.getDriverDetailsQuery(search.replace(/[()]/g, '')))
        .pipe(takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
          finalize(() => {
            this.arrivalDetailsEditModel.isLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: ElasticResponseModel) => {
          if (data && data.hits && data.hits.hits) {
            this.arrivalDetailsEditModel.resourceList = data.hits.hits;
            this.getDriverImage(DriverDetailsUtils.loadDriverDetails(data), isEdit);
          } else {
            this.resetResource();
          }
        }, (error: Error) => {
          this.resetResource();
        });
    } else {
      this.resetResource();
    }
  }
  resetResource() {
    this.arrivalDetailsEditModel.resourceList = [];
    this.arrivalDetailsEditModel.resourcesWithImages = [];
  }
  getDriverImage(resourceDetails: FetchDetails[], isEdit = false) {
    this.arrivalDetailsEditService.getResourceImage(ActivityLogUtils.getDriverIds(resourceDetails))
      .pipe(takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
        finalize(() => {
          this.arrivalDetailsEditModel.isLoading = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((data: DriverImageDetails[]) => {
        this.arrivalDetailsEditModel.resourcesWithImages = [];
        if (data) {
          this.arrivalDetailsEditModel.resourcesWithImages = ActivityLogUtils.imageDetails(data);
          if (isEdit) {
            this.arrivalDetailsEditModel.contactName = find(this.arrivalDetailsEditModel.
              resourcesWithImages, ['emplId', this.arrivalDetailsEditModel.contactID]);
            this.frameArrivalDeviationFormDetails();
          }
        }
      }, (error: Error) => {
        this.arrivalDetailsEditModel.resourcesWithImages = [];
      });
  }
  onReasonSelected(selectedReason: string) {
    this.arrivalDetailsEditModel.arrivalTimeDeviationReason = selectedReason;
  }
  validateActivityLogForm(): void {
    if (this.arrivalDetailsEditModel.arrivalDeviationType) {
      ActivityLogUtils.checkForReasonResponsibility(this.arrivalDetailsEditModel, 'editArrivalForm');
      FormValidationUtils.validateAllFormFields(this.arrivalDetailsEditModel.editArrivalForm);
      this.changeDetector.detectChanges();
    }
  }
  frameArrivalRequest(): void {
    if (this.arrivalDetailsEditModel.arrivalDeviationType &&
      this.arrivalDetailsEditModel.arrivalDeviationType.toLowerCase() !== 'ontime') {
      this.arrivalDetailsEditModel.editArrivalRequest.arrivalTimeDeviationDetails =
        ActivityLogUtils.frameArrivalDeviationRequest(this.arrivalDetailsEditModel.isFreeText,
          this.arrivalDetailsEditModel.arrivalDeviationType,
          this.arrivalDetailsEditModel.editArrivalForm.controls);
    } else {
      this.arrivalDetailsEditModel.editArrivalRequest.arrivalTimeDeviationDetails = null;
    }
  }
  removeValues(isReason: boolean) {
    ActivityLogUtils.resetFormControls(this.arrivalDetailsEditModel, 'editArrivalForm', isReason);
  }
  saveForm() {
    if (!this.arrivalDetailsEditModel.editArrivalForm.dirty && !this.arrivalDetailsEditModel.showCheckCallDetails) {
      ActivityLogUtils.onNoChangeMessage(this.toastMessage);
      return;
    }
    ActivityLogUtils.checkMandatoryFields(this.arrivalDetailsEditModel.editArrivalForm);
    FormValidationUtils.validateAllFormFields(this.arrivalDetailsEditModel.editArrivalForm);
    this.changeDetector.detectChanges();
    if (this.arrivalDetailsEditModel.editArrivalForm.invalid) {
      ActivityLogUtils.checkArrivalFormValidity(this.toastMessage, this.arrivalDetailsEditModel.editArrivalForm,
        this.arrivalDetailsEditModel, true, this.arrivalDeviationType, this.changeDetector);
    } else {
      this.afterFormValid();
    }
  }
  afterFormValid() {
    if (this.arrivalDetailsEditModel.arrivalDeviationType !== 'No deviation type') {
      this.toastMessage.clear();
      this.arrivalDetailsEditModel.editArrivalRequest.arrivalTimestamp =
        (this.arrivalDetailsEditModel.findArrivalRequest.arrivalTimestamp)
          ? this.arrivalDetailsEditModel.findArrivalRequest.arrivalTimestamp :
          this.arrivalDetailsEditModel.editArrivalRequest.arrivalTimestamp;
      this.validateActivityLogForm();
      if (this.arrivalDetailsEditModel.editArrivalForm.valid) {
        this.frameArrivalRequest();
        this.changeDetector.detectChanges();
        this.updateArrivalActivity();
      } else {
        ActivityLogUtils.requiredFieldError(this.arrivalDeviationType, this.changeDetector);
      }
    }
  }
  saveCheckCallArrival() {
    this.arrivalDetailsEditModel.editArrivalRequest.checkCallId = this.arrivalDetailsEditModel.checkCallID;
    this.arrivalDetailsEditModel.editArrivalRequest.operationalPlanNumber =
      this.arrivalDetailsEditModel.loadDetails.operationalPlanNumber;
    this.arrivalDetailsEditModel.editArrivalRequest.operationalPlanStopSequenceNumber =
      this.arrivalDetailsEditModel.findArrivalRequest.operationalPlanStopSequenceNumber;
    this.arrivalDetailsEditModel.editArrivalRequest.checkCallSourceTimestamp =
      this.arrivalDetailsEditModel.editArrivalRequest.arrivalTimestamp;
    this.arrivalDetailsEditModel.editArrivalRequest.resourceDetails = {
      type: 'Truck',
      value: ActivityLogUtils.getTruckValue(this.arrivalDetailsEditModel.resourceOverview)
    };
    this.arrivalDetailsEditModel.editArrivalRequest.checkCallSource = this.arrivalDetailsEditModel.activityLogDetails.checkCallSource;
    this.arrivalDetailsEditModel.editArrivalRequest.comments =
      ActivityLogUtils.getValueOrNull(this.arrivalDetailsEditModel.editArrivalForm.controls.comments.value);
    ActivityLogUtils.getCheckCallReq(this.arrivalDetailsEditModel.editArrivalRequest, this.arrivalDetailsEditModel.activityType,
      this.arrivalDetailsEditModel.isWarningOverride);
  }
  updateArrivalActivity() {
    if (this.arrivalDetailsEditModel.showCheckCallDetails) {
      this.saveCheckCallArrival();
      if (this.arrivalDetailsEditModel.editArrivalRequest && this.arrivalDetailsEditModel.checkCallID) {
        if (this.arrivalDetailsEditModel.editArrivalRequest.resourceDetails &&
          this.arrivalDetailsEditModel.editArrivalRequest.resourceDetails.value) {
          this.updateArrivalCheckCall();
        } else {
          this.toastMessage.clear();
          ActivityLogUtils.resourceFieldError(this.toastMessage);
        }
      }
    } else {
      if (this.arrivalDetailsEditModel.editArrivalRequest && this.arrivalDetailsEditModel.checkCallID) {
        this.updateArrivalCheckCall();
      }
    }
  }
  updateArrivalCheckCall() {
    this.arrivalDetailsEditModel.isLoading = true;
    this.changeDetector.detectChanges();
    this.arrivalDetailsEditService.updateArrivalDetails(this.arrivalDetailsEditModel.
      editArrivalRequest, this.arrivalDetailsEditModel.checkCallID, this.arrivalDetailsEditModel.showCheckCallDetails).
      pipe(takeWhile(() => this.arrivalDetailsEditModel.canSubscribe),
        finalize(() => {
          this.arrivalDetailsEditModel.isLoading = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((data: ArrivalDeviationResponse) => {
        this.arrivalDetailsEditModel.isLoading = false;
        if (data) {
          ActivityLogUtils.successMessage(this.toastMessage, 'Arrival', 'updated');
          this.navigateToParent();
        }
      }, (error) => {
        this.arrivalDetailsEditModel.isLoading = false;
        this.handleUpdateArrivalError(error);
      });
  }
  navigateToParent() {
    timer(ActivityLogModel.editSaveTimer).subscribe(() => {
      if (this.arrivalDetailsEditModel.isTracking || this.arrivalDetailsEditModel.editFromTracking) {
        this.router.navigate(['/trackingdetails'],
          {
            queryParams: this.arrivalDetailsEditModel.trackingDetailsParam
          });
      } else if (this.arrivalDetailsEditModel.checkCallNavigation) {
        this.router.navigate(['/tracking'],
          {
            queryParams: {
              fromCheckCall: 'true'
            }
          });
      } else {
        this.router.navigate(['/loaddetails', this.arrivalDetailsEditModel.findArrivalRequest.operationalPlanID],
          {
            queryParams: {
              index: 2
            }
          });
      }
    });
  }
  handleUpdateArrivalError(error) {
    if (error && error.status === 500) {
      this.toastMessage.add({
        severity: 'error',
        summary: 'Server Error',
        detail: ErrorUtils.getErrorMessage(error.status)
      });
    } else {
      if (error && error.error && error.error.errors && ActivityLogUtils.handleEmptyError(error, this.toastMessage)) {
        this.arrivalDeviationType.emit(error.error.errors);
        ActivityLogUtils.checkDeviationMandatoryFields(this.arrivalDetailsEditModel, 'editArrivalForm', error['error'].errors);
      }
      ActivityLogUtils.arrivalError(error['error'], this.toastMessage);
    }
  }
  validateFormFields(fieldName: string) {
    return (this.arrivalDetailsEditModel.editArrivalForm.get(fieldName).invalid
      && this.arrivalDetailsEditModel.editArrivalForm.get(fieldName).touched);
  }
  validateDeviationFormFields(formGroupName: string, fieldName: string) {
    return (this.arrivalDetailsEditModel.editArrivalForm.get(formGroupName).get(fieldName).invalid
      && this.arrivalDetailsEditModel.editArrivalForm.get(formGroupName).get(fieldName).touched);
  }
  onTextAreaType() {
    this.arrivalDetailsEditModel.textareaCount = this.arrivalDetailsEditModel.editArrivalForm.controls.comments ?
    this.arrivalDetailsEditModel.editArrivalForm.controls.comments.value.length : 0;
  }
  addCommentsControl() {
    if (this.arrivalDetailsEditModel.showCheckCallDetails) {
      this.arrivalDetailsEditModel.editArrivalForm.addControl('comments', new FormControl());
    }
  }
  getCommentsCount(data: ViewActivityLogDetails) {
    if (data.comments) {
      this.arrivalDetailsEditModel.textareaCount = data.comments.length;
    }
  }
  getZoneFormat() {
    return ActivityLogUtils.getZoneFormat(this.arrivalDetailsEditModel.timeZone);
  }
}

