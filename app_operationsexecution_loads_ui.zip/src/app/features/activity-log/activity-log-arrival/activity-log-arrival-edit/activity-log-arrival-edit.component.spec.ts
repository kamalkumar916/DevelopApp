import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { MessageService } from 'primeng/components/common/messageservice';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { TooltipModule } from 'primeng/tooltip';
import { configureTestSuite } from 'ng-bullet';

import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { AppSharedDataService } from '../../../../shared/jbh-app-services/app-shared-data.service';

import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { ActivityLogArrivalEditComponent } from './activity-log-arrival-edit.component';
import { ActivityLogLocationDetailsComponent } from '../../activity-log-location-details/activity-log-location-details.component';
import { ActivityLogResourceInformationComponent } from '../activity-log-resource-information/activity-log-resource-information.component';
import { GlobalPopupsModule } from './../../../../shared/global-popups/global-popups.module';
import { ActivityLogUtils } from '../../services/activity-log.utils';

describe('ActivityLogArrivalEditComponent', () => {
  let component: ActivityLogArrivalEditComponent;
  let fixture: ComponentFixture<ActivityLogArrivalEditComponent>;
  const formBuilder: FormBuilder = new FormBuilder();
  let editArrivalform: FormGroup;
  const numberPrefixTypeDTO = {
    prefix: '',
    number: '',
    typeRequired: ''
  };
  const trailer = {
    prefix: '',
    number: '',
    typeRequired: false,
    length: 0,
    isLengthRequired: false,
    isPreLoaded: false,
    category: '',
    type: ''
  };
  const editArrivalDetails = {
    operationalPlanCheckCallId: 1,
    arrivalDateTime: '2019-09-26T10:10:00-05:00',
    operationalPlanStopId: 1,
    operationalPlanId: 1,
    loadedType: '',
    loadedBy: '',
    departureTimestamp: '',
    lastUpdatedTimestamp: '',
    operationalPlanStopDetails: {
      operationalPlanStopSequenceNumber: 1,
      operationalPlanStopReasonCode: 'Pickup',
      operationalPlanStopReasonCodeDescription: 'Pickup',
      locationDetails: {
        locationId: '26551',
        locationName: 'VAN Buren Main',
        locationCode: 'VAVAC3',
        address: {
          addressLine1: '5 Main St',
          addressLine2: '',
          city: 'Van Buren',
          state: 'AR',
          zipcode: '729565706',
          country: 'USA',
          countryName: 'USA',
          timeZone: 'America/Chicago'
        }
      },
      appointmentStartTimestamp: '2019-09-26T10:00:00-05:00',
      appointmentEndTimestamp: '2019-09-26T10:00:00-05:00',
      stopSequenceDescription: 'Origin'
    },
    lastUpdateProgramName: 'Process ID',
    lastUpdatedUserId: 'pidordm',
    lastUpdatedOn: '09/28/2019 01:47 PM GMT',
    comments: 'test',
    arrivalTimeDeviationDetails: {
      arrivalTimeDeviationType: 'Early',
      arrivalTimeDeviationReason: 'Driver',
      arrivalTimeDeviationReasonCategory: 'Driver',
      arrivalDeviationResponsibilityPartyType: 'JBH',
      contactID: '5465575',
      contactName: 'JAMES',
      contactText: 'SA'
    },
    loadedTimestamp: '',
    proNumber: null,
    weight: null,
    volume: null,
    temperature: null,
    count: null,
    countedBy: '',
    sealNumber: '',
    bolNumber: '',
    poNumbers: null,
    shipperIdentificationNumber: '',
    receiverStateId: null,
    receiverStateName: '',
    hazmatIndicator: '',
    pickupEquipmentDetails: null,
    dropEquipmentDetails: null,
    stopServicesTypeCodes: null,
    stopServices: null
  };
  const loadInfo = {
    operationalPlanId: 0,
    operationalPlanNumber: '',
    operationalPlanStopSequenceNumber: 0,
    operationalPlanType: {
      operationalPlanTypeCode: '',
      operationalPlanTypeDescription: ''
    },
    operationalPlanSubtype: {
      operationalPlanSubtypeCode: '',
      operationalPlanSubtypeDescription: ''
    },
    operationalPlanStatus: {
      operationalPlanStatusCode: '',
      operationalPlanStatusDescription: ''
    },
    operationalPlanServiceOfferingCode: '',
    operationalPlanTransitModeCode: '',
    operationalPlanFinanceBusinessUnitCode: '',
    desirabilityIndexNumber: 0,
    resource: '',
    truck: '',
    requiredEquipment: '',
    trailer: '',
    container: '',
    chassis: '',
    classifications: [],
    loadedMilesWithUnit: '',
    loadedMiles: '',
    emptyMiles: '',
    estimatedTotalMiles: '',
    items: '',
    totalWeight: '',
    requestedService: [],
    estimatedTimeOfCompletion: '',
    routeSequenceNumber: '',
    totalRouteSequenceNumber: '',
    routePlanId: '',
    routeId: '',
    payRoute: [],
    utilization: null,
    totalPointsQuantity: '',
    networkOperationalPlanIndicator: '',
    externalOperationalPlanBoardIndicator: '',
    bulkProcessIndicator: '',
    operationalGroupCode: '',
    customerRate: [],
    tripPlanTransitValue: '',
    operationalPlanStopDTOs: null,
    billTo: [],
    operationalPlanOwnershipDTOs: [],
    equipmentDetails: {
      isPreLoaded: false,
      truck: numberPrefixTypeDTO,
      chassis: numberPrefixTypeDTO,
      container: numberPrefixTypeDTO,
      trailer: trailer,
      currentTrailer: trailer,
      driverId: 0,
      equipmentId: 0,
      alphaCode: '',
      firstName: '',
      lastName: '',
      middleName: '',
      resourceName: '',
      tanker: numberPrefixTypeDTO,
      hopper: numberPrefixTypeDTO
    },
    operationalPlanRouteGuideStatus: {
      operationalPlanRouteGuideStatusCode: '',
      operationalPlanRouteGuideStatusDescription: ''
    },
    servicePriorityCode: '',
    committedFreightIndicator: '',
    shipmentId: [],
    payRouteLists: [],
    jbhuntFailureCount: 0,
    operationalPlanOrderIds: {}
  };
  const arrivalTimeDeviationDetails = {
    arrivalTimeDeviationType: 'Early',
    arrivalTimeDeviationReason: 'Other',
    arrivalTimeDeviationReasonCategory: 'Other',
    arrivalDeviationResponsibilityPartyType: 'driver',
    contactID: '12445',
    contactName: 'James',
    contactText: 'test'
  };
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, JbhLoaderModule, ReactiveFormsModule, CalendarModule, DirectivesModule,
        AutoCompleteModule, PipesModule, TooltipModule, RouterTestingModule, NoopAnimationsModule, GlobalPopupsModule],
      providers: [UserService, MessageService, AppConfigService, DatePipe, AppSharedDataService],
      declarations: [ActivityLogArrivalEditComponent, ActivityLogLocationDetailsComponent, ActivityLogResourceInformationComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogArrivalEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onDateTyped have been called', () => {
    spyOn(component, 'onDateTyped');
    component.onDateTyped();
    expect(component.onDateTyped).toHaveBeenCalled();
  });

  it('saveCheckCallArrival have been called', () => {
    spyOn(component, 'saveCheckCallArrival');
    component.saveCheckCallArrival();
    expect(component.saveCheckCallArrival).toHaveBeenCalled();
  });

  it('arrivalFinalizeMethod have been called', () => {
    component.arrivalFinalizeMethod();
    expect(component.arrivalDetailsEditModel.isLoading).toBe(false);
  });

  it('frameArrivalDeviationFormDetails have been called', () => {
    component.frameArrivalDeviationFormDetails();
    expect(component.arrivalDetailsEditModel.isLoading).toBe(false);
  });

  it('resetResource have been called', () => {
    component.resetResource();
    expect(component.arrivalDetailsEditModel.resourcesWithImages.length).toBe(0);
  });
  it('editFromTracking has been set', () => {
    component.editFromTracking = true;
    expect(component.arrivalDetailsEditModel.editFromTracking).toBeTruthy();
  });
  it('trackingDetailsParam has been set', () => {
    const param = {
      equipmentId: 0
    };
    component.trackingParam = param;
    expect(component.arrivalDetailsEditModel.trackingDetailsParam).toBe(param);
  });
  it('isTracking has been set', () => {
    component.fromCheckCallPage = true;
    component.arrivalDetailsEditModel.showCheckCallDetails = true;
    component.arrivalDetailsEditModel.checkCallNavigation = true;
    component.arrivalDetailsEditModel.isTracking = true;
    expect(component.arrivalDetailsEditModel.isTracking).toBeTruthy();
  });
  it('overrideAllWarning has been set', () => {
    component.overrideAllWarning = true;
    expect(component.arrivalDetailsEditModel.isWarningOverride).toBeTruthy();
  });
  it('fieldErrorList has been set', () => {
    const errorList = ['error', 'warning'];
    component.fieldErrorList = errorList;
    component.arrivalDetailsEditModel.checkCallErrorFieldList = errorList;
    expect(component.arrivalDetailsEditModel.checkCallErrorFieldList).toBe(errorList);
  });
  it('loadDetails has been set', () => {
    spyOn(component, 'getStopId').and.callThrough();
    component.loadDetails = loadInfo;
    component.arrivalDetailsEditModel.loadDetails = loadInfo;
    component.arrivalDetailsEditModel.findArrivalRequest.operationalPlanID = loadInfo.operationalPlanId;
    component.arrivalDetailsEditModel.findArrivalRequest.operationalPlanNumber = loadInfo.operationalPlanNumber;
    expect(component.getStopId).toHaveBeenCalled();
  });
  it('onDateChange have been called', () => {
    spyOn(component, 'formatDateValue').and.callThrough();
    const obj = { overlayVisible: true };
    component.onDateChange(obj, true);
    expect(component.formatDateValue).toHaveBeenCalled();
  });
  it('onDateChange have been called', () => {
    const obj = { overlayVisible: true };
    component.onDateChange(obj, false);
    expect(obj.overlayVisible).toBe(false);
  });
  it('clearDateTime have been called', () => {
    const obj = { overlayVisible: true };
    component.clearDateTime(false, obj);
    expect(obj.overlayVisible).toBeFalsy();
  });
  it('clearDateTime have been called', () => {
    component.clearDateTime(true);
    expect(component.arrivalDetailsEditModel.editArrivalForm.controls.arrivalDate.value).toBeNull();
  });
  it('onTimeTyped have been called', () => {
    spyOn(component, 'onTimeTyped');
    component.onTimeTyped();
    expect(component.onTimeTyped).toHaveBeenCalled();
  });
  it('getArrivalDeviationDetails have been called', () => {
    component.getArrivalDeviationDetails(arrivalTimeDeviationDetails);
    expect(component.arrivalDetailsEditModel.contactText).toBe(arrivalTimeDeviationDetails.contactText);
  });
  it('onReasonSelected have been called', () => {
    component.onReasonSelected('reason');
    expect(component.arrivalDetailsEditModel.arrivalTimeDeviationReason).toEqual('reason');
  });
  it('onTextAreaType have been called', () => {
    component.onTextAreaType();
    expect(component.arrivalDetailsEditModel.textareaCount).toEqual(0);
  });
  it('onsearchReasonText have been called', () => {
    component.onsearchReasonText('edw', true);
    expect(component.arrivalDetailsEditModel.results).toEqual([]);
  });
  it('onSelectDriver have been called', () => {
    component.onSelectDriver('1234');
    expect(component.arrivalDetailsEditModel.contactID).toEqual('1234');
  });
  it('initializeFormGroup has been called', () => {
    editArrivalform = formBuilder.group({
      arrivalDate: [''],
      arrivalTime: [''],
      arrivalLate: formBuilder.group({
        lateReasonCategory: [],
        lateReason: [],
        lateReasonResponsibility: [''],
        lateReasonContact: ['']
      }),
      arrivalEarly: formBuilder.group({
        earlyReasonCategory: [],
        earlyReason: [],
        earlyReasonResponsibility: [''],
        earlyReasonContact: ['']
      })
    });
    component.initializeFormGroup();
    expect(component.arrivalDetailsEditModel.editArrivalForm.controls.arrivalDate.value).toBe('');
  });
  it('activityLogArrivalEdit ngOnDestroy should be called', () => {
    component.ngOnDestroy();
    expect(component.arrivalDetailsEditModel.canSubscribe).toBe(false);
  });
  it('formatData should be called', () => {
    component.formatData(editArrivalDetails);
    expect(component.arrivalDetailsEditModel.timeZone).toBe(editArrivalDetails.operationalPlanStopDetails.
      locationDetails.address.timeZone);
  });
  it('getArrivalCallDetails should be called', () => {
    component.getArrivalCallDetails(123, 'arrival');
    expect(component.arrivalDetailsEditModel.isLoading).toBeTruthy();
  });
  it('getCommentsCount should be called', () => {
    component.getCommentsCount(editArrivalDetails);
    expect(component.arrivalDetailsEditModel.textareaCount).toBeDefined();
  });
  it('arrivalResponse should be called', () => {
    component.arrivalResponse(editArrivalDetails);
    expect(component.arrivalDetailsEditModel.activityLogDetails).toEqual(editArrivalDetails);
  });
  it('onReasonCategorySelected should be called', () => {
    component.onReasonCategorySelected('Driver', false);
    expect(component.arrivalDetailsEditModel.reason).toEqual([]);
  });
  it('onReasonCategorySelected for isEdit should be called', () => {
    component.onReasonCategorySelected('Driver', true);
    expect(component.arrivalDetailsEditModel.reason).toEqual([]);
  });
  it('frameArrivalRequest should be called', () => {
    component.arrivalDetailsEditModel.arrivalDeviationType = 'Late';
    component.arrivalDetailsEditModel.isFreeText = false;
    component.arrivalDetailsEditModel.editArrivalForm.controls.arrivalLate.patchValue({
        lateReasonCategory: 'Driver',
        lateReason: 'Driver',
        lateReasonResponsibility: 'JBH',
        lateReasonContact: '5465575'
    });
    spyOn(ActivityLogUtils, 'frameArrivalDeviationRequest').and.callFake((isFreeText, deviationType, formvalue) => {
      if (!isFreeText && deviationType === 'Late' && formvalue) {
        return {
          arrivalTimeDeviationType: 'Late',
          arrivalTimeDeviationReason: 'Driver',
          arrivalTimeDeviationReasonCategory: 'Driver',
          arrivalDeviationResponsibilityPartyType: 'JBH',
          contactText: null,
          contactID: '5465575'
        };
      }
    });
    component.frameArrivalRequest();
    expect(component.arrivalDetailsEditModel.editArrivalRequest.arrivalTimeDeviationDetails).toBeDefined();
  });
  it('frameArrivalRequest for ontime should be called', () => {
    component.arrivalDetailsEditModel.arrivalDeviationType = 'OnTime';
    component.frameArrivalRequest();
    expect(component.arrivalDetailsEditModel.editArrivalRequest.arrivalTimeDeviationDetails).toBeNull();
  });
});
