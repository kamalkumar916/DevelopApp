import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { TooltipModule } from 'primeng/tooltip';
import { configureTestSuite } from 'ng-bullet';

import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { AppSharedDataService } from '../../../../shared/jbh-app-services/app-shared-data.service';

import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { ActivityLogArrivalViewComponent } from './activity-log-arrival-view.component';
import { ActivityLogLocationDetailsComponent } from '../../activity-log-location-details/activity-log-location-details.component';
import { GlobalPopupsModule } from './../../../../shared/global-popups/global-popups.module';
import { ActivityLogService } from '../../services/activity-log.service';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { ActivityLogUtils } from '../../services/activity-log.utils';

const stopLocationDetails = {
  operationalPlanStopDetails: {
    locationDetails: {
      locationId: '26551',
      locationName: 'VAN Buren Main',
      locationCode: 'VAVAC3',
      address: {
        addressLine1: '5 Main St',
        addressLine2: '',
        city: 'Van Buren',
        state: 'AR',
        zipcode: '729565706',
        country: 'USA',
        countryName: 'USA',
        timeZone: 'America/Chicago'
      }
    }
  }
};

const viewArrivalLogdetails = {
  operationalPlanCheckCallId: 1,
  arrivalDateTime: '2019-09-26T10:10:00-05:00',
  operationalPlanStopId: 1,
  operationalPlanId: 1,
  loadedType: '',
  loadedBy: '',
  departureTimestamp: '',
  lastUpdatedTimestamp: '',
  operationalPlanStopDetails: {
    operationalPlanStopSequenceNumber: 1,
    operationalPlanStopReasonCode: 'Pickup',
    operationalPlanStopReasonCodeDescription: 'Pickup',
    locationDetails: stopLocationDetails.operationalPlanStopDetails.locationDetails,
    appointmentStartTimestamp: '2019-09-26T10:00:00-05:00',
    appointmentEndTimestamp: '2019-09-26T10:00:00-05:00',
    stopSequenceDescription: 'Origin'
  },
  lastUpdateProgramName: 'Process ID',
  lastUpdatedUserId: 'pidordm',
  lastUpdatedOn: '09/28/2019 01:47 PM GMT',
  comments: '',
  arrivalTimeDeviationDetails: {
    arrivalTimeDeviationType: 'Early',
    arrivalTimeDeviationReason: 'Driver',
    arrivalTimeDeviationReasonCategory: 'Driver',
    arrivalDeviationResponsibilityPartyType: 'JBH',
    contactID: '5465575',
    contactName: 'JAMES',
    contactText: 'SA'
  },
  loadedTimestamp: '',
  proNumber: null,
  weight: null,
  volume: null,
  temperature: null,
  count: null,
  countedBy: '',
  sealNumber: '',
  bolNumber: '',
  poNumbers: null,
  shipperIdentificationNumber: '',
  receiverStateId: null,
  receiverStateName: '',
  hazmatIndicator: '',
  pickupEquipmentDetails: null,
  dropEquipmentDetails: null,
  stopServicesTypeCodes: null,
  stopServices: null
};
class MockActivityLogService {
  constructor() { }

  getCheckCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    return of(viewArrivalLogdetails);
  }
}
describe('ActivityLogArrivalViewComponent', () => {
  let component: ActivityLogArrivalViewComponent;
  let fixture: ComponentFixture<ActivityLogArrivalViewComponent>;
  let activityLogService: ActivityLogService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,
        JbhLoaderModule, PipesModule,
        TooltipModule, RouterTestingModule,
        GlobalPopupsModule,
        DirectivesModule,
        NoopAnimationsModule],
      providers: [AppConfigService, AppSharedDataService, { provide: ActivityLogService, useClass: MockActivityLogService }],
      declarations: [ActivityLogArrivalViewComponent, ActivityLogLocationDetailsComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogArrivalViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('ActivityLogArrivalViewComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('manipulateData should be called when all activityLogDetails present', () => {
    component.activityLogDetailsModel.activityLogDetails = viewArrivalLogdetails;
    spyOn(ActivityLogUtils, 'getLocationDetails');
    spyOn(ActivityLogUtils, 'getArrivedDate');
    component.manipulateData();
    expect(component.activityLogDetailsModel.splitViewDetailsData.location)
      .toBe(ActivityLogUtils.getLocationDetails(viewArrivalLogdetails.operationalPlanStopDetails.locationDetails));
    expect(component.activityLogDetailsModel.splitViewDetailsData.arrivalTime)
      .toBe(ActivityLogUtils.getArrivedDate(viewArrivalLogdetails.arrivalDateTime,
        viewArrivalLogdetails.operationalPlanStopDetails.locationDetails.address.timeZone));
  });


  it('manipulateData should be called when timezone is null', () => {
    viewArrivalLogdetails.operationalPlanStopDetails.locationDetails.address.timeZone = null;
    component.activityLogDetailsModel.activityLogDetails = viewArrivalLogdetails;
    spyOn(ActivityLogUtils, 'getLocationDetails');
    spyOn(ActivityLogUtils, 'getArrivedDate');
    component.manipulateData();
    expect(component.activityLogDetailsModel.splitViewDetailsData.location)
      .toBe(ActivityLogUtils.getLocationDetails(viewArrivalLogdetails.operationalPlanStopDetails.locationDetails));
    expect(component.activityLogDetailsModel.splitViewDetailsData.arrivalTime)
      .toBe(ActivityLogUtils.getArrivedDate(viewArrivalLogdetails.arrivalDateTime,
        'America/Chicago'));
  });

  it('manipulateData should be called when operationalPlanStopDetails is null', () => {
    viewArrivalLogdetails.operationalPlanStopDetails = null;
    viewArrivalLogdetails.arrivalDateTime = null;
    component.activityLogDetailsModel.activityLogDetails = viewArrivalLogdetails;
    component.manipulateData();
    expect(component.activityLogDetailsModel.splitViewDetailsData.location)
      .toBe(null);
  });
  it('manipulateData should be called when arrivalTimeDeviationDetails is null', () => {
    viewArrivalLogdetails.arrivalTimeDeviationDetails = null;
    component.activityLogDetailsModel.activityLogDetails = viewArrivalLogdetails;
    component.manipulateData();
    expect(component.activityLogDetailsModel.splitViewDetailsData.arrivalStatus)
      .toBe('(OnTime)');
  });

  it('getArrivalCallDetails should be called when service call success', () => {
    spyOn(component, 'manipulateData');
    component.getArrivalCallDetails(123, 'arrival');
    expect(component.activityLogDetailsModel.loading).toBeFalsy();
  });

  it('getArrivalCallDetails should be called on service call error', () => {
    spyOn(component, 'manipulateData');
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getCheckCallDetails').and.returnValue(throwError(null));
    component.getArrivalCallDetails(123, 'arrival');
    expect(component.activityLogDetailsModel.loading).toBeFalsy();
  });

  it('sequenceNumber have been called when stopSequenceNumber given', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.sequenceNumber({ stopSequenceNumber: '1', stopId: '', destinationHeader: '' });
    expect(component.stopSequenceNumber.emit).toHaveBeenCalled();
  });

  it('sequenceNumber have been called when stopSequenceNumber is null', () => {
    spyOn(component.stopSequenceNumber, 'emit');
    component.sequenceNumber({ stopSequenceNumber: null, stopId: '', destinationHeader: '' });
    expect(component.stopSequenceNumber.emit).toHaveBeenCalledTimes(0);
  });
});
