import { Component, OnInit, Input, ChangeDetectionStrategy, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { takeWhile, finalize } from 'rxjs/operators';

import { AppointmentDateFormatterPipe } from '../../../../shared/pipes/appointment-date-formatter.pipe';
import { ActivityLogModel } from '../../models/activity-log.model';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ViewActivityLogDetails, StopDetails } from '../../models/activity-log.interface';
import { ActivityLogService } from '../../services/activity-log.service';

@Component({
  selector: 'app-activity-log-arrival-view',
  templateUrl: './activity-log-arrival-view.component.html',
  styleUrls: ['./activity-log-arrival-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogArrivalViewComponent implements OnInit {
  @Output() readonly stopSequenceNumber: EventEmitter<StopDetails> = new EventEmitter();
  activityLogDetailsModel: ActivityLogModel;
  constructor(private readonly activityLogService: ActivityLogService, private readonly changeDetector: ChangeDetectorRef,
    private readonly activatedRoute: ActivatedRoute) {
    this.activityLogDetailsModel = new ActivityLogModel();
  }

  ngOnInit() {
    this.activityLogDetailsModel.activityType = this.activatedRoute.queryParams['_value']['activityType'];
    this.activityLogDetailsModel.checkCallId = this.activatedRoute.queryParams['_value']['checkCallId'];
    if (this.activityLogDetailsModel.checkCallId && this.activityLogDetailsModel.activityType) {
      this.getArrivalCallDetails(this.activityLogDetailsModel.checkCallId, this.activityLogDetailsModel.activityType);
    }
  }
  getArrivalCallDetails(operationalPlanCheckCallId: number, activityType: string) {
    this.activityLogDetailsModel.loading = true;
    this.activityLogService.getCheckCallDetails(operationalPlanCheckCallId, activityType)
      .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
        finalize(() => {
          this.activityLogDetailsModel.loading = false;
          this.changeDetector.detectChanges();
        }))
      .subscribe((data: ViewActivityLogDetails) => {
        this.activityLogDetailsModel.loading = false;
        if (data) {
          this.activityLogDetailsModel.activityLogDetails = data;
          this.manipulateData();
        }
      }, (error: Error) => {
        this.activityLogDetailsModel.loading = false;
      });
  }
  manipulateData() {
    const data = this.activityLogDetailsModel.activityLogDetails;
    let appointmentObject;
    if (data.operationalPlanStopDetails && data.operationalPlanStopDetails.locationDetails) {
      this.activityLogDetailsModel.splitViewDetailsData.location =
        ActivityLogUtils.getLocationDetails(data.operationalPlanStopDetails.locationDetails);
    }
    if (data.operationalPlanStopDetails) {
      appointmentObject = {
        appointmentStartTimestamp: data.operationalPlanStopDetails.appointmentStartTimestamp.toString(),
        appointmentEndTimestamp: data.operationalPlanStopDetails.appointmentEndTimestamp.toString(),
        timeZone: data.operationalPlanStopDetails.locationDetails.address.timeZone ?
        data.operationalPlanStopDetails.locationDetails.address.timeZone : 'America/Chicago'
      };
      this.activityLogDetailsModel.splitViewDetailsData.stopReasonCode =
        data.operationalPlanStopDetails.operationalPlanStopReasonCodeDescription;
      this.activityLogDetailsModel.splitViewDetailsData.stopSequenceDescription =
        data.operationalPlanStopDetails.stopSequenceDescription;
    }
    if (data.arrivalDateTime) {
      this.activityLogDetailsModel.splitViewDetailsData.arrivalTime =
        ActivityLogUtils.getArrivedDate(data.arrivalDateTime,
          data.operationalPlanStopDetails.locationDetails.address.timeZone);
    }
    if (appointmentObject && appointmentObject.appointmentStartTimestamp && appointmentObject.appointmentEndTimestamp) {
      this.activityLogDetailsModel.splitViewDetailsData.appointment =
        new AppointmentDateFormatterPipe().transform(appointmentObject);
    }
    if (!data.arrivalTimeDeviationDetails) {
      this.activityLogDetailsModel.splitViewDetailsData.arrivalStatus = '(OnTime)';
    }
  }

  sequenceNumber(event) {
    if (event.stopSequenceNumber) {
      this.stopSequenceNumber.emit({
        'stopSequenceNumber': event.stopSequenceNumber,
        'stopId': event.stopId,
        'destinationHeader': event.destinationHeader
      });
    }
  }

}

