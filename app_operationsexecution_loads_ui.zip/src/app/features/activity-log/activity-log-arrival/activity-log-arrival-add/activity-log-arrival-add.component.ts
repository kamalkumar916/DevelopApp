import { Component, OnInit, OnDestroy, Input, Output, EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

import { takeWhile, finalize } from 'rxjs/operators';
import { MessageService } from 'primeng/components/common/messageservice';
import { findIndex } from 'lodash';

import { ActivityLogArrivalAddModel } from './model/activity-log-arrival-add.model';
import { ActivityLogService } from '../../services/activity-log.service';
import { ActivityLogArrivalAddService } from './services/activity-log-arrival-add.service';


import {
  ReasonResponsibility, ArrivalDeviationResponse, AddArrivalRequestObj,
  ArrivalTimeDeviationDetails,
  ArrivalDeviationRequest,
  LateReasonCategory,
  LateReason,
  OperationalPlanStopAppointmentChangeReason
} from './model/activity-log-arrival-add.interface';
import * as moment from 'moment';
import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { ActivityLogArrivalAddUtils } from './services/activity-log-arrival-add.utils';
import { Router } from '@angular/router';
import { timer } from 'rxjs';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { ErrorList, OperationalPlanStopDetails } from '../../models/activity-log.interface';
import { FormValidationUtils } from '../../../../shared/jbh-app-services/form-validation-utils';
import { DriverDetailQuery } from '../../../../shared/query/driver-detail.query';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { DriverDetailsUtils } from '../../../service/driver-details.utils';
import { FetchDetails } from '../../../model/driver-details.interface';
import { ActivityLogModel } from '../../models/activity-log.model';
import { ErrorUtils } from '../../../../shared/jbh-app-services/error-utils';
import { OperationalPlanStopDTO } from '../../../load-details/model/load-details.interface';
import { LoadOverview } from '../../../load-details/load-details-overview/model/load-overview.interface';
import { AddressDetailsPipe } from '../../../../shared/pipes/address-details.pipe';

@Component({
  selector: 'app-activity-log-arrival-add',
  templateUrl: './activity-log-arrival-add.component.html',
  styleUrls: ['./activity-log-arrival-add.component.scss', '../../activity-log.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogArrivalAddComponent implements OnInit, OnDestroy {
  addArrivalModel: ActivityLogArrivalAddModel;
  @Output() arrivalDeviationType: EventEmitter<ErrorList[]> = new EventEmitter<ErrorList[]>();
  constructor(private readonly fb: FormBuilder,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly addArrivalDetailsService: ActivityLogArrivalAddService,
    private readonly toastMessage: MessageService,
    private readonly activityLogDetailsService: ActivityLogService,
    private readonly router: Router, private readonly localStorageService: LocalStorageService) {
    this.addArrivalModel = new ActivityLogArrivalAddModel();
  }

  @Input() set arrivalRequestObj(data: ArrivalDeviationRequest) {
    if (data && data.operationalPlanID && data.operationalPlanStopSequenceNumber) {
      this.addArrivalModel.findArrivalRequest.operationalPlanID = data.operationalPlanID;
      this.addArrivalModel.findArrivalRequest.operationalPlanStopSequenceNumber = data.operationalPlanStopSequenceNumber;
      this.addArrivalModel.operationalPlanNumber = data.operationalPlanNumber;
    }
  }
  @Input() set resourceDetails(data) {
    if (data && data.equipmentId) {
      this.addArrivalModel.truckNumber = data.equipmentId;
    }
  }

  @Input() set overrideAllWarning(event) {
    this.addArrivalModel.isOverrideWarning = event;
  }
  @Input() set stopInformation(stopInfo: OperationalPlanStopDTO) {
    this.addArrivalModel.stopLocationAdd = stopInfo;
    if (stopInfo && stopInfo.locationDetailsDTO && stopInfo.locationDetailsDTO.timezone) {
      this.addArrivalModel.timeZone = stopInfo.locationDetailsDTO.timezone;
    }
  }
  @Input() set loadDetails(loadInfo: LoadOverview) {
    this.addArrivalModel.loadDetails = loadInfo;
  }
  @Input() set reload(isReload: boolean) {
    if (isReload) {
      this.addArrivalModel.isReload = isReload;
    }
  }
  ngOnInit() {
    this.addArrivalModel.addArrivalForm = this.initializeFormGroup();
    this.getReasonCategoryDetails();
    if (this.addArrivalModel.isReload) {
      this.getLocalStoreItem();
    }
  }
  clearLocalStoreItem() {
    this.localStorageService.clearItem('formDetails', 'values');
    this.localStorageService.clearItem('pairedEquipment', 'values');
  }
  getLocalStoreItem() {
    if (this.localStorageService.getItem('arrivalForm', 'values')) {
      const arrivalDetails = this.localStorageService.getItem('arrivalForm', 'values');
      this.addArrivalModel.arrivalDate = arrivalDetails.arrivalDate;
      this.addArrivalModel.arrivalTime = arrivalDetails.arrivalTime;
      this.addArrivalModel.timeZone = arrivalDetails.timeZone;
      this.getEarlyOrLateArrival();
      this.addArrivalModel.addArrivalForm.patchValue(arrivalDetails.arrivalForm);
      this.onReasonCategorySelected(arrivalDetails.reason);
    }
  }
  ngOnDestroy() {
    this.addArrivalModel.canSubscribe = false;
    if (this.addArrivalModel.addArrivalForm) {
      this.addArrivalModel.addArrivalForm.removeControl('arrivalLate');
      this.addArrivalModel.addArrivalForm.removeControl('arrivalEarly');
    }
  }
  initializeFormGroup(): FormGroup {
    return this.fb.group({
      arrivalDate: [''],
      arrivalTime: [''],
      arrivalLate: this.fb.group({
        lateReasonCategory: [],
        lateReason: [],
        lateReasonResponsibility: [''],
        lateReasonContact: ['']
      }),
      arrivalEarly: this.fb.group({
        earlyReasonCategory: [],
        earlyReason: [],
        earlyReasonResponsibility: [''],
        earlyReasonContact: ['']
      }),
      comments: ''
    });
  }
  onDateChange(dateValue, isDate: boolean) {
    dateValue.overlayVisible = false;
    const dateObj = DateUtils.getTimeValue(dateValue);
    if (isDate) {
      this.formatDateValue(dateValue);
      ActivityLogUtils.checkArrivalTime(this.addArrivalModel, false, this.toastMessage, 'Arrival');
    } else {
      this.formatTimeValue(dateValue.value);
      this.addArrivalModel.arrivalTimeSelected =
        ActivityLogUtils.formatTimeSelected(this.addArrivalModel.addArrivalForm.controls.arrivalTime.value);
      ActivityLogUtils.checkArrivalTime(this.addArrivalModel, false, this.toastMessage, 'Arrival');
    }
    ActivityLogUtils.checkMandatoryFields(this.addArrivalModel.addArrivalForm);
    if (this.addArrivalModel.arrivalDate && this.addArrivalModel.arrivalTime) {
      this.getEarlyOrLateArrival();
    }
  }
  onDateTyped() {
    this.formatDateValue(this.addArrivalModel.addArrivalForm.controls.arrivalDate.value);
    if (this.addArrivalModel.addArrivalForm.controls.arrivalDate.value > new Date()) {
      ActivityLogUtils.dateValidation(this.addArrivalModel.addArrivalForm, 'arrivalDate',
        this.toastMessage, 'Arrival');
    }
    ActivityLogUtils.checkArrivalTime(this.addArrivalModel, false, this.toastMessage, 'Arrival');
    if (this.addArrivalModel.arrivalDate && this.addArrivalModel.arrivalTime) {
      this.getEarlyOrLateArrival();
    }
  }
  onTimeTyped() {
    this.formatTimeValue(this.addArrivalModel.addArrivalForm.controls.arrivalTime.value);
  }
  clearDateTime(isDate: boolean, calObj?: any) {
    if (isDate) {
      this.addArrivalModel.addArrivalForm.controls.arrivalDate.reset();
    } else {
      this.addArrivalModel.addArrivalForm.controls.arrivalTime.reset();
      calObj.overlayVisible = false;
    }
  }
  formatDateValue(arrivalDate: Date) {
    this.addArrivalModel.arrivalDate = moment(new Date(arrivalDate)).format('YYYY-MM-DD');
  }
  formatTimeValue(arrivalTime: Date) {
    this.addArrivalModel.arrivalTime = moment(new Date(arrivalTime)).format('H:mm');
  }
  getEarlyOrLateArrival() {
    this.addArrivalModel.addArrivalForm.get(`arrivalLate`).reset();
    this.addArrivalModel.addArrivalForm.get(`arrivalEarly`).reset();
    this.addArrivalModel.addArrivalForm.get(`comments`).reset();
    if (this.addArrivalModel.arrivalDate && this.addArrivalModel.arrivalTime) {
      this.addArrivalModel.findArrivalRequest.arrivalTimestamp = DateUtils.dateTimeZoneFormat(this.
        addArrivalModel.arrivalDate, this.addArrivalModel.arrivalTime, this.addArrivalModel.timeZone);
    }
    this.addArrivalModel.arrivalDeviationType = 'No deviation type';
    if (this.addArrivalModel.addArrivalForm.valid) {
      this.addArrivalModel.isLoading = true;
      this.addArrivalDetailsService.getArrivalType(this.addArrivalModel.findArrivalRequest).
        pipe(takeWhile(() => this.addArrivalModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: ArrivalDeviationResponse) => {
          this.addArrivalModel.isLoading = false;
          if (data && data.arrivalDeviationType) {
            this.addArrivalModel.arrivalDeviationType = data.arrivalDeviationType;
            this.handleLateOrEarlyArrival(data);
          }
        }, (error) => {
          this.handleError(error);
        });
    } else {
      this.arrivalDeviationType.emit([]);
    }
  }
  handleLateOrEarlyArrival(data) {
    if (this.addArrivalModel.arrivalDeviationType.toLowerCase() !== 'ontime') {
      if (this.validateStopInformation(this.addArrivalModel.stopLocationAdd.locationDetailsDTO)) {
        const stopSequence = this.getStopSequenceNumber();
        const stopInfo = this.getStopInfo(stopSequence);
        const locationName = `${new AddressDetailsPipe().transform(this.addArrivalModel.stopLocationAdd.locationDetailsDTO,
          ['locationNameCode'])},
          ${new AddressDetailsPipe().transform(this.addArrivalModel.stopLocationAdd.locationDetailsDTO.address,
            ['locationAddress'])}
          ${new AddressDetailsPipe().transform(this.addArrivalModel.stopLocationAdd.locationDetailsDTO,
              ['addressZipDetails'])}`;
        this.arrivalDeviationEmitter(data.arrivalDeviationType, stopInfo, locationName);
      } else if (this.validateStopInformation(this.addArrivalModel.stopLocationAdd.cityDetailsDTO)) {
        const stopSequence = this.getStopSequenceNumber();
        const stopInfo = this.getStopInfo(stopSequence);
        const locationName = `${this.addArrivalModel.stopLocationAdd.cityDetailsDTO.cityName},
        ${this.addArrivalModel.stopLocationAdd.cityDetailsDTO.stateCode}, ${this.addArrivalModel.
            stopLocationAdd.cityDetailsDTO.countryCode}`;
        this.arrivalDeviationEmitter(data.arrivalDeviationType, stopInfo, locationName);
      }
    } else {
      this.arrivalDeviationType.emit([]);
    }
  }
  validateStopInformation(locationOrCityDto) {
    return this.addArrivalModel.loadDetails && this.addArrivalModel.loadDetails.operationalPlanStopDTOs &&
      this.addArrivalModel.stopLocationAdd && this.addArrivalModel.stopLocationAdd.operationalPlanStopSequenceNumber
      && locationOrCityDto;
  }
  getStopSequenceNumber() {
    return findIndex(this.addArrivalModel.loadDetails.operationalPlanStopDTOs,
      ['operationalPlanStopSequenceNumber', this.addArrivalModel.stopLocationAdd.operationalPlanStopSequenceNumber]);
  }
  getStopInfo(stopSequenceNumber) {
    return stopSequenceNumber === 0 ?
      'Origin' : stopSequenceNumber === this.addArrivalModel.loadDetails.operationalPlanStopDTOs.length - 1 ? 'Destination' :
        `Stop${stopSequenceNumber + 1}`;
  }
  arrivalDeviationEmitter(arrivalDeviationType: string, stopInfo: string, locationName: string) {
    this.arrivalDeviationType.emit([{
      errorMessage: `${arrivalDeviationType} Arrival at the ${stopInfo} - ${locationName}`,
      errorType: 'Arrival Deviation',
      errorSeverity: 'ERROR'
    }]);
  }
  handleError(error) {
    this.addArrivalModel.isLoading = false;
    this.addArrivalModel.arrivalDeviationType = '';
    if (error && error.status === 500) {
      this.toastMessage.add({
        severity: 'error',
        summary: 'Server Error',
        detail: ErrorUtils.getErrorMessage(error.status)
      });
    } else {
      ActivityLogUtils.arrivalError(error['error'], this.toastMessage);
      this.arrivalDeviationType.emit([]);
    }
  }
  loadReasonResponsibility() {
    this.addArrivalDetailsService.getReasonResponsibilityTypes().pipe(
      takeWhile(() => this.addArrivalModel.canSubscribe),
      finalize(() => {
        this.changeDetector.detectChanges();
      })
    ).subscribe((data: ReasonResponsibility) => {
      this.addArrivalModel.reasonResponsibility = [];
      if (data && data._embedded && data._embedded.arrivalDeviationResponsibilityPartyTypes.length > 0) {
        this.addArrivalModel.reasonResponsibility = data._embedded.arrivalDeviationResponsibilityPartyTypes.map(reasonTypes => {
          return {
            label: reasonTypes.arrivalDeviationResponsibilityPartyTypeDescription,
            value: reasonTypes.arrivalDeviationResponsibilityPartyTypeCode
          };
        });
      }
    });
  }
  getReasonCategoryDetails() {
    this.addArrivalDetailsService.getReasonCategory().pipe(
      takeWhile(() => this.addArrivalModel.canSubscribe),
      finalize(() => {
        this.changeDetector.detectChanges();
      })
    ).subscribe((data: LateReasonCategory) => {
      this.addArrivalModel.reasonCategory = this.getFormattedReasonCategory(data);
    }, (error) => {
      this.addArrivalModel.reasonCategory = [];
    });
  }
  getFormattedReasonCategory(data) {
    let reasonCategoryData = [];
    if (data) {
      reasonCategoryData = data._embedded.operationalPlanStopAppointmentChangeReasonCategories.map((reasonCategory) => {
        return {
          'label': reasonCategory.operationalPlanAppointmentChangeCategoryDescription,
          'value': reasonCategory.operationalPlanAppointmentChangeCategoryCode
        };
      });
    }
    return reasonCategoryData;
  }
  onReasonCategorySelected(reasonCategoryValue: string) {
    if (reasonCategoryValue) {
      this.addArrivalModel.arrivalTimeDeviationReasonCategory = reasonCategoryValue;
      this.addArrivalDetailsService.getReason(reasonCategoryValue).pipe(
        takeWhile(() => this.addArrivalModel.canSubscribe),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      ).subscribe((data: LateReason) => {
        this.addArrivalModel.reason = this.getFormattedReason(data);
      });
    }
  }
  getFormattedReason(data: LateReason) {
    let lateReasonData = [];
    if (data) {
      lateReasonData = data._embedded.operationalPlanStopAppointmentChangeReasons.map(
        (lateReason: OperationalPlanStopAppointmentChangeReason) => {
          return {
            'label': lateReason.operationalPlanAppointmentChangeDescription,
            'value': lateReason.operationalPlanAppointmentChangeCode
          };
        });
    }
    return lateReasonData;
  }
  onReasonSelected(selectedReason: string) {
    this.addArrivalModel.arrivalTimeDeviationReason = selectedReason;
  }

  onSelectReasonResponsibility(selectedReasonResp: string, groupName: string, controlName: string) {
    this.addArrivalModel.arrivalDeviationResponsibilityPartyType = selectedReasonResp;
    if (selectedReasonResp === 'Other') {
      this.addArrivalModel.isFreeText = true;
      this.addArrivalModel.addArrivalForm.get(groupName).get(controlName).reset();
    } else {
      this.addArrivalModel.isFreeText = false;
    }
    this.changeDetector.detectChanges();
  }
  onsearchReasonText(searchText: string, isText: boolean) {
    if (isText) {
      this.addArrivalModel.results = [];
    } else {
      this.loadReasonContact(searchText);
    }
  }
  onSelectDriver(selectedDriverId: string) {
    this.addArrivalModel.contactID = selectedDriverId;
  }
  onTextAreaType() {
    this.addArrivalModel.textareaCount = this.addArrivalModel.addArrivalForm.controls.comments.value.length;
  }
  loadReasonContact(search: string) {
    if (this.addArrivalModel.arrivalDeviationResponsibilityPartyType.toLowerCase() !== 'carrier') {
      this.addArrivalDetailsService.getResourceDetails(DriverDetailQuery.getDriverDetailsQuery(search.replace(/[()]/g, '')))
        .pipe(takeWhile(() => this.addArrivalModel.canSubscribe),
          finalize(() => {
            this.changeDetector.detectChanges();
          })).subscribe((data: any) => {
            if (data && data.hits && data.hits.hits) {
              this.addArrivalModel.resourceList = data.hits.hits;
              this.getDriverImage(DriverDetailsUtils.loadDriverDetails(data));
            } else {
              this.resetResource();
            }
          }, (error) => {
            this.resetResource();
          });
    } else {
      this.resetResource();
    }
  }
  resetResource() {
    this.addArrivalModel.resourceList = [];
    this.addArrivalModel.resourcesWithImages = [];
  }
  getDriverImage(resourceDetails: FetchDetails[]) {
    this.addArrivalDetailsService.getResourceImage(ActivityLogUtils.getDriverIds(resourceDetails))
      .pipe(takeWhile(() => this.addArrivalModel.canSubscribe),
        finalize(() => {
          this.changeDetector.detectChanges();
        })).subscribe((data: any) => {
          this.addArrivalModel.resourcesWithImages = [];
          if (data) {
            this.addArrivalModel.resourcesWithImages = ActivityLogUtils.imageDetails(data);
          }
        }, (error: Error) => {
          this.addArrivalModel.resourcesWithImages = [];
        });
  }
  onRemoveValues(isEarly: boolean) {
    this.addArrivalModel.resourceList = [];
    this.addArrivalModel.resourcesWithImages = [];
    this.addArrivalModel.isFreeText = false;
    if (isEarly) {
      this.addArrivalModel.addArrivalForm.controls.arrivalEarly.get('earlyReasonContact').reset();
    } else {
      this.addArrivalModel.addArrivalForm.controls.arrivalLate.get('lateReasonContact').reset();
    }
  }
  saveForm() {
    this.arrivalDeviationType.emit([]);
    this.validateMandatoryFields();
    if (this.addArrivalModel.addArrivalForm.invalid) {
      ActivityLogUtils.checkArrivalFormValidity(this.toastMessage, this.addArrivalModel.addArrivalForm,
        this.addArrivalModel, false, this.arrivalDeviationType, this.changeDetector);
    } else {
      this.toastMessage.clear();
      this.frameArrivalAddRequest();
      if (this.addArrivalModel.arrivalDeviationType && this.addArrivalModel.arrivalRequest
        && !this.addArrivalModel.isLoading) {
        if (this.addArrivalModel.arrivalRequest.resourceDetails.value) {
          this.arrivalSaveCall();
        } else {
          this.toastMessage.clear();
          ActivityLogUtils.resourceFieldError(this.toastMessage);
        }
      }
    }
  }
  validateMandatoryFields() {
    ActivityLogUtils.checkMandatoryFields(this.addArrivalModel.addArrivalForm);
    FormValidationUtils.validateAllFormFields(this.addArrivalModel.addArrivalForm);
    if (this.addArrivalModel.arrivalDeviationType) {
      ActivityLogUtils.checkForReasonResponsibility(this.addArrivalModel, 'addArrivalForm');
      FormValidationUtils.validateAllFormFields(this.addArrivalModel.addArrivalForm);
    }
    this.changeDetector.detectChanges();
  }
  frameArrivalAddRequest() {
    this.addArrivalModel.arrivalRequest.operationalPlanNumber = this.addArrivalModel.operationalPlanNumber;
    this.addArrivalModel.arrivalRequest.operationalPlanStopSequenceNumber =
      this.addArrivalModel.findArrivalRequest.operationalPlanStopSequenceNumber;
    this.addArrivalModel.arrivalRequest.arrivalTimestamp = this.addArrivalModel.findArrivalRequest.arrivalTimestamp;
    this.addArrivalModel.arrivalRequest.checkCallSourceTimestamp = DateUtils.dateTimeZoneFormat(moment(new Date()).
      format('YYYY-MM-DD'), moment(new Date()).format('H:mm'), this.addArrivalModel.timeZone);
    this.addArrivalModel.arrivalRequest.resourceDetails.value = this.addArrivalModel.truckNumber;
    this.addArrivalModel.arrivalRequest.arrivalTimeDeviationDetails =
      ActivityLogArrivalAddUtils.arrivalDeviationRequestJson(this.addArrivalModel);
    this.addArrivalModel.arrivalRequest.comments =
      ActivityLogUtils.getValueOrNull(this.addArrivalModel.addArrivalForm.controls.comments.value);
    this.addArrivalModel.arrivalRequest.isWarningOverride = this.addArrivalModel.isOverrideWarning;
  }
  arrivalSaveCall(): void {
    if (this.addArrivalModel.addArrivalForm.valid) {
      this.addArrivalModel.isLoading = true;
      this.changeDetector.detectChanges();
      this.addArrivalDetailsService.addArrivalDetails(this.addArrivalModel.arrivalRequest).
        pipe(takeWhile(() => this.addArrivalModel.canSubscribe),
          finalize(() => {
            this.addArrivalModel.isLoading = false;
            this.changeDetector.detectChanges();
          })).subscribe((data: ArrivalDeviationResponse) => {
            this.addArrivalModel.isLoading = false;
            if (data) {
              this.clearLocalStoreItem();
              ActivityLogUtils.successMessage(this.toastMessage, 'Arrival', 'added');
              timer(ActivityLogModel.addSaveTimer).subscribe(() => {
                this.navigateToParent();
              });
            }
          }, (error) => {
            this.addArrivalModel.isLoading = false;
            if (ActivityLogUtils.handleErrorAndNull(error, this.toastMessage)) {
              this.arrivalDeviationType.emit(error.error.errors);
              ActivityLogUtils.checkDeviationMandatoryFields(this.addArrivalModel, 'addArrivalForm', error.error.errors);
            }
          });
    } else {
      ActivityLogUtils.requiredFieldError(this.arrivalDeviationType, this.changeDetector);
    }
  }
  navigateToParent() {
    if (this.router.url && this.router.url.indexOf('/trackingdetails') !== -1) {
      this.router.navigate(['/trackingdetails'], { queryParams: this.localStorageService.getItem('TrackingDetails', 'param') });
    } else {
      this.router.navigate(['/loaddetails', this.addArrivalModel.findArrivalRequest.operationalPlanID],
        { queryParams: { index: 2 } });
    }
  }
  validateFormFields(fieldName: string) {
    return (this.addArrivalModel.addArrivalForm.get(fieldName).invalid
      && this.addArrivalModel.addArrivalForm.get(fieldName).touched);
  }
  validateDeviationFormFields(formGroupName: string, fieldName: string) {
    return (this.addArrivalModel.addArrivalForm.get(formGroupName).get(fieldName).invalid
      && this.addArrivalModel.addArrivalForm.get(formGroupName).get(fieldName).touched);
  }
  getZoneFormat() {
    return ActivityLogUtils.getZoneFormat(this.addArrivalModel.timeZone);
  }
}

