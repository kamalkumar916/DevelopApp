import { Self2, Page } from '../../../models/activity-log.interface';

export interface LateReasonCategory {
    _embedded: Embedded;
    _links: Links2;
    page: Page;
}

export interface Links2 {
    self: Self2;
    profile?: Self;
    search?: Self;
}

export interface Embedded {
    operationalPlanStopAppointmentChangeReasonCategories: OperationalPlanStopAppointmentChangeReasonCategory[];
}

export interface OperationalPlanStopAppointmentChangeReasonCategory {
    createTimestamp: string;
    createProgramName: string;
    lastUpdateProgramName: string;
    createUserId: string;
    lastUpdateUserId: string;
    operationalPlanAppointmentChangeCategoryCode: string;
    operationalPlanAppointmentChangeCategoryDescription: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: Links;
}

export interface Links {
    self: Self;
    operationalPlanStopAppointmentChangeReasonCategory: Self;
}


export interface LateReason {
    _embedded: LateReasonEmbedded;
    _links: Links2;
}

export interface LateReasonEmbedded {
    operationalPlanStopAppointmentChangeReasons: OperationalPlanStopAppointmentChangeReason[];
}

export interface OperationalPlanStopAppointmentChangeReason {
    createTimestamp: string;
    createProgramName: string;
    lastUpdateProgramName: string;
    createUserId: string;
    lastUpdateUserId: string;
    operationalPlanAppointmentChangeDescription: string;
    operationalPlanAppointmentChangeCode: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: LateReasonLinks;
}

export interface LateReasonLinks {
    self: Self;
    operationalPlanStopAppointmentChangeReason: Self;
    operationalPlanAppointmentChangeCategoryCode: Self;
}
export interface ReasonResponsibility {
    _embedded: ReasonTypesEmbedded;
    _links: ReasonTypeLinks;
    page: Page;
}
export interface ReasonTypesEmbedded {
    arrivalDeviationResponsibilityPartyTypes: ArrivalDeviationResponsibilityPartyTypesItem[];
}
export interface ArrivalDeviationResponsibilityPartyTypesItem {
    createTimestamp: string;
    createProgramName: string;
    lastUpdateProgramName: string;
    createUserId: string;
    lastUpdateUserId: string;
    arrivalDeviationResponsibilityPartyTypeCode: string;
    arrivalDeviationResponsibilityPartyTypeDescription: string;
    effectiveTimestamp: string;
    expirationTimestamp: string;
    lastUpdateTimestampString: string;
    _links: ReasonTypeLinks;
}
export interface ReasonTypeLinks {
    self: Self;
    arrivalDeviationResponsibilityPartyType: ArrivalDeviationResponsibilityPartyType;
    profile?: Profile;
}
export interface Self {
    href: string;
    templated?: boolean;
}
export interface ArrivalDeviationResponsibilityPartyType {
    href: string;
}
export interface Profile {
    href: string;
}
export interface ArrivalDeviationRequest {
    operationalPlanID: number;
    operationalPlanStopSequenceNumber: number;
    operationalPlanStopID?: number;
    arrivalTimestamp?: string;
    operationalPlanNumber?: string;
    truck?: number | string;
    destinationHeader?: string;
}
export interface ArrivalDeviationResponse {
    operationalPlanId: number;
    operationalPlanStopId: number;
    operationalPlanStopSequenceNumber: string;
    appointmentStartTimestamp: string;
    appointmentEndTimestamp: string;
    arrivalDeviationType: string;
}
export interface AddArrivalRequestObj {
    operationalPlanNumber: string;
    operationalPlanStopSequenceNumber: number;
    arrivalType: string;
    arrivalTimestamp: string;
    checkCallSourceTimestamp: string;
    hubReading: string;
    arrivalCheckCallType: string;
    resourceDetails: ResourceDetails;
    isAutoCheckCall: boolean;
    checkCallSource: string;
    arrivalTimeDeviationDetails?: ArrivalTimeDeviationDetails;
    comments: string;
    isWarningOverride: boolean;
}
export interface ResourceDetails {
    type: string;
    value: number;
}
export interface ArrivalTimeDeviationDetails {
    arrivalTimeDeviationType: string;
    arrivalTimeDeviationReason: string;
    arrivalTimeDeviationReasonCategory: string;
    arrivalDeviationResponsibilityPartyType: string;
    contactID?: string;
    contactText?: string;
}

export interface EditArrivalRequest {
    checkCallId?: number;
    operationalPlanNumber?: string;
    operationalPlanStopSequenceNumber?: number;
    arrivalType?: string;
    checkCallSourceTimestamp?: string;
    hubReading?: string;
    arrivalCheckCallType?: string;
    resourceDetails?: ResourceDetails;
    isAutoCheckCall?: boolean;
    checkCallSource?: string;
    comments?: string;
    isWarningOverride?: boolean;
    arrivalTimestamp: string;
    arrivalTimeDeviationDetails?: ArrivalTimeDeviationDetails;
}
