import { FormGroup } from '@angular/forms';
import { ListItem } from '../../../../../features/model/common.interface';
import { ArrivalDeviationRequest, AddArrivalRequestObj, EditArrivalRequest } from './activity-log-arrival-add.interface';
import { HitsModel } from '../../../../../features/model/elastic-response.interface';
import {
    ViewActivityLogDetails, OperationalPlanStopDetails, ResourceOverview, TrackingDetailsParam
} from '../../../models/activity-log.interface';
import { OperationalPlanStopDTO } from '../../../../load-details/model/load-details.interface';
import { LoadOverview } from '../../../../load-details/load-details-overview/model/load-overview.interface';

export class ActivityLogArrivalAddModel {
    results: string[];
    addArrivalForm: FormGroup;
    reasonCategory: ListItem[];
    reason: ListItem[];
    reasonResponsibility: ListItem[];
    isFreeText: boolean;
    canSubscribe: boolean;
    resourceList: HitsModel[];
    resourcesWithImages: any;
    textareaCount: number;
    arrivalDate: string | Date;
    arrivalTime: string;
    arrivalDateTime: string;
    findArrivalRequest: ArrivalDeviationRequest;
    arrivalDeviationType: string;
    arrivalRequest: AddArrivalRequestObj;
    arrivalTimeDeviationReason: string;
    arrivalDeviationResponsibilityPartyType: string;
    arrivalTimeDeviationReasonCategory: string;
    contactID: string;
    operationalPlanNumber: string;
    truckNumber: number;
    isLoading: boolean;
    editArrivalForm: FormGroup;
    regex: RegExp;
    editArrivalRequest: EditArrivalRequest;
    categorySelected: string;
    comments: string;
    contactText: string;
    contactName: string;
    checkCallID: number;
    activityLogDetails: ViewActivityLogDetails;
    isOverrideWarning: boolean;
    todayDate: Date;
    arrivalTimeSelected: string;
    showCheckCallDetails: boolean;
    checkCallErrorFieldList: string[];
    noDeviationType: string;
    loadDetails: LoadOverview;
    stopLocationAdd: OperationalPlanStopDTO;
    stopLocationEdit: OperationalPlanStopDetails;
    activityType: string;
    isWarningOverride: boolean;
    timeZone: string;
    checkCallNavigation: boolean;
    isTracking: boolean;
    editFromTracking: boolean;
    resourceOverview: ResourceOverview;
    trackingDetailsParam: TrackingDetailsParam;
    isReload: boolean;
    defaultArrivalDate: Date;

    constructor() {
        this.isFreeText = false;
        this.results = [];
        this.canSubscribe = true;
        this.textareaCount = 0;
        this.reasonResponsibility = [];
        this.defaultArrivalDate =  new Date();
        this.findArrivalRequest = {
            operationalPlanID: 0,
            operationalPlanStopSequenceNumber: 0
        };
        this.isLoading = false;
        this.regex = /\(([^)]+)\)/;
        this.editArrivalRequest = {
            arrivalTimestamp: ''
        };
        this.arrivalRequest = {
            operationalPlanNumber: '',
            operationalPlanStopSequenceNumber: 0,
            arrivalType: 'arrival',
            arrivalTimestamp: '',
            checkCallSourceTimestamp: '',
            hubReading: null,
            arrivalCheckCallType: null,
            comments: '',
            resourceDetails: {
                type: 'Truck',
                value: null
            },
            isAutoCheckCall: false,
            checkCallSource: 'MnlChkCal',
            isWarningOverride: false,
            arrivalTimeDeviationDetails: {
                arrivalTimeDeviationType: '',
                arrivalTimeDeviationReason: '',
                arrivalTimeDeviationReasonCategory: '',
                arrivalDeviationResponsibilityPartyType: '',
                contactID: '',
                contactText: ''
            }
        };
        this.isOverrideWarning = false;
        this.reasonCategory = [];
        this.reason = [];
        this.arrivalDeviationType = 'No deviation type';
        this.todayDate = new Date();
        this.noDeviationType = 'No deviation type';
        this.loadDetails = null;
        this.stopLocationAdd = null;
        this.stopLocationEdit = null;
        this.timeZone = '';
        this.resourceOverview = null;
    }
}
