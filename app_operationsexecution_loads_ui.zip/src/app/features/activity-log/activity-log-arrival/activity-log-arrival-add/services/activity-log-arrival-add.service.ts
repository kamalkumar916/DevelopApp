import { Injectable } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ElasticResponseModel } from '../../../../../features/model/elastic-response.interface';
import { AppConfigService } from './../../../../../shared/service/app-config.service';
import {
  LateReasonCategory, LateReason, ReasonResponsibility, ArrivalDeviationRequest,
  ArrivalDeviationResponse, AddArrivalRequestObj
} from '../model/activity-log-arrival-add.interface';
import { DriverImageDetails } from '../../../../model/driver-details.interface';


@Injectable({
  providedIn: 'root'
})
export class ActivityLogArrivalAddService {
  endpoint: any;
  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('activitylog');
  }
  getResourceDetails(queryParam: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getResourceDetails, queryParam);
  }
  getResourceImage(queryParam: string[]): Observable<DriverImageDetails[]> {
    const url = `${this.endpoint.getResourceImage}?personIds=&userIds=${queryParam}`;
    return this.http.get<DriverImageDetails[]>(url);
  }
  getReasonCategory(): Observable<LateReasonCategory> {
    return this.http.get<LateReasonCategory>(this.endpoint.reasonCategory);
  }
  getReason(reasonCode: string): Observable<LateReason> {
    return this.http.get<LateReason>(`${this.endpoint.reason}/category?category=${reasonCode}`);
  }
  getReasonResponsibilityTypes(): Observable<ReasonResponsibility> {
    return this.http.get<ReasonResponsibility>(this.endpoint.responsibilityTypes);
  }
  getArrivalType(arrivalRequestObject: ArrivalDeviationRequest): Observable<ArrivalDeviationResponse> {
    return this.http.post<ArrivalDeviationResponse>(this.endpoint.getArrivalType, arrivalRequestObject);
  }
  addArrivalDetails(addArrivalRequestObj: AddArrivalRequestObj): Observable<any> {
    return this.http.post<any>(this.endpoint.addArrival, addArrivalRequestObj);
  }
}
