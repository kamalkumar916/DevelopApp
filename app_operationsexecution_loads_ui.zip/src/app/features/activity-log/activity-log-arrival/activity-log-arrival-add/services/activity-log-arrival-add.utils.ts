import { ArrivalTimeDeviationDetails } from '../model/activity-log-arrival-add.interface';

export class ActivityLogArrivalAddUtils {
  static arrivalDeviationRequestJson(addArrivalModel): ArrivalTimeDeviationDetails {
    if (addArrivalModel.arrivalDeviationType === 'Late' ||
      addArrivalModel.arrivalDeviationType === 'Early') {
      if (addArrivalModel.contactID) {
        return {
          arrivalTimeDeviationType: addArrivalModel.arrivalDeviationType,
          arrivalTimeDeviationReason: addArrivalModel.arrivalTimeDeviationReason,
          arrivalTimeDeviationReasonCategory: addArrivalModel.arrivalTimeDeviationReasonCategory,
          arrivalDeviationResponsibilityPartyType: addArrivalModel.arrivalDeviationResponsibilityPartyType,
          contactID: addArrivalModel.contactID
        };
      } else {
        return this.getDeviationdetails(addArrivalModel);
      }
    } else {
      return null;
    }
  }
  static getDeviationdetails(addArrivalModel) {
    let reasonContactText;
    if (addArrivalModel.arrivalDeviationType.toLowerCase() === 'late') {
      reasonContactText = addArrivalModel.addArrivalForm.controls.arrivalLate.get('lateReasonContact').value;
    } else {
      reasonContactText = addArrivalModel.addArrivalForm.controls.arrivalEarly.get('earlyReasonContact').value;
    }
    return {
      arrivalTimeDeviationType: addArrivalModel.arrivalDeviationType ? addArrivalModel.arrivalDeviationType : null,
      arrivalTimeDeviationReason: addArrivalModel.arrivalTimeDeviationReason ? addArrivalModel.arrivalTimeDeviationReason : null,
      arrivalTimeDeviationReasonCategory: addArrivalModel.arrivalTimeDeviationReasonCategory ?
                    addArrivalModel.arrivalTimeDeviationReasonCategory : null,
      arrivalDeviationResponsibilityPartyType: addArrivalModel.arrivalDeviationResponsibilityPartyType ?
                    addArrivalModel.arrivalDeviationResponsibilityPartyType : null,
      contactText: reasonContactText
    };
  }
}
