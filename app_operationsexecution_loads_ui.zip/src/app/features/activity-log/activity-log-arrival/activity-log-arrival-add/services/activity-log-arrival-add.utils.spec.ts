import { ActivityLogArrivalAddUtils } from './activity-log-arrival-add.utils';


describe('ActivityLogArrivalAddUtils', () => {
    it('arrivalDeviationRequestJson have been called', () => {
        const returnResult = {
            arrivalDeviationType: '',
            arrivalTimeDeviationReason: '',
            arrivalTimeDeviationReasonCategory: '',
            arrivalDeviationResponsibilityPartyType: '',
            contactID: ''
        };
        const result = ActivityLogArrivalAddUtils.arrivalDeviationRequestJson(returnResult);
        expect(result).toBe(null);
    });

    it('arrivalDeviationRequestJson have been called when late', () => {
        const returnResult = {
            arrivalDeviationType: 'Late',
            arrivalTimeDeviationReason: '',
            arrivalTimeDeviationReasonCategory: '',
            arrivalDeviationResponsibilityPartyType: '',
            contactID: '256342'
        };
        const result = ActivityLogArrivalAddUtils.arrivalDeviationRequestJson(returnResult);
        expect(result).toBeTruthy();
    });
});
