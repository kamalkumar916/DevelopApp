import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { configureTestSuite } from 'ng-bullet';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogArrivalAddService } from './activity-log-arrival-add.service';

describe('ActivityLogArrivalAddService', () => {
  let service: ActivityLogArrivalAddService;
  let httpTestingController: HttpTestingController;

  const arrivalDeviationRequest = {
    operationalPlanID: 1,
    operationalPlanStopSequenceNumber: 12,
    operationalPlanStopID: 0,
    arrivalTimestamp: '',
    operationalPlanNumber: '',
    truck: null,
    destinationHeader: ''
  };
  const addArrivalRequestObj = {
    operationalPlanNumber: '',
    operationalPlanStopSequenceNumber: 1,
    arrivalType: '',
    arrivalTimestamp: '',
    checkCallSourceTimestamp: '',
    hubReading: '',
    arrivalCheckCallType: '',
    resourceDetails: {
      type: '',
      value: 1
    },
    isAutoCheckCall: true,
    checkCallSource: '',
    arrivalTimeDeviationDetails: {
      arrivalTimeDeviationType: '',
      arrivalTimeDeviationReason: '',
      arrivalTimeDeviationReasonCategory: '',
      arrivalDeviationResponsibilityPartyType: '',
      contactID: '',
      contactText: ''
    },
    comments: '',
    isWarningOverride: true
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogArrivalAddService, AppConfigService]
    });
  });

  beforeEach(() => {
    service = TestBed.get(ActivityLogArrivalAddService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('getResourceDetails have been called', () => {
    service.getResourceDetails({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getResourceDetails);
    expect(req.request.method).toEqual('POST');
  });

  it('getResourceImage have been called', () => {
    const queryParam = [''];
    service.getResourceImage(queryParam).subscribe();
    const url = `${service.endpoint.getResourceImage}?personIds=&userIds=${queryParam}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toEqual('GET');
  });

  it('getReasonCategory have been called', () => {
    service.getReasonCategory().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.reasonCategory);
    expect(req.request.method).toEqual('GET');
  });

  it('getReason have been called', () => {
    const reasonCode = '';
    service.getReason(reasonCode).subscribe();
    const url = `${service.endpoint.reason}/category?category=${reasonCode}`;
    const req = httpTestingController.expectOne(url);
    expect(req.request.url).toEqual(url);
  });

  it('getReasonResponsibilityTypes have been called', () => {
    service.getReasonResponsibilityTypes().subscribe();
    const req = httpTestingController.expectOne(service.endpoint.responsibilityTypes);
    expect(req.request.method).toEqual('GET');
  });

  it('getArrivalType have been called', () => {
    service.getArrivalType(arrivalDeviationRequest).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getArrivalType);
    expect(req.request.method).toEqual('POST');
  });

  it('addArrivalDetails have been called', () => {
    service.addArrivalDetails(addArrivalRequestObj).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.addArrival);
    expect(req.request.method).toEqual('POST');
  });
});

