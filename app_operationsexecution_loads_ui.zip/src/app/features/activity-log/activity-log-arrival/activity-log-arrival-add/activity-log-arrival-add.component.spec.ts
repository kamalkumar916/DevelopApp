import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { MessageService } from 'primeng/components/common/messageservice';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { configureTestSuite } from 'ng-bullet';

import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { ActivityLogArrivalAddComponent } from './activity-log-arrival-add.component';
import { ActivityLogResourceInformationComponent } from '../activity-log-resource-information/activity-log-resource-information.component';
import { DirectivesModule } from './../../../../shared/directives/directives.module';

import { ActivityLogUtils } from '../../services/activity-log.utils';
import { of } from 'rxjs/internal/observable/of';
import { ActivityLogArrivalAddService } from './services/activity-log-arrival-add.service';

const arrivalDeviationResponse = {
    operationalPlanId: 0,
    operationalPlanStopId: 0,
    operationalPlanStopSequenceNumber: '',
    appointmentStartTimestamp: '',
    appointmentEndTimestamp: '',
    arrivalDeviationType: 'early'
};
describe('ActivityLogArrivalAddComponent', () => {
  let component: ActivityLogArrivalAddComponent;
  let fixture: ComponentFixture<ActivityLogArrivalAddComponent>;
  const arrivalRequestObj = { operationalPlanID: 123, operationalPlanStopSequenceNumber: 456, operationalPlanNumber: '' };
  const resourceDetails = { equipmentId: 789 };
  const numberPrefixTypeDTO = {
    prefix: '',
    number: '',
    typeRequired: ''
  };
  const trailer = {
    prefix: '',
    number: '',
    typeRequired: false,
    length: 0,
    isLengthRequired: false,
    isPreLoaded: false,
    category: '',
    type: ''
  };
  const overrideAllWarning = true;
  const loadInfo = {
    operationalPlanId: 0,
    operationalPlanNumber: '',
    operationalPlanType: {
      operationalPlanTypeCode: '',
      operationalPlanTypeDescription: ''
    },
    operationalPlanSubtype: {
      operationalPlanSubtypeCode: '',
      operationalPlanSubtypeDescription: ''
    },
    operationalPlanStatus: {
      operationalPlanStatusCode: '',
      operationalPlanStatusDescription: ''
    },
    operationalPlanServiceOfferingCode: '',
    operationalPlanTransitModeCode: '',
    operationalPlanFinanceBusinessUnitCode: '',
    desirabilityIndexNumber: 0,
    resource: '',
    truck: '',
    requiredEquipment: '',
    trailer: '',
    container: '',
    chassis: '',
    classifications: [],
    loadedMilesWithUnit: '',
    loadedMiles: '',
    emptyMiles: '',
    estimatedTotalMiles: '',
    items: '',
    totalWeight: '',
    requestedService: [],
    estimatedTimeOfCompletion: '',
    routeSequenceNumber: '',
    totalRouteSequenceNumber: '',
    routePlanId: '',
    routeId: '',
    payRoute: [],
    utilization: null,
    totalPointsQuantity: '',
    networkOperationalPlanIndicator: '',
    externalOperationalPlanBoardIndicator: '',
    bulkProcessIndicator: '',
    operationalGroupCode: '',
    customerRate: [],
    tripPlanTransitValue: '',
    operationalPlanStopDTOs: null,
    billTo: [],
    operationalPlanOwnershipDTOs: [],
    equipmentDetails: {
      isPreLoaded: false,
      truck: numberPrefixTypeDTO,
      chassis: numberPrefixTypeDTO,
      container: numberPrefixTypeDTO,
      trailer: trailer,
      currentTrailer: trailer,
      driverId: 0,
      equipmentId: 0,
      alphaCode: '',
      firstName: '',
      lastName: '',
      middleName: '',
      resourceName: '',
      tanker: numberPrefixTypeDTO,
      hopper: numberPrefixTypeDTO
    },
    operationalPlanRouteGuideStatus: {
      operationalPlanRouteGuideStatusCode: '',
      operationalPlanRouteGuideStatusDescription: ''
    },
    servicePriorityCode: '',
    committedFreightIndicator: '',
    shipmentId: [],
    payRouteLists: [],
    jbhuntFailureCount: 0,
    operationalPlanOrderIds: {}
  };
  const stopInformation = {
    operationalPlanStopId: 99,
    operationalPlanStopSequenceNumber: 456,
    operationalPlanStopReason: {
      operationalPlanStopReasonCode: ''
    },
    operationalPlanStopStatus: {
      operationalPlanStopStatusCode: '',
      operationalPlanStopStatusDescription: ''
    },
    locationDetailsDTO: {
      locationId: 12,
      locationName: '',
      locationCode: '',
      address: {
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipcode: '',
        country: ''
      },
      locationSubTypes: [{ code: '', description: '' }],
      timezone: 'IST'
    },
    operationalPlanStopAppointment: {
      appointmentStartTimestamp: '',
      appointmentEndTimestamp: ''
    },
    handlingUnitSummaryDTO: {
      handlingType: '',
      handlingQuantity: 45,
      weight: { value: 45, unitOfMeasurementCode: '' },
      density: { value: 45, unitOfMeasurementCode: '' },
      volume: { value: 45, unitOfMeasurementCode: '' },
      length: { value: 45, unitOfMeasurementCode: '' },
      itemHandlingUnitWidth: 98,
      itemHandlingUnitHeight: 98,
      itemDetailDTO: []
    }
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, CalendarModule, DropdownModule, RouterTestingModule,
        AutoCompleteModule, JbhLoaderModule, ReactiveFormsModule, PipesModule,
        NoopAnimationsModule, DirectivesModule],
      providers: [UserService, AppConfigService, MessageService, LocalStorageService],
      declarations: [ActivityLogArrivalAddComponent, ActivityLogResourceInformationComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogArrivalAddComponent);
    component = fixture.componentInstance;
    component.reload = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.arrivalRequestObj = arrivalRequestObj;
    component.resourceDetails = resourceDetails;
    component.overrideAllWarning = overrideAllWarning;
    component.stopInformation = stopInformation;
    component.reload = true;
    expect(component).toBeTruthy();
  });

  it('getLocalStoreItem have been called', () => {
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'getItem').and.returnValue({ arrivalDate: '', arrivalTime: '', timeZone: '', arrivalForm: {} });
    spyOn(component, 'getEarlyOrLateArrival');
    spyOn(component, 'onReasonCategorySelected');
    component.getLocalStoreItem();
    expect(component.addArrivalModel.arrivalDate).toEqual('');
  });

  it('validateMandatoryFields have been called', () => {
    spyOn(ActivityLogUtils, 'checkMandatoryFields');
    component.validateMandatoryFields();
    expect(ActivityLogUtils.checkMandatoryFields).toHaveBeenCalled();
  });

  it('onDateTyped have been called', () => {
    spyOn(component, 'formatDateValue');
    spyOn(ActivityLogUtils, 'dateValidation');
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    component.addArrivalModel.arrivalDate = tomorrow.toString();
    component.addArrivalModel.arrivalTime = tomorrow.getTime().toString();
    component.addArrivalModel.addArrivalForm.controls['arrivalDate'].patchValue(tomorrow);
    component.onDateTyped();
    expect(component.formatDateValue).toHaveBeenCalled();
  });

  it('frameArrivalAddRequest have been called', () => {
    component.overrideAllWarning = overrideAllWarning;
    component.frameArrivalAddRequest();
    expect(component.addArrivalModel.arrivalRequest.isWarningOverride).toEqual(overrideAllWarning);
  });

  it('resetResource have been called', () => {
    component.resetResource();
    expect(component.addArrivalModel.resourcesWithImages.length).toBe(0);
  });

  it('clearDateTime have been called', () => {
    const obj = { overlayVisible: true };
    component.clearDateTime(false, obj);
    expect(obj.overlayVisible).toBeFalsy();
  });

  it('clearDateTime have been called', () => {
    component.clearDateTime(true);
    expect(component.addArrivalModel.addArrivalForm.controls.arrivalDate.value).toBeNull();
  });

  it('onTimeTyped have been called', () => {
    spyOn(component, 'formatTimeValue').and.callThrough();
    component.onTimeTyped();
    expect(component.formatTimeValue).toHaveBeenCalled();
  });

  it('onDateChange have been called', () => {
    spyOn(component, 'formatDateValue').and.callThrough();
    const obj = { overlayVisible: true };
    component.onDateChange(obj, true);
    expect(component.formatDateValue).toHaveBeenCalled();
  });

  it('onDateChange have been called', () => {
    const obj = { overlayVisible: true };
    component.onDateChange(obj, false);
    expect(obj.overlayVisible).toBe(false);
  });

  it('handleLateOrEarlyArrival have been called', () => {
    const data = {};
    component.stopInformation = stopInformation;
    component.addArrivalModel.arrivalDeviationType = 'ontime';
    spyOn(component.arrivalDeviationType, 'emit');
    component.handleLateOrEarlyArrival(data);
    expect(component.arrivalDeviationType.emit).toHaveBeenCalledWith([]);
  });

  it('handleLateOrEarlyArrival have been called', () => {
    spyOn(component, 'validateStopInformation').and.returnValue(true);
    spyOn(component, 'getStopSequenceNumber');
    spyOn(component, 'getStopInfo').and.returnValue('');
    const data = { arrivalDeviationType: '' };
    component.stopInformation = stopInformation;
    component.handleLateOrEarlyArrival(data);
    expect(component.getStopSequenceNumber).toHaveBeenCalled();
  });

  it('onReasonSelected have been called', () => {
    component.onReasonSelected('reason');
    expect(component.addArrivalModel.arrivalTimeDeviationReason).toEqual('reason');
  });

  it('clearLocalStoreItem have been called', () => {
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'clearItem');
    component.clearLocalStoreItem();
    expect(localStorageService.clearItem).toHaveBeenCalled();
  });
  it('loadDetails has been set', () => {
    component.loadDetails = loadInfo;
    expect(component.addArrivalModel.loadDetails).toBeTruthy();
  });
  it('reload has been set', () => {
    component.reload = true;
    expect(component.addArrivalModel.isReload).toBeTruthy();
  });
  it('onSelectDriver have been called', () => {
    component.onSelectDriver('1234');
    expect(component.addArrivalModel.contactID).toEqual('1234');
  });
  it('onTextAreaType have been called', () => {
    component.onTextAreaType();
    expect(component.addArrivalModel.textareaCount).toEqual(0);
  });
  it('onSelectReasonResponsibility have been called', () => {
    component.onSelectReasonResponsibility('driver', 'late', 'lateReasonContact');
    component.addArrivalModel.arrivalDeviationResponsibilityPartyType = 'driver';
    expect(component.addArrivalModel.isFreeText).toEqual(false);
  });
  it('onsearchReasonText have been called', () => {
    component.onsearchReasonText('edw', true);
    expect(component.addArrivalModel.results).toEqual([]);
  });
});
