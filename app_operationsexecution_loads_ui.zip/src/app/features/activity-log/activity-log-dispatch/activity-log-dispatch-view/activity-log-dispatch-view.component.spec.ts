import { ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';

import { JbhLoaderModule } from '../../../../shared/jbh-loader/jbh-loader.module';

import { ActivityLogDispatchViewComponent } from './activity-log-dispatch-view.component';
import { PipesModule } from './../../../../shared/pipes/pipes.module';
import { DirectivesModule } from './../../../../shared/directives/directives.module';
import { TooltipModule } from 'primeng/tooltip';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { AppSharedDataService } from '../../../../shared/jbh-app-services/app-shared-data.service';
import { ActivityLogService } from './../../services/activity-log.service';
import { RouterTestingModule } from '@angular/router/testing';
import { GlobalPopupsModule } from './../../../../shared/global-popups/global-popups.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { throwError } from 'rxjs/internal/observable/throwError';
import { of } from 'rxjs/internal/observable/of';
import { DateUtils } from './../../../../shared/jbh-app-services/date-utils';

const dropEquipmentDetails = [
  {
    equipmentId: 1,
    equipmentType: 'CONTAINER',
    equipmentPrefix: 'JBHU',
    equipmentNumber: '745632'
  }
];
const pickupEquipmentDetails = [
  {
    equipmentId: 1,
    equipmentType: 'CHASSIS',
    equipmentPrefix: 'JBHZ',
    equipmentNumber: '697884'
  }
];
const originStopDetails = {
  locationDetails: {
    locationId: '26551',
    locationName: 'VAN Buren Main',
    locationCode: 'VAVAC3',
    address: {
      addressLine1: '5 Main St',
      addressLine2: '',
      city: 'Van Buren',
      state: 'AR',
      zipcode: '729565706',
      country: 'USA',
      countryName: 'USA',
      timeZone: 'America/Chicago'
    }
  },
  appointmentStartTimeStamp: '2019-09-29T10:00:00-04:00',
  appointmentEndTimeStamp: '2019-09-29T11:00:00-04:00'
};

const destinationStopDetails = {
  locationDetails: {
    locationId: '99858',
    locationName: 'Francis Harvey Remodeling, LLC',
    locationCode: 'FRSH53',
    address: {
      addressLine1: '697 Hartford Tpke',
      addressLine2: '',
      city: 'Shrewsbury',
      state: 'MA',
      zipcode: '015454103',
      country: 'USA',
      countryName: 'USA',
      timeZone: 'America/New_York'
    }
  },
  appointmentStartTimeStamp: '2019-09-29T10:00:00-04:00',
  appointmentEndTimeStamp: '2019-09-29T11:00:00-04:00'
};
const payRouteSegments =
  [
    {
      operationalPlanPayRouteSegmentId: 9788,
      originCityId: 31984,
      destinationCityId: 2680,
      payRouteSegmentStatusCode: 'Empty',
      segmentSequenceNumber: 1,
      originOperationalPlanStopId: null,
      destinationOperationalPlanStopId: 69221,
      originCityName: 'New York',
      originStateCode: 'NY',
      originStopSequenceNumber: null,
      destinationCityName: 'Van Buren',
      destinationStateCode: 'AR',
      destinationSequenceNumber: 1
    },
    {
      operationalPlanPayRouteSegmentId: 9789,
      originCityId: 2680,
      destinationCityId: 18118,
      payRouteSegmentStatusCode: 'Loaded',
      segmentSequenceNumber: 2,
      originOperationalPlanStopId: 69221,
      destinationOperationalPlanStopId: 69222,
      originCityName: 'Van Buren',
      originStateCode: 'AR',
      originStopSequenceNumber: 1,
      destinationCityName: 'Shrewsbury',
      destinationStateCode: 'MA',
      destinationSequenceNumber: 2
    }
  ];
const viewDispatchDetails = {
  dispatchTimeStamp: '2019-09-30T05:45:48.709-04:00',
  loadNumber: 'L37186',
  loadType: 'Freight',
  emptyMiles: null,
  loadedMiles: 1505,
  origin: originStopDetails,
  destination: destinationStopDetails,
  intermediateStops: 0,
  pickupEquipments: pickupEquipmentDetails,
  dropEquipments: dropEquipmentDetails,
  payRouteDetails: payRouteSegments
};

class MockActivityLogService {
  constructor() { }
  getDispatchCheckCallDetails(operationalPlanCheckCallId: number) {
    return of(viewDispatchDetails);
  }
}

describe('ActivityLogDispatchViewComponent', () => {
  let component: ActivityLogDispatchViewComponent;
  let fixture: ComponentFixture<ActivityLogDispatchViewComponent>;
  let activityLogService: ActivityLogService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, JbhLoaderModule, TooltipModule, PipesModule,
        RouterTestingModule, GlobalPopupsModule, DirectivesModule, NoopAnimationsModule],
      declarations: [ActivityLogDispatchViewComponent],
      providers: [AppConfigService, AppSharedDataService, { provide: ActivityLogService, useClass: MockActivityLogService }]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogDispatchViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('ActivityLogDispatchViewComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('getDispatchDetails have been called when service call success', () => {
    spyOn(component, 'formatAppointmentDetails');
    spyOn(DateUtils, 'convertOffsetDateByDefaultTimeZone');
    spyOn(component, 'formatLocationDetails');
    component.getDispatchDetails(123);
    expect(component.activityLogDetailsModel.loading).toBeFalsy();
    expect(component.activityLogDetailsModel.originAppointmentTime).toBe(component.formatAppointmentDetails(viewDispatchDetails.origin));
    expect(component.activityLogDetailsModel.destinationAppointmentTime).
      toBe(component.formatAppointmentDetails(viewDispatchDetails.destination));
    expect(component.activityLogDetailsModel.originLocation).toBe(component.formatLocationDetails(viewDispatchDetails.origin));
    expect(component.activityLogDetailsModel.originLocation).toBe(component.formatLocationDetails(viewDispatchDetails.origin));
    expect(component.activityLogDetailsModel.destinationLocation).toBe(component.formatLocationDetails(viewDispatchDetails.destination));
    expect(component.activityLogDetailsModel.dispatchTimeStamp).
      toBe(DateUtils.convertOffsetDateByDefaultTimeZone(viewDispatchDetails.dispatchTimeStamp,
        'MMM DD,YYYY hh:mm A z'));
  });

  it('getDispatchDetails error block have been called when service fails', () => {
    activityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getDispatchCheckCallDetails').and.returnValue(throwError(null));
    component.getDispatchDetails(123);
    expect(component.activityLogDetailsModel.loading).toBeFalsy();
  });

  it('formatLocationDetails have been called', () => {
    const stopDto = destinationStopDetails;
    const returnValue = component.formatLocationDetails(stopDto);
    expect(returnValue).toBe(stopDto.locationDetails);
  });
  it('formatLocationDetails else have been called', () => {
    const originDestination = {
      appointmentStartTimeStamp: '2019-09-29T10:00:00-04:00',
      appointmentEndTimeStamp: '2019-09-29T11:00:00-04:00',
      locationDetails: null
    };
    const returnValue = component.formatLocationDetails(originDestination);
    expect(returnValue).toBeNull();
  });
  it('formatAppointmentDetails else have been called', () => {
    const originDestination = {
      appointmentStartTimeStamp: null,
      appointmentEndTimeStamp: null,
      locationDetails: null
    };
    const returnValue = component.formatAppointmentDetails(originDestination);
    expect(returnValue).toBeNull();
  });
});
