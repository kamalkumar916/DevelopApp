import { Component, OnInit, Input, ChangeDetectorRef, ChangeDetectionStrategy, ElementRef } from '@angular/core';
import { LoadOverview } from '../../../load-details/load-details-overview/model/load-overview.interface';
import { ActivityLogModel } from '../../models/activity-log.model';
import { ActivatedRoute } from '@angular/router';
import { ActivityLogService } from '../../services/activity-log.service';
import { takeWhile, finalize } from 'rxjs/operators';
import { ViewDispatchDetails, OriginDestination } from '../../models/activity-log.interface';
import { ActivityLogUtils } from '../../services/activity-log.utils';
import { GlobalPopupsComponent } from '../../../../shared/global-popups/global-popups.component';
import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';

@Component({
  selector: 'app-activity-log-dispatch-view',
  templateUrl: './activity-log-dispatch-view.component.html',
  styleUrls: ['./activity-log-dispatch-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogDispatchViewComponent implements OnInit {
  activityLogDetailsModel: ActivityLogModel;

  constructor(private readonly activityLogService: ActivityLogService, private readonly changeDetector: ChangeDetectorRef,
    private readonly activatedRoute: ActivatedRoute) {
    this.activityLogDetailsModel = new ActivityLogModel();
  }

  ngOnInit() {
    this.activityLogDetailsModel.checkCallId = this.activatedRoute.queryParams['_value']['checkCallId'];
    if (this.activityLogDetailsModel.checkCallId) {
      this.getDispatchDetails(this.activityLogDetailsModel.checkCallId);
    }
  }

  getDispatchDetails(operationalPlanCheckCallId: number) {
    this.activityLogDetailsModel.loading = true;
    this.activityLogService.getDispatchCheckCallDetails(operationalPlanCheckCallId)
      .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
        finalize(() => {
          this.activityLogDetailsModel.loading = false;
          this.changeDetector.detectChanges();
        })).subscribe((data: ViewDispatchDetails) => {
          this.activityLogDetailsModel.loading = false;
          if (data) {
            this.activityLogDetailsModel.dispatchDetails = data;
            this.activityLogDetailsModel.originAppointmentTime = this.formatAppointmentDetails(data.origin);
            this.activityLogDetailsModel.destinationAppointmentTime = this.formatAppointmentDetails(data.destination);
            this.activityLogDetailsModel.originLocation = this.formatLocationDetails(data.origin);
            this.activityLogDetailsModel.destinationLocation = this.formatLocationDetails(data.destination);
            if (data.dispatchTimeStamp) {
              this.activityLogDetailsModel.dispatchTimeStamp = DateUtils.convertOffsetDateByDefaultTimeZone(data.dispatchTimeStamp,
              'MMM DD,YYYY hh:mm A z');
            }
            this.changeDetector.markForCheck();
            this.changeDetector.detectChanges();
          }
        }, (error: Error) => {
          this.activityLogDetailsModel.loading = false;
        });
  }
  formatLocationDetails(stopDto: OriginDestination) {
    if (stopDto && stopDto.locationDetails) {
      return stopDto.locationDetails;
    } else {
      return null;
    }

  }
  formatAppointmentDetails(stopDto: OriginDestination) {
    if (stopDto && stopDto.appointmentStartTimeStamp && stopDto.appointmentEndTimeStamp) {
      return {
        appointmentStartTimestamp: stopDto.appointmentStartTimeStamp,
        appointmentEndTimestamp: stopDto.appointmentEndTimeStamp,
        timeZone: stopDto.locationDetails.address.timeZone
      };
    } else {
      return null;
    }
  }
}
