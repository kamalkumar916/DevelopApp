import { Component, OnInit, Output, EventEmitter, ViewChild, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';

import { takeWhile, finalize } from 'rxjs/operators';
import { filter } from 'lodash';
import { timer } from 'rxjs';
import { MessageService } from 'primeng/components/common/messageservice';

import { LocalStorageService } from '../../shared/jbh-app-services/local-storage.service';
import { AppSharedDataService } from '../../shared/jbh-app-services/app-shared-data.service';

import { ActivityLogModel } from './models/activity-log.model';
import { ActivityLogService } from './services/activity-log.service';
import { LoadOverview } from '../../features/load-details/load-details-overview/model/load-overview.interface';
import { ActivityLogLoadedAddComponent } from './activity-log-loaded/activity-log-loaded-add/activity-log-loaded-add.component';
import { ActivityLogUtils } from './services/activity-log.utils';
import { ErrorList, TrackingDetailsParam, ResourceOverview, UpdateLocationHeader,
  TelematicsEquipment } from './models/activity-log.interface';
import { ErrorUtils } from '../../shared/jbh-app-services/error-utils';
import { EquipmentGroupItem } from '../../features/tracking-details/model/tracking-details.interface';

@Component({
  selector: 'app-activity-log',
  templateUrl: './activity-log.component.html',
  styleUrls: ['./activity-log.component.scss']
})
export class ActivityLogComponent implements OnInit, OnDestroy {
  activityLogDetailsModel: ActivityLogModel;
  @ViewChild('addArrival') addArrival: any;
  @ViewChild('editArrival') editArrival: any;
  @ViewChild('addLoaded') addLoaded;
  @ViewChild('addUnloaded') addUnloaded;
  loadDetailsPath = '/loaddetails';
  trackingDetailsPath = '/trackingdetails';
  checkCallPath = '/tracking';
  @Output() arrivalDeviationType: EventEmitter<ErrorList[]> = new EventEmitter<ErrorList[]>();
  constructor(private readonly activityLogService: ActivityLogService,
    private readonly appSharedDataService: AppSharedDataService,
    private readonly changeDetector: ChangeDetectorRef, private readonly router: Router,
    private readonly activatedRoute: ActivatedRoute, private readonly localStorageService: LocalStorageService,
    private readonly toastMessage: MessageService) {
    this.activityLogDetailsModel = new ActivityLogModel();
  }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe((routeParams) => {
      this.activityLogDetailsModel.loadNumber = routeParams.loadNumber;
      this.activityLogDetailsModel.activityType = routeParams.activityType;
      this.activityLogDetailsModel.index = routeParams.index;

      this.activityLogDetailsModel.checkCallId = routeParams.checkCallId;
      this.activityLogDetailsModel.edit = routeParams.edit === 'true';
      this.activityLogDetailsModel.view = this.activityLogDetailsModel.edit !== true && routeParams && routeParams.checkCallId;
      this.activityLogDetailsModel.fromActivityLog = routeParams.hasCheckCall === 'true';
      this.activityLogDetailsModel.editFromTracking = routeParams.fromTrack === 'true';
    });
    this.activityLogDetailsModel.isTracking = this.router.url && this.router.url.indexOf(this.trackingDetailsPath) !== -1;
    this.activityLogDetailsModel.isCheckCallTracking = this.router.url && this.router.url.indexOf(this.checkCallPath) !== -1;
    this.activityLogDetailsModel.onlyTrackingDetails = this.router.url && this.router.url.indexOf('/trackingdetails/') !== -1;
    this.activityLogDetailsModel.noCheckCall = this.activityLogDetailsModel.onlyTrackingDetails &&
      !this.activityLogDetailsModel.fromActivityLog;
    if (this.activityLogDetailsModel.fromActivityLog) {
      this.activityLogDetailsModel.isCheckCallTracking = true;
    }
    this.activityLogDetailsModel.checkCallNavigation = this.activityLogDetailsModel.isCheckCallTracking &&
      !this.activityLogDetailsModel.fromActivityLog;

    this.activityLogDetailsModel.checkCallInputs = {
      isCheckCallTracking: this.activityLogDetailsModel.isCheckCallTracking,
      checkCallNavigation: this.activityLogDetailsModel.checkCallNavigation,
      isTracking: this.activityLogDetailsModel.isTracking
    };

    if (this.activityLogDetailsModel.isCheckCallTracking) {
      this.getCheckCallErrorWarningList();
    }
    this.setHeader();
    this.getLoadOverView();
    this.getResourceDetails();
    this.setScrollToTop();
  }
  onEquipmentLocationAction() {
    this.activityLogDetailsModel.isLocationUpdate = false;
    this.activityLogDetailsModel.isReload = true;
    this.getLoadOverView();
    this.getResourceDetails();
    this.arrivalDevationType([]);
    this.activityLogDetailsModel.breadCrumb.pop();
    this.changeDetector.detectChanges();
    if (this.activityLogDetailsModel.isCheckCallTracking) {
      this.getCheckCallErrorWarningList();
    }
  }
  setHeader() {
    const arrivalDetails = 'Arrival Details';
    switch (this.activityLogDetailsModel.activityType) {
      case 'comment':
        this.getBreadCrumbData('Comment Details');
        this.activityLogDetailsModel.activityLogHeader = 'COMMENTS';
        break;
      case 'dispatch':
        this.getBreadCrumbData('Dispatch Details');
        this.activityLogDetailsModel.activityLogHeader = 'DISPATCH DETAILS';
        break;
      case 'arrival':
        this.setHeaderAndMenu(arrivalDetails);
        break;
      case 'loaded':
        this.setHeaderAndMenu('Loaded Details');
        break;
      case 'unloaded':
        this.setHeaderAndMenu('Unloaded Details');
        break;
      case 'arrivalandloaded':
        this.setHeaderAndMenu('Arrival and Loaded Details');
        break;
      case 'arrivalandunloaded':
        this.setHeaderAndMenu('Arrival and Unloaded Details');
        break;
    }
  }
  setHeaderAndMenu(headerMenuDetail) {
    this.getBreadCrumbData(headerMenuDetail);
    this.activityLogDetailsModel.activityLogHeader = headerMenuDetail.toUpperCase();
    this.activityLogDetailsModel.subHeader = headerMenuDetail;
  }
  frameActivityLogHeader() {
    const destinationHeading = this.activityLogDetailsModel.arrivalRequestObj.destinationHeader;
    const stopSeqNumber = this.activityLogDetailsModel.arrivalRequestObj.operationalPlanStopSequenceNumber;
    let stopDesc = '';
    if (destinationHeading) {
      stopDesc = destinationHeading;
    } else {
      stopDesc = (stopSeqNumber === 1) ?
        'Origin' : `Stop ${stopSeqNumber}`;
    }
    switch (this.activityLogDetailsModel.activityType) {
      case 'arrival':
        this.activityLogDetailsModel.activityLogHeader =
          `${stopDesc} ARRIVAL DETAILS`;
        break;
      case 'loaded':
        this.activityLogDetailsModel.activityLogHeader = `${stopDesc} LOADED DETAILS`;
        break;
      case 'unloaded':
        this.activityLogDetailsModel.activityLogHeader = `${stopDesc} UNLOADED DETAILS`;
        break;
      case 'arrivalandloaded':
        this.activityLogDetailsModel.activityLogHeader = `${stopDesc} ARRIVAL AND LOADED DETAILS`;
        break;
      case 'arrivalandunloaded':
        this.activityLogDetailsModel.activityLogHeader = `${stopDesc} ARRIVAL AND UNLOADED DETAILS`;
        break;
    }
  }
  getLoadOverView() {
    this.activityLogDetailsModel.isLoading = true;
    this.activityLogDetailsModel.isAddCheckCallLoaded = true;
    if (this.activityLogDetailsModel.loadNumber) {
      this.activityLogService.getLoadOverview(this.activityLogDetailsModel.loadNumber)
        .pipe(
          takeWhile(() => this.activityLogDetailsModel.canSubscribe)).subscribe((data: LoadOverview) => {
            this.activityLogDetailsModel.isAddCheckCallLoaded = false;
            this.activityLogDetailsModel.isLoading = false;
            if (data) {
              this.activityLogDetailsModel.loadOverviewDetails = data;
              this.changeDetector.detectChanges();
            }
          }, (error) => {
            this.activityLogDetailsModel.isLoading = false;
            this.activityLogDetailsModel.isAddCheckCallLoaded = false;
            this.activityLogDetailsModel.loadOverviewDetails = null;
          });
    }
  }
  getResourceDetails() {
    this.activityLogDetailsModel.isResourceLoading = true;
    if (this.activityLogDetailsModel.loadNumber) {
      this.activityLogService.getResourceOverviewDetails(this.activityLogDetailsModel.loadNumber)
        .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
          finalize(() => {
            this.activityLogDetailsModel.isResourceLoading = false;
            this.changeDetector.detectChanges();
          }))
        .subscribe((data: ResourceOverview) => {
          if (data) {
            this.activityLogDetailsModel.resourceOverview = data;
            this.activityLogDetailsModel.resourceIdVal = data.alphaCode ? data.alphaCode : null;
            this.activityLogDetailsModel.driverIdComments = data.driverId ? data.driverId : '';
            this.changeDetector.detectChanges();
          }
        }, (error) => {
          this.activityLogDetailsModel.resourceOverview = null;
          this.activityLogDetailsModel.resourceIdVal = null;
        });
    }
  }
  getCheckCallErrorWarningList() {
    this.activityLogService.getCheckCallErrors(this.activityLogDetailsModel.checkCallId)
      .pipe(
        takeWhile(() => this.activityLogDetailsModel.canSubscribe)).subscribe((data: any) => {
          if (data) {
            const exceptionErrorArray = data['checkCallErrorDTO'][0]['checkCallExceptions'];
            const exceptionList = [];
            exceptionErrorArray.forEach((exceptionObj) => {
              ActivityLogUtils.activityLogError(exceptionObj, exceptionList);
              if (exceptionObj.taskTypeName) {
                this.activityLogDetailsModel.fieldErrorList.push(exceptionObj.taskTypeName.toLowerCase());
              }
            });
            this.arrivalDevationType(exceptionList);
          }
        });
  }

  addarrivalunloaded() {
    if (this.activityLogDetailsModel.arrivalLoadedUnloadedRequest.arrivalCheckCallDetails &&
      this.activityLogDetailsModel.arrivalLoadedUnloadedRequest.loadedUnloadedCheckCallDetails) {
      if (this.activityLogDetailsModel.arrivalLoadedUnloadedRequest.arrivalCheckCallDetails.resourceDetails.value &&
        this.activityLogDetailsModel.arrivalLoadedUnloadedRequest.loadedUnloadedCheckCallDetails.resourceDetails.value) {
        this.activityLogDetailsModel.isArrivalLoadUnloadLoading = true;
        this.activityLogService.addArrivalAndUnloaded(this.activityLogDetailsModel.arrivalLoadedUnloadedRequest)
          .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe)).subscribe((arrivalUnloadedData) => {
            this.activityLogDetailsModel.isArrivalLoadUnloadLoading = false;
            if (arrivalUnloadedData) {
              this.navigateToListPage('Arrival and Unloaded');
            }
          }, (error) => {
            this.handleError(error);
            this.addArrival.changeDetector.detectChanges();
            this.addUnloaded.changeDetector.detectChanges();
          });
      } else {
        this.toastMessage.clear();
        ActivityLogUtils.resourceFieldError(this.toastMessage);
      }
    }
  }

  ngOnDestroy() {
    this.activityLogDetailsModel.canSubscribe = false;
  }
  onSave() {
    this.saveAddActivityLog();
    this.changeDetector.markForCheck();
    this.changeDetector.detectChanges();
  }
  onCancel() {
    if (this.activityLogDetailsModel.isTracking || this.activityLogDetailsModel.editFromTracking) {
      this.router.navigate([this.trackingDetailsPath],
        {
          queryParams: this.getTrackingDetailsQueryParam()
        });
    } else if (this.activityLogDetailsModel.checkCallNavigation) {
      this.router.navigate([this.checkCallPath],
        {
          queryParams: {
            fromCheckCall: 'true'
          }
        });
    } else {
      this.router.navigate([`${this.loadDetailsPath}/${this.activityLogDetailsModel.loadNumber}`],
        {
          queryParams: {
            index: 2
          }
        });
    }
  }
  sequenceNumber(event) {
    if (this.activityLogDetailsModel.loadOverviewDetails) {
      this.activityLogDetailsModel.arrivalRequestObj = {
        'operationalPlanID': Number(this.activityLogDetailsModel.loadNumber),
        'operationalPlanStopSequenceNumber': event.stopSequenceNumber,
        'operationalPlanStopID': event.stopId,
        'destinationHeader': event.destinationHeader,
        'truck': ActivityLogUtils.getTruckValue(this.activityLogDetailsModel.resourceOverview),
        'operationalPlanNumber': this.activityLogDetailsModel.loadOverviewDetails.operationalPlanNumber
      };
    } else {
      this.activityLogDetailsModel.arrivalRequestObj = {
        'operationalPlanID': Number(this.activityLogDetailsModel.loadNumber),
        'operationalPlanStopSequenceNumber': event.stopSequenceNumber,
        'destinationHeader': event.destinationHeader,
      };
    }
    this.frameActivityLogHeader();
  }
  checkCallStopId(event) {
    this.activityLogDetailsModel.stopID = event.checkCallStopId;
  }
  arrivalDevationType(event) {
    this.activityLogDetailsModel.showError = true;
    if (event && event.length > 0) {
      this.activityLogDetailsModel.errorMessage = filter(event, ['errorSeverity', 'ERROR']);
      this.activityLogDetailsModel.warningMessage = filter(event, ['errorSeverity', 'WARNING']);
      this.checkErrorWarningMessageDisplay();
    } else {
      this.activityLogDetailsModel.errorMessage = [];
      this.activityLogDetailsModel.warningMessage = [];
    }
    this.changeDetector.detectChanges();
  }

  getBreadCrumbData(LabelVal: string) {
    if (this.activityLogDetailsModel.isTracking || this.activityLogDetailsModel.editFromTracking) {
      this.activityLogDetailsModel.breadCrumb = [{
        label: 'Tracking',
        routerLink: ['/loadtracking']
      },
      {
        label: 'Load Tracking',
        routerLink: ['/loadtracking']
      },
      {
        label: 'Tracking Details',
        routerLink: [this.trackingDetailsPath],
        queryParams: this.getTrackingDetailsQueryParam()
      }
      ];
    } else if (this.activityLogDetailsModel.checkCallNavigation) {
      this.activityLogDetailsModel.breadCrumb = [{
        label: 'Tracking',
        routerLink: ['/tracking']
      },
      {
        label: 'Tracking Tasks',
        routerLink: ['/tracking'],
        queryParams: {
          fromCheckCall: 'true'
        }
      }
      ];
    } else {
      this.activityLogDetailsModel.breadCrumb = [
        { label: 'Loads', routerLink: [''] },
        {
          label: 'Load Details',
          routerLink: [`${this.loadDetailsPath}/${this.activityLogDetailsModel.loadNumber}`]
        }
      ];
    }
    this.activityLogDetailsModel.breadCrumb.push({
      label: LabelVal,
      routerLink: ['/activityLog']
    });
  }
  onBack() {
    if (this.activityLogDetailsModel.isTracking || this.activityLogDetailsModel.editFromTracking) {
      this.router.navigate([this.trackingDetailsPath],
        {
          queryParams: this.getTrackingDetailsQueryParam()
        });
    } else if (this.activityLogDetailsModel.checkCallNavigation) {
      this.router.navigate([this.checkCallPath],
        {
          queryParams: {
            fromCheckCall: 'true'
          }
        });
    } else {
      this.router.navigate([`${this.loadDetailsPath}`, this.activityLogDetailsModel.loadNumber],
        {
          queryParams: {
            index: 2
          }
        });
    }
  }
  onEdit() {
    this.router.navigate(['loaddetails/activityLog'],
    {
      queryParams: {
        checkCallId: this.activityLogDetailsModel.checkCallId,
        loadNumber: this.activityLogDetailsModel.loadNumber,
        activityType: this.activityLogDetailsModel.activityType,
        resourceId: this.activityLogDetailsModel.resourceIdVal,
        resourceType: this.activityLogDetailsModel.resourceTypeVal,
        edit: true,
        fromTrack: (this.activityLogDetailsModel.noCheckCall) ? this.activityLogDetailsModel.noCheckCall : ''
      }
    });
  }
  overrideWarning(event) {
    this.activityLogDetailsModel.isOverrideWarning = event ? event : false;
    this.activityLogDetailsModel.showError = false;
  }
  saveArrivalAndLoaded(): void {
    if (!this.activityLogDetailsModel.isArrivalLoadUnloadLoading) {
      this.arrivalDevationType([]);
      this.toastMessage.clear();
      this.addArrival.validateMandatoryFields();
      this.addLoaded.validateMandatoryFields();
      if (this.addArrival.addArrivalModel.addArrivalForm.valid && this.addLoaded.activityLogLoadedAddModel.addLoadedForm.valid) {
        this.addArrival.frameArrivalAddRequest();
        if (this.addArrival.addArrivalModel.arrivalRequest && this.addLoaded.frameLoadedAddRequest()) {
          this.arrivalAndLoadedAdd();
        }
      } else {
        this.arrivalDevationType([{
          errorMessage: `Check call has missing required fields`,
          errorType: 'Form Validation',
          errorSeverity: 'ERROR'
        }]);
      }
    }
  }
  arrivalAndLoadedAdd() {
    const arrivalAndLoadedReq =
      this.frameArrivalAndLoadedRequest(this.addArrival.addArrivalModel.arrivalRequest, this.addLoaded.frameLoadedAddRequest());
    if (arrivalAndLoadedReq.arrivalCheckCallDetails.resourceDetails.value &&
      arrivalAndLoadedReq.loadedUnloadedCheckCallDetails.resourceDetails.value) {
      this.activityLogDetailsModel.isArrivalLoadUnloadLoading = true;
      this.activityLogService.addArrivalLoaded(arrivalAndLoadedReq)
        .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
          finalize(() => this.changeDetector.detectChanges()))
        .subscribe((arrivalLoadedData) => {
          this.activityLogDetailsModel.isArrivalLoadUnloadLoading = false;
          this.clearLocalStoreItem();
          if (arrivalLoadedData) {
            this.navigateToListPage('Arrival and Loaded');
          }
        }, (error) => {
          this.handleError(error);
          this.addArrival.changeDetector.detectChanges();
          this.addLoaded.changeDetector.detectChanges();
        });
    } else {
      this.toastMessage.clear();
      ActivityLogUtils.resourceFieldError(this.toastMessage);
    }
  }
  saveArrivalAndUnloaded(): void {
    if (!this.activityLogDetailsModel.isArrivalLoadUnloadLoading) {
      this.arrivalDevationType([]);
      this.toastMessage.clear();
      this.addArrival.validateMandatoryFields();
      this.addUnloaded.validateUnloadedCall();
      if (this.addArrival.addArrivalModel.addArrivalForm.invalid || this.addUnloaded.activityLogUnloadedAddModel.addUnloadedForm.invalid) {
        this.arrivalDevationType([{
          errorMessage: `Check call has missing required fields`,
          errorType: 'Form Validation',
          errorSeverity: 'ERROR'
        }]);
      } else {
        this.addArrival.frameArrivalAddRequest();
        const addUnloadedRequestInput = ActivityLogUtils.frameUnloadedRequest(this.addUnloaded.activityLogUnloadedAddModel);
        const addUnloadedReq = this.addUnloaded.isValidRequest(addUnloadedRequestInput);
        this.activityLogDetailsModel.arrivalLoadedUnloadedRequest.arrivalCheckCallDetails = this.addArrival.addArrivalModel.arrivalRequest;
        this.activityLogDetailsModel.arrivalLoadedUnloadedRequest.loadedUnloadedCheckCallDetails = addUnloadedReq;
        this.addarrivalunloaded();
      }
    }
  }
  saveAddActivityLog() {
    switch (this.activityLogDetailsModel.activityType) {
      case 'arrival':
        this.addArrival.saveForm();
        break;
      case 'loaded':
        this.addLoaded.saveForm();
        break;
      case 'unloaded':
        this.addUnloaded.saveForm();
        break;
      case 'arrivalandunloaded':
        this.saveArrivalAndUnloaded();
        break;
      case 'arrivalandloaded':
        this.saveArrivalAndLoaded();
        break;
      default:
        break;
    }
  }
  frameArrivalAndLoadedRequest(arrivalReq, loadedReq) {
    return {
      arrivalCheckCallDetails: arrivalReq,
      loadedUnloadedCheckCallDetails: loadedReq
    };
  }
  handleError(error) {
    this.activityLogDetailsModel.isArrivalLoadUnloadLoading = false;
    if (error && error.status === 500) {
      this.toastMessage.add({
        severity: 'error',
        summary: 'Server Error',
        detail: ErrorUtils.getErrorMessage(error.status)
      });
    } else if (error && error.error && error.error.errors) {
      this.handleEmptyError(error);
    }
  }
  handleEmptyError(error) {
    if (error.error.errors.length === 1 && !error.error.errors[0].errorMessage) {
      this.toastMessage.add({
        severity: 'error',
        summary: 'Server Error',
        detail: ErrorUtils.getErrorMessage(500)
      });
    } else {
      this.arrivalDevationType(error.error.errors);
      this.findFormGroup(error.error.errors);
    }
  }
  navigateToListPage(toastHeader: string) {
    ActivityLogUtils.successMessage(this.toastMessage, toastHeader, 'added');
    timer(ActivityLogModel.addSaveTimer).subscribe(() => {
      if (this.activityLogDetailsModel.isTracking) {
        this.router.navigate([this.trackingDetailsPath], { queryParams: this.localStorageService.getItem('TrackingDetails', 'param') });
      } else if (this.activityLogDetailsModel.checkCallNavigation) {
        this.router.navigate([this.checkCallPath],
          {
            queryParams: {
              fromCheckCall: 'true'
            }
          });
      } else {
        this.router.navigate([this.loadDetailsPath, this.activityLogDetailsModel.loadNumber],
          { queryParams: { index: 2 } });
      }
    });
  }
  loadStopInformation(stopDetails) {
    this.activityLogDetailsModel.stopInformation = stopDetails;
  }
  findFormGroup(error) {
    const arrivalModel = this.addArrival.addArrivalModel;
    let loadedUnloadedFormGroup;
    if (this.activityLogDetailsModel.activityType === 'arrivalandunloaded') {
      loadedUnloadedFormGroup = this.addUnloaded.activityLogUnloadedAddModel.addUnloadedForm;
    } else if (this.activityLogDetailsModel.activityType === 'arrivalandloaded') {
      loadedUnloadedFormGroup = this.addLoaded.activityLogLoadedAddModel.addLoadedForm;
    }
    ActivityLogUtils.checkDeviationMandatoryFields(arrivalModel, 'addArrivalForm', error);
    ActivityLogUtils.checkRuleValidationError(error, loadedUnloadedFormGroup,
      this.arrivalDeviationType, this.changeDetector);
  }
  getTrackingDetailsQueryParam(): TrackingDetailsParam {
    const paramDetails = this.localStorageService.getItem('TrackingDetails', 'param');
    this.activityLogDetailsModel.trackingDetailsParam = {
      driverId: this.queryParamNullCheck(paramDetails, 'driverId'),
      equipmentId: this.queryParamNullCheck(paramDetails, 'equipmentId'),
      loadNumber: this.queryParamNullCheck(paramDetails, '.loadNumber'),
      equipmentNumber: this.queryParamNullCheck(paramDetails, 'equipmentNumber'),
      index: +this.localStorageService.getSessionItem('tabIndex')
    };
    return this.activityLogDetailsModel.trackingDetailsParam;
  }
  queryParamNullCheck(queryParam: TrackingDetailsParam, paramName: string): number {
    return queryParam && queryParam[paramName] ? queryParam[paramName] : '';
  }
  checkErrorWarningMessageDisplay() {
    let isError = false;
    if (this.activityLogDetailsModel.errorMessage.length > 0 || this.activityLogDetailsModel.warningMessage.length > 0) {
      isError = true;
      this.appSharedDataService.saveData(isError);
    } else {
      this.appSharedDataService.saveData(isError);
    }
  }

  onRemove() {
    this.activityLogDetailsModel.removeDisplayDialog = true;
  }
  onCancelPopup() {
    this.activityLogDetailsModel.removeDisplayDialog = false;
  }

  onRemoveConfirm() {
    const checkCallID = [];
    const activityType = this.activityLogDetailsModel.activityType.charAt(0).toUpperCase() +
      this.activityLogDetailsModel.activityType.substr(1);
    checkCallID.push(this.activityLogDetailsModel.checkCallId);
    this.activityLogService.getLoadRemove(checkCallID)
      .pipe(takeWhile(() => this.activityLogDetailsModel.canSubscribe),
      )
      .subscribe((data: any) => {
        timer(3000).subscribe((_: any) => {
          this.toastMessage.add({
            severity: 'success',
            summary: 'Success',
            detail: `${activityType} event has been removed successfully`
          });
          this.onBack();
        });

        this.changeDetector.detectChanges();
      }, (error: Error) => {
        if (error['status'] === 409) {
          this.toastMessage.clear();
          this.toastMessage.add({
            severity: 'error',
            summary: '',
            detail: ''
          });
        }
      });

  }
  setScrollToTop() {
    const contentContainer = window.document.querySelector('.main') || window;
    contentContainer.scrollTo(0, 0);
  }
  updateLocation(equipmentLocationInfo: UpdateLocationHeader) {
    this.activityLogDetailsModel.isLocationUpdate = equipmentLocationInfo.hasLocation;
    this.activityLogDetailsModel.currentTrailerValue = equipmentLocationInfo;
    this.activityLogDetailsModel.breadCrumb.push({
      label: 'Update Location',
      routerLink: ['/activityLog']
    });
    this.setLocalStoreItems();
    this.changeDetector.detectChanges();
  }
  getEquipmentInfo(equipmentDetails: EquipmentGroupItem[]) {
    this.activityLogDetailsModel.equipmentList = equipmentDetails;
  }
  checkTelematicsPickup(telematicsPickup: boolean) {
    this.activityLogDetailsModel.hasTelematicsPickup = telematicsPickup;
  }
  telematicsEquipment(equipDetail: TelematicsEquipment) {
    this.activityLogDetailsModel.telematicsEquipmentDetails = equipDetail;
  }
  setLocalStoreItems() {
    if (this.activityLogDetailsModel.activityType === 'loaded') {
      this.loadedLocalStore();
    } else if (this.activityLogDetailsModel.activityType === 'arrivalandloaded') {
      const arrivalDetails = this.getArrivalFormValue();
      this.localStorageService.setItem('arrivalForm', 'values', arrivalDetails);
      const loadedFormValue = this.frameLoadedUnloadedValue(this.addLoaded.activityLogLoadedAddModel,
        this.addLoaded.activityLogLoadedAddModel.addLoadedForm.value);
      this.localStorageService.setItem('loadedForm', 'values', loadedFormValue);
      this.localStorageService.setItem('pairedEquipment', 'values', this.addLoaded.activityLogLoadedAddModel.equipmentPaired);
    } else if (this.activityLogDetailsModel.activityType === 'unloaded') {
      this.unloadedLocalStore();
    } else if (this.activityLogDetailsModel.activityType === 'arrivalandunloaded') {
      const arrivalDetails = this.getArrivalFormValue();
      this.localStorageService.setItem('arrivalForm', 'values', arrivalDetails);
      const unLoadedFormValue = this.frameLoadedUnloadedValue(this.addUnloaded.activityLogUnloadedAddModel,
        this.addUnloaded.activityLogUnloadedAddModel.addUnloadedForm.value);
      this.localStorageService.setItem('unloadedForm', 'values', unLoadedFormValue);
      this.localStorageService.setItem('unloadedpairedEquipment', 'values', this.addUnloaded.activityLogUnloadedAddModel.equipmentPaired);
    }
  }
  loadedLocalStore() {
    if (this.activityLogDetailsModel.isCheckCallTracking) {
      const loadedFormValue = this.frameLoadedUnloadedValue(this.addLoaded.activityLogLoadedEditModel,
        this.addLoaded.activityLogLoadedEditModel.addLoadedForm.value);
      this.localStorageService.setItem('checkcallloadedForm', 'values', loadedFormValue);
      this.localStorageService.setItem('checkcallpairedEquipment', 'values', this.addLoaded.activityLogLoadedEditModel.equipmentPaired);
    } else {
      const loadedFormValue = this.frameLoadedUnloadedValue(this.addLoaded.activityLogLoadedAddModel,
        this.addLoaded.activityLogLoadedAddModel.addLoadedForm.value);
      this.localStorageService.setItem('loadedForm', 'values', loadedFormValue);
      this.localStorageService.setItem('pairedEquipment', 'values', this.addLoaded.activityLogLoadedAddModel.equipmentPaired);
    }
  }
  unloadedLocalStore() {
    if (this.activityLogDetailsModel.isCheckCallTracking) {
      const unLoadedFormValue = this.frameLoadedUnloadedValue(this.addUnloaded.activityLogUnloadedEditModel,
        this.addUnloaded.activityLogUnloadedEditModel.editUnloadedForm.value);
      this.localStorageService.setItem('unloadedForm', 'values', unLoadedFormValue);
      this.localStorageService.setItem('unloadedpairedEquipment', 'values', this.addUnloaded.
      activityLogUnloadedEditModel.equipmentPaired);
    } else {
      const unLoadedFormValue = this.frameLoadedUnloadedValue(this.addUnloaded.activityLogUnloadedAddModel,
        this.addUnloaded.activityLogUnloadedAddModel.addUnloadedForm.value);
      this.localStorageService.setItem('unloadedForm', 'values', unLoadedFormValue);
      this.localStorageService.setItem('unloadedpairedEquipment', 'values', this.addUnloaded.activityLogUnloadedAddModel.equipmentPaired);
    }
  }
  frameLoadedUnloadedValue(modelValue, formValue) {
    return {
      formDetails: formValue,
      trailerSelected: modelValue.trailerOrContainerSelected,
      departureTime: modelValue.departureTimestamp
    };
  }
  getArrivalFormValue() {
    return {
      arrivalForm: this.addArrival.addArrivalModel.addArrivalForm.value,
      arrivalDate: this.addArrival.addArrivalModel.arrivalDate,
      arrivalTime: this.addArrival.addArrivalModel.arrivalTime,
      reason: this.addArrival.addArrivalModel.arrivalTimeDeviationReasonCategory,
      timeZone: this.addArrival.addArrivalModel.timeZone
    };
  }
  clearLocalStoreItem() {
    this.localStorageService.clearItem('arrivalForm', 'values');
    this.localStorageService.clearItem('loadedForm', 'values');
    this.localStorageService.clearItem('pairedEquipment', 'values');
    this.localStorageService.clearItem('unloadedForm', 'values');
    this.localStorageService.clearItem('unloadedpairedEquipment', 'values');
    this.localStorageService.clearItem('checkcallloadedForm', 'values');
    this.localStorageService.clearItem('checkcallpairedEquipment', 'values');
  }
}
