import { LocationDetails, LocationFormat } from '../../../features/model/location-address.interface';
import { AddArrivalRequestObj } from '../activity-log-arrival/activity-log-arrival-add/model/activity-log-arrival-add.interface';
import { AddLoadedRequest } from '../activity-log-loaded/activity-log-loaded-add/model/activity-log-loaded-add.interface';

export interface OperationalPlanStopDetails {
    operationalPlanStopSequenceNumber: number;
    operationalPlanStopReasonCode: string;
    operationalPlanStopReasonCodeDescription: string;
    locationDetails: LocationDetails;
    appointmentStartTimestamp: string;
    appointmentEndTimestamp: string;
    stopSequenceDescription: string;
    operationalPlanStopId?: number;
}
export interface ViewActivityLogDetails {
    operationalPlanCheckCallId?: number;
    operationalPlanStopId: number;
    operationalPlanId: number;
    arrivalDateTime?: string;
    operationalPlanStopDetails: OperationalPlanStopDetails;
    lastUpdateProgramName: string;
    lastUpdatedUserId: string;
    lastUpdatedOn?: string;
    loadedTimestamp: string;
    proNumber: number;
    weight: WeightDetail;
    volume: VolumeDetail;
    temperature: TemperatureDetail;
    loadedBy?: string;
    loadedType?: string;
    unloadedBy?: string;
    unloadedType?: string;
    unloadedTimestamp?: string;
    count: number;
    countedBy: string;
    sealNumber: string;
    bolNumber: string;
    poNumbers: string[];
    shipperIdentificationNumber: string;
    receiverStateId: number;
    receiverStateName: string;
    hazmatIndicator: string;
    comments: string;
    lastUpdatedTimestamp?: string;
    departureTimestamp?: string;
    pickupEquipmentDetails: PickUpDetails[];
    dropEquipmentDetails: PickUpDetails[];
    stopServicesTypeCodes: string[];
    stopServices: string[];
    arrivalTimeDeviationDetails?: ArrivalTimeDeviationDetails;
    unitOfWeightMeasurement?: string;
    poNumber?: string;
    checkCallSource?: string;
}
export interface WeightDetail {
    weight: number;
    unitOfWeightMeasurement: string;
}
export interface VolumeDetail {
    volume: number;
    unitOfVolumeMeasurement: string;
}
export interface TemperatureDetail {
    temperature: number;
    unitOfTemperatureMeasurement: string;
}
export interface PickUpDetails {
    equipmentId: number;
    equipmentType: string;
    equipmentPrefix: string;
    equipmentNumber: string;
    oldTruckId?: number;
    equipmentCategory?: string;
}
export interface AppointmentDetails {
    appointmentStartTimestamp: string;
    appointmentEndTimestamp: string;
}
export interface SplitViewDetails {
    location: LocationFormat;
    stopReasonCode: string;
    lastUpdatedBy: string;
    lastUpdatedOn: string;
    appointment: string;
    arrivalTime: string;
    arrivalStatus: string;
    comments: string;
    stopSequenceDescription: string;
}
export interface CheckCallInputs {
    isCheckCallTracking: boolean;
    checkCallNavigation: boolean;
    isTracking: boolean;
}
export interface ArrivalTimeDeviationDetails {
    arrivalTimeDeviationType: string;
    arrivalTimeDeviationReason: string;
    arrivalTimeDeviationReasonCategory: string;
    arrivalDeviationResponsibilityPartyType: string;
    contactID: string;
    contactName: string;
    contactText: string;
}
export interface Page {
    size: number;
    totalElements: number;
    totalPages: number;
    number: number;
}

export interface Links2 {
    self: Self2;
    profile: Self;
}

export interface Self2 {
    href: string;
    templated: boolean;
}
export interface Self {
    href: string;
}
export interface StopDetails {
    stopId: number;
    stopSequenceNumber: number;
    destinationHeader?: string;
}
export interface ErrorList {
    fieldErrorFlag?: boolean;
    errorMessage: string;
    errorType: string;
    fieldName?: any;
    code?: string;
    errorSeverity: string;
}
export interface TelematicsEquipment {
    equipmentId: number;
    equipmentNumber: string;
    equipmentCategory: string;
    equipmentPrefix: string;
}
export interface DropEquipment {
    equipmentAssociationId?: any;
    equipmentId: number;
    equipmentNumber: string;
    equipmentPrefix: string;
    stack: boolean;
    sequenceNumber?: any;
    equipmentCategory: string;
    businessUnit?: any;
    operationalGroupCode?: any;
    operationalGroupDescription?: any;
    equipmentType: string;
    equipmentStatus: string;
    trailingEquipmentStatus: string;
    length: string;
    width: string;
    height: string;
    equipmentMaintenanceStatus: string;
    equipmentMissing?: any;
    equipmentAssociationGroupId?: any;
    oldEquipmentAssociationGroupId?: any;
    removeEquipment?: any;
    locationDetails?: any;
    stackedEquipmentList?: any;
    links: any[];
}
export interface FinalDestination {
    stateID: number;
    stateCode: string;
    stateName: string;
}

export interface ArrivalLoadedUnloaded {
    arrivalCheckCallDetails: any;
    loadedUnloadedCheckCallDetails: any;
}
export interface ArrivalLoaded {
    arrivalCheckCallDetails: AddArrivalRequestObj;
    loadedUnloadedCheckCallDetails: AddLoadedRequest;
}

export interface DropEquipmentDetail {
    equipmentId: number;
    equipmentType: string;
    equipmentPrefix: string;
    equipmentNumber: string;
    stackedEquipmentList?: any;
    equipmentCategory: string;
}
export interface ViewDispatchDetails {
    dispatchTimeStamp: string;
    loadNumber: string;
    loadType: string;
    emptyMiles?: number;
    loadedMiles?: number;
    origin: OriginDestination;
    destination: OriginDestination;
    intermediateStops: number;
    pickupEquipments?: any;
    dropEquipments?: any;
    payRouteDetails: PayRouteDetails;
}
export interface PayRouteDetails {
    operationalPlanPayRouteSegmentId: number;
    originCityId: number;
    originCityName: string;
    originStateCode: string;
    destinationCityId: number;
    destinationCityName: string;
    destinationStateCode: string;
    payRouteSegmentStatusCode: string;
    segmentSequenceNumber: number;
    originOperationalPlanStopId: number;
    destinationOperationalPlanStopId: number;
}
export interface OriginDestination {
    locationDetails: LocationDetails;
    appointmentStartTimeStamp: string;
    appointmentEndTimeStamp: string;
}

export interface EquipmentGroup {
    equipmentNumber: string;
    equipmentType: string;
    equipmentId: number;
    equipmentPrefix?: string;
}
export interface TrackingDetailsParam {
    driverId?: number | string;
    equipmentId: number;
    loadNumber?: number;
    equipmentNumber?: number;
    index?: number;
    view?: string;
}
export interface CityDTO {
    cityId: number;
    cityName: string;
    stateCode: string;
    countryCode: string;
}

export interface ResourceOverview {
    driverId: string;
    equipmentId: number;
    resourceStatus: string;
    truck: string;
    trailers?: any;
    plannedLoads: number;
    fleet: string;
    board: string;
    operationalStatus: string;
    emptyMiles: number;
    drivingHoursRemainingAtReadyTime: number;
    readyTime: string;
    readyLocation: ReadyLocation;
    estimatedTimeOfCompletion: string;
    estimatedTimeOfArrival: string;
    timeOff?: any;
    timeOfLocation?: any;
    timeOffType?: any;
    timeOffDate?: any;
    numberOfDays?: any;
    marketingArea?: any;
    utilization: string;
    serviceFailures?: any;
    type: string[];
    payType: string[];
    certifications: any[];
    aobrStatusDurationHours: number;
    aobrStatus?: any;
    driveHours: number;
    workHours: number;
    onDutyHours: number;
    aobrLastUpdated: number;
    scheduleStart?: any;
    previousSegementStatus?: any;
    alphaCode: string;
    firstName: string;
    middleName: string;
    lastName: string;
    resourceName: string;
    preferredName: string;
    expirationDate: string;
    physicalExpirationDate: string;
    dotReviewDate: string;
    driverStatus: string;
    emptyMilesLimit?: any;
    firstStopLocationId: number;
    lastStopLocationId: number;
    firstStopLattitude: number;
    firstStopLongitude: number;
    lastStopLattitude: number;
    lastStopLongitude: number;
    operationalPlanId: number;
    endorsements: Endorsement[];
    originCityState: string;
    destinationCityState: string;
    suggestedBreak: string;
    fleetManager: FleetManager;
    fleetCode: string;
    fleetName: string;
    safetyTerminal: string;
    totalLoadsHauledForTheWeek: string;
    totalMilesHauledForTheWeek: string;
    boardCode: string;
    recapHours: number[];
    lastLocation: string;
    currentLocation: string;
    lastLocationUpdatedTimeStamp: string;
    latitude: string;
    longitude: string;
    driverPlannedLoads?: any;
    truckPlannedLoads: number;
    maintenanceTerminal: string;
    maintenanceTerminalDescription: string;
    nextServiceDateandTime: string;
    nextServiceType: string;
    serviceAppointmentStatus: string;
    milesTillNextService: number;
    secondSeatDriverDetails?: any;
    currentLoadNumber: string;
    utilizationStatus: any[];
    contactDetails: ContactDetails;
}

export interface ContactDetails {
    homePhone: string;
    workPhone?: any;
    email?: any;
}

export interface FleetManager {
    emplId: string;
    userId: string;
    firstName: string;
    middleName: string;
    lastName: string;
    prefName: string;
    personType: string;
    personSubType: string;
    isDriver: string;
    status: string;
    positionNbr: string;
    positionDescr: string;
    managerEmplId: string;
    managerName: string;
    departmentCode: string;
    costCenterID: string;
    businessUnit: string;
    jobCode: string;
    jobTitle: string;
    jobGroup: string;
    locationCode: string;
    locationDesc: string;
    phone: string;
    extenstion: string;
    email: string;
}

export interface Endorsement {
    qualifierClass: string;
    qualifierType: string;
    expirationDate: string;
}

export interface ReadyLocation {
    id: number;
    locationName: string;
    locationCode: string;
    addressLine1: string;
    addressLine2: string;
    state: string;
    city: string;
    zipcode: string;
    country: string;
    latitude: number;
    longitude: number;
    locationContacts: any[];
}
export interface UpdateLocationHeader {
    equipmentCategory: string;
    equipmentNumber: string;
    equipmentId: number;
    equipmentPrefix ?: string;
    hasLocation?: boolean;
}
