import { MenuItem } from 'primeng/api';
import { LoadOverview } from '../../../features/load-details/load-details-overview/model/load-overview.interface';
import { ArrivalDeviationRequest } from '../activity-log-arrival/activity-log-arrival-add/model/activity-log-arrival-add.interface';

import {
    ViewActivityLogDetails, SplitViewDetails, ErrorList, ArrivalLoadedUnloaded, FinalDestination,
    ViewDispatchDetails, AppointmentDetails, CheckCallInputs, ResourceOverview, UpdateLocationHeader,
    TrackingDetailsParam, TelematicsEquipment
} from './activity-log.interface';
import { ResourceDetails } from '../../../features/fleet-planning/planby-resource/resource-overview/model/resource-overview.interface';
import { OperationPlanStopDTO } from '../../load-planning/load-tasks/driver-exception/view-details/model/view-details.interface';
import { LocationDetails } from '../../model/location-address.interface';
import { SecureModel } from '../../../shared/directives/models/secure.model';
import { AppConfig } from '../../../../config/app.config';
import { EquipmentGroupItem } from '../../tracking-details/model/tracking-details.interface';

export class ActivityLogModel {
    public static get addSaveTimer(): number { return 2000; }
    public static get editSaveTimer(): number { return 2300; }
    breadCrumb: MenuItem[];
    loadNumber: number;
    canSubscribe: boolean;
    loading: boolean;
    loadOverviewDetails: LoadOverview;
    stopStatus: string;
    isLoading: boolean;
    arrivalRequestObj: ArrivalDeviationRequest;
    checkCallId: number;
    arrivalCallRowDetails: any;
    appointmentDetails: string;
    operationalPlanCheckCallId: number;
    splitViewDetailsData: SplitViewDetails;
    viewActivityLogDetails: ViewActivityLogDetails;
    activityType: string;
    index: any;
    activityLogDetails: ViewActivityLogDetails;
    departureTime: string;
    lastUpdatedOn: string;
    view: boolean;
    isEdit: boolean;
    activityLogHeader: string;
    dispatchDetails: ViewDispatchDetails;
    isOverrideWarning: boolean;
    subHeader: string;
    showError: boolean;
    errorMessage: ErrorList[];
    warningMessage: ErrorList[];
    isTracking: boolean;
    isCheckCallTracking: boolean;
    onlyTrackingDetails: boolean;
    arrivalLoadedUnloadedRequest: ArrivalLoadedUnloaded;
    finalDestination: FinalDestination;
    resourceId: string;
    driverImg: string;
    resourceType: string;
    isSectionLoading: boolean;
    resourceDetails: ResourceDetails;
    resourceDetailsValues: ResourceDetails;
    resourceIdVal: string;
    resourceTypeVal: string;
    stopInformation: OperationPlanStopDTO;
    originAppointmentTime: AppointmentDetails;
    destinationAppointmentTime: AppointmentDetails;
    originLocation: LocationDetails;
    destinationLocation: LocationDetails;
    dispatchTimeStamp: string;
    edit: boolean;
    driverId: string;
    truck: string;
    driverType: string;
    truckType: string;
    formattedResourceName: string;
    fromActivityLog: boolean;
    editFromTracking: boolean;
    checkCallNavigation: boolean;
    noCheckCall: boolean;
    fieldErrorList: string[];
    removeDisplayDialog: boolean;
    removeButton: SecureModel;
    saveButton: SecureModel;
    appConfig;
    isAddCheckCallLoaded: boolean;
    stopID: number;
    timeZone: string;
    checkCallInputs: CheckCallInputs;
    isArrivalLoadUnloadLoading: boolean;
    resourceOverview: ResourceOverview;
    isResourceLoading: boolean;
    driverIdComments: string;
    equipmentId: string;
    isLocationUpdate: boolean;
    currentTrailerValue: UpdateLocationHeader;
    equipmentList: EquipmentGroupItem[];
    trackingDetailsParam: TrackingDetailsParam;
    isReload: boolean;
    hasTelematicsPickup: boolean;
    telematicsEquipmentDetails: TelematicsEquipment;

    constructor() {
        this.removeDisplayDialog = false;
        this.canSubscribe = true;
        this.view = false;
        this.splitViewDetailsData = {
            location: null,
            stopReasonCode: '',
            lastUpdatedBy: '',
            lastUpdatedOn: '',
            appointment: '',
            arrivalTime: '',
            arrivalStatus: '',
            comments: '',
            stopSequenceDescription: ''
        };
        this.activityLogHeader = '';
        this.isOverrideWarning = false;
        this.subHeader = '';
        this.showError = false;
        this.errorMessage = [];
        this.warningMessage = [];
        this.arrivalLoadedUnloadedRequest = {
            arrivalCheckCallDetails: {},
            loadedUnloadedCheckCallDetails: {}
        };
        this.isLoading = false;
        this.loading = false;
        this.isSectionLoading = false;
        this.stopInformation = null;
        this.edit = false;
        this.driverType = 'Driver';
        this.truckType = 'Truck';
        this.fieldErrorList = [];
        this.appConfig = AppConfig.getConfig();
        this.removeButton = { url: this.appConfig.api.activitylog.getRemoveLoadList, operation: 'C' };
        this.saveButton = { url: this.appConfig.api.activitylog.addArrival, operation: 'C' };
        this.isAddCheckCallLoaded = false;
        this.isArrivalLoadUnloadLoading = false;
        this.resourceOverview = null;
        this.isResourceLoading = false;
    }
}
