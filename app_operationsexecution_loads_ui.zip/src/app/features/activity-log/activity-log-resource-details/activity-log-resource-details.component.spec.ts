import { ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TooltipModule } from 'primeng/tooltip';
import { JbhLoaderModule } from '../../../shared/jbh-loader/jbh-loader.module';
import { PipesModule } from './../../../shared/pipes/pipes.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AppConfigService } from '../../../shared/service/app-config.service';

import { ActivityLogResourceDetailsComponent } from './activity-log-resource-details.component';
import { GlobalPopupsModule } from '../../../shared/global-popups/global-popups.module';
import { AppSharedDataService } from '../../../shared/jbh-app-services/app-shared-data.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { StompConnectionService } from '../../../shared/stomp-connection/stomp-connection.service';
import { WebSocketService } from '../../../shared/jbh-app-services/web-socket.service';
import { UserService } from '../../../shared/jbh-esa';
import { AssetCommunicationModule } from './../../sidebar/asset-communication/asset-communication.module';
import { of } from 'rxjs/internal/observable/of';
import { ActivityLogService } from '../services/activity-log.service';

describe('ActivityLogResourceDetailsComponent', () => {
  let component: ActivityLogResourceDetailsComponent;
  let fixture: ComponentFixture<ActivityLogResourceDetailsComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, JbhLoaderModule, TooltipModule,
        PipesModule, NoopAnimationsModule, GlobalPopupsModule, RouterTestingModule, AssetCommunicationModule],
      declarations: [ ActivityLogResourceDetailsComponent ],
      providers: [AppConfigService, AppSharedDataService, UserService, StompConnectionService, WebSocketService,
        MessageService],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogResourceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('resourceId has been set', () => {
    component.driverEquipId = '123';
    expect(component.activityLogModel.resourceId).toBeDefined();
  });
  it('setUrlData have been called', () => {
    const appSharedDataService: AppSharedDataService = TestBed.get(AppSharedDataService);
    spyOn(appSharedDataService, 'getData').and.returnValue(of('value'));
    component.setUrlData();
    expect(appSharedDataService.getData).toHaveBeenCalled();
  });
  it('getResourceImg have been called', () => {
    component.activityLogModel.resourceId = '123';
    const activityLogService: ActivityLogService = TestBed.get(ActivityLogService);
    spyOn(activityLogService, 'getResourceImages').and.callThrough();
    component.getResourceImg();
    expect(activityLogService.getResourceImages).toHaveBeenCalled();
  });
});
