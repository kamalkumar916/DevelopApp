import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, Input, ViewChild, ElementRef } from '@angular/core';
import { takeWhile } from 'rxjs/operators';

import { ActivityLogService } from './../services/activity-log.service';
import { ActivityLogModel } from './../models/activity-log.model';
import { ResourceDetails } from '../../../features/fleet-planning/planby-resource/resource-overview/model/resource-overview.interface';
import { AppSharedDataService } from '../../../shared/jbh-app-services/app-shared-data.service';
import { Utils } from '../../../shared/jbh-app-services/utils';
import { ResourceOverview } from '../models/activity-log.interface';
@Component({
  selector: 'app-activity-log-resource-details',
  templateUrl: './activity-log-resource-details.component.html',
  styleUrls: ['./activity-log-resource-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogResourceDetailsComponent implements OnInit {
  @ViewChild('driverProfile') driverIcon: ElementRef;
  activityLogModel: ActivityLogModel;
  @Input() set driverEquipId(resourceId: any) {
    if (resourceId) {
      this.activityLogModel.resourceId = resourceId;
    }
  }

  @Input() set resourceDetails(resourceDetails: ResourceOverview) {
    if (resourceDetails) {
      this.getResourceImg();
      this.activityLogModel.resourceOverview = resourceDetails;
      this.activityLogModel.driverId = this.activityLogModel.resourceOverview.alphaCode;
      this.activityLogModel.truck = this.activityLogModel.resourceOverview.truck;
      this.activityLogModel.formattedResourceName = Utils.standardDriverNameFormat(this.activityLogModel.resourceOverview);
    }
  }
  constructor(private readonly activityLogService: ActivityLogService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly appSharedDataService: AppSharedDataService) {
    this.activityLogModel = new ActivityLogModel();
  }

  ngOnInit() {
  }

  getResourceImg() {
    if (this.activityLogModel.resourceId) {
      this.activityLogService.getResourceImages(this.activityLogModel.resourceId)
        .pipe(takeWhile(() => this.activityLogModel.canSubscribe))
        .subscribe((data: any) => {
          if (data.length !== 0 && data[0].thumbPhoto) {
            this.activityLogModel.driverImg = data[0].thumbPhoto;
          }
          this.changeDetector.detectChanges();
        });
    }
  }

  setUrlData() {
    let urlData;
    this.appSharedDataService.getData()
      .subscribe((data: any) => {
        if (data) {
          urlData = data;
        }
      });
    return urlData;
  }
  checkValue(value) {
    return value ? value : '';
  }
}
