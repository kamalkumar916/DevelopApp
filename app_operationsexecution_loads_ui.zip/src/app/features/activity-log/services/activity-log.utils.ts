import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TitleCasePipe } from '@angular/common';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';

import { find, filter } from 'lodash';

import { DateUtils } from '../../../shared/jbh-app-services/date-utils';
import {
  ViewActivityLogDetails, AppointmentDetails, VolumeDetail,
  TemperatureDetail, WeightDetail, ResourceOverview
} from '../models/activity-log.interface';
import { LocationDetails, LocationFormat } from '../../../features/model/location-address.interface';
import { ArrivalTimeDeviationDetails } from '../activity-log-arrival/activity-log-arrival-add/model/activity-log-arrival-add.interface';
import { AddressDetailsPipe } from '../../../shared/pipes/address-details.pipe';
import { FetchDetails, DriverImageDetails } from '../../model/driver-details.interface';
import { ListItem } from '../../model/common.interface';
import { ErrorUtils } from '../../../shared/jbh-app-services/error-utils';
import { AppointmentDateFormatterPipe } from '../../../shared/pipes/appointment-date-formatter.pipe';

export class ActivityLogUtils {
  static getLocationDetails(locObj: LocationDetails): any {
    if (locObj) {
      return this.formattedLocationDetails(locObj) ? this.formattedLocationDetails(locObj) : '---';
    } else {
      return '---';
    }
  }
  static formattedLocationDetails(locObj: LocationDetails): LocationFormat {
    const locationAddressDetails = { locationDetails: '', addressDetails: '', addressZipDetails: '' };
    if (locObj) {
      locationAddressDetails['locationDetails'] = new AddressDetailsPipe().getLocationNameCodeDetails(locObj);
      if (locObj['address']) {
        locationAddressDetails['addressDetails'] += new AddressDetailsPipe().locationAddressOneAndTwoDetails(locObj['address']);
        locationAddressDetails['addressZipDetails'] += new AddressDetailsPipe().getAddressZipDetails(locObj);
      }
    }
    return locationAddressDetails;
  }
  static getAppointmentDate(appointmentDetails: AppointmentDetails): string {
    const startTime = DateUtils.getDateTime(appointmentDetails.appointmentStartTimestamp);
    const endTime = DateUtils.getDateTime(appointmentDetails.appointmentStartTimestamp);
    return (startTime && endTime) ? `${startTime} to ${endTime} CST` : `${startTime} CST`;
  }
  static getArrivedDate(arrivalDate: string, timeZone = ''): string {
    if (arrivalDate) {
    const arrivalDatetime = new Date(arrivalDate);
    return `${this.getMonthName(arrivalDatetime.getMonth())} ${arrivalDatetime.getDate()},
     ${this.getDayName(arrivalDatetime.getDay())} ${this.formatDateTimeZone(arrivalDatetime, timeZone)}`;
    } else {
      return '';
    }
  }
  static getMonthName(monthIndex: number): string {
    const monthNames =
      ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return monthNames[monthIndex];
  }
  static getDayName(dayIndex: number): string {
    const dayNames =
      ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return dayNames[dayIndex];
  }
  static formatDateTimeZone(date: Date, timeZone = ''): string {
    return `${momentTimezone.tz(date, timeZone).format('hh:mm A z')}`;
  }
  static checkArrivalStatus(arrivalCallDetails: ViewActivityLogDetails): string {
    let loadedUnloadedTime;
    let appointmentStartTime;
    let appointmentEndTime;
    if (arrivalCallDetails.operationalPlanStopDetails) {
      appointmentStartTime = new Date(DateUtils.getDateTime(
        arrivalCallDetails.operationalPlanStopDetails.appointmentStartTimestamp)).valueOf();
      appointmentEndTime = new Date(DateUtils.getDateTime(
        arrivalCallDetails.operationalPlanStopDetails.appointmentEndTimestamp)).valueOf();
    }
    if (arrivalCallDetails.loadedTimestamp) {
      loadedUnloadedTime = this.getLoadedUnloadedTimeStamp(arrivalCallDetails.loadedTimestamp);
    } else if (arrivalCallDetails.unloadedTimestamp) {
      loadedUnloadedTime = this.getLoadedUnloadedTimeStamp(arrivalCallDetails.unloadedTimestamp);
    } else {
      loadedUnloadedTime = null;
    }
    if (loadedUnloadedTime && loadedUnloadedTime >= appointmentStartTime && loadedUnloadedTime <= appointmentEndTime) {
      return 'OnTime';
    } else if (loadedUnloadedTime < appointmentStartTime) {
      return 'Early';
    } else if (loadedUnloadedTime > appointmentStartTime) {
      return 'Late';
    } else {
      return null;
    }
  }
  static getLoadedUnloadedTimeStamp(loadedUnloadedTimeStamp: string): number {
    let loadedUnloadedTime;
    if (loadedUnloadedTimeStamp.length >= 19) {
      const timeStamp = `${loadedUnloadedTimeStamp.substr(0, 19)}Z`;
      loadedUnloadedTime = new Date(DateUtils.getDateTime(timeStamp)).valueOf();
    }
    return loadedUnloadedTime;
  }
  static checkMandatoryFields(formGroupName) {
    if (!formGroupName.controls.arrivalDate.value) {
      formGroupName.controls['arrivalDate'].setErrors({ 'invalid': true });
    }
    if (!formGroupName.controls.arrivalTime.value) {
      formGroupName.controls['arrivalTime'].setErrors({ 'invalid': true });
    }
  }
  static requiredFieldError(errorEmitter, changeDetector) {
    errorEmitter.emit([{
      errorMessage: `Check call has missing required fields`,
      errorType: 'Form Validation',
      errorSeverity: 'ERROR'
    }]);
    changeDetector.detectChanges();
  }
  static arrivalError(errorObj, toastMessage) {
    toastMessage.clear();
    if (errorObj['errors']) {
      for (const error of errorObj.errors) {
        if (error['errorSeverity'].toLowerCase() === 'error') {
          toastMessage.add({
            severity: 'error',
            summary: 'Error',
            detail: error.errorMessage
          });
        }
      }
    }
  }
  static checkForReasonResponsibility(arrivalModel, formGroupName) {
    if (arrivalModel.arrivalDeviationType.toLowerCase() === 'late' || arrivalModel.arrivalDeviationType.toLowerCase() === 'early') {
      if (arrivalModel.arrivalDeviationType.toLowerCase() === 'late') {
        this.checkMandatoryReasonResponsibility(arrivalModel, formGroupName, 'arrivalLate', 'lateReasonResponsibility');
        this.checkMandatoryReasonResponsibility(arrivalModel, formGroupName, 'arrivalLate', 'lateReasonCategory');
        this.checkMandatoryReasonResponsibility(arrivalModel, formGroupName, 'arrivalLate', 'lateReason');
      } else {
        this.checkMandatoryReasonResponsibility(arrivalModel, formGroupName, 'arrivalEarly', 'earlyReasonResponsibility');
        this.checkMandatoryReasonResponsibility(arrivalModel, formGroupName, 'arrivalEarly', 'earlyReasonCategory');
        this.checkMandatoryReasonResponsibility(arrivalModel, formGroupName, 'arrivalEarly', 'earlyReason');
      }
    }
  }
  static checkMandatoryReasonResponsibility(arrivalModel, formGroupName, arrivalLateOrEarly, formControlName) {
    if (!arrivalModel[formGroupName].controls[arrivalLateOrEarly].get(formControlName).value) {
      arrivalModel[formGroupName].controls[arrivalLateOrEarly].controls[formControlName].setErrors({ 'invalid': true });
    }
  }
  static setFormValue(editModel) {
    editModel.editArrivalForm.patchValue({
      arrivalDate: editModel.arrivalDate,
      arrivalTime: editModel.arrivalTime
    });
  }
  static setEarlyFormValue(editModel, category, reason, partyType, contact?) {
    editModel.editArrivalForm.controls.arrivalEarly.patchValue({
      earlyReasonCategory: category,
      earlyReason: reason,
      earlyReasonResponsibility: partyType,
      earlyReasonContact: editModel.contactName ? editModel.contactName : editModel.contactText
    });
  }
  static setLateFormValue(editModel, category, reason, partyType, contact?) {
    editModel.editArrivalForm.controls.arrivalLate.patchValue({
      lateReasonCategory: category,
      lateReason: reason,
      lateReasonResponsibility: partyType,
      lateReasonContact: editModel.contactName ? editModel.contactName : editModel.contactText
    });
  }
  static getContactText(arrivalForm, isFreeText, formControl): string {
    return (arrivalForm.controls[formControl].value && isFreeText) ?
      arrivalForm.controls[formControl].value : null;
  }
  static getContactID(arrivalForm, isFreeText, formControl): string {
    return (arrivalForm.controls[formControl].value && !isFreeText) ?
      arrivalForm.controls[formControl].value.emplId : null;
  }
  static frameArrivalDeviationRequest(isFreeText, arrivalDeviationType, arrivalForm): ArrivalTimeDeviationDetails {
    if (arrivalDeviationType === 'Late') {
      return {
        arrivalTimeDeviationType: arrivalDeviationType,
        arrivalTimeDeviationReason: (arrivalForm.arrivalLate.controls.lateReason.value) ?
          arrivalForm.arrivalLate.controls.lateReason.value.value : '',
        arrivalTimeDeviationReasonCategory: (arrivalForm.arrivalLate.controls.lateReasonCategory.value) ?
          arrivalForm.arrivalLate.controls.lateReasonCategory.value.value : '',
        arrivalDeviationResponsibilityPartyType: (arrivalForm.
          arrivalLate.controls.lateReasonResponsibility.value) ? arrivalForm.
            arrivalLate.controls.lateReasonResponsibility.value.value : '',
        contactText: this.getContactText(arrivalForm.arrivalLate, isFreeText, 'lateReasonContact'),
        contactID: this.getContactID(arrivalForm.arrivalLate, isFreeText, 'lateReasonContact')
      };
    } else {
      return {
        arrivalTimeDeviationType: arrivalDeviationType,
        arrivalTimeDeviationReason: (arrivalForm.arrivalEarly.controls.earlyReason.value) ?
          arrivalForm.arrivalEarly.controls.earlyReason.value.value : '',
        arrivalTimeDeviationReasonCategory: (arrivalForm.arrivalEarly.controls.earlyReasonCategory.value) ?
          arrivalForm.arrivalEarly.controls.earlyReasonCategory.value.value : '',
        arrivalDeviationResponsibilityPartyType: (arrivalForm.
          arrivalEarly.controls.earlyReasonResponsibility.value) ? arrivalForm.
            arrivalEarly.controls.earlyReasonResponsibility.value.value : '',
        contactText: this.getContactText(arrivalForm.arrivalEarly, isFreeText, 'earlyReasonContact'),
        contactID: this.getContactID(arrivalForm.arrivalEarly, isFreeText, 'earlyReasonContact')
      };
    }
  }
  static resetFormControls(arrivalModel, formGroupName, isReason = false) {
    let formControl;
    if (arrivalModel.arrivalDeviationType === 'Early') {
      formControl = isReason ? 'earlyReason' : 'earlyReasonContact';
      arrivalModel[formGroupName].controls.arrivalEarly.controls[formControl].reset();
    } else if (arrivalModel.arrivalDeviationType === 'Late') {
      formControl = isReason ? 'lateReason' : 'lateReasonContact';
      arrivalModel[formGroupName].controls.arrivalLate.controls[formControl].reset();
    }
  }
  static getDriverIds(resourceDetails: FetchDetails[]): string[] {
    return resourceDetails.map((item: FetchDetails) => {
      return item.userId;
    });
  }
  static imageDetails(data: DriverImageDetails[]): FetchDetails[] {
    return data.map((item: DriverImageDetails) => {
      return {
        preferedName: item.firstName,
        lastname: item.lastName,
        userId: item.userId,
        value: `${item.firstName} ${item.lastName} (${item.userId})`,
        profilePicture: (item['profilePicture']) ? `data:image/png;base64,${item['profilePicture']}` : null,
        noProfilePicture: `${item.firstName} ${item.lastName}`,
        emplId: item.personId
      };
    });
  }
  static formatDateValue(dateValue: Date) {
    return moment(new Date(dateValue)).format('YYYY-MM-DD');
  }
  static formatTimeValue(timeValue: Date) {
    return moment(new Date(timeValue)).format('H:mm');
  }
  static setDefaultUnits(formGroupName, controlName: string, units) {
    const volumeUnits = formGroupName.get(controlName);
    volumeUnits.setValue(units);
  }
  static checkForHazmat(loadOverviewDetails) {
    let hazmatObj;
    if (loadOverviewDetails && loadOverviewDetails.classifications) {
      hazmatObj = find(loadOverviewDetails.classifications, { 'operationalPlanClassificationCode': 'Hazmat' });
    }
    return (hazmatObj !== undefined);
  }
  static setUnloadedTypeByAndCounted(unloadedDetails: ViewActivityLogDetails, formGroup: FormGroup, unloadedModel) {
    formGroup.patchValue({
      unloadedBy: find(unloadedModel.unloadedBy, ['label', unloadedDetails['unloadedBy']]),
      countedBy: find(unloadedModel.countedBy, ['label', unloadedDetails['countedBy']])
    });
  }
  static setStopService(unloadedDetails: ViewActivityLogDetails, formGroup: FormGroup) {
    const stopServiceValue = [];
    unloadedDetails.stopServices
      .forEach((stopService, i) => {
        stopServiceValue.push({ 'label': stopService, 'value': unloadedDetails.stopServicesTypeCodes[i] });
      });
    formGroup.controls.stopServices.setValue(stopServiceValue);
  }
  static setReferenceAndCommentValues(unloadedDetails: ViewActivityLogDetails, formGroup: FormGroup) {
    formGroup.patchValue({
      comments: unloadedDetails.comments,
      shipmentIdentification: unloadedDetails.shipperIdentificationNumber,
      billOfLadingNumber: unloadedDetails.bolNumber,
      proNumber: unloadedDetails.proNumber,
      sealNumber: unloadedDetails.sealNumber,
      purchaseOrderNumber: (unloadedDetails.poNumbers && unloadedDetails.poNumbers.length > 0) ? unloadedDetails.poNumbers[0] : '',
      hazmat: unloadedDetails.hazmatIndicator,
      quantity: (unloadedDetails.count) ? unloadedDetails.count.toString() : ''
    });
  }
  static setWeightValue(formGroup: FormGroup, weight: WeightDetail) {
    formGroup.controls.weightUnits.setValue({
      weight: weight.weight,
      units: new TitleCasePipe().transform(weight.unitOfWeightMeasurement)
    });
  }
  static setVolumeValue(formGroup: FormGroup, volume: VolumeDetail) {
    formGroup.controls.volumeUnits.setValue({ volume: volume.volume, units: volume.unitOfVolumeMeasurement });
  }
  static setTemperatureValue(formGroup: FormGroup, temperature: TemperatureDetail) {
    formGroup.controls.temperatureReadingUnits.
      setValue({ temperatureReading: temperature.temperature, units: temperature.unitOfTemperatureMeasurement });
  }
  static getLoadedUnloadedFormGroup(formBuilder: FormBuilder) {
    return formBuilder.group({
      departureDate: [''],
      departureTime: [''],
      countedBy: ['', Validators.required],
      hazmat: ['', Validators.required],
      dropEquipmentDetails: formBuilder.group({}),
      trailerOrContainer: [''],
      stopServices: [[]],
      shipmentIdentification: [''],
      billOfLadingNumber: [''],
      purchaseOrderNumber: [''],
      sealNumber: [''],
      proNumber: [''],
      finalDestination: [''],
      quantity: [''],
      weightUnits: formBuilder.group({
        weight: [''],
        units: ['']
      }),
      volumeUnits: formBuilder.group({
        volume: [''],
        units: ['']
      }),
      temperatureReadingUnits: formBuilder.group({
        temperatureReading: [''],
        units: ['']
      }),
      comments: ['']
    });
  }
  static setHazmatValue(loadUnloadForm: FormGroup, isHazmat: boolean) {
    if (loadUnloadForm && loadUnloadForm.controls) {
      loadUnloadForm.controls.hazmat.setValue(isHazmat);
    }
  }
  static setStopServiceSelectedValue(selectedValue: ListItem, driver: ListItem, lumper: ListItem,
    driverLumperValue: string[], formGroup: FormGroup) {
    const stopService = formGroup.get('stopServices').value;
    if (stopService && stopService.length > 0) {
      switch (selectedValue.label.toLowerCase()) {
        case 'driver':
          this.setDefaultStopService(stopService, driver, driverLumperValue, formGroup);
          break;
        case 'lumper':
          this.setDefaultStopService(stopService, lumper, driverLumperValue, formGroup);
          break;
        default:
          this.removeDefaultValue(stopService, driverLumperValue, formGroup);
      }
    } else if (stopService && stopService.length === 0) {
      switch (selectedValue.label.toLowerCase()) {
        case 'driver':
          formGroup.controls.stopServices.setValue([driver]);
          break;
        case 'lumper':
          formGroup.controls.stopServices.setValue([lumper]);
          break;
      }
    }
  }
  static setDefaultStopService(stopService: ListItem[], defaultValue: ListItem, filterOutLabel: string[], formGroup: FormGroup) {
    const filteredService = filter(stopService, (service) => {
      return service.label.toLowerCase() !== filterOutLabel[0] && service.label.toLowerCase() !== filterOutLabel[1];
    });
    filteredService.push(defaultValue);
    formGroup.controls.stopServices.setValue(filteredService);
  }
  static removeDefaultValue(stopService: ListItem[], filterLabel: string[], formGroup: FormGroup) {
    const removedService = filter(stopService, (service) => {
      return service.label.toLowerCase() !== filterLabel[0] && service.label.toLowerCase() !== filterLabel[1];
    });
    formGroup.controls.stopServices.setValue(removedService);
  }
  static getFormattedData(datatoFormat, label: string, value: string) {
    let formattedData = [];
    formattedData = datatoFormat.map((data) => {
      return {
        'label': data[label],
        'value': data[value]
      };
    });
    return formattedData;
  }
  static frameUnloadedRequest(unloadedModel) {
    return {
      loadedTimestamp: unloadedModel.findUnloadedEarlyRequest.unloadedTimestamp,
      departureTimestamp: unloadedModel.departureTimestamp ? unloadedModel.departureTimestamp : null,
      planNumber: unloadedModel.operationalPlanNumber,
      stopSequenceNumber: unloadedModel.stopSequenceNumber,
      receiverStateId: unloadedModel.finalDestination,
      overrideWarning: unloadedModel.isWarningOverride,
      pickupEquipmentValue: (unloadedModel.unloadedDetails && unloadedModel.unloadedDetails.pickupEquipmentDetails) ?
        unloadedModel.unloadedDetails.pickupEquipmentDetails :
        this.getPickupEquipmentValue(unloadedModel.trailerOrContainerSelected, unloadedModel.equipmentPaired),
      dropEquipmentValue: (unloadedModel.unloadedDetails && unloadedModel.unloadedDetails.dropEquipmentDetails) ?
        unloadedModel.unloadedDetails.dropEquipmentDetails : this.getDropEquipmentValues(unloadedModel.addUnloadedForm),
      timeZone: unloadedModel.timeZone
    };
  }
  static getPickupEquipmentValue(trailerOrContainer, equipmentPaired) {
    let pickupData = [];
    if (trailerOrContainer) {
      if (equipmentPaired && equipmentPaired.length > 0) {
        pickupData = this.setPickupEquipmentValue(equipmentPaired);
      } else {
        trailerOrContainer.value.oldTruckId = (trailerOrContainer.value && trailerOrContainer.value.oldTruckId) ?
          trailerOrContainer.value.oldTruckId : null;
        pickupData.push(trailerOrContainer.value);
      }
    }
    return pickupData;
  }
  static setPickupEquipmentValue(equipmentPaired) {
    const pickupData = [];
    for (const equipmentGroup of equipmentPaired) {
      pickupData.push({
        equipmentId: equipmentGroup.equipmentId,
        equipmentNumber: equipmentGroup.equipmentNumber,
        equipmentPrefix: equipmentGroup.equipmentPrefix,
        equipmentType: equipmentGroup.equipmentType,
        oldEquipmentAssociationGroupId: equipmentGroup.oldEquipmentAssociationGroupId,
        equipmentAssociationId: equipmentGroup.equipmentAssociationId,
        equipmentAssociationGroupId: equipmentGroup.equipmentAssociationGroupId,
        isRemoveGroup: equipmentGroup.isRemoveGroup,
        isOldStack: equipmentGroup.isOldStack,
        oldTruckId: equipmentGroup.oldTruckId
      });
      if (equipmentGroup.stackedEquipmentList && equipmentGroup.stackedEquipmentList.length > 0) {
        for (const stackedEquipment of equipmentGroup.stackedEquipmentList) {
          pickupData.push({
            equipmentId: stackedEquipment.equipmentId,
            equipmentNumber: stackedEquipment.equipmentNumber,
            equipmentPrefix: stackedEquipment.equipmentPrefix,
            equipmentType: stackedEquipment.equipmentType,
            oldEquipmentAssociationGroupId: stackedEquipment.oldEquipmentAssociationGroupId,
            equipmentAssociationId: stackedEquipment.equipmentAssociationId,
            equipmentAssociationGroupId: stackedEquipment.equipmentAssociationGroupId,
            isRemoveGroup: stackedEquipment.isRemoveGroup,
            isOldStack: stackedEquipment.isOldStack,
            oldTruckId: equipmentGroup.oldTruckId
          });
        }
      }
    }
    return pickupData;
  }
  static setHazmatControl(loadUnloadForm: FormGroup, hazmatIndicator: string) {
    loadUnloadForm.controls.hazmat.setValue(hazmatIndicator.toLowerCase() === 'yes');
  }
  static frameTimeStampValues(dateValue, timeValue, ) {
    if (dateValue && timeValue) {
      return DateUtils.dateTimeFormat(dateValue, timeValue);
    } else {
      return null;
    }
  }
  static successMessage(toastMessage, activityType: string, method: string) {
    toastMessage.add({
      severity: 'success',
      summary: 'Success!',
      detail: `${activityType} event has been ${method} successfully`
    });
  }
  static onNoChangeMessage(noChangeToastMessage) {
    noChangeToastMessage.add({
      severity: 'info',
      summary: 'Info',
      detail: 'No changes detected'
    });
  }
  static checkDeviationMandatoryFields(arrivalModel, formGroupName, errorObject) {
    if (arrivalModel.arrivalDeviationType.toLowerCase() === 'late' || arrivalModel.arrivalDeviationType.toLowerCase() === 'early') {
      if (arrivalModel.arrivalDeviationType.toLowerCase() === 'late') {
        this.checkLateDeviationFields(errorObject, arrivalModel, formGroupName);
      } else {
        this.checkEarlyDeviationFields(errorObject, arrivalModel, formGroupName);
      }
    }
  }
  static checkLateDeviationFields(errorObject, arrivalModel, formGroupName) {
    for (const element of errorObject) {
      const control = this.checkErrors(element);
      const lateControlName = this.getControlName(control, 'late');
      if (control && lateControlName) {
        if (lateControlName !== 'comments') {
          if (!arrivalModel[formGroupName].controls.arrivalLate.get(lateControlName).value) {
            arrivalModel[formGroupName].controls.arrivalLate.get(lateControlName).setErrors({ 'invalid': true });
          }
        } else {
          arrivalModel[formGroupName].get('comments').setErrors({ 'invalid': true });
        }
      }
    }
  }
  static checkEarlyDeviationFields(errorObject, arrivalModel, formGroupName) {
    for (const element of errorObject) {
      const mandatoryControl = this.checkErrors(element);
      const earlyControlName = this.getControlName(mandatoryControl, 'early');
      if (mandatoryControl && earlyControlName) {
        if (earlyControlName !== 'comments') {
          if (!arrivalModel[formGroupName].controls.arrivalEarly.get(earlyControlName).value) {
            arrivalModel[formGroupName].controls.arrivalEarly.get(earlyControlName).setErrors({ 'invalid': true });
          }
        } else {
          arrivalModel[formGroupName].get('comments').setErrors({ 'invalid': true });
        }
      }
    }
  }
  static checkErrors(errorObject) {
    return errorObject.fieldName;
  }
  static getControlName(fieldName: string, deviationtype: string) {
    let controlName;
    switch (fieldName) {
      case 'ReasonCnt':
        controlName = `${deviationtype}ReasonContact`;
        break;
      case 'LtErRsnRes':
        controlName = `${deviationtype}ReasonResponsibility`;
        break;
      case 'LtErRsnCt':
        controlName = `${deviationtype}ReasonCategory`;
        break;
      case 'LtErRsnCod':
        controlName = `${deviationtype}Reason`;
        break;
      case 'Comments':
        controlName = `comments`;
        break;
    }
    return controlName;
  }
  static getFormattedEquipment(dropEquipment) {
    let dropEqp = [];
    dropEqp = dropEquipment.map((equipment) => {
      return {
        equipmentId: equipment.equipmentId,
        equipmentType: equipment.equipmentType,
        equipmentPrefix: equipment.equipmentPrefix,
        equipmentNumber: equipment.equipmentNumber,
        stackedEquipmentList: equipment.stackedEquipmentList && equipment.stackedEquipmentList.length > 0 ?
          this.getStackedEquip(equipment.stackedEquipmentList) : []
      };
    });
    return dropEqp;
  }
  static getValueOrNull(data) {
    return data ? data : null;
  }
  static invalidTimeMessage(toastMessage, activityType: string) {
    toastMessage.clear();
    toastMessage.add({
      severity: 'error',
      summary: 'Error',
      detail: `${activityType} date time cannot be a future date time`
    });
  }
  static checkArrivalTime(arrivalModel, isEdit: boolean, toastMessage, activityType: string) {
    const formName = !isEdit ? 'addArrivalForm' : 'editArrivalForm';
    const arrivalDateTime = (arrivalModel.arrivalDate) ?
      DateUtils.getMomentDate(`${arrivalModel.arrivalDate},${arrivalModel.arrivalTimeSelected}`) : '';
    if (moment(arrivalDateTime).isAfter(moment())) {
      arrivalModel[formName].controls.arrivalTime.setErrors({ invalid: true });
      arrivalModel[formName].controls.arrivalTime.markAsTouched();
      arrivalModel.arrivalDeviationType = '';
      this.invalidTimeMessage(toastMessage, activityType);
    } else if (arrivalModel[formName].controls.arrivalDate.invalid &&
      arrivalModel[formName].controls.arrivalDate.touched) {
      this.invalidTimeMessage(toastMessage, activityType);
    } else if (!arrivalModel[formName].controls.arrivalDate.value &&
      !arrivalModel[formName].controls.arrivalDate.touched) {
      arrivalModel[formName].controls.arrivalDate.setErrors({ invalid: true });
      arrivalModel[formName].controls.arrivalDate.markAsTouched();
    } else {
      arrivalModel[formName].controls.arrivalTime.setErrors(null);
    }
  }
  static checkLoadedTime(loadedModel, toastMessage, activityType: string) {
    const loadedDateTime = (loadedModel.loadedDate) ?
      DateUtils.getMomentDate(`${loadedModel.loadedDate},${loadedModel.loadedTimeSelected}`) : '';
    if (moment(loadedDateTime).isAfter(moment())) {
      loadedModel.addLoadedForm.controls.loadedTime.setErrors({ invalid: true });
      loadedModel.addLoadedForm.controls.loadedTime.markAsTouched();
      this.invalidTimeMessage(toastMessage, activityType);
    } else if (loadedModel.addLoadedForm.controls.loadedDate.invalid &&
      loadedModel.addLoadedForm.controls.loadedDate.touched) {
      this.invalidTimeMessage(toastMessage, activityType);
    } else if (!loadedModel.addLoadedForm.controls.loadedDate.value &&
      !loadedModel.addLoadedForm.controls.loadedDate.touched) {
      loadedModel.addLoadedForm.controls.loadedDate.setErrors({ invalid: true });
      loadedModel.addLoadedForm.controls.loadedDate.markAsTouched();
    } else {
      if (loadedModel.addLoadedForm.controls.loadedTime.value) {
        loadedModel.addLoadedForm.controls.loadedTime.setErrors(null);
      }
    }
  }
  static checkUnloadedTime(unloadedModel, isEdit: boolean, toastMessage, activityType: string) {
    const formName = !isEdit ? 'addUnloadedForm' : 'editUnloadedForm';
    const unloadedDateTime = (unloadedModel.unloadedDate) ?
      DateUtils.getMomentDate(`${unloadedModel.unloadedDate},${unloadedModel.unloadedTimeSelected}`) : '';
    if (moment(unloadedDateTime).isAfter(moment())) {
      unloadedModel[formName].controls.unloadedTime.setErrors({ invalid: true });
      unloadedModel[formName].controls.unloadedTime.markAsTouched();
      this.invalidTimeMessage(toastMessage, activityType);
    } else if (unloadedModel[formName].controls.unloadedDate.invalid &&
      unloadedModel[formName].controls.unloadedDate.touched) {
      this.invalidTimeMessage(toastMessage, activityType);
    } else if (!unloadedModel[formName].controls.unloadedDate.value &&
      !unloadedModel[formName].controls.unloadedDate.touched) {
      unloadedModel[formName].controls.unloadedDate.setErrors({ invalid: true });
      unloadedModel[formName].controls.unloadedDate.markAsTouched();
    } else {
      if (unloadedModel[formName].controls.unloadedTime.value) {
        unloadedModel[formName].controls.unloadedTime.setErrors(null);
      }
    }
  }
  static formatTimeSelected(time: string) {
    return moment(new Date(time)).format('hh:mm a');
  }
  static getFormatedLoadedByValue(loadedByValues, stopReasonCode) {
    let loadedBy = [];
    loadedBy = this.getFormattedData(loadedByValues,
      'operationalPlanStopActivityPartyTypeDescription', 'operationalPlanStopActivityPartyTypeCode');
    if (stopReasonCode &&
      stopReasonCode.operationalPlanStopReasonCode) {
      loadedBy = filter(loadedBy, (loadedByData) => {
        if (stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'delivery' ||
          stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'dropequi') {
          return loadedByData.label.toLowerCase() !== 'preloaded' && loadedByData.label.toLowerCase() !== 'shipper';
        } else if (stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'pickup' ||
          stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'pickupequi') {
          return loadedByData.label.toLowerCase() !== 'receiver';
        }
      });
    }
    return loadedBy;
  }
  static getFormatedCountedByValue(countedByValues, stopReasonCode) {
    let countedBy = [];
    countedBy = this.getFormattedData(countedByValues,
      'countedByPartyTypeDescription', 'countedByPartyTypeCode');
    if (stopReasonCode &&
      stopReasonCode.operationalPlanStopReasonCode) {
      countedBy = filter(countedBy, (countedByData) => {
        if (stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'delivery' ||
          stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'dropequi') {
          return countedByData.label.toLowerCase() !== 'shipper';
        } else if (stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'pickup' ||
          stopReasonCode.operationalPlanStopReasonCode.toLowerCase() === 'pickupequi') {
          return countedByData.label.toLowerCase() !== 'receiver';
        }
      });
    }
    return countedBy;
  }
  static getStackedEquip(stackedEquipment) {
    const stackedEquip = [];
    stackedEquipment.forEach((stackedEquimentData) => {
      stackedEquip.push({
        equipmentId: stackedEquimentData.equipmentId,
        equipmentType: stackedEquimentData.equipmentType,
        equipmentPrefix: stackedEquimentData.equipmentPrefix,
        equipmentNumber: stackedEquimentData.equipmentNumber
      });
    });
    return stackedEquip;
  }
  static getTrailerOrContainer(data: any) {
    const truck = [];
    if (data) {
      data.forEach((value) => {
        truck.push({
          'label': value._source.prefixWithEquipmentNumber.trim(),
          'value': this.getTrailerOrContainerValue(value._source)
        });
      });
    }
    return truck;
  }

  static getTrailerOrContainerValue(trailerOrContainerValue) {
    return {
      'equipmentId': trailerOrContainerValue.equipmentID,
      'equipmentType': trailerOrContainerValue.equipmentTypeName,
      'equipmentPrefix': trailerOrContainerValue.equipmentPrefix,
      'equipmentNumber': trailerOrContainerValue.equipmentNumber,
      'oldEquipmentAssociationGroupId': trailerOrContainerValue.oldEquipmentAssociationGroupId,
      'equipmentAssociationId': trailerOrContainerValue.equipmentAssociationId,
      'equipmentAssociationGroupId': trailerOrContainerValue.equipmentAssociationGroupId,
      'isRemoveGroup': trailerOrContainerValue.isRemoveGroup,
      'isOldStack': trailerOrContainerValue.isOldStack
    };
  }

  static getChassis(equipments, assetId) {
    const trailerOrContainer = find(equipments, ['equipmentId', assetId.value.equipmentId]);
    let chassis = null;
    if (trailerOrContainer.stackedEquipmentList && trailerOrContainer.stackedEquipmentList.length > 0) {
      const chassisData = find(trailerOrContainer.stackedEquipmentList, { 'equipmentCategory': 'CHASSIS' });
      if (chassisData) {
        chassis = {
          'equipmentId': chassisData.equipmentId,
          'equipmentType': chassisData.equipmentType,
          'equipmentPrefix': chassisData.equipmentPrefix,
          'equipmentNumber': chassisData.equipmentNumber
        };
      }
    }
    return chassis;
  }
  static checkArrivalFormValidity(toastMessage, formGroupName, model, isEdit, errorEmitter, changeDetector) {
    toastMessage.clear();
    if (!formGroupName.controls.arrivalDate.value ||
      !formGroupName.controls.arrivalTime.value || formGroupName.invalid) {
      ActivityLogUtils.requiredFieldError(errorEmitter, changeDetector);
    } else {
      this.checkArrivalTime(model, isEdit, toastMessage, 'Arrival');
    }
  }
  static checkLoadedFormValidity(toastMessage, formGroupName, model, errorEmiter, changeDetector) {
    toastMessage.clear();
    if ((formGroupName.controls.loadedDate.value && formGroupName.controls.loadedTime.value)
      && (formGroupName.controls.loadedDate.invalid || formGroupName.controls.loadedTime.invalid)) {
      this.checkLoadedTime(model, toastMessage, 'Loaded');
    } else if (formGroupName.invalid) {
      this.requiredFieldError(errorEmiter, changeDetector);
    }
  }
  static checkUnloadedFormValidity(toastMessage, formGroupName, model, isEdit, errorEmitter, changeDetector) {
    toastMessage.clear();
    if ((formGroupName.controls.unloadedDate.value && formGroupName.controls.unloadedTime.value)
      && (formGroupName.controls.unloadedDate.invalid || formGroupName.controls.unloadedTime.invalid)) {
      this.checkUnloadedTime(model, isEdit, toastMessage, 'Unloaded');
    } else {
      this.requiredFieldError(errorEmitter, changeDetector);
    }
  }
  static checkRuleValidationError(errorArray, formGroupName, errorEmitter, changeDetector) {
    for (const error of errorArray) {
      this.mandatoryRuleValidationFields(formGroupName, this.checkErrors(error));
    }
    if (formGroupName.invalid) {
      this.requiredFieldError(errorEmitter, changeDetector);
    }
  }
  static mandatoryRuleValidationFields(formGroupName, fieldName: string) {
    switch (fieldName) {
      case 'Quantity':
        formGroupName.get('quantity').setErrors({ 'invalid': true });
        break;
      case 'PONumber':
        formGroupName.get('purchaseOrderNumber').setErrors({ 'invalid': true });
        break;
      case 'SealNumber':
        formGroupName.get('sealNumber').setErrors({ 'invalid': true });
        break;
      case 'BOLNmbr':
        formGroupName.get('billOfLadingNumber').setErrors({ 'invalid': true });
        break;
      case 'ShipID':
        formGroupName.get('shipmentIdentification').setErrors({ 'invalid': true });
        break;
      case 'Weight':
        formGroupName.get('weightUnits').get('weight').setErrors({ 'invalid': true });
        break;
      case 'Tmperature':
        formGroupName.get('temperatureReadingUnits').get('temperatureReading').setErrors({ 'invalid': true });
        break;
      case 'Remarks':
        formGroupName.get('comments').setErrors({ 'invalid': true });
        break;
      case 'Volume':
        formGroupName.get('volumeUnits').get('volume').setErrors({ 'invalid': true });
        break;
      case 'PRONumber':
        formGroupName.get('proNumber').setErrors({ 'invalid': true });
        break;
      case 'DepDateTim':
        this.setDepartureFieldMandatory(formGroupName);
        break;
      default: break;
    }
  }
  static checkAllReferenceException(operationalPlanReferenceNumberDTOs, stopDto, loadedUnloadedForm,
    loadedUnloadedDetails) {
    const referenceArray = ['BOL', 'SHIPID', 'PO NBR', 'SEAL', 'PRO NBR'];
    for (const error of referenceArray) {
      this.checkReferenceNumberException(operationalPlanReferenceNumberDTOs, stopDto, error, loadedUnloadedForm,
        loadedUnloadedDetails);
      this.checkMultipleReference(operationalPlanReferenceNumberDTOs, stopDto, error, loadedUnloadedForm);
    }
  }
  static checkReferenceNumberException(operationalPlanReferenceNumberDTOs, stopDto, typeCode, loadedUnloadedForm,
    loadedUnloadedDetails ) {
    const hasException = find(operationalPlanReferenceNumberDTOs,
          (item: any) => item.operationalPlanStopId ===
          stopDto.operationalPlanStopId && item.referenceNumberTypeCode === typeCode);

    if (hasException) {
      switch (typeCode) {
        case 'PO NBR':
          this.checkPONBRSealException(loadedUnloadedDetails, hasException, loadedUnloadedForm, 'purchaseOrderNumber');
          break;
        case 'SEAL':
          this.checkPONBRSealException(loadedUnloadedDetails, hasException, loadedUnloadedForm, 'sealNumber');
          break;
        case 'BOL':
          this.checkPONBRSealException(loadedUnloadedDetails, hasException, loadedUnloadedForm, 'billOfLadingNumber');
          break;
        case 'SHIPID':
          if (hasException.referenceNumberValue !== loadedUnloadedDetails.shipperIdentificationNumber) {
          this.referenceFieldValidation(loadedUnloadedForm, 'shipmentIdentification');
          }
          break;
        case 'PRO NBR':
          if (hasException.referenceNumberValue !== loadedUnloadedDetails.proNumber) {
            this.referenceFieldValidation(loadedUnloadedForm, 'proNumber');
          }
          break;
        default: break;
      }
    }
  }
  static checkPONBRSealException(loadedUnloadedDetails, hasException, loadedUnloadedForm, typeCode) {
    if (typeCode === 'purchaseOrderNumber' && loadedUnloadedDetails.poNumbers && loadedUnloadedDetails.poNumbers.length > 0 &&
      hasException.referenceNumberValue !== loadedUnloadedDetails.poNumbers[0]) {
      this.referenceFieldValidation(loadedUnloadedForm, 'purchaseOrderNumber');
    }
    if (typeCode === 'sealNumber' && hasException.referenceNumberValue !== loadedUnloadedDetails.sealNumber) {
      this.referenceFieldValidation(loadedUnloadedForm, 'sealNumber');
    }
    if (typeCode === 'billOfLadingNumber' && hasException.referenceNumberValue !== loadedUnloadedDetails.bolNumber) {
      this.referenceFieldValidation(loadedUnloadedForm, 'billOfLadingNumber');
    }
  }
  static referenceFieldValidation(formGroupName, formControl) {
    formGroupName.controls[formControl].setErrors({ invalid: true });
    formGroupName.controls[formControl].markAsTouched();
  }
  static checkMultipleReference(operationalPlanReferenceNumberDTOs, stopDto, typeCode, loadedUnloadedForm) {
      const hasException = filter(operationalPlanReferenceNumberDTOs,
        (item: any) => item.operationalPlanStopId ===
        stopDto.operationalPlanStopId && item.referenceNumberTypeCode === typeCode);

      if (hasException.length > 1) {
        switch (typeCode) {
          case 'PO NBR':
            this.referenceFieldValidation(loadedUnloadedForm, 'purchaseOrderNumber');
            break;
          case 'SEAL':
            this.referenceFieldValidation(loadedUnloadedForm, 'sealNumber');
            break;
          case 'BOL':
            this.referenceFieldValidation(loadedUnloadedForm, 'billOfLadingNumber');
            break;
          case 'SHIPID':
            this.referenceFieldValidation(loadedUnloadedForm, 'shipmentIdentification');
            break;
          case 'PRO NBR':
            this.referenceFieldValidation(loadedUnloadedForm, 'proNumber');
            break;
          default: break;
        }
      }
  }
  static setDepartureFieldMandatory(formGroupName) {
    if (!formGroupName.get('departureDate').value) {
      formGroupName.get('departureDate').setErrors({ 'invalid': true });
    }
    if (!formGroupName.get('departureTime').value) {
      formGroupName.get('departureTime').setErrors({ 'invalid': true });
    }
  }
  static dateValidation(formGroupName, formControl, toastMessage, activityType) {
    formGroupName.controls[formControl].setErrors({ invalid: true });
    formGroupName.controls[formControl].markAsTouched();
    this.invalidTimeMessage(toastMessage, activityType);
  }
  static getDropEquipmentValues(loadedUnloadedForm: FormGroup) {
    const dropEquipmentValues = [];
    if (loadedUnloadedForm.get('dropEquipmentDetails') && loadedUnloadedForm.get('dropEquipmentDetails').value &&
      Object.entries(loadedUnloadedForm.get('dropEquipmentDetails').value.length > 0)) {
      const dropEquipmentData = Object.entries(loadedUnloadedForm.get('dropEquipmentDetails').value);
      dropEquipmentData.forEach((entries) => {
        if (entries[1] && entries[1]['length'] !== 0) {
          const dropEquipment = JSON.parse(entries[1][0]);
          dropEquipment.stackedEquipmentList.forEach((stackedEquipment) => {
            dropEquipmentValues.push(stackedEquipment);
          });
          delete dropEquipment.stackedEquipmentList;
          dropEquipmentValues.push(dropEquipment);
        }
      });
    }
    return dropEquipmentValues.length > 0 ? dropEquipmentValues : null;
  }
  static droppedOrUndropped(loadedUnloadedForm: FormGroup) {
    let checked = false;
    const dropEquipmentData = Object.entries(loadedUnloadedForm.get('dropEquipmentDetails').value);
    dropEquipmentData.forEach((entries) => {
      if (entries && entries[1] && entries[1]['length'] !== 0) {
        checked = true;
      }
    });
    return checked;
  }
  static checkeddroppedOrUndropped(loadedUnloadedForm: FormGroup) {
    const selectedStatus = [];
    const dropEquipmentData = Object.entries(loadedUnloadedForm.get('dropEquipmentDetails').value);
    dropEquipmentData.forEach((entries) => {
      if (entries && entries[1] && entries[1]['length'] !== 0) {
        selectedStatus.push('checked');
      }
    });
    return (dropEquipmentData.length === selectedStatus.length);
  }
  static getArrivalMandatory(errorList) {
    return errorList.indexOf('arrival call - missing mandatory attribute') !== -1;
  }
  static getBOLError(loadedModel: any, formGroupName: FormGroup) {
    if (loadedModel.fieldErrorList.includes(loadedModel.loadedErrorTaskTypeName.BOLPRONo)) {
      this.highLightErrorFields(formGroupName, 'billOfLadingNumber');
      this.highLightErrorFields(formGroupName, 'proNumber');
    }
  }
  static getStopServicesError(loadedModel: any, formGroupName: FormGroup) {
    if (loadedModel.fieldErrorList.includes(loadedModel.loadedErrorTaskTypeName.stopServices)) {
      this.highLightErrorFields(formGroupName, 'stopServices');
    }
    if (loadedModel.fieldErrorList.includes(loadedModel.loadedErrorTaskTypeName.weight)) {
      formGroupName.get('weightUnits').get('weight').setErrors({ invalid: true });
      formGroupName.get('weightUnits').get('weight').markAsTouched();
    }
  }
  static getFinalDestError(loadedModel: any) {
    return loadedModel.fieldErrorList.indexOf(loadedModel.loadedErrorTaskTypeName.finalDest) !== -1;
  }
  static getEquipmentError(loadedModel: any, formGroupName: FormGroup) {
    const checkCallError = [loadedModel.loadedErrorTaskTypeName.equipmentNumber,
    loadedModel.loadedErrorTaskTypeName.equipmentType,
    loadedModel.loadedErrorTaskTypeName.equipmentLength,
    loadedModel.loadedErrorTaskTypeName.trailingEquipNonOpr,
    loadedModel.loadedErrorTaskTypeName.trailingEquipNonAvailable,
    loadedModel.loadedErrorTaskTypeName.trailingEquipLiveLoad
    ];

    const hasEquipmentError = loadedModel.fieldErrorList.some(errorObj => checkCallError.indexOf(errorObj) >= 0);

    if (hasEquipmentError) {
      formGroupName.get('trailerOrContainer').setErrors({ invalid: true });
      formGroupName.get('trailerOrContainer').markAsTouched();
      if (formGroupName.get('trailerOrContainer').value) {
        formGroupName.get('trailerOrContainer').markAsDirty();
      }
    }
  }
  static getLoadedMandatory(loadedModel: any, formGroupName: FormGroup) {
    if (loadedModel.fieldErrorList.includes(loadedModel.loadedErrorTaskTypeName.loadedTime)) {
      this.highLightErrorFields(formGroupName, 'loadedTime');
    }
    if (loadedModel.fieldErrorList.includes(loadedModel.loadedErrorTaskTypeName.loadedBy)) {
      this.highLightLoadedErrorFields(formGroupName, 'loadedBy');
      this.highLightLoadedErrorFields(formGroupName, 'loadedType');
      this.highLightLoadedErrorFields(formGroupName, 'countedBy');
    }
  }
  static getUnLoadedMandatory(unLoadedModel: any, formGroupName: FormGroup) {
    if (unLoadedModel.fieldErrorList.includes(unLoadedModel.unLoadedErrorTaskTypeName.unLoadedTime)) {
      this.highLightErrorFields(formGroupName, 'unloadedTime');
    }
    if (unLoadedModel.fieldErrorList.includes(unLoadedModel.unLoadedErrorTaskTypeName.unLoadedBy)) {
      this.highLightLoadedErrorFields(formGroupName, 'unloadedBy');
      this.highLightLoadedErrorFields(formGroupName, 'unloadedType');
      this.highLightLoadedErrorFields(formGroupName, 'countedBy');
    }
  }
  static getUnLoadedBOLError(unLoadedModel: any, formGroupName: FormGroup) {
    if (unLoadedModel.fieldErrorList.includes(unLoadedModel.unLoadedErrorTaskTypeName.BOLPRONo)) {
      this.highLightErrorFields(formGroupName, 'billOfLadingNumber');
      this.highLightErrorFields(formGroupName, 'proNumber');
    }
  }
  static getUnLoadedStopServicesError(unLoadedModel: any, formGroupName: FormGroup) {
    if (unLoadedModel.fieldErrorList.includes(
      unLoadedModel.unLoadedErrorTaskTypeName.stopServices)) {
      this.highLightErrorFields(formGroupName, 'stopServices');
    }
    if (unLoadedModel.fieldErrorList.includes(
      unLoadedModel.unLoadedErrorTaskTypeName.weight)) {
      formGroupName.get('weightUnits').get('weight').setErrors({ invalid: true });
      formGroupName.get('weightUnits').get('weight').markAsTouched();
    }
  }
  static getUnloadedEquipError(unLoadedModel: any, formGroupName: FormGroup) {
    if (unLoadedModel.fieldErrorList.includes(unLoadedModel.unLoadedErrorTaskTypeName.trailingEquipment ||
      unLoadedModel.unLoadedErrorTaskTypeName.trailingEquipNotAvailable)) {
      this.highLightErrorFields(formGroupName, 'trailerOrContainer');
    }
  }
  static highLightErrorFields(formGroupName: FormGroup, formControl: string) {
    formGroupName.controls[formControl].setErrors({ invalid: true });
    formGroupName.controls[formControl].markAsTouched();
    if (formGroupName.controls[formControl].value) {
      formGroupName.controls[formControl].markAsDirty();
    }
  }
  static getTruckValue(resourceOverview: ResourceOverview) {
    return resourceOverview && resourceOverview.equipmentId ? resourceOverview.equipmentId : null;
  }
  static getCheckCallReq(arrivalEditModel, activityType, isWarningOverride) {
    arrivalEditModel.isWarningOverride = isWarningOverride;
    arrivalEditModel.isAutoCheckCall = false;
    arrivalEditModel.arrivalType = activityType;
    arrivalEditModel.hubReading = null;
    arrivalEditModel.arrivalCheckCallType = 'ArrivalAtStop';
  }
  static highLightLoadedErrorFields(formGroupName: FormGroup, formControl: string) {
    if (!formGroupName.controls[formControl].value) {
      formGroupName.controls[formControl].setErrors({ invalid: true });
      formGroupName.controls[formControl].markAsTouched();
    }
  }
  static handleErrorAndNull(error, toastMessage) {
    if (error && error.status === 500) {
      toastMessage.add({
        severity: 'error',
        summary: 'Server Error',
        detail: ErrorUtils.getErrorMessage(error.status)
      });
      return false;
    } else if (error && error.error && error.error.errors) {
      return this.handleEmptyError(error, toastMessage);
    } else {
      return false;
    }
  }
  static handleEmptyError(error, toastMessage) {
    if (error.error.errors.length === 1 &&
      !error.error.errors[0].errorMessage &&
      error.error.errors[0].errorMessage === 'null') {
      toastMessage.add({
        severity: 'error',
        summary: 'Server Error',
        detail: ErrorUtils.getErrorMessage(500)
      });
      return false;
    } else {
      return true;
    }
  }
  static getZoneFormat(timeZone = '') {
    return timeZone ? momentTimezone().tz(timeZone).format('z') : momentTimezone().tz('America/Chicago').format('z');
  }
  static resourceFieldError(toastMessageResource) {
    toastMessageResource.add({
      severity: 'error',
      summary: 'Error',
      detail: 'Resource information missing'
    });
  }
  static getLoadedUnloadedTypeValue(loadedTypeValues: ListItem[], checkCallLoadedType: string) {
    const loadedType = find(loadedTypeValues,
      { label: checkCallLoadedType });
    return loadedType && loadedType.value ? loadedType.value : null;
  }
  static formatBasedOnZone(datePipe, event, format) {
    return datePipe.transform(event.toLowerCase().includes('z') ? event.slice(0, -1) : event, format);
  }
  static activityLogError(exceptionObj, exceptionList) {
    if (exceptionObj && exceptionObj.exceptionTaskMessages && exceptionObj.exceptionTaskMessages.length > 0) {
      exceptionObj.exceptionTaskMessages.forEach((exceptionMessage) => {
        exceptionList.push({
          errorMessage: exceptionMessage,
          errorType: '',
          errorSeverity: exceptionObj.exceptionOverrideTypeCode.toUpperCase(),
          code: exceptionObj.taskTypeName.toLowerCase()
        });
      });
    }
  }
  static checkLocalStoreHazmat(loadUnloadForm, isHazmat, isReload) {
    if (!isReload) {
      this.setHazmatValue(loadUnloadForm, isHazmat);
    } else if (isReload && !loadUnloadForm.controls.hazmat.value) {
      this.setHazmatValue(loadUnloadForm, isHazmat);
    }
  }
}
