import { ActivityLogUtils } from './activity-log.utils';
import { FormBuilder, FormGroup } from '@angular/forms';

describe('ActivityLogUtils', () => {
const formBuilder: FormBuilder = new FormBuilder();
let editArrivalform: FormGroup;
const equipmentDetails = [{
    equipmentId: 1,
    equipmentNumber: '12',
    equipmentPrefix: '',
    equipmentType: 'DRY VAN',
    oldEquipmentAssociationGroupId: null,
    equipmentAssociationId: null,
    equipmentAssociationGroupId: null,
    isRemoveGroup: false,
    isOldStack: false,
    oldTruckId: null,
    stackedEquipmentList: []
}];
const fetchDetails = [{
    preferedName: 'CODY',
    lastname: 'OWENS',
    userId: 'JDCS3497',
    value: '',
    profilePicture: null,
    noProfilePicture: null,
    emplId: '289888'
}];
editArrivalform = formBuilder.group({
    arrivalDate: [''],
    arrivalTime: [''],
    arrivalLate: formBuilder.group({
      lateReasonCategory: [],
      lateReason: [],
      lateReasonResponsibility: [''],
      lateReasonContact: ['']
    }),
    arrivalEarly: formBuilder.group({
      earlyReasonCategory: [],
      earlyReason: [],
      earlyReasonResponsibility: [''],
      earlyReasonContact: ['']
    })
  });
    const lateModelValue = {
    arrivalDeviationType: 'Late',
    editArrivalform: editArrivalform
    };
    const earlyModelValue = {
        arrivalDeviationType: 'Early',
        editArrivalform: editArrivalform
    };

    it('getLoadedUnloadedFormGroup have been called', () => {
        const value = ActivityLogUtils.getLoadedUnloadedFormGroup(formBuilder);
        expect(value.controls.departureTime.value).toBe('');
    });
    it('getDriverIds have been called', () => {
        const driverId = ActivityLogUtils.getDriverIds(fetchDetails);
        expect(driverId).toBeDefined();
    });
    it('imageDetails have been called', () => {
        const driverImageDetails = [{
            personId: '289888',
            userId: 'JDCS3497',
            firstName: 'CODY',
            middleName: 'Ryan',
            lastName: 'OWENS',
            preferredName: 'CODY',
            profilePicture: null,
            positionDescription: null,
            teamname: null,
            jobtitle: null
        }];
        const imagedetails = ActivityLogUtils.imageDetails(driverImageDetails);
        expect(imagedetails).toBeDefined();
    });
    it('getAppointmentDate have been called', () => {
        const AppointmentDetails = {
            appointmentStartTimestamp: '2019-09-26T10:00:00-05:00',
            appointmentEndTimestamp: '2019-09-26T10:00:00-05:00'
        };
        const time = ActivityLogUtils.getAppointmentDate(AppointmentDetails);
        expect(time).toBeDefined();
    });
    it('frameArrivalDeviationRequest for emptylateform have been called', () => {
        const returnValue = ActivityLogUtils.frameArrivalDeviationRequest(false, 'Late', editArrivalform.controls);
        expect(returnValue).toBeDefined();
    });
    it('frameArrivalDeviationRequest for late have been called', () => {
        editArrivalform.controls.arrivalLate.patchValue({
            lateReasonCategory: { value: 'Driver' },
            lateReason: { value: 'Driver' },
            lateReasonResponsibility: { value: 'JBH' },
            lateReasonContact: '5465575'
        });
        const returnValue = ActivityLogUtils.frameArrivalDeviationRequest(false, 'Late', editArrivalform.controls);
        expect(returnValue).toBeDefined();
    });
    it('frameArrivalDeviationRequest for emptyearlyform have been called', () => {
        const returnValue = ActivityLogUtils.frameArrivalDeviationRequest(false, 'Early', editArrivalform.controls);
        expect(returnValue).toBeDefined();
    });
    it('frameArrivalDeviationRequest for early have been called', () => {
        editArrivalform.controls.arrivalEarly.patchValue({
            earlyReasonCategory: { value: 'Driver' },
            earlyReason: { value: 'Driver' },
            earlyReasonResponsibility: { value: 'JBH' },
            earlyReasonContact: 'test'
        });
        const returnValue = ActivityLogUtils.frameArrivalDeviationRequest(true, 'Early', editArrivalform.controls);
        expect(returnValue).toBeDefined();
    });
    it('checkErrors have been called', () => {
        const error = {
            fieldErrorFlag: true,
            errorMessage: 'Check Call has missing required fields.',
            errorType: 'Field Validation Error',
            fieldName: 'LtErRsnCod',
            code: 'ARRIVAL_CHECKCALL_VALIDATION',
            errorSeverity: 'ERROR'
        };
        const fieldName = ActivityLogUtils.checkErrors(error);
        expect(fieldName).toBeDefined();
    });
    it('getPickupEquipmentValue else have been called', () => {
        const trailer = {
            value: { oldTruckId: 1234}
        };
        const result = ActivityLogUtils.getPickupEquipmentValue(trailer, equipmentDetails);
        expect(result).toBeDefined();
    });
    it('getPickupEquipmentValue of empty equipment have been called', () => {
        const trailer = {
            value: { oldTruckId: 1234}
        };
        const result = ActivityLogUtils.getPickupEquipmentValue(trailer, []);
        expect(result).toBeDefined();
    });
    it('getPickupEquipmentValue else have been called', () => {
        const trailer = {
            value: { oldTruckId: ''}
        };
        const stackedEquipment = [{
            equipmentId: 1,
            equipmentNumber: '12',
            equipmentPrefix: '',
            equipmentType: 'DRY VAN',
            oldEquipmentAssociationGroupId: null,
            equipmentAssociationId: null,
            equipmentAssociationGroupId: null,
            isRemoveGroup: false,
            isOldStack: false,
            oldTruckId: null,
        stackedEquipmentList: [{
            equipmentId: 1,
            equipmentNumber: '12',
            equipmentPrefix: '',
            equipmentType: 'DRY VAN',
            oldEquipmentAssociationGroupId: null,
            equipmentAssociationId: null,
            equipmentAssociationGroupId: null,
            isRemoveGroup: false,
            isOldStack: false,
            oldTruckId: null
        }]
    }];
        const result = ActivityLogUtils.getPickupEquipmentValue(trailer, stackedEquipment);
        expect(result).toBeDefined();
    });
    it ('resetFormControls for earlyReason have been called', () => {
        ActivityLogUtils.resetFormControls(earlyModelValue, 'editArrivalform', true);
        expect(editArrivalform.controls.arrivalEarly.get('earlyReason').value).toBeNull();
    });
    it ('resetFormControls for earlyReasonContact have been called', () => {
        ActivityLogUtils.resetFormControls(earlyModelValue, 'editArrivalform');
        expect(editArrivalform.controls.arrivalEarly.get('earlyReasonContact').value).toBeNull();
    });
    it ('resetFormControls for lateReason have been called', () => {
        ActivityLogUtils.resetFormControls(lateModelValue, 'editArrivalform', true);
        expect(editArrivalform.controls.arrivalLate.get('lateReason').value).toBeNull();
    });
    it ('resetFormControls for lateReasonContact have been called', () => {
        ActivityLogUtils.resetFormControls(lateModelValue, 'editArrivalform');
        expect(editArrivalform.controls.arrivalLate.get('lateReasonContact').value).toBeNull();
    });
    it('getControlName for earlyReasonContact have been called', () => {
        const resultValue = ActivityLogUtils.getControlName('ReasonCnt', 'early');
        expect(resultValue).toBeDefined();
    });
    it('getControlName for earlyReasonResponsibility have been called', () => {
        const resultValue = ActivityLogUtils.getControlName('LtErRsnRes', 'early');
        expect(resultValue).toBeDefined();
    });
    it('getControlName for earlyReasonCategory have been called', () => {
        const resultValue = ActivityLogUtils.getControlName('LtErRsnCt', 'early');
        expect(resultValue).toBeDefined();
    });
    it('getControlName for earlyReason have been called', () => {
        const resultValue = ActivityLogUtils.getControlName('LtErRsnCod', 'early');
        expect(resultValue).toBeDefined();
    });
    it('getControlName for comments have been called', () => {
        const resultValue = ActivityLogUtils.getControlName('Comments', 'early');
        expect(resultValue).toBeDefined();
    });
});
