import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../shared/service/app-config.service';
import { ActivityLogService } from './activity-log.service';
import { configureTestSuite } from 'ng-bullet';

describe('ActivityLogService', () => {
  let service: ActivityLogService;
  let httpTestingController: HttpTestingController;
  const IsLoadedEarly = {
    loadedTimestamp: '',
    unloadedTimestamp: '',
    operationalPlanID: 0,
    operationalPlanStopID: 0,
    isEdit: false
  };
  const arrivalLoaded = {
    arrivalCheckCallDetails: {
      operationalPlanNumber: '',
      operationalPlanStopSequenceNumber: 1,
      arrivalType: '',
      arrivalTimestamp: '',
      checkCallSourceTimestamp: '',
      hubReading: '',
      arrivalCheckCallType: '',
      resourceDetails: {
        type: '',
        value: 1
      },
      isAutoCheckCall: true,
      checkCallSource: '',
      arrivalTimeDeviationDetails: {
        arrivalTimeDeviationType: '',
        arrivalTimeDeviationReason: '',
        arrivalTimeDeviationReasonCategory: '',
        arrivalDeviationResponsibilityPartyType: '',
        contactID: '',
        contactText: ''
      },
      comments: '',
      isWarningOverride: false
    },
    loadedUnloadedCheckCallDetails: {
      operationalPlanNumber: '',
      operationalPlanStopSequenceNumber: 0,
      receiverStateId: null,
      stopServices: [],
      hazmatIndicator: false,
      isWarningOverride: false,
      checkCallDetails: {
        loadedTimestamp: '',
        loadedBy: '',
        loadedType: '',
        count: 0,
        countedBy: '',
        sealNumber: '',
        bolNumber: '',
        poNumbers: [],
        shipperIdentificationNumber: '',
        unloadedTimestamp: '',
        unloadedBy: '',
        unloadedType: '',
        hubReading: null,
        pickupEquipmentDetails: null,
        dropEquipmentDetails: null,
        comments: '',
        departureTimestamp: null,
        proNumber: '',
        weight: {
          weight: 0,
          unitOfWeightMeasurement: ''
        },
        volume: {
          volume: 0,
          unitOfVolumeMeasurement: ''
        },
        temperature: {
          temperature: 0,
          unitOfTemperatureMeasurement: ''
        }
      },
      resourceDetails: {
        type: 'Truck',
        value: 0
      },
      checkCallSourceTimestamp: 0,
      checkCallMessage: null,
      isAutoCheckCall: false,
      checkCallSource: 'MnlChkCal',
      locationDetails: null
    }
  };
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(ActivityLogService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getLoadOverview should be called', () => {
    service.getLoadOverview(0).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getLoadPlanningLoadDetail}0`);
    expect(req.request.method).toEqual('GET');
  });
  it('getResourceOverviewDetails should be called', () => {
    service.getResourceOverviewDetails(0).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getResourceLoadOverview}0`);
    expect(req.request.method).toEqual('GET');
  });
  it('getCheckCallErrors should be called', () => {
    service.getCheckCallErrors(0).subscribe();
    const req = httpTestingController.expectOne(`${service.activitylogEndpoint.getCheckCallErrors}/0`);
    expect(req.request.method).toEqual('GET');
  });
  it('getLoadedType should be called', () => {
    service.getLoadedType().subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.loadedType);
    expect(req.request.method).toEqual('GET');
  });
  it('getLoadedBy should be called', () => {
    service.getLoadedBy().subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.loadedBy);
    expect(req.request.method).toEqual('GET');
  });
  it('getCountedBy should be called', () => {
    service.getCountedBy().subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.countedBy);
    expect(req.request.method).toEqual('GET');
  });
  it('getUnitOfWeight should be called', () => {
    service.getUnitOfWeight().subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.unitOfWeight);
    expect(req.request.method).toEqual('GET');
  });
  it('getUnitOfVolume should be called', () => {
    service.getUnitOfVolume().subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.unitOfVolume);
    expect(req.request.method).toEqual('GET');
  });
  it('getUnitOfTemperature should be called', () => {
    service.getUnitOfTemperature().subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.unitOfTemperature);
    expect(req.request.method).toEqual('GET');
  });
  it('getStopServices should be called', () => {
    service.getStopServices('').subscribe();
    const req = httpTestingController.expectOne(`${service.activitylogEndpoint.stopServices}/stopservices?stopService=${''}`);
    expect(req.request.method).toEqual('GET');
  });
  it('getResourceImages should be called', () => {
    service.getResourceImages(0).subscribe();
    const req = httpTestingController.expectOne(`${service.adminEndpoint.getUserImages}/0/AD_USERID,THUMBNAIL_PHOTO`);
    expect(req.request.method).toEqual('GET');
  });
  it('getResourceOverview should be called', () => {
    service.getResourceOverview(0, '').subscribe();
    const req = httpTestingController.expectOne(`${service.resourceEndpoint.getLoadOverview}/resources/0/type/${''}`);
    expect(req.request.method).toEqual('GET');
  });
  it('getDispatchCheckCallDetails should be called', () => {
    service.getDispatchCheckCallDetails(0).subscribe();
    const req = httpTestingController.expectOne(`${service.activitylogEndpoint.viewDispatchDetails}/0`);
    expect(req.request.method).toEqual('GET');
  });
  it('getCheckCallDetails should be called', () => {
    service.getCheckCallDetails(0, '', false).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.viewActivityLogDetails}/${''}/0`);
    expect(req.request.method).toEqual('GET');
  });
  it('getCheckCallDetails should be called', () => {
    service.getCheckCallDetails(0, '', true).subscribe();
    const req = httpTestingController.expectOne(`${service.activitylogEndpoint.editCheckCallDetails}/${''}/0`);
    expect(req.request.method).toEqual('GET');
  });
  it('addArrivalLoaded should be called', () => {
    service.addArrivalLoaded(arrivalLoaded).subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.addArrivalLoaded);
    expect(req.request.method).toEqual('POST');
  });
  it('getTrailerOrContainer should be called', () => {
    service.getTrailerOrContainer({}).subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.trailerOrContainer);
    expect(req.request.method).toEqual('POST');
  });
  it('addArrivalAndUnloaded should be called', () => {
    service.addArrivalAndUnloaded(arrivalLoaded).subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.addarrivalUnloaded);
    expect(req.request.method).toEqual('POST');
  });
  it('getUnloadedDateTime should be called', () => {
    service.getUnloadedDateTime(IsLoadedEarly).subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.addUnloadedDateTime);
    expect(req.request.method).toEqual('POST');
  });
  it('getFinalDestination should be called', () => {
    service.getFinalDestination(0).subscribe();
    const req = httpTestingController.expectOne(`${service.activitylogEndpoint.finalDestination}0`);
    expect(req.request.method).toEqual('GET');
  });
  it('getEquipmentDetails should be called', () => {
    service.getEquipmentDetails(0).subscribe();
    const req = httpTestingController.expectOne(`${service.activitylogEndpoint.equipmentDetails}0?equipment=trailingEquipment`);
    expect(req.request.method).toEqual('GET');
  });
  it('getLoadRemove should be called', () => {
    service.getLoadRemove([]).subscribe();
    const req = httpTestingController.expectOne(service.activitylogEndpoint.getRemoveLoadList);
    expect(req.request.method).toEqual('PATCH');
  });
});
