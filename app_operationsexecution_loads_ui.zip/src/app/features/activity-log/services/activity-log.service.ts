import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfigService } from './../../../shared/service/app-config.service';
import { Observable } from 'rxjs';
import { LoadOverview } from '../../../features/load-details/load-details-overview/model/load-overview.interface';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import {
    ResourceImageResponse, ResourceDetails
} from '../../../features/fleet-planning/planby-resource/resource-overview/model/resource-overview.interface';

import {
    OperationalPlanStopActivityType, OperationalPlanStopActivityPartyType,
    CountedBy, UnitOfWeight, UnitOfVolume, UnitOfTemperature,
    StopServices,
    IsLoadedEarly,
    IsLoadedEarlyError
} from '../activity-log-loaded/activity-log-loaded-add/model/activity-log-loaded-add.interface';
import {
    ViewActivityLogDetails, DropEquipment, FinalDestination, ArrivalLoadedUnloaded,
    ArrivalLoaded,
    ViewDispatchDetails
} from '../models/activity-log.interface';
import { ElasticResponseModel } from '../../model/elastic-response.interface';
@Injectable({
    providedIn: 'root'
})
export class ActivityLogService {
    endpoint: any;
    adminEndpoint: any;
    activitylogEndpoint: any;
    resourceEndpoint: any;
    opertionalPlanEndpoint: any;
    constructor(private readonly http: HttpClient,
        private readonly appConfigService: AppConfigService
    ) {
        this.endpoint = appConfigService.getApi('loadDetails');
        this.activitylogEndpoint = appConfigService.getApi('activitylog');
        this.adminEndpoint = appConfigService.getApi('admin');
        this.resourceEndpoint = appConfigService.getApi('manualResourcePlanning');
        this.opertionalPlanEndpoint = appConfigService.getApi('operationalPlan');
    }
    getLoadOverview(planId: number): Observable<LoadOverview> {
        return this.http.get<LoadOverview>(`${this.endpoint.getLoadPlanningLoadDetail}${planId}`);
    }
    getResourceOverviewDetails(operationalPlanNumber: number): Observable<any> {
        return this.http.get(`${this.opertionalPlanEndpoint.getResourceLoadOverview}${operationalPlanNumber}`);
    }
    getCheckCallErrors(checkCallId: number): Observable<any> {
        return this.http.get(`${this.activitylogEndpoint.getCheckCallErrors}/${checkCallId}`);
    }
    getCheckCallDetails(operationalPlanCheckCallId: number, activityType: string, showCheckCallDetails = false):
        Observable<ViewActivityLogDetails> {
        if (showCheckCallDetails) {
            return this.http.get<ViewActivityLogDetails>(`${this.activitylogEndpoint.
                editCheckCallDetails}/${activityType}/${operationalPlanCheckCallId}`);
        } else {
            return this.http.get<ViewActivityLogDetails>(`${this.endpoint.
                viewActivityLogDetails}/${activityType}/${operationalPlanCheckCallId}`);
        }
    }
    getLoadedType(): Observable<OperationalPlanStopActivityType> {
        return this.http.get<OperationalPlanStopActivityType>(this.activitylogEndpoint.loadedType);
    }
    getLoadedBy(): Observable<OperationalPlanStopActivityPartyType> {
        return this.http.get<OperationalPlanStopActivityPartyType>(this.activitylogEndpoint.loadedBy);
    }
    getCountedBy(): Observable<CountedBy> {
        return this.http.get<CountedBy>(this.activitylogEndpoint.countedBy);
    }
    getUnitOfWeight(): Observable<UnitOfWeight> {
        return this.http.get<UnitOfWeight>(this.activitylogEndpoint.unitOfWeight);
    }
    getUnitOfVolume(): Observable<UnitOfVolume> {
        return this.http.get<UnitOfVolume>(this.activitylogEndpoint.unitOfVolume);
    }
    getUnitOfTemperature(): Observable<UnitOfTemperature> {
        return this.http.get<UnitOfTemperature>(this.activitylogEndpoint.unitOfTemperature);
    }
    getStopServices(stopService: string): Observable<StopServices> {
        return this.http.get<StopServices>(`${this.activitylogEndpoint.stopServices}/stopservices?stopService=${stopService}`);
    }
    getUnloadedDateTime(unLoadedDateTime: IsLoadedEarly): Observable<IsLoadedEarlyError> {
        return this.http.post<IsLoadedEarlyError>(this.activitylogEndpoint.addUnloadedDateTime, unLoadedDateTime);
    }
    getEquipmentDetails(equipmentId): Observable<DropEquipment[]> {
        return this.http.get<DropEquipment[]>(`${this.activitylogEndpoint.equipmentDetails}${equipmentId}?equipment=trailingEquipment`);
    }
    getFinalDestination(operationalPlanCheckCallId: number): Observable<FinalDestination> {
        return this.http.get<FinalDestination>(`${this.activitylogEndpoint.finalDestination}${operationalPlanCheckCallId}`);
    }
    addArrivalAndUnloaded(arivalUnloadedRequest: ArrivalLoadedUnloaded): Observable<any> {
        return this.http.post<any>(this.activitylogEndpoint.addarrivalUnloaded, arivalUnloadedRequest);
    }
    addArrivalLoaded(arrivalLoadedReq: ArrivalLoaded): Observable<any> {
        return this.http.post<any>(this.activitylogEndpoint.addArrivalLoaded, arrivalLoadedReq);
    }
    getResourceImages(driverId: string | number): Observable<ResourceImageResponse> {
        return this.http.get<ResourceImageResponse>(`${this.adminEndpoint.getUserImages}/${driverId}/AD_USERID,THUMBNAIL_PHOTO`);
    }
    getResourceOverview(resourceId, resourceType): Observable<ResourceDetails> {
        return this.http.get<ResourceDetails>(`${this.resourceEndpoint.getLoadOverview}/resources/${resourceId}/type/${resourceType}`);
    }
    getDispatchCheckCallDetails(operationalPlanCheckCallId: number): Observable<ViewDispatchDetails> {
        return this.http.get<ViewDispatchDetails>(`${this.activitylogEndpoint.
            viewDispatchDetails}/${operationalPlanCheckCallId}`);

    }
    getTrailerOrContainer(trailerOrContainerQuery): Observable<ElasticResponseModel> {
        return this.http.post<ElasticResponseModel>(this.activitylogEndpoint.trailerOrContainer, trailerOrContainerQuery);
    }

    getLoadRemove(loadId: number[]) {
        return this.http.patch<any>(this.activitylogEndpoint.getRemoveLoadList, loadId);
    }

}
