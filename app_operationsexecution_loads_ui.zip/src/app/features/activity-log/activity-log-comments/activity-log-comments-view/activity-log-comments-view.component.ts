import { Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { takeWhile, finalize } from 'rxjs/operators';

import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';

import { TrackingDetailsParam } from '../../models/activity-log.interface';
import { ActivityLogCommentsViewModel } from './models/activity-log-comments-view.model';
import { ViewCommentsResponse } from './models/activity-log-comments-view.interface';
import { ActivityLogCommentsViewService } from './services/activity-log-comments-view.service';
import { LoadOverview } from '../../../../features/load-details/load-details-overview/model/load-overview.interface';
import { EmailRecipientDetails } from '../activity-log-comments-add/models/activity-log-comments-add.interface';
import { ViewCommentsQuery } from './query/view-comments-query';

@Component({
  selector: 'app-activity-log-comments-view',
  templateUrl: './activity-log-comments-view.component.html',
  styleUrls: ['./activity-log-comments-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogCommentsViewComponent implements OnInit, OnDestroy {
  @Input() set commentNumber(commentNumber) {
    if (commentNumber) {
      this.activityLogCommentsViewModel.commentNumber = commentNumber;
      this.getViewComments();

    }
  }
  @Input() set loadNumber(loadNumber) {
    if (loadNumber) {
      this.activityLogCommentsViewModel.loadNumber = loadNumber;
    }
  }
  @Input() set loadedDetails(loadOverviewDetails: LoadOverview) {
    if (loadOverviewDetails) {
      this.activityLogCommentsViewModel.loadOverview = loadOverviewDetails;
    }
  }
  activityLogCommentsViewModel: ActivityLogCommentsViewModel;
  constructor(private readonly changeDetector: ChangeDetectorRef, private readonly localStorageService: LocalStorageService,
    private readonly activityLogCommentsViewService: ActivityLogCommentsViewService,
    private readonly router: Router) {
    this.activityLogCommentsViewModel = new ActivityLogCommentsViewModel();
  }

  ngOnInit() {
    this.activityLogCommentsViewModel.isTracking = this.router.url && this.router.url.indexOf('/trackingdetails') !== -1;
  }

  ngOnDestroy() {
    this.activityLogCommentsViewModel.subscribeFlag = false;
  }

  navigateBack() {
    if (this.activityLogCommentsViewModel.isTracking) {
      const params = this.localStorageService.getItem('TrackingDetails', 'param');
      this.router.navigate(['/trackingdetails'],
        {
          queryParams: {
            'driverId': this.queryParamNullCheck(params, 'driverId'),
            'equipmentId': this.queryParamNullCheck(params, 'equipmentId'),
            'loadNumber': this.queryParamNullCheck(params, 'loadNumber'),
            'equipmentNumber': this.queryParamNullCheck(params, 'equipmentNumber'),
            'index': 1
          }
        });
    } else {
      if (this.activityLogCommentsViewModel.loadNumber) {
        this.router.navigate([`loaddetails/${this.activityLogCommentsViewModel.loadNumber}`],
          {
            queryParams: {
              index: 2
            }
          });
      } else {
        this.router.navigate(['/loaddetails']);

      }
    }
  }
  queryParamNullCheck(queryParam: TrackingDetailsParam, paramName: string): string {
    return queryParam && queryParam[paramName] ? queryParam[paramName] : '';
  }
  getViewComments() {
    this.activityLogCommentsViewService.getViewComments(this.activityLogCommentsViewModel.commentNumber)
      .pipe(takeWhile(() => this.activityLogCommentsViewModel.subscribeFlag
      ), finalize(() => this.changeDetector.detectChanges())).subscribe((viewResponse: ViewCommentsResponse) => {
        if (viewResponse) {
          this.activityLogCommentsViewModel.viewDetails = viewResponse;
          if (viewResponse.personList && viewResponse.personList.length > 0) {
            this.checkIdandPopulateValues(viewResponse.personList);
          }
        }
      });
  }

  checkIdandPopulateValues(personList: EmailRecipientDetails[]) {
    this.activityLogCommentsViewModel.customMailList = personList.filter(value => {
      return value.personId === null || value.personId === '';
    });
    const personIdList = personList.map(value => {
      if (value.personId !== null || value.personId === '' || value.personId !== undefined) {
        return value.userId;
      }
    });
    this.populateEmailDetails(personIdList.join(' '));
  }

  populateEmailDetails(searchIds) {
    this.activityLogCommentsViewService.getResourceDetails(ViewCommentsQuery.frameResourcesQuery(searchIds))
      .pipe(takeWhile(() => this.activityLogCommentsViewModel.subscribeFlag
      ), finalize(() => this.changeDetector.detectChanges())).subscribe((data) => {
        if (data && data['hits'] && data['hits']['hits'] && data['hits']['hits'].length > 0) {
          this.checkForRoleType(data['hits']['hits']);
        }
      });
  }

  checkForRoleType(sourceArray) {
    sourceArray.forEach(userValue => {
      if (userValue._source.roles && userValue._source.roles.length > 0 &&
        userValue._source.roles[0].roleTypeCode.toLowerCase() === 'orderowner') {
        const emailDetails = this.frameEmailObject(userValue._source);
        this.activityLogCommentsViewModel.orderOwnerList.push(emailDetails);
      } else if (userValue._source.roles && userValue._source.roles.length === 0) {
        const emailDetails = this.frameEmailObject(userValue._source);
        this.activityLogCommentsViewModel.fleetMgrList.push(emailDetails);
      }
    });
  }

  frameEmailObject(userValue) {
    return {
      'personId': userValue.personDTO.emplId ? userValue.personDTO.emplId : '',
      'emailId': userValue.personDTO.email ? userValue.personDTO.email : '',
      'firstName': userValue.personDTO.firstName ? userValue.personDTO.firstName : '',
      'lastName': userValue.personDTO.lastName ? userValue.personDTO.lastName : '',
      'userId': userValue.personDTO.userId ? userValue.personDTO.userId : ''
    };
  }

}

