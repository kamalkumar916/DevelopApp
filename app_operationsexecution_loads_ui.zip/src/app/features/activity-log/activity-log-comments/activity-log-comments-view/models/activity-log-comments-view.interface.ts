export interface ViewCommentsResponse {
    operationalPlanId: number;
    temperature: number;
    unitOfMeasurementCode: string;
    comment: string;
    isLoadComment: boolean;
    personList: any[];

}
