import { ViewCommentsResponse } from './activity-log-comments-view.interface';
import { LoadOverview } from '../../../../../features/load-details/load-details-overview/model/load-overview.interface';
import { EmailRecipientDetails } from '../../activity-log-comments-add/models/activity-log-comments-add.interface';

export class ActivityLogCommentsViewModel {
    subscribeFlag: boolean;
    commentNumber: string;
    loadNumber: string;
    viewDetails: ViewCommentsResponse;
    isTracking: boolean;
    loadOverview: LoadOverview;
    fleetMgrList: EmailRecipientDetails[];
    orderOwnerList: EmailRecipientDetails[];
    customMailList: EmailRecipientDetails[];

    constructor() {
        this.subscribeFlag = true;
        this.viewDetails = null;
        this.fleetMgrList = [];
        this.orderOwnerList = [];
        this.customMailList = [];
    }
}
