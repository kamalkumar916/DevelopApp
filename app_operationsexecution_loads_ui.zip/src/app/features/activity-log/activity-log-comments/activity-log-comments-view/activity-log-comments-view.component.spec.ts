import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { MessageService } from 'primeng/components/common/messageservice';
import { configureTestSuite } from 'ng-bullet';
import { Router } from '@angular/router';

import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { ActivityLogCommentsViewComponent } from './activity-log-comments-view.component';
import { ActivityLogCommentsViewService } from './services/activity-log-comments-view.service';
import { of } from 'rxjs/internal/observable/of';

const commentNumber = 1;
const loadNumber = 12345;
const numberPrefixTypeDTO = {
  prefix: '',
  number: '',
  typeRequired: ''
};
const trailer = {
  prefix: '',
  number: '',
  typeRequired: false,
  length: 0,
  isLengthRequired: false,
  isPreLoaded: false,
  category: '',
  type: ''
};
const loadOverviewDetails = {
  operationalPlanId: 0,
  operationalPlanNumber: '',
  operationalPlanType: {
    operationalPlanTypeCode: '',
    operationalPlanTypeDescription: ''
  },
  operationalPlanSubtype: {
    operationalPlanSubtypeCode: '',
    operationalPlanSubtypeDescription: ''
  },
  operationalPlanStatus: {
    operationalPlanStatusCode: '',
    operationalPlanStatusDescription: ''
  },
  operationalPlanServiceOfferingCode: '',
  operationalPlanTransitModeCode: '',
  operationalPlanFinanceBusinessUnitCode: '',
  desirabilityIndexNumber: 0,
  resource: '',
  truck: '',
  requiredEquipment: '',
  trailer: '',
  container: '',
  chassis: '',
  classifications: [],
  loadedMilesWithUnit: '',
  loadedMiles: '',
  emptyMiles: '',
  estimatedTotalMiles: '',
  items: '',
  totalWeight: '',
  requestedService: [],
  estimatedTimeOfCompletion: '',
  routeSequenceNumber: '',
  totalRouteSequenceNumber: '',
  routePlanId: '',
  routeId: '',
  payRoute: [],
  utilization: null,
  totalPointsQuantity: '',
  networkOperationalPlanIndicator: '',
  externalOperationalPlanBoardIndicator: '',
  bulkProcessIndicator: '',
  operationalGroupCode: '',
  customerRate: [],
  tripPlanTransitValue: '',
  operationalPlanStopDTOs: null,
  billTo: [],
  operationalPlanOwnershipDTOs: [],
  equipmentDetails: {
    isPreLoaded: false,
    truck: numberPrefixTypeDTO,
    chassis: numberPrefixTypeDTO,
    container: numberPrefixTypeDTO,
    trailer: trailer,
    currentTrailer: trailer,
    driverId: 0,
    equipmentId: 0,
    alphaCode: '',
    firstName: '',
    lastName: '',
    middleName: '',
    resourceName: '',
    tanker: numberPrefixTypeDTO,
    hopper: numberPrefixTypeDTO
  },
  operationalPlanRouteGuideStatus: {
    operationalPlanRouteGuideStatusCode: '',
    operationalPlanRouteGuideStatusDescription: ''
  },
  servicePriorityCode: '',
  committedFreightIndicator: '',
  shipmentId: [],
  payRouteLists: [],
  jbhuntFailureCount: 0,
  operationalPlanOrderIds: {}
};
const getViewCommentsData = {
  operationalPlanId: 12345,
  temperature: 0,
  unitOfMeasurementCode: '',
  comment: '',
  isLoadComment: false,
  personList: [{
    personId: '',
    emailId: '',
    firstName: '',
    lastName: '',
    preferedName: '',
    userId: '',
    isValidFlag: false,
    emailRecipientType: ''
  }]
};
const getResourceDetailsData = {
  hits: {
    hits: [{
      sort: [],
      _id: '',
      _index: '',
      _score: null,
      _source: {},
      _type: '',
    }],
    max_score: null,
    total: null
  },
  timed_out: true,
  took: null,
  _shards: {
    total: null,
    successful: null,
    skipped: null,
    failed: null
  },
  aggregations: null
};
class MockActivityLogCommentsViewService {
  constructor() { }
  getViewComments(cmtNumber) {
    return of(getViewCommentsData);
  }
  getResourceDetails(query) {
    return of(getResourceDetailsData);
  }
}

describe('ActivityLogCommentsViewComponent', () => {
  let component: ActivityLogCommentsViewComponent;
  let fixture: ComponentFixture<ActivityLogCommentsViewComponent>;
  let router: Router;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, PipesModule, RouterTestingModule.withRoutes([])],
      providers: [LocalStorageService, UserService, AppConfigService, MessageService,
        { provide: ActivityLogCommentsViewService, useClass: MockActivityLogCommentsViewService }],
      declarations: [ActivityLogCommentsViewComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogCommentsViewComponent);
    router = TestBed.get(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Input commentNumber should call the spy getViewComments', () => {
    spyOn(component, 'getViewComments');
    component.commentNumber = commentNumber;
    expect(component.getViewComments).toHaveBeenCalled();
  });

  it('Input loadedDetails should call the spy getViewComments', () => {
    spyOn(component, 'getViewComments');
    component.loadedDetails = loadOverviewDetails;
    expect(component.activityLogCommentsViewModel.loadOverview).toBeDefined();
  });

  it('ActivityLogCommentsViewComponent navigateBack should be called with loadNumber', () => {
    component.loadNumber = loadNumber;
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateBack();
    expect(navigateSpy).toHaveBeenCalledWith(['loaddetails/12345'],
      {
        queryParams: {
          index: 2
        }
      });
  });

  it('ActivityLogCommentsViewComponent navigateBack should be called ', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateBack();
    expect(navigateSpy).toHaveBeenCalledWith(['/loaddetails']);
  });

  it('ActivityLogCommentsViewComponent navigateBack should be called with isTracking', () => {
    const localStorageService: LocalStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'getItem').and.returnValue({ driverId: '', equipmentId: 12345, loadNumber: 12345, equipmentNumber: 12345 });
    component.activityLogCommentsViewModel.isTracking = true;
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateBack();
    expect(navigateSpy).toHaveBeenCalledWith(['/trackingdetails'],
      {
        queryParams: {
          'driverId': '',
          'equipmentId': 12345,
          'loadNumber': 12345,
          'equipmentNumber': 12345,
          'index': 1
        }
      });
  });

  it('getViewComments should call the spy checkIdandPopulateValues', () => {
    spyOn(component, 'checkIdandPopulateValues');
    component.getViewComments();
    expect(component.checkIdandPopulateValues).toHaveBeenCalled();
  });

  it('checkIdandPopulateValues is called with personId as null', () => {
    spyOn(component, 'populateEmailDetails');
    const data = [{
      personId: null,
      emailId: '',
      firstName: '',
      lastName: '',
      preferedName: '',
      userId: '',
      isValidFlag: false,
      emailRecipientType: ''
    }];
    component.checkIdandPopulateValues(data);
    expect(component.populateEmailDetails).toHaveBeenCalled();
  });

  it('checkIdandPopulateValues is called with personId as empty string', () => {
    spyOn(component, 'populateEmailDetails');
    const data = [{
      personId: '',
      emailId: '',
      firstName: '',
      lastName: '',
      preferedName: '',
      userId: '',
      isValidFlag: false,
      emailRecipientType: ''
    }];
    component.checkIdandPopulateValues(data);
    expect(component.populateEmailDetails).toHaveBeenCalled();
  });

  it('populateEmailDetails should call the spy checkForRoleType', () => {
    spyOn(component, 'checkForRoleType');
    component.populateEmailDetails(null);
    expect(component.checkForRoleType).toHaveBeenCalled();
  });

  it('checkForRoleType should insert one object into orderOwnerList array', () => {
    component.activityLogCommentsViewModel.orderOwnerList = [];
    const data = [{
      sort: [],
      _id: '',
      _index: '',
      _score: null,
      _source: {
        roles: [{
          roleTypeCode: 'orderowner'
        }],
        personDTO: {
          emplId: '',
          email: '',
          firstName: '',
          lastName: '',
          userId: ''
        }
      },
      _type: '',
    }];
    component.checkForRoleType(data);
    expect(component.activityLogCommentsViewModel.orderOwnerList.length).toEqual(1);
  });

  it('checkForRoleType should call the spy frameEmailObject', () => {
    spyOn(component, 'frameEmailObject').and.callThrough();
    component.activityLogCommentsViewModel.fleetMgrList = [];
    const data = [{
      sort: [],
      _id: '',
      _index: '',
      _score: null,
      _source: {
        roles: [],
        personDTO: {
          emplId: '1',
          email: 'abc',
          firstName: 'a',
          lastName: 'c',
          userId: '1'
        }
      },
      _type: '',
    }];
    component.checkForRoleType(data);
    expect(component.frameEmailObject).toHaveBeenCalled();
  });

});
