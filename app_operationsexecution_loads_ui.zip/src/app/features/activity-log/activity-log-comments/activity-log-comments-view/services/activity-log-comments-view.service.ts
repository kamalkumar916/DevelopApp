import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ViewCommentsResponse } from '../models/activity-log-comments-view.interface';
import { ElasticResponseModel } from '../../../../model/elastic-response.interface';

@Injectable({
  providedIn: 'root'
})
export class ActivityLogCommentsViewService {
  endpoint: any;

  constructor(private readonly http: HttpClient,
    private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('activitylog');
  }

  getViewComments(commentNumber): Observable<ViewCommentsResponse> {
    return this.http.get<ViewCommentsResponse>(`${this.endpoint.getViewComments}/${commentNumber}`);
  }

  getResourceDetails(queryParam: object): Observable<ElasticResponseModel> {
    return this.http.post<ElasticResponseModel>(this.endpoint.getResourceDetails, queryParam);
  }
}
