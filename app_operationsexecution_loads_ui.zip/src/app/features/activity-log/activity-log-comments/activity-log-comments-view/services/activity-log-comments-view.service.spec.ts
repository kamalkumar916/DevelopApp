import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogCommentsViewService } from './activity-log-comments-view.service';
import { configureTestSuite } from 'ng-bullet';

describe('ActivityLogCommentsViewService', () => {
  let service: ActivityLogCommentsViewService;
  let httpTestingController: HttpTestingController;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogCommentsViewService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(ActivityLogCommentsViewService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getViewComments should be called', () => {
    service.getViewComments('').subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getViewComments}/${''}`);
    expect(req.request.method).toEqual('GET');
  });
  it('getResourceDetails should be called', () => {
    service.getResourceDetails({}).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.getResourceDetails);
    expect(req.request.method).toEqual('POST');
  });
});
