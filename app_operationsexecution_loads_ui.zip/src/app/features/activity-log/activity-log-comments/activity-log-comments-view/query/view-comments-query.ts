export class ViewCommentsQuery {

    static frameResourcesQuery(personIds: string): object {

        return {
            '_source': ['personDTO', 'roles'],
            'from': 0,
            'size': 100,
            'query': {
                'bool': {
                    'must': [
                        {
                            'query_string': {
                                'default_field': 'userID',
                                'query': personIds
                            }
                        }
                    ]
                }
            }
        };
    }
}
