import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AppConfigService } from '../../../../../shared/service/app-config.service';
import { ActivityLogCommentsAddService } from './activity-log-comments-add.service';
import { configureTestSuite } from 'ng-bullet';

describe('ActivityLogCommentsAddService', () => {
  let service: ActivityLogCommentsAddService;
  let httpTestingController: HttpTestingController;
  const saveRequestObject = {
    operationalPlanId: 0,
    temperature: '',
    unitOfMeasurementCode: '',
    comment: '',
    isLoadComment: false,
    personId: '',
    personList: []
  };
  const utilityServiceObject = {
    _embedded: {
      unitOfTemperatureMeasurements: [{
        lastUpdateTimestampString: '',
        unitOfTemperatureMeasurementCode: 'Celcius',
        unitOfTemperatureMeasurementDescription: '',
        _links: {
          self: {
            href: ''
          },
          unitOfTemperatureMeasurements: {
            href: ''
          }
        }
      }]
    },
    _links: {
      self: {
        href: '',
        templated: false
      },
      profile: {
        href: ''
      },
    },
    page: {
      size: 0,
      totalElements: 0,
      totalPages: 0,
      number: 0
    }
  };
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ActivityLogCommentsAddService, AppConfigService]
    });
  });
  beforeEach(() => {
    service = TestBed.get(ActivityLogCommentsAddService);
    httpTestingController = TestBed.get(HttpTestingController);
  });
  afterEach(() => {
    httpTestingController.verify();
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getTemperatureUnitsList should be called', () => {
    service.getTemperatureUnitsList().subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.unitOfTemperature}`);
    expect(req.request.method).toEqual('GET');
  });
  it('getFleetMgrList should be called', () => {
    service.getFleetMgrList('').subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getFleetMgrList}/${''}`);
    expect(req.request.method).toEqual('GET');
  });
  it('getOrderOwnerList should be called', () => {
    service.getOrderOwnerList(0).subscribe();
    const req = httpTestingController.expectOne(`${service.endpoint.getOrderOwnerList}/0`);
    expect(req.request.method).toEqual('GET');
  });
  it('saveAddComment should be called', () => {
    service.saveAddComment(saveRequestObject).subscribe();
    const req = httpTestingController.expectOne(service.endpoint.saveComment);
    expect(req.request.method).toEqual('POST');
  });
  it('setTemperatureUnitsList should be called', () => {
    spyOn(service, 'setUnitFirstCharacter').and.callThrough();
    const expectedResponse = [{
      label: 'Unit', value: null
    }, {
      label: 'C', value: 'Celcius'
    }];
    const res = service.setTemperatureUnitsList(utilityServiceObject);
    expect(res).toEqual(expectedResponse);
  });

});
