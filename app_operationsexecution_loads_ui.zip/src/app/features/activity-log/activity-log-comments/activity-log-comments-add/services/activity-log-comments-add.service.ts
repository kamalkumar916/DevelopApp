import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { EmailRecipientDetails, SaveRequestModel, UtilityServiceModel } from '../models/activity-log-comments-add.interface';
import { AppConfigService } from '../../../../../shared/service/app-config.service';

@Injectable({
  providedIn: 'root'
})
export class ActivityLogCommentsAddService {
  endpoint: any;

  constructor(private readonly http: HttpClient, private readonly appConfigService: AppConfigService) {
    this.endpoint = appConfigService.getApi('activitylog');
  }
  getTemperatureUnitsList(): Observable<UtilityServiceModel> {
    return this.http.get<any>(this.endpoint.unitOfTemperature);
  }
  saveAddComment(data: SaveRequestModel): Observable<any> {
    return this.http.post<any>(this.endpoint.saveComment, data);
  }
  setTemperatureUnitsList(data: UtilityServiceModel) {
    const temperatureUnits = [
      { label: 'Unit', value: null }
    ];
    if (data && data._embedded && data._embedded.unitOfTemperatureMeasurements) {
      data._embedded.unitOfTemperatureMeasurements.forEach(element => {
        if (element.unitOfTemperatureMeasurementCode) {
          temperatureUnits.push({
            label: this.setUnitFirstCharacter(element.unitOfTemperatureMeasurementCode),
            value: element.unitOfTemperatureMeasurementCode
          });
        }
      });
    }
    return temperatureUnits;
  }

  setUnitFirstCharacter(unit: string): string {
    return unit.slice(0, 1);
  }

  getFleetMgrList(fleetId: string): Observable<EmailRecipientDetails> {
    return this.http.get<any>(`${this.endpoint.getFleetMgrList}/${fleetId}`);
  }

  getOrderOwnerList(loadId: number): Observable<EmailRecipientDetails[]> {
    return this.http.get<any>(`${this.endpoint.getOrderOwnerList}/${loadId}`);
  }

}
