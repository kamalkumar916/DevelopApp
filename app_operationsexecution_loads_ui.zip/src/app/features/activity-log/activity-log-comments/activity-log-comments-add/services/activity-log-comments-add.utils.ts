import {
  Person, EmailPreviewDetails, EmailPreviewStopDetails, EmailRecipientDetails,
  ResourceOverviewDetails
} from '../models/activity-log-comments-add.interface';
import { Utils } from '../../../../../shared/jbh-app-services/utils';

export class ActivityLogCommentsAddUtils {

  static setEmailPreviewFields(response, resourceResponse): EmailPreviewDetails {
    if (response) {
      return {
        driver: (resourceResponse) ? Utils.standardDriverNameFormat(resourceResponse) : '---',
        truck: (resourceResponse) ? ActivityLogCommentsAddUtils.setTruckNumber(resourceResponse) : '---',
        businessUnit: ActivityLogCommentsAddUtils.setNullValue(response.operationalPlanFinanceBusinessUnitCode),
        serviceOffering: ActivityLogCommentsAddUtils.setNullValue(response.operationalPlanServiceOfferingCode),
        businessUnitServiceOffering: ActivityLogCommentsAddUtils.setBusinessUnitServiceOfferingField(
          response.operationalPlanFinanceBusinessUnitCode, response.operationalPlanServiceOfferingCode),
        shipmentId: response.shipmentId && response.shipmentId.length ? response.shipmentId : '---'
      };
    } else {
      return {
        driver: (resourceResponse) ? Utils.standardDriverNameFormat(resourceResponse) : '---',
        truck: (resourceResponse) ? ActivityLogCommentsAddUtils.setTruckNumber(resourceResponse) : '---',
        businessUnit: '',
        serviceOffering: '',
        businessUnitServiceOffering: '---',
        shipmentId: '---',
      };
    }
  }
  static setNullValue(fieldValue): string {
    return fieldValue ? fieldValue : '';
  }
  static setDetaultValue(field): string {
    return field ? field : '---';
  }
  static setBusinessUnitServiceOfferingField(businessUnit, serviceOffering): string {
    return ((businessUnit && serviceOffering) ? ` - ${serviceOffering}` : (serviceOffering ? serviceOffering : '---'));
  }
  static setTruckNumber(response: ResourceOverviewDetails): string {
    return (response.truck) ? response.truck : '---';
  }
  static formatLocation(locationDetail: object): string {
    let location = '';
    if (locationDetail) {
      location = locationDetail['locationName'] ? `${locationDetail['locationName']}, ` : '';
      location += locationDetail['locationCode'] ? `(${locationDetail['locationCode']}) ` : '';
    }
    return location;
  }
  static formatAddressDetails(addressDetails): string {
    let address = '';
    if (addressDetails) {
      address += addressDetails['address']['addressLine1'] ? `${addressDetails['address']['addressLine1']} ` : '';
      address += addressDetails['address']['addressLine2'] ? `${addressDetails['address']['addressLine2']}, ` : '';
    }
    return address;
  }
  static formatCountryAdressDetails(addressDetails): string {
    let countryAddress = '';
    if (addressDetails) {
      countryAddress += addressDetails['address']['city'] ? `${addressDetails['address']['city']}, ` : '';
      countryAddress += addressDetails['address']['state'] ? `${addressDetails['address']['state']} ` : '';
      countryAddress += addressDetails['address']['zipcode'] ? `${addressDetails['address']['zipcode']} ` : '';
      countryAddress += addressDetails['address']['country'] ? `${addressDetails['address']['country']}` : '';
    }
    return countryAddress;
  }
  static formatContactDetails(contact: Person): string {
    let contactStr = '';
    if (contact) {
      contactStr += (contact.firstName) ? contact.firstName : '';
      contactStr += (contact.lastName) ? ` ${contact.lastName}` : '';
      contactStr += (contact.telephoneNumber) ? ` ${contact.telephoneNumber}` : '';
      contactStr += (contact.contactExtension) ? ` ${contact.contactExtension}` : '';
    }
    return contactStr;
  }
  static setHeaderValue(stopListLength: number, sequenceNumber: number): string {
    return (sequenceNumber === 1) ? 'Origin' : this.stopSequenceNumberFormatter(sequenceNumber, stopListLength);
  }
  static setHeaderHintValue(operationalPlanStopReasonCode): string {
    return operationalPlanStopReasonCode ? ` (${operationalPlanStopReasonCode})` : '';
  }

  static stopSequenceNumberFormatter(stopSequenceNumber: number, stopListLength: number): string {
    return (stopSequenceNumber === stopListLength) ? `Destination` : `Stop ${stopSequenceNumber}`;
  }
  static formatLoadNumbers(orderNumberList: number[]): number[] {
    return (orderNumberList && orderNumberList.length) ? orderNumberList : [];
  }
  static constructDefaultEmailPreviewStop(): EmailPreviewStopDetails[] {
    return [{
      header: 'Origin',
      headerHint: '',
      planStopSequenceNumber: '1',
      stopIndex: null,
      appointmentDate: '---',
      locationDetail: '',
      addressDetail: '',
      zipCodeDetail: '',
      contactDetail: '---',
      orderNumbers: []
    }];
  }

  static customEmailValidator(emailAddress: string): boolean {
    const emailFormat = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/i;
    return emailFormat.test(emailAddress);
  }

  static mapEmailOrderOwnerDetails(response: EmailRecipientDetails[], recipientType: string): EmailRecipientDetails[] {
    return response.map((data) => {
      return this.mapEmailFleetMgrDetails(data, recipientType);
    });
  }

  static mapEmailFleetMgrDetails(data: EmailRecipientDetails, recipientType: string): EmailRecipientDetails {
    return {
      personId: data['personId'] ? data['personId'] : null,
      emailId: data['emailId'] ? data['emailId'] : '',
      firstName: data['firstName'] ? data['firstName'] : '',
      lastName: data['lastName'] ? data['lastName'] : '',
      userId: data['userId'] ? data['userId'] : '',
      isValidFlag: true,
      emailRecipientType: recipientType
    };
  }

  static frameFinalPersonList(emailList: EmailRecipientDetails[]): EmailRecipientDetails[] {
    return emailList.map((data) => {
      return {
        personId: data['personId'] ? data['personId'] : null,
        emailId: data['emailId'] ? data['emailId'] : '',
        firstName: data['firstName'] ? data['firstName'] : '',
        lastName: data['lastName'] ? data['lastName'] : '',
        userId: data['userId'] ? data['userId'] : '',
      };
    });
  }


}
