import { ActivityLogCommentsAddUtils } from './activity-log-comments-add.utils';

describe('ActivityLogCommentsAddUtils', () => {
    it('should be created', () => {
        expect(ActivityLogCommentsAddUtils).toBeTruthy();
    });
    it('setNullValue have been called', () => {
        const call = ActivityLogCommentsAddUtils.setNullValue('test');
        expect(call).toBeDefined();
    });
    it('setNullValue Null case have been called', () => {
        const call = ActivityLogCommentsAddUtils.setNullValue('');
        expect(call).toBeDefined();
    });
    it('setDetaultValue have been called', () => {
        const call = ActivityLogCommentsAddUtils.setDetaultValue('test');
        expect(call).toBeDefined();
    });
    it('setDetaultValue Null case have been called', () => {
        const call = ActivityLogCommentsAddUtils.setDetaultValue('');
        expect(call).toBeDefined();
    });
    it('setBusinessUnitServiceOfferingField have been called', () => {
        const call = ActivityLogCommentsAddUtils.setBusinessUnitServiceOfferingField('test', 'test1');
        expect(call).toBeDefined();
    });
    it('setBusinessUnitServiceOfferingField Null case have been called', () => {
        const call = ActivityLogCommentsAddUtils.setBusinessUnitServiceOfferingField('', '');
        expect(call).toBeDefined();
    });
    it('setTruckNumber  have been called', () => {
        const responseData = {
            alphaCode: 'tes',
            lastName: 'jbh',
            firstName: 'test',
            preferredName: 'test',
            truck: 'test',
        };
        const call = ActivityLogCommentsAddUtils.setTruckNumber(responseData);
        expect(call).toBeDefined();
    });
    it('setTruckNumber Null case have been called', () => {
        const responseData = {
            alphaCode: 'tes',
            lastName: 'jbh',
            firstName: 'test',
            preferredName: 'test',
            truck: '',
        };
        const call = ActivityLogCommentsAddUtils.setTruckNumber(responseData);
        expect(call).toBeDefined();
    });
    it('formatLocation have been called', () => {
        const locationData = {
            locationName: 'chennai',
            locationCode: 'chn',
        };
        const call = ActivityLogCommentsAddUtils.formatLocation(locationData);
        expect(call).toBeDefined();
    });
    it('formatLocation Null case have been called', () => {
        const locationData = {
            locationName: '',
            locationCode: '',
        };
        const call = ActivityLogCommentsAddUtils.formatLocation(locationData);
        expect(call).toBeDefined();
    });
    it('formatAddressDetails  have been called', () => {
        const addressData = {
            address: {
                addressLine1: 'test',
                addressLine2: 'test1'
            },
        };
        const call = ActivityLogCommentsAddUtils.formatAddressDetails(addressData);
        expect(call).toBeDefined();
    });
    it('formatAddressDetails Null case have been called', () => {
        const addressData = {
            address: {
                addressLine1: '',
                addressLine2: ''
            },
        };
        const call = ActivityLogCommentsAddUtils.formatAddressDetails(addressData);
        expect(call).toBeDefined();
    });
    it('formatCountryAdressDetails have been called', () => {
        const addressData = {
            address: {
                city: 'chennai',
                state: 'Tamil nadu',
                zipcode: '632114',
                country: 'india'
            },
        };
        const call = ActivityLogCommentsAddUtils.formatCountryAdressDetails(addressData);
        expect(call).toBeDefined();
    });
    it('formatCountryAdressDetails Null case have been called', () => {
        const addressData = {
            address: {
                city: '',
                state: '',
                zipcode: '',
                country: ''
            },
        };
        const call = ActivityLogCommentsAddUtils.formatCountryAdressDetails(addressData);
        expect(call).toBeDefined();
    });
    it('formatContactDetails have been called', () => {
        const contactData = {
            firstName: 'test',
            lastName: 'test1',
            contactExtension: 'test2',
            telephoneNumber: 'test3'
        };
        const call = ActivityLogCommentsAddUtils.formatContactDetails(contactData);
        expect(call).toBeDefined();
    });
    it('formatContactDetails Null case have been called', () => {
        const contactData = {
            firstName: '',
            lastName: '',
            contactExtension: '',
            telephoneNumber: ''
        };
        const call = ActivityLogCommentsAddUtils.formatContactDetails(contactData);
        expect(call).toBeDefined();
    });
    it('setHeaderValue have been called', () => {
        spyOn(ActivityLogCommentsAddUtils, 'stopSequenceNumberFormatter');
        const call = ActivityLogCommentsAddUtils.setHeaderValue(123, 1);
        expect(call).toBeDefined();
    });
    it('setHeaderValue second case have been called', () => {
        spyOn(ActivityLogCommentsAddUtils, 'stopSequenceNumberFormatter').and.returnValue('stop 1');
        const call = ActivityLogCommentsAddUtils.setHeaderValue(123, 12);
        expect(call).toBeDefined();
    });
    it('setHeaderHintValue  have been called', () => {
        const call = ActivityLogCommentsAddUtils.setHeaderHintValue('test');
        expect(call).toBeDefined();
    });
    it('setHeaderHintValue Null case have been called', () => {
        const call = ActivityLogCommentsAddUtils.setHeaderHintValue('');
        expect(call).toBeDefined();
    });
    it('stopSequenceNumberFormatter  have been called', () => {
        const call = ActivityLogCommentsAddUtils.stopSequenceNumberFormatter(1, 1);
        expect(call).toBeDefined();
    });
    it('stopSequenceNumberFormatter null case have been called', () => {
        const call = ActivityLogCommentsAddUtils.stopSequenceNumberFormatter(0, 1);
        expect(call).toBeDefined();
    });
    it('formatLoadNumbers  have been called', () => {
        const call = ActivityLogCommentsAddUtils.formatLoadNumbers([12, 11]);
        expect(call).toBeDefined();
    });
    it('formatLoadNumbers Null case have been called', () => {
        const call = ActivityLogCommentsAddUtils.formatLoadNumbers([]);
        expect(call).toBeDefined();
    });
    it('constructDefaultEmailPreviewStop have been called', () => {
        const call = ActivityLogCommentsAddUtils.constructDefaultEmailPreviewStop();
        expect(call).toBeDefined();
    });
    it('customEmailValidator have been called', () => {
        const call = ActivityLogCommentsAddUtils.customEmailValidator('test');
        expect(call).toBeDefined();
    });
    it('mapEmailOrderOwnerDetails have been called', () => {
        const responseData = [{
            personId: 'test',
            emailId: 'test',
            firstName: 'test',
            lastName: 'test',
            preferedName: 'test',
            userId: 'test',
            isValidFlag: true,
            emailRecipientType: 'test',
        }];
        spyOn(ActivityLogCommentsAddUtils, 'mapEmailFleetMgrDetails');
        const call = ActivityLogCommentsAddUtils.mapEmailOrderOwnerDetails(responseData, 'test');
        expect(call).toBeDefined();
    });
    it('mapEmailFleetMgrDetails have been called', () => {
        const responseData = {
            personId: 'test',
            emailId: 'test',
            firstName: 'test',
            lastName: 'test',
            preferedName: 'test',
            userId: 'test',
            isValidFlag: true,
            emailRecipientType: 'test',
        };
        const call = ActivityLogCommentsAddUtils.mapEmailFleetMgrDetails(responseData, 'test');
        expect(call).toBeDefined();
    });
    it('frameFinalPersonList have been called', () => {
        const responseData = [{
            personId: 'test',
            emailId: 'test',
            firstName: 'test',
            lastName: 'test',
            preferedName: 'test',
            userId: 'test',
            isValidFlag: true,
            emailRecipientType: 'test',
        }];
        const call = ActivityLogCommentsAddUtils.frameFinalPersonList(responseData);
        expect(call).toBeDefined();
    });


});
