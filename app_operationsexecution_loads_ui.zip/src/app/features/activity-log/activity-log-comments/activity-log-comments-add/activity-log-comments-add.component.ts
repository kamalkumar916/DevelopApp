import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef, Input } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { takeWhile, finalize } from 'rxjs/operators';
import * as moment from 'moment-timezone';
import { uniq, uniqBy } from 'lodash';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';

import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { Utils } from '../../../../shared/jbh-app-services/utils';
import { DateUtils } from '../../../../shared/jbh-app-services/date-utils';
import { TrackingDetailsParam } from '../../models/activity-log.interface';
import { ActivityLogCommentsAddModel } from './models/activity-log-comments-add.model';
import { ActivityLogCommentsAddService } from './services/activity-log-comments-add.service';
import { ActivityLogCommentsAddUtils } from './services/activity-log-comments-add.utils';
import { LoadDetailsService } from '../../../../features/load-details/services/load-details.service';
import { UserService } from '../../../../shared/jbh-esa/index';
import {
  OperationalPlanStopAppointment, SaveRequestModel,
  EmailPreviewUserDetails, EmailPreviewStopDetails,
  EmailRecipientDetails, LocationDetailsDTO, ResourceOverviewDetails
} from './models/activity-log-comments-add.interface';
import { LoadOverview } from '../../../../features/load-details/load-details-overview/model/load-overview.interface';


@Component({
  selector: 'app-activity-log-comments-add',
  templateUrl: './activity-log-comments-add.component.html',
  styleUrls: ['./activity-log-comments-add.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivityLogCommentsAddComponent implements OnInit, OnDestroy {
  @Input() set loadNumber(loadNumber: number) {
    this.activityLogCommentsAddModel.addCommentLoadNumber = loadNumber;
  }

  @Input() set loadedDetails(loadOverviewDetails: LoadOverview) {
    if (loadOverviewDetails) {
      this.activityLogCommentsAddModel.loadOverview = loadOverviewDetails;
      this.activityLogCommentsAddModel.loadOverviewStops = loadOverviewDetails.operationalPlanStopDTOs;
      this.activityLogCommentsAddModel.loadOverviewStopsCount =
        (loadOverviewDetails.operationalPlanStopDTOs) ? loadOverviewDetails.operationalPlanStopDTOs.length : 0;
      this.setEmailPreview(this.activityLogCommentsAddModel.loadOverview, this.activityLogCommentsAddModel.resourceDetails);
      this.setEmailStop(loadOverviewDetails);
    }

  }

  @Input() set resoureDetails(resoureViewDetails: ResourceOverviewDetails) {
    if (resoureViewDetails) {
      this.activityLogCommentsAddModel.resourceDetails = resoureViewDetails;
      this.setEmailPreview(this.activityLogCommentsAddModel.loadOverview, this.activityLogCommentsAddModel.resourceDetails);
    }
  }

  @Input() resourceId: string;

  activityLogCommentsAddModel: ActivityLogCommentsAddModel;
  constructor(private readonly changeDetector: ChangeDetectorRef, private readonly router: Router,
    private readonly formBuilder: FormBuilder, private readonly localStorageService: LocalStorageService,
    private readonly activityLogCommentsAddService: ActivityLogCommentsAddService,
    private readonly loadDetailsService: LoadDetailsService, private readonly userService: UserService,
    private readonly toastMessage: MessageService) {
    this.activityLogCommentsAddModel = new ActivityLogCommentsAddModel();
  }

  ngOnInit() {
    this.initializeAddCommentForm();
    this.getTemperatureUnitsList();
    this.getUserDetails();
    this.setEmailPreview(this.activityLogCommentsAddModel.loadOverview, this.activityLogCommentsAddModel.resourceDetails);
    this.setEmailStop(this.activityLogCommentsAddModel.loadOverview);
    this.activityLogCommentsAddModel.isTracking = this.router.url && this.router.url.indexOf('/trackingdetails') !== -1;
  }

  ngOnDestroy() {
    this.activityLogCommentsAddModel.subscribeFlag = false;
  }

  initializeAddCommentForm() {
    this.activityLogCommentsAddModel.addCommentForm = this.formBuilder.group({
      temperaturValue: [''],
      temperaturUnit: [''],
      comments: ['', Validators.required],
      addLoadComment: [''],
      sendEmail: [''],
      sendEmailList: [],
      accountRepresentative: [''],
      fleetManager: ['']
    });
  }

  get addCommentFormControls() {
    return this.activityLogCommentsAddModel.addCommentForm.controls;
  }
  getTemperatureUnitsList() {
    this.activityLogCommentsAddService.getTemperatureUnitsList()
      .pipe(
        takeWhile(() => this.activityLogCommentsAddModel.subscribeFlag),
        finalize(() => {
          this.changeDetector.detectChanges();
        })
      ).subscribe((data) => {
        if (data) {
          this.activityLogCommentsAddModel.unitMeasureList = this.activityLogCommentsAddService.setTemperatureUnitsList(data);
        }
      });
  }
  setEmailPreview(loadOverviewDetails: LoadOverview, resoureOverViewDetails) {
    this.activityLogCommentsAddModel.emailPreviewDetails =
      ActivityLogCommentsAddUtils.setEmailPreviewFields(loadOverviewDetails, resoureOverViewDetails);
  }
  setEmailStop(loadOverviewDetails: LoadOverview) {
    if (loadOverviewDetails) {
      this.setEmailPreviewStops(loadOverviewDetails.operationalPlanStopDTOs);
    } else {
      this.activityLogCommentsAddModel.emailPreviewStopsDetails = ActivityLogCommentsAddUtils.constructDefaultEmailPreviewStop();
    }
  }

  getUserDetails() {
    this.activityLogCommentsAddModel.emailPreviewUserDetails = this.setUserDetails(this.userService.userDetails);
  }

  onAddLoadCommentChecked(event: boolean) {
    this.activityLogCommentsAddModel.isAddLoadComment = event;
  }
  onSendEmailChecked(event: boolean) {
    this.activityLogCommentsAddModel.isEmailChecked = event;
    if (event) {
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').setValidators([Validators.required]);
      this.changeDetector.detectChanges();
    } else {
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').setValidators(null);
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').reset();
      this.activityLogCommentsAddModel.addCommentForm.get('accountRepresentative').reset();
      this.activityLogCommentsAddModel.addCommentForm.get('fleetManager').reset();
      this.activityLogCommentsAddModel.emailIdList = [];
    }
  }

  onTextAreaType() {
    if (this.checkCommentsValue()) {
      this.activityLogCommentsAddModel.textAreaCount =
        this.activityLogCommentsAddModel.addCommentForm.get('comments').value.length;
    } else {
      this.activityLogCommentsAddModel.textAreaCount = 0;
    }

  }
  onTemperatureType() {
    let validTemperature =
      this.activityLogCommentsAddModel.addCommentForm.get('temperaturValue').value.
        replace(/[[\]{}()*,:;<>\+"~&!@#%^&*_=\/?\\^$|a-zA-Z]/g, '');
    if (validTemperature) {
      let position = validTemperature.indexOf('.');
      let lastPosition = validTemperature.lastIndexOf('.');
      let len = validTemperature.length;
      if (position !== lastPosition) {
        validTemperature = validTemperature.slice(0, position + 1) + validTemperature.slice(position, len).replace(/[.]/g, '');
      }
      if (position > -1 && len > position + 3) {
        validTemperature = validTemperature.slice(0, position + 3);
      }
      position = validTemperature.indexOf('-');
      lastPosition = validTemperature.lastIndexOf('-');
      len = validTemperature.length - 1;
      if (position === 0 && lastPosition > 0) {
        validTemperature = '-' + validTemperature.slice(1, len).replace(/-/g, '');
      } else if (position > 0 && lastPosition > 0) {
        validTemperature = validTemperature.replace(/-/g, '');
      }
    }
    this.activityLogCommentsAddModel.addCommentForm.get('temperaturValue').patchValue(validTemperature);
    this.checkValidTemperatureAndUnit();
  }

  onTemperatureUnitChange() {
    this.checkValidTemperatureAndUnit();
  }

  checkValidTemperatureAndUnit() {
    const temperature = this.activityLogCommentsAddModel.addCommentForm.get('temperaturValue');
    const temperatureUnit = this.activityLogCommentsAddModel.addCommentForm.get('temperaturUnit');
    if (temperature.value && temperatureUnit.value || !temperature.value && !temperatureUnit.value) {
      temperature.markAsUntouched();
      temperatureUnit.markAsUntouched();
      this.activityLogCommentsAddModel.isTemperatureCorrect = true;
      this.activityLogCommentsAddModel.temperatureErrorMsg = '';
    }
  }
  checkCommentsValue() {
    return this.activityLogCommentsAddModel.addCommentForm.get('comments') &&
      this.activityLogCommentsAddModel.addCommentForm.get('comments').value;
  }

  onPreviewHide() {
    this.activityLogCommentsAddModel.isPreviewVisible = false;
  }

  onPreview() {
    this.activityLogCommentsAddModel.isPreviewVisible = true;
    this.updatePreviewDetails();
  }

  onCancel() {
    this.navigateToActivityLog();
  }

  onSave() {
    if (this.activityLogCommentsAddModel.addCommentForm.valid) {
      if (this.checkTempValueAndTempUnit()) {
        const constructSaveComment = this.constructAddCommentSave();
        this.activityLogCommentsAddService.saveAddComment(constructSaveComment)
          .pipe(
            takeWhile(() => this.activityLogCommentsAddModel.subscribeFlag),
            finalize(() => {
              this.changeDetector.detectChanges();
            })
          ).subscribe((data) => {
            this.navigateToActivityLog();
          });
      } else {
        this.toastMessage.add({
          severity: 'error',
          summary: 'Missing Required Information',
          detail: `Provide the required information in the highlighted
          fields and submit the form again.`
        });
      }
    } else {
      this.activityLogCommentsAddModel.addCommentForm.get('comments').markAsTouched();
      if (this.activityLogCommentsAddModel.isEmailChecked) {
        this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').markAsTouched();
      }
      this.checkTempValueAndTempUnit();
      this.toastMessage.clear();
      this.toastMessage.add({
        severity: 'error',
        summary: 'Missing Required Information',
        detail: `Provide the required information in the highlighted
        fields and submit the form again.`
      });
      this.activityLogCommentsAddModel.addCommentForm.markAsTouched();
    }
  }

  navigateToActivityLog() {
    if (this.activityLogCommentsAddModel.isTracking) {
      const params = this.localStorageService.getItem('TrackingDetails', 'param');
      this.router.navigate(['/trackingdetails'],
        {
          queryParams: {
            'driverId': this.queryParamNullCheck(params, 'driverId'),
            'equipmentId': this.queryParamNullCheck(params, 'equipmentId'),
            'loadNumber': this.queryParamNullCheck(params, 'loadNumber'),
            'equipmentNumber': this.queryParamNullCheck(params, 'equipmentNumber'),
            'index': 1
          }
        });
    } else {
      if (this.activityLogCommentsAddModel.addCommentLoadNumber) {
        this.router.navigate([`loaddetails/${this.activityLogCommentsAddModel.addCommentLoadNumber}`],
          {
            queryParams: {
              index: 2
            }
          });
      } else {
        this.router.navigate(['/loaddetails']);
      }
    }
  }
  queryParamNullCheck(queryParam: TrackingDetailsParam, paramName: string): string {
    return queryParam && queryParam[paramName] ? queryParam[paramName] : '';
  }
  checkTempValueAndTempUnit(): boolean {
    this.activityLogCommentsAddModel.isTemperatureCorrect = true;
    this.activityLogCommentsAddModel.temperatureErrorMsg = '';
    const temperature = this.activityLogCommentsAddModel.addCommentForm.get('temperaturValue');
    const temperatureUnit = this.activityLogCommentsAddModel.addCommentForm.get('temperaturUnit');
    if (temperature.value && !temperatureUnit.value) {
      temperature.markAsUntouched();
      temperatureUnit.markAsTouched();
      this.activityLogCommentsAddModel.isTemperatureCorrect = false;
      this.activityLogCommentsAddModel.temperatureErrorMsg = 'Please select Unit of Measure for Temperature';
    } else if (temperatureUnit.value && !temperature.value) {
      temperature.markAsTouched();
      temperatureUnit.markAsUntouched();
      this.activityLogCommentsAddModel.isTemperatureCorrect = false;
      this.activityLogCommentsAddModel.temperatureErrorMsg = 'Please Update Temperature as Unit of Measure is selected';
    } else {
      this.activityLogCommentsAddModel.isTemperatureCorrect = true;
      this.activityLogCommentsAddModel.temperatureErrorMsg = '';
    }
    return this.activityLogCommentsAddModel.isTemperatureCorrect;
  }

  updatePreviewDetails() {
    this.activityLogCommentsAddModel.emailPreviewUserDetails = this.setUserDetails(this.userService.userDetails);
  }

  constructAddCommentSave(): SaveRequestModel {
    return {
      operationalPlanId: Number(this.activityLogCommentsAddModel.addCommentLoadNumber),
      temperature: this.activityLogCommentsAddModel.addCommentForm.controls.temperaturValue.value,
      unitOfMeasurementCode: this.activityLogCommentsAddModel.addCommentForm.controls.temperaturUnit.value,
      comment: this.activityLogCommentsAddModel.addCommentForm.controls.comments.value,
      isLoadComment: this.activityLogCommentsAddModel.isAddLoadComment,
      personList: this.activityLogCommentsAddModel.emailIdList.length > 0 ?
        ActivityLogCommentsAddUtils.frameFinalPersonList(this.activityLogCommentsAddModel.emailIdList) : []
    };
  }

  setEmailPreviewStops(stopList) {
    if (stopList && stopList.length) {
      this.activityLogCommentsAddModel.emailPreviewStopsDetails = stopList.map((stop, index) => {
        return this.constructEmailPreviewStop(stop, index, stopList.length);
      });

    }

  }
  constructEmailPreviewStop(stopValue, index: number, stopListLength: number): EmailPreviewStopDetails {
    return {
      header: ActivityLogCommentsAddUtils.setHeaderValue(stopListLength, stopValue.operationalPlanStopSequenceNumber),
      headerHint: ActivityLogCommentsAddUtils.setHeaderHintValue(stopValue.operationalPlanStopReason.operationalPlanStopReasonCode),
      planStopSequenceNumber: ActivityLogCommentsAddUtils.setNullValue(stopValue.operationalPlanStopSequenceNumber),
      stopIndex: index,
      appointmentDate: this.formatAppointmentDate(stopValue.operationalPlanStopAppointment, stopValue.locationDetailsDTO),
      locationDetail: ActivityLogCommentsAddUtils.formatLocation(stopValue.locationDetailsDTO),
      addressDetail: ActivityLogCommentsAddUtils.formatAddressDetails(stopValue.locationDetailsDTO),
      zipCodeDetail: ActivityLogCommentsAddUtils.formatCountryAdressDetails(stopValue.locationDetailsDTO),
      contactDetail: (stopValue['toReachContactPerson']) ?
        Utils.getGeneralContactDetails(stopValue, 'toReachContactPerson') : '',
      orderNumbers: ActivityLogCommentsAddUtils.formatLoadNumbers(stopValue.orderIds)
    };
  }

  formatAppointmentDate(appointment: OperationalPlanStopAppointment, locationDetail: LocationDetailsDTO): string {
    const timezone = locationDetail.timezone ? locationDetail.timezone : '';
    if (appointment) {
      return DateUtils.getFormattedStartEndDateString(appointment.appointmentStartTimestamp,
        appointment.appointmentEndTimestamp, timezone);
    } else {
      return '---';
    }
  }

  setUserDetails(userDetail): EmailPreviewUserDetails {
    return {
      userDetail: Utils.standardNameFormat(userDetail),
      comments: this.activityLogCommentsAddModel.addCommentForm.controls.comments.value,
      userUpdatedTime: DateUtils.convertOffsetDateByDefaultTimeZone(moment(), 'l HH:mm A z')
    };
  }

  onSendMailChecked(checkboxType: string, checked: boolean) {
    if (checkboxType === 'fleetmanager') {
      this.fetchFleetMgrs(checked);
    } else {
      this.fetchOrderOwners(checked);
    }
  }

  fetchFleetMgrs(checked: boolean) {
    if (checked) {
      this.activityLogCommentsAddModel.fleetMgrList = [];
      this.activityLogCommentsAddService.getFleetMgrList(this.resourceId)
        .pipe(
          takeWhile(() => this.activityLogCommentsAddModel.subscribeFlag),
          finalize(() => {
            this.changeDetector.detectChanges();
          })
        ).subscribe((data) => {
          if (data) {
            this.activityLogCommentsAddModel.fleetMgrList.push(ActivityLogCommentsAddUtils.mapEmailFleetMgrDetails(data, 'fleetMgr'));
            this.pushValidEmailId('fleetMgrList');
          }
        });
    } else {
      this.onSendMailUnChecked('fleetMgrList');
    }
  }

  fetchOrderOwners(checked: boolean) {
    if (checked) {
      this.activityLogCommentsAddService.getOrderOwnerList(this.activityLogCommentsAddModel.addCommentLoadNumber)
        .pipe(
          takeWhile(() => this.activityLogCommentsAddModel.subscribeFlag),
          finalize(() => {
            this.changeDetector.detectChanges();
          })
        ).subscribe((data) => {
          if (data && data.length) {
            this.activityLogCommentsAddModel.orderOwnerList = ActivityLogCommentsAddUtils.mapEmailOrderOwnerDetails(data, 'orderOwner');
            this.pushValidEmailId('orderOwnerList');
          }
        });
    } else {
      this.onSendMailUnChecked('orderOwnerList');
    }
  }

  onValidateEmail(valueTyped: string, event?) {
    if (valueTyped) {
      this.checkForValidemail(valueTyped, event);
    } else {
      this.activityLogCommentsAddModel.errorMailList = [];
      this.checkErrorIdExists();
    }
  }

  checkForValidemail(valueTyped: string, event) {
    this.activityLogCommentsAddModel.customMailList = [];
    const mailIdList = valueTyped.split(';');
    let inValidcount = 0;
    let errorMail = '';
    const invalidmailArray = [];
    mailIdList.forEach(value => {
      value = value.trim();
      const isValid = ActivityLogCommentsAddUtils.customEmailValidator(value);
      const emailDetails = {
        'personId': null,
        'emailId': value,
        'isValidFlag': isValid
      };
      if (!isValid && value !== '') {
        invalidmailArray.push(value);
        this.activityLogCommentsAddModel.errorMailList = uniq(invalidmailArray);
        inValidcount++;
        errorMail = errorMail + `${value};`;
      } else if (isValid && value !== '') {
        this.activityLogCommentsAddModel.customMailList.push(emailDetails);
      }
    });
    this.pushValidEmailId('customMailList');
    if (inValidcount) {
      this.checkAndSetErrors(event, errorMail);
    } else {
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').setErrors(null);
      if (event && event.target) {
        event.target.value = '';
      }
    }
  }

  showErrorToastMessage(summary, detail) {
    this.toastMessage.clear();
    this.toastMessage.add({
      severity: 'error',
      summary,
      detail
    });
  }

  checkAndSetErrors(event, errorMail: string) {
    if (event && event.target) {
      event.target.value = errorMail;
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').markAsTouched();
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').setErrors({ 'status': 'Invalid' });
    } else {
      this.showErrorToastMessage('Invalid Email', 'Please use a valid email format.');
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').setErrors(null);
    }
  }

  pushValidEmailId(mailListToAdd: string) {
    this.activityLogCommentsAddModel.emailIdList = uniqBy([...this.activityLogCommentsAddModel.emailIdList,
    ...this.activityLogCommentsAddModel[mailListToAdd]], 'emailId');
    this.activityLogCommentsAddModel.addCommentForm.controls.sendEmailList.setValue(this.activityLogCommentsAddModel.emailIdList);
    this.checkErrorIdExists();
  }

  onSendMailUnChecked(mailListToRemove: string) {
    this.activityLogCommentsAddModel.emailIdList = this.activityLogCommentsAddModel.emailIdList.filter(selected => {
      return !this.activityLogCommentsAddModel[mailListToRemove].find(value => {
        return value.emailId === selected.emailId;
      });
    });
    this.activityLogCommentsAddModel[mailListToRemove] = [];
    this.activityLogCommentsAddModel.addCommentForm.controls.sendEmailList.setValue(this.activityLogCommentsAddModel.emailIdList);
    this.checkErrorIdExists();
  }

  onRemoveEmailId(value: EmailRecipientDetails) {
    this.activityLogCommentsAddModel.emailIdList = this.activityLogCommentsAddModel.emailIdList.filter(selected => {
      return selected.emailId !== value.emailId;
    });
    if (value && value['emailRecipientType']) {
      this.removeAndUnCheck(value);
    } else {
      this.activityLogCommentsAddModel.addCommentForm.controls.sendEmailList.setValue(this.activityLogCommentsAddModel.emailIdList);
    }
    this.checkErrorIdExists();
  }

  removeAndUnCheck(value: EmailRecipientDetails) {
    const listToCheck = `${value['emailRecipientType']}List`;
    this.activityLogCommentsAddModel[listToCheck] = this.activityLogCommentsAddModel[listToCheck].filter(selected => {
      return selected.emailId !== value.emailId;
    });
    if (this.activityLogCommentsAddModel[listToCheck].length === 0) {
      if (value['emailRecipientType'] === 'orderOwner') {
        this.activityLogCommentsAddModel.addCommentForm.get('accountRepresentative').reset();
      } else {
        this.activityLogCommentsAddModel.addCommentForm.get('fleetManager').reset();
      }
    }
  }

  checkErrorIdExists() {
    if (this.activityLogCommentsAddModel.errorMailList.length > 0 || this.activityLogCommentsAddModel.emailIdList.length === 0) {
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').setErrors({ 'invalid': true });
    } else {
      this.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').setErrors(null);
    }
  }

}
