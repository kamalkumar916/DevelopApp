import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';

import { DropdownModule } from 'primeng/dropdown';
import { DialogModule } from 'primeng/dialog';
import { CheckboxModule } from 'primeng/checkbox';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { MessageService } from 'primeng/components/common/messageservice';
import { configureTestSuite } from 'ng-bullet';

import { LocalStorageService } from '../../../../shared/jbh-app-services/local-storage.service';
import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { UserService } from '../../../../shared/jbh-esa/index';
import { AppConfigService } from '../../../../shared/service/app-config.service';
import { LoadDetailsService } from '../../../../features/load-details/services/load-details.service';
import { ActivityLogCommentsAddComponent } from './activity-log-comments-add.component';
import { ChipsModule } from 'primeng/chips';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { ActivityLogCommentsAddService } from './services/activity-log-comments-add.service';
import { ActivityLogCommentsAddUtils } from './services/activity-log-comments-add.utils';
import { Router } from '@angular/router';

const loadOverView = {
  operationalPlanId: null,
  operationalPlanNumber: '',
  operationalPlanType: {
    operationalPlanTypeCode: '',
    operationalPlanTypeDescription: ''
  },
  operationalPlanSubtype: {
    operationalPlanSubtypeCode: '',
    operationalPlanSubtypeDescription: ''
  },
  operationalPlanStatus: {
    operationalPlanStatusCode: '',
    operationalPlanStatusDescription: ''
  },
  operationalPlanServiceOfferingCode: '',
  operationalPlanTransitModeCode: '',
  operationalPlanFinanceBusinessUnitCode: '',
  desirabilityIndexNumber: null,
  resource: '',
  truck: '',
  requiredEquipment: '',
  trailer: '',
  container: '',
  chassis: '',
  classifications: [{
    operationalPlanClassificationCode: '',
    operationalPlanClassificationDescription: ''
  }],
  loadedMilesWithUnit: '',
  loadedMiles: '',
  emptyMiles: '',
  estimatedTotalMiles: '',
  items: '',
  totalWeight: '',
  unitOfWeightMeasurementCode: '',
  requestedService: [{
    operationalPlanServiceTypeCode: '',
    operationalPlanServiceTypeDescription: ''
  }],
  estimatedTimeOfCompletion: '',
  routeSequenceNumber: '',
  totalRouteSequenceNumber: '',
  routePlanId: '',
  routeId: '',
  payRoute: [{
    operationalPlanPayRouteSegmentId: null,
    originCityId: null,
    destinationCityId: null,
    payRouteSegmentStatusCode: '',
    segmentSequenceNumber: null,
    originOperationalPlanStopId: null,
    destinationOperationalPlanStopId: null,
    originCityName: '',
    originStateCode: '',
    destinationCityName: '',
    destinationStateCode: ''
  }],
  utilization: {
    utilizationStatusCode: '',
    utilizationStatusDescription: ''
  },
  totalPointsQuantity: '',
  networkOperationalPlanIndicator: '',
  externalOperationalPlanBoardIndicator: '',
  bulkProcessIndicator: '',
  operationalGroupCode: '',
  customerRate: [],
  tripPlanTransitValue: '',
  operationalPlanStopDTOs: null,
  billTo: [{
    accountName: '',
    accountCode: '',
    address: {
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      zipcode: '',
      country: ''
    },
    contact: {
      firstName: '',
      lastName: '',
      contactExtension: '',
      telephoneNumber: ''
    }
  }],
  operationalPlanOwnershipDTOs: [{
    teamMembers: [{
      roleTypeCode: '',
      roleTypeName: '',
      teamId: null,
      teamMemberId: '',
      teamMemberName: '',
      teamMemberUserId: '',
      teamName: ''
    }],
    taskAssignmentId: null,
    taskAssignmentName: ''
  }],
  equipmentDetails: {
    isPreLoaded: true,
    truck: {
      prefix: '',
      number: '',
      typeRequired: ''
    },
    chassis: {
      prefix: '',
      number: '',
      typeRequired: ''
    },
    container: {
      prefix: '',
      number: '',
      typeRequired: ''
    },
    trailer: {
      prefix: '',
      number: '',
      typeRequired: true,
      length: null,
      isLengthRequired: true,
      isPreLoaded: true,
      category: '',
      type: ''
    },
    currentTrailer: {
      prefix: '',
      number: '',
      typeRequired: true,
      length: null,
      isLengthRequired: true,
      isPreLoaded: true,
      category: '',
      type: ''
    },
    driverId: null,
    equipmentId: null,
    alphaCode: '',
    firstName: '',
    lastName: '',
    middleName: '',
    resourceName: '',
    tanker: {
      prefix: '',
      number: '',
      typeRequired: ''
    },
    hopper: {
      prefix: '',
      number: '',
      typeRequired: ''
    }
  },
  splitLoadApplicable: true,

  operationalPlanRouteGuideStatus: {
    operationalPlanRouteGuideStatusCode: '',
    operationalPlanRouteGuideStatusDescription: ''
  },
  servicePriorityCode: '',
  committedFreightIndicator: '',
  shipmentId: [''],
  payRouteLists: [{
    operationalPlanPayRouteSegmentId: null,
    originCityId: null,
    destinationCityId: null,
    payRouteSegmentStatusCode: '',
    segmentSequenceNumber: null,
    originOperationalPlanStopId: null,
    destinationOperationalPlanStopId: null,
    originCityName: '',
    originStateCode: '',
    destinationCityName: '',
    destinationStateCode: ''
  }],
  jbhuntFailureCount: null,
  operationalPlanOrderIds: null,
  taskReason: [],
  operationalPlanReferenceNumberDTOs: null
};
const resourceOverviewDetails = {
  alphaCode: '',
  lastName: '',
  firstName: '',
  preferredName: '',
  truck: ''
};
const unitOfTemperatureData = {
  _links: {
    profile: { href: '' },
    self: { href: '', templated: true }
  },
  page: {
    number: 0,
    size: 20,
    totalElements: 2,
    totalPages: 1
  },
  _embedded: {
    unitOfTemperatureMeasurements: [{
      lastUpdateTimestampString: '',
      unitOfTemperatureMeasurementCode: 'Celsius',
      unitOfTemperatureMeasurementDescription: 'Celsius Temperature',
      _links: {
        self: { href: '' },
        unitOfTemperatureMeasurement: { href: '' }
      }
    }]
  }
};

class MockActivityLogCommentsAddService {
  constructor() { }
  getTemperatureUnitsList() {
    return of(unitOfTemperatureData);
  }
  saveAddComment() {
    return throwError(null);
  }
  getFleetMgrList(fleetId) {
    return of({
      personId: '',
      emailId: ''
    });
  }
  getOrderOwnerList(loadId) {
    return of([{
      personId: '',
      emailId: ''
    }]);
  }
  setUnitFirstCharacter(unit) {
    return unit.slice(0, 1);
  }
  setTemperatureUnitsList(data) {
    return [{ label: 'Unit', value: 'Celsius' }];
  }
}

describe('ActivityLogCommentsAddComponent', () => {
  let component: ActivityLogCommentsAddComponent;
  let fixture: ComponentFixture<ActivityLogCommentsAddComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        ReactiveFormsModule,
        DropdownModule,
        DialogModule,
        CheckboxModule,
        AutoCompleteModule,
        PipesModule,
        ScrollPanelModule,
        RouterTestingModule,
        ChipsModule
      ],
      providers: [
        LocalStorageService,
        UserService,
        AppConfigService,
        MessageService,
        LoadDetailsService,
        { provide: ActivityLogCommentsAddService, useClass: MockActivityLogCommentsAddService }
      ],
      declarations: [
        ActivityLogCommentsAddComponent
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogCommentsAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('loadNumber should set the value of addCommentLoadNumber to be 1', () => {
    component.loadNumber = 1;
    expect(component.activityLogCommentsAddModel.addCommentLoadNumber).toEqual(1);
  });

  it('loadedDetails should call the spy setEmailStop', () => {
    spyOn(component, 'setEmailPreview');
    spyOn(component, 'setEmailStop');
    component.loadedDetails = loadOverView;
    expect(component.setEmailStop).toHaveBeenCalled();
  });

  it('resoureDetails should call the spy setEmailPreview', () => {
    spyOn(component, 'setEmailPreview');
    component.resoureDetails = resourceOverviewDetails;
    expect(component.setEmailPreview).toHaveBeenCalled();
  });

  it('onTextAreaType should set the textAreaCount value to 0', () => {
    spyOn(component, 'checkCommentsValue').and.returnValue('');
    component.onTextAreaType();
    expect(component.activityLogCommentsAddModel.textAreaCount).toEqual(0);
  });

  it('onTextAreaType should call the spy checkCommentsValue', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('comments').patchValue('comment');
    spyOn(component, 'checkCommentsValue').and.returnValue('comment');
    component.onTextAreaType();
    expect(component.checkCommentsValue).toHaveBeenCalled();
  });

  it('onTemperatureType should call the spy checkValidTemperatureAndUnit', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturValue').patchValue('23.751');
    spyOn(component, 'checkValidTemperatureAndUnit');
    component.onTemperatureType();
    expect(component.checkValidTemperatureAndUnit).toHaveBeenCalled();
  });

  it('onTemperatureType should call the spy checkValidTemperatureAndUnit', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturValue').patchValue('23.751');
    spyOn(component, 'checkValidTemperatureAndUnit');
    component.onTemperatureType();
    expect(component.checkValidTemperatureAndUnit).toHaveBeenCalled();
  });

  it('checkValidTemperatureAndUnit should set the isTemperatureCorrect value to be true', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturValue').patchValue('30');
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturUnit').patchValue('Celsius');
    component.checkValidTemperatureAndUnit();
    expect(component.activityLogCommentsAddModel.isTemperatureCorrect).toBeTruthy();
  });

  it('onCancel have been called', () => {
    spyOn(component, 'navigateToActivityLog');
    component.onCancel();
    expect(component.navigateToActivityLog).toHaveBeenCalled();
  });

  it('onSendEmailChecked should set the value of emailIdList equal to empty array', () => {
    component.onSendEmailChecked(false);
    expect(component.activityLogCommentsAddModel.emailIdList).toEqual([]);
  });

  it('onPreviewHide have been called', () => {
    component.onPreviewHide();
    expect(component.activityLogCommentsAddModel.isPreviewVisible).toBe(false);
  });

  it('onPreview should call the spy updatePreviewDetails', () => {
    spyOn(component, 'updatePreviewDetails');
    component.onPreview();
    expect(component.updatePreviewDetails).toHaveBeenCalled();
  });

  it('onSendMailChecked should call the spy fetchFleetMgrs', () => {
    spyOn(component, 'fetchFleetMgrs');
    component.onSendMailChecked('fleetmanager', true);
    expect(component.fetchFleetMgrs).toHaveBeenCalled();
  });

  it('onSendMailChecked should call the spy fetchOrderOwners', () => {
    spyOn(component, 'fetchOrderOwners');
    component.onSendMailChecked('abcd', true);
    expect(component.fetchOrderOwners).toHaveBeenCalled();
  });

  it('pushValidEmailId have been called', () => {
    spyOn(component, 'checkErrorIdExists');
    component.pushValidEmailId('abcd');
    expect(component.checkErrorIdExists).toHaveBeenCalled();
  });

  it('onSendMailUnChecked have been called', () => {
    spyOn(component, 'checkErrorIdExists');
    component.activityLogCommentsAddModel.emailIdList = [{
      personId: '',
      emailId: ''
    }];
    component.activityLogCommentsAddModel.fleetMgrList = [{
      personId: '',
      emailId: ''
    }];
    component.onSendMailUnChecked('fleetMgrList');
    expect(component.checkErrorIdExists).toHaveBeenCalled();
  });

  it('fetchFleetMgrs should call the spy pushValidEmailId', () => {
    spyOn(ActivityLogCommentsAddUtils, 'mapEmailFleetMgrDetails').and.returnValue({});
    spyOn(component, 'pushValidEmailId');
    component.fetchFleetMgrs(true);
    expect(component.pushValidEmailId).toHaveBeenCalled();
  });

  it('fetchFleetMgrs should call the spy onSendMailUnChecked', () => {
    spyOn(component, 'onSendMailUnChecked');
    component.fetchFleetMgrs(false);
    expect(component.onSendMailUnChecked).toHaveBeenCalled();
  });

  it('fetchOrderOwners should call the spy onSendMailUnChecked', () => {
    spyOn(component, 'onSendMailUnChecked');
    component.fetchOrderOwners(false);
    expect(component.onSendMailUnChecked).toHaveBeenCalled();
  });

  it('fetchOrderOwners should call the spy pushValidEmailId', () => {
    spyOn(ActivityLogCommentsAddUtils, 'mapEmailOrderOwnerDetails').and.returnValue([{
      personId: '',
      emailId: ''
    }]);
    spyOn(component, 'pushValidEmailId');
    component.fetchOrderOwners(true);
    expect(component.pushValidEmailId).toHaveBeenCalled();
  });

  it('onValidateEmail should call the spy checkErrorIdExists', () => {
    spyOn(component, 'checkErrorIdExists');
    component.onValidateEmail('');
    expect(component.checkErrorIdExists).toHaveBeenCalled();
  });

  it('onValidateEmail should call the spy checkForValidemail', () => {
    spyOn(component, 'checkForValidemail');
    component.onValidateEmail('abc');
    expect(component.checkForValidemail).toHaveBeenCalled();
  });

  it('checkForValidemail should call the spy pushValidEmailId', () => {
    spyOn(ActivityLogCommentsAddUtils, 'customEmailValidator').and.returnValue(true);
    spyOn(component, 'pushValidEmailId');
    component.activityLogCommentsAddModel.errorMailList = [];
    component.checkForValidemail('abc@jbh.com', { target: { value: '' } });
    expect(component.pushValidEmailId).toHaveBeenCalled();
  });

  it('checkForValidemail should call the spy checkAndSetErrors', () => {
    spyOn(ActivityLogCommentsAddUtils, 'customEmailValidator').and.returnValue(false);
    spyOn(component, 'pushValidEmailId');
    spyOn(component, 'checkAndSetErrors');
    component.activityLogCommentsAddModel.errorMailList = [];
    component.checkForValidemail('abc', { target: { value: '' } });
    expect(component.checkAndSetErrors).toHaveBeenCalled();
  });

  it('checkAndSetErrors should set the sendEmailList formcontrol as touched', () => {
    component.checkAndSetErrors({ target: { value: '' } }, '');
    expect(component.activityLogCommentsAddModel.addCommentForm.get('sendEmailList').touched).toBeTruthy();
  });

  it('checkAndSetErrors should call the spy showErrorToastMessage', () => {
    spyOn(component, 'showErrorToastMessage');
    component.checkAndSetErrors({ target: null }, '');
    expect(component.showErrorToastMessage).toHaveBeenCalled();
  });

  it('checkCommentsValue should return the string comment', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('comments').patchValue('comment');
    expect(component.checkCommentsValue()).toEqual('comment');
  });

  it('navigateToActivityLog should call the navigate spy', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.activityLogCommentsAddModel.isTracking = true;
    const localStorageService = TestBed.get(LocalStorageService);
    spyOn(localStorageService, 'getItem').and.returnValue({
      driverId: null,
      equipmentId: null,
      loadNumber: null,
      equipmentNumber: null,
      index: null,
      view: null
    });
    component.navigateToActivityLog();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('navigateToActivityLog should call the navigate spy with query params', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.activityLogCommentsAddModel.isTracking = false;
    component.activityLogCommentsAddModel.addCommentLoadNumber = 1;
    component.navigateToActivityLog();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('navigateToActivityLog should call the navigate spy with route loaddetails', () => {
    const router = TestBed.get(Router);
    spyOn(router, 'navigate');
    component.activityLogCommentsAddModel.isTracking = false;
    component.activityLogCommentsAddModel.addCommentLoadNumber = null;
    component.navigateToActivityLog();
    expect(router.navigate).toHaveBeenCalledWith(['/loaddetails']);
  });

  it('checkTempValueAndTempUnit should return true', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturValue').patchValue('23');
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturUnit').patchValue('Celsius');
    expect(component.checkTempValueAndTempUnit()).toEqual(true);
  });

  it('checkTempValueAndTempUnit is called without temperaturUnit', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturValue').patchValue('23');
    expect(component.checkTempValueAndTempUnit()).toEqual(false);
  });

  it('checkTempValueAndTempUnit is called without temperaturValue', () => {
    component.activityLogCommentsAddModel.addCommentForm.get('temperaturUnit').patchValue('Celsius');
    expect(component.checkTempValueAndTempUnit()).toEqual(false);
  });
});
