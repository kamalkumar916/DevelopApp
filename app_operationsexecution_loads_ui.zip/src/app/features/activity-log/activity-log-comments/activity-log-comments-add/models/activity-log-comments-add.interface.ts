import { Links2, Page, Self } from '../../../models/activity-log.interface';
import { EmailRecipient } from '../../../../../shared/email-contact-shared/model/email-contact-shared.interface';
export class ActivityLogCommentsAdd {
}

export class DropdownModel {
    label: string;
    value: string;
}

export class ResourceOverviewDetails {
    alphaCode: string;
    lastName: string;
    firstName: string;
    preferredName: string;
    truck: string;
}
export class AutoCompleteModel {
    name: string;
    code: string;
}
export interface Person {
    firstName: string;
    lastName: string;
    contactExtension: string;
    telephoneNumber: string;
}
export interface OperationalPlanStopAppointment {
    appointmentStartTimestamp: string;
    appointmentEndTimestamp: string;
}
export class EmailPreviewDetails {
    driver: string;
    truck: string;
    businessUnit: string;
    serviceOffering: string;
    businessUnitServiceOffering: string;
    shipmentId: string;
}
export class EmailPreviewStopDetails {
    header: string;
    headerHint: string;
    planStopSequenceNumber: string;
    stopIndex: number;
    appointmentDate: string;
    locationDetail: string;
    addressDetail: string;
    zipCodeDetail: string;
    contactDetail: string;
    orderNumbers: number[];
}
export class EmailPreviewUserDetails {
    userDetail: string;
    comments: string;
    userUpdatedTime: string;
}
export class SaveRequestModel {
    operationalPlanId: number;
    temperature: string;
    unitOfMeasurementCode: string;
    comment: string;
    isLoadComment: boolean;
    personList: EmailRecipientDetails[];
}
export interface UtilityServiceModel {
    _embedded: UnitOfTemperature;
    _links: Links2;
    page: Page;
}

export interface UnitOfTemperature {
    unitOfTemperatureMeasurements: UnitOfTemperatureMeasurements[];

}
export interface UnitOfTemperatureMeasurements {
    lastUpdateTimestampString: string;
    unitOfTemperatureMeasurementCode: string;
    unitOfTemperatureMeasurementDescription: string;
    _links: CountedByLinks;
}
export interface CountedByLinks {
    self: Self;
    unitOfTemperatureMeasurements: Self;
}

export interface EmailRecipientDetails {
    personId: string;
    emailId: string;
    firstName?: string;
    lastName?: string;
    preferedName?: string;
    userId?: string;
    isValidFlag?: boolean;
    emailRecipientType?: string;
}

export interface LocationDetailsDTO {
    timezone: string;
    locationCode: string;
    locationId: number;
    locationName: string;
}
