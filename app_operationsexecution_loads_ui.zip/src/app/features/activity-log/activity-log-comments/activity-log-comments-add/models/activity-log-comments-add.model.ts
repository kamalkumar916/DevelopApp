import { FormGroup } from '@angular/forms';
import {
    DropdownModel, AutoCompleteModel, EmailPreviewDetails, EmailPreviewUserDetails, EmailRecipientDetails, ResourceOverviewDetails
} from './activity-log-comments-add.interface';
import {
    OperationalPlanStopDTOs, LoadOverview
} from '../../../../../features/load-details/load-details-overview/model/load-overview.interface';

export class ActivityLogCommentsAddModel {
    addCommentLoadNumber: number;
    operationalPlanNumber: string;

    textAreaValue: string;
    textAreaCount: number;
    isEmailChecked: boolean;
    isAddLoadComment: boolean;
    isPreviewVisible: boolean;
    unitMeasureList: DropdownModel[];
    emailSuggestions: any[];
    sendEmail: AutoCompleteModel[];
    addCommentForm: FormGroup;
    subscribeFlag: boolean;
    loadOverview: LoadOverview;
    loadOverviewStops: OperationalPlanStopDTOs[];
    loadOverviewStopsCount: number;
    emailPreviewDetails: EmailPreviewDetails;
    emailPreviewUserDetails: EmailPreviewUserDetails;
    emailPreviewStopsDetails: any[];
    maxTextAreaLength: number;
    isTemperatureCorrect: boolean;
    temperatureErrorMsg: string;
    isTracking: boolean;
    emailIdList: EmailRecipientDetails[];
    fleetMgrList: EmailRecipientDetails[];
    orderOwnerList: EmailRecipientDetails[];
    customMailList: EmailRecipientDetails[];
    errorMailList: Array<string>;
    resourceDetails: ResourceOverviewDetails;

    constructor() {
        this.subscribeFlag = true;
        this.textAreaValue = '';
        this.textAreaCount = 0;
        this.isEmailChecked = false;
        this.isAddLoadComment = false;
        this.isPreviewVisible = false;
        this.unitMeasureList = [
            { label: 'Unit', value: '' }
        ];

        this.maxTextAreaLength = 2000;
        this.emailSuggestions = [];
        this.isTemperatureCorrect = true;
        this.temperatureErrorMsg = '';
        this.emailIdList = [];
        this.fleetMgrList = [];
        this.orderOwnerList = [];
        this.customMailList = [];
        this.errorMailList = [];
    }
}
