import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TranslateService } from '@ngx-translate/core';
import { LocalizationResolver } from './core/i18n/localization.resolver';

import { ErrorPageComponent } from './shared/errors/index';
import { RouteGuard, AuthGuard } from './shared/jbh-esa';
const iconAdmin = 'icon-Admin';
const iconMachine = 'icon-Machine';
const iconSearch = 'icon-Search';
const iconPlaceholder = 'icon-Placeholder';
const activityLogModule = './features/activity-log/activity-log.module#ActivityLogModule';

// Routes Commented for Intial PROD Release
const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: './features/dashboard/dashboard.module#DashboardModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Dashboard',
      pathIcon: 'icon-Home',
      order: 1
    }
  },
  {
    path: 'manageplan',
    loadChildren: './features/manage-plan/manage-plan.module#ManagePlanModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Manage Plan',
      pathIcon: 'icon-Home',
      order: 1
    }
  },
  {
    path: 'loadplanning/loadtasks',
    loadChildren: './features/load-planning/load-tasks/load-tasks.module#LoadTasksModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Load Tasks',
      pathIcon: 'icon-Clipboard_Check',
      order: 2
    }
  },
  {
    path: 'fleetplanning',
    loadChildren: './features/load-resource-plan/load-resource-plan.module#LoadResourcePlanModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Fleet Planning',
      pathIcon: 'icon-Truck',
      order: 2
    }
  },
  {
    path: 'loadplanning/search',
    loadChildren: './features/load-planning/search-loads/search-loads.module#SearchLoadsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Search Loads',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'drivertask/search',
    loadChildren:
      './features/drivertask/search-driver-task/search-driver-task.module#SearchDriverTaskModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Search Driver Task',
      pathIcon: 'icon-Crate_Search',
      order: 2
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'drivertask/search/view',
    loadChildren:
      './features/drivertask/view-driver-task/view-driver-task.module#ViewDriverTaskModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'View Driver Task',
      pathIcon: iconPlaceholder,
      order: 2
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'drivertask/create',
    loadChildren: './features/drivertask/create-driver-task/create-driver-task.module#CreateDriverTaskModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Create Driver Task',
      pathIcon: 'icon-Crate',
      order: 2
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'loadplanning/plannedloads',
    loadChildren:
      './features/load-planning/planned-loads/planned-loads.module#PlannedLoadsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Planned Loads',
      pathIcon: 'icon-Document_List',
      order: 2
    }
  },
  {
    path: 'admin/automationrules',
    loadChildren: './features/admin/automation-rules/automation-rules.module#AutomationRulesModule',
    resolve: {
      translationLoaded: LocalizationResolver
    },
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Load Automation Rules',
      pathIcon: iconMachine,
      order: 2
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'admin/automationrules/viewconfigurerule',
    loadChildren: './features/admin/automation-rules/automation-rules.module#AutomationRulesModule',
    resolve: {
      translationLoaded: LocalizationResolver
    },
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Load Automation Rules',
      pathIcon: iconMachine,
      order: 2
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'admin/automationrules/predefinedRules',
    loadChildren: './features/admin/automation-rules/automation-rules.module#AutomationRulesModule',
    resolve: {
      translationLoaded: LocalizationResolver
    },
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Load Automation Rules',
      pathIcon: iconMachine,
      order: 2
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'loadsanalytics',
    loadChildren: './features/loads-analytics/loads-analytics.module#LoadsAnalyticsModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Loads Analytics',
      pathIcon: 'icon-Reports',
      order: 1
    }
  },
  {
    path: 'admin/operationalteammanagement',
    resolve: {
      translationLoaded: LocalizationResolver
    },
    loadChildren: './features/admin/operational-team-management/operational-team-management.module#OperationalTeamManagementModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Operational Team Management',
      pathIcon: 'icon-User_Group_Solid',
      order: 2
    }
  },
  {
    path: 'admin',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Administration',
      pathIcon: iconAdmin,
      order: 1
    },
    children: [{
      path: 'manageequipment',
      loadChildren: './features/admin/manage-equipment-group/manage-equipment-group.module#ManageEquipmentGroupModule',
      data: {
        createSidebarEntry: true,
        pathDisplayText: 'Manage Equipment',
        pathIcon: iconSearch,
        order: 1
      }
    }
    ],
    canActivate: [RouteGuard]
  },
  {
    path: 'managereferences',
    loadChildren: './features/admin/manage-references/manage-references.module#ManageReferencesModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Manage References',
      pathIcon: 'icon-Documents_List',
      order: 2
    }
  },
  {
    path: 'utilization-status',
    loadChildren: './features/admin/manage-references/utilization-status/utilization-status.module#UtilizationStatusModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Utilization Status',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'driver-task-type-and-sub-type',
    loadChildren:
      `${'./features/admin/manage-references/driver-task-type-and-sub-type/' +
      'driver-task-type-and-sub-type.module#DriverTaskTypeAndSubTypeModule'}`,
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Driver Task Type and Sub Type',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'stop-service-and-stop-reason',
    loadChildren:
      `${'./features/admin/manage-references/stop-service-and-stop-reason/' +
      'stop-service-and-stop-reason.module#StopServiceAndStopReasonModule'}`,
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Stop Service and Stop Reason',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'appointment-change-reason',
    loadChildren:
      './features/admin/manage-references/appointment-change-reason/appointment-change-reason.module#AppointmentChangeReasonModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Appointment Change Reason',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'operational-team-category-and-team-type',
    loadChildren:
      `${'./features/admin/manage-references/operational-team-category-and-team-type/' +
      'operational-team-category-and-team-type.module#OperationalTeamCategoryAndTeamTypeModule'}`,
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Operational Team Category And Type',
      pathIcon: iconMachine,
      order: 2
    }
  },
  {
    path: 'capacity-evaluation-association',
    loadChildren:
      `${'./features/admin/manage-references/capacity-evaluation-association/' +
      'capacity-evaluation-association.module#CapacityEvaluationAssociationModule'}`,
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Capacity Evaluation Association',
      pathIcon: iconMachine,
      order: 2
    }
  },
  {
    path: 'error/:status',
    component: ErrorPageComponent
  },
  {
    path: 'loaddetails/activityLog',
    loadChildren: activityLogModule,
    data: {
      createSidebarEntry: false
    }
  },
  {
    path: 'trackingdetails/activityLog',
    loadChildren: activityLogModule,
    data: {
      createSidebarEntry: false
    }
  },
  {
    path: 'tracking/activityLog',
    loadChildren: activityLogModule,
    data: {
      createSidebarEntry: false
    }
  },
  {
    path: 'trackingdetails/unassignequipment',
    loadChildren: './shared/load-details-stop-activity/load-details-stop-activity.module#LoadDetailsStopActivityModule',
    data: {
      createSidebarEntry: false
    }
  },
  {
    path: 'loaddetails/unassignequipment',
    loadChildren: './shared/load-details-stop-activity/load-details-stop-activity.module#LoadDetailsStopActivityModule',
    data: {
      createSidebarEntry: false
    }
  },
  {
    path: 'tenderhistory',
    loadChildren: './features/tender/tender-history/tender-history.module#TenderHistoryModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Tender History',
      pathIcon: 'icon-History',
      order: 2
    }
  },
  {
    path: 'locationupdate',
    resolve: {
      translationLoaded: LocalizationResolver
    },
    loadChildren: './features/location-update/location-update.module#LocationUpdateModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Location Update',
      pathIcon: 'icon-Locations',
    }
  },
  {
    path: 'loaddetails',
    loadChildren: './features/load-details/load-details.module#LoadDetailsModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Load Details',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'resourcecomments',
    loadChildren:
      './features/resource-comments/resource-comments.module#ResourceCommentsModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Resource Comments',
      pathIcon: 'icon-Clipboard_Check',
      order: 2
    }
  },
  {
    path: 'switch',
    loadChildren:
      './features/switch/switch.module#SwitchModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Switch',
      pathIcon: 'icon-Device_Laptop',
      order: 2
    }
  },
  {
    path: 'tracking',
    loadChildren: './features/tracking/tracking.module#TrackingModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Tracking Tasks',
      pathIcon: 'icon-Tracking',
      order: 2
    }
  },
  {
    path: 'loadtracking',
    loadChildren: './features/load-tracking/load-tracking.module#LoadTrackingModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Load Tracking',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'trackingdetails',
    loadChildren: './features/tracking-details/tracking-details.module#TrackingDetailsModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Tracking Details',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'sendReferences',
    loadChildren: './features/tracking-details/send-references/send-references.module#SendReferencesModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Send References',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'repositionTruck',
    loadChildren: './features/reposition-truck/reposition-truck.module#RepositionTruckModule',
    data: {
      createSidebarEntry: false,
      pathDisplayText: 'Reposition Truck',
      pathIcon: iconSearch,
      order: 2
    }
  },
  {
    path: 'searchplanninghistory',
    loadChildren: './features/search-load-planning-history/search-load-planning-history.module#SearchLoadPlanningHistoryModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Search Planning History',
      pathIcon: iconSearch,
      order: 2
    }
  },
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: '/dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [TranslateService, LocalizationResolver, RouteGuard, AuthGuard]
})
export class AppRoutingModule { }


